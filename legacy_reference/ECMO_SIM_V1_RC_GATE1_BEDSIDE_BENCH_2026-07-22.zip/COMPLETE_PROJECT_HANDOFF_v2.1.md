# ECMO SIMULATOR — COMPLETE PROJECT HANDOFF
## Canonical Handoff: v2.1 Position-State Architecture
**Prepared:** July 22, 2026  
**Project:** ECMO Clinical Simulation / Educator-Configured Scenario Engine  
**Canonical source package:** `ecmo-sim-position-state-v2.1`

---

# 1. Executive Summary

The project has pivoted from an attempted high-fidelity mathematical physiology simulator into a **clinically meaningful cause-and-effect training engine**.

The governing educational principle is:

> The simulator should teach the learner to recognize clinically important changes, choose appropriate assessments/interventions, see plausible consequences, and stabilize the patient—or allow deterioration to a clinically coherent endpoint. It does not need to calculate every physiologic variable with research-grade precision.

This is now the central architecture.

The project is **not a collection of hard-coded scenarios**. The intended architecture separates:

1. **Generic engine mechanics** — time, state, monitoring, circuit controls, studies, information delivery, endpoints.
2. **Reusable clinical knowledge** — complications, observations, action consequences, trajectories.
3. **Scenario configuration** — starting patient/support state, selected learning objectives, eligible complications, timing/orchestration, case-specific context.
4. **Learner cockpit** — monitor, ECMO console, controls, interventions, information/results.
5. **Educator workflow** — one standardized form used to generate cases without programming.
6. **Debrief/comparative analysis** — expected clinical pathway versus actual learner pathway and resulting patient outcome.

The current build proves this architecture in code and includes a playable **six-case Low-Flow Troubleshooting Pack**, with Low-Flow 03 specifically hardened around explicit patient-position state.

**Current verification:** 98/98 automated tests passing in the v2.1 source package.

**Important:** This is a strong architecture/prototype and bench-testing build. It is **not yet clinically validated for formal competency assessment**. Timing values, thresholds, consequence magnitudes, some protocol logic, and many knowledge-ready modules still require expert review and scenario-specific bench validation.

---

# 2. The Design Pivot That Governs Everything

## Earlier direction

The early engine attempted to model physiology numerically: exact relationships among drugs, vital signs, flow, pressures, gas exchange, and labs.

That approach creates two major problems:

- false precision: numbers may look authoritative even when coefficients are placeholders;
- enormous scope: every drug, disease, interaction, lab, and device relationship becomes a physiology-modeling problem.

## Current direction

The engine instead models **clinically significant state transitions**.

Example:

- If clinically significant bradycardia is present and epinephrine is an appropriate treatment, the simulator does not need to derive an exact heart rate from an exact receptor-level dose model.
- It needs to recognize that the treatment is appropriate, move the patient toward an appropriate clinical state, and make the monitor reflect that improvement.
- If the same action is ineffective in the active clinical context, it should produce little/no meaningful improvement.
- If it is dangerous in that context, it should produce a plausible adverse consequence.

This gives us:

`Clinical context + learner action + time + current state -> clinically plausible consequence`

rather than:

`thousands of mathematical variables -> attempted reproduction of a human being`

The numerical physiology layer remains useful for display coherence and certain relationships, but it is subordinate to the clinical-event/state system.

---

# 3. Non-Negotiable Architectural Rules

## 3.1 Do not hard-code scenarios

A scenario should not contain bespoke code such as:

`if scenario == low_flow_03 and learner presses restore_position then cure patient`

Instead:

- the scenario says what is true at the start;
- reusable complication knowledge defines how clinical states respond to actions/context;
- the engine evaluates the interaction.

## 3.2 Clinical effects belong to reusable knowledge

The same action may be:

- preferred,
- acceptable,
- temporizing,
- ineffective,
- harmful,
- critical-error

depending on active clinical context.

## 3.3 Only clinically meaningful changes matter

Do not spend development effort modeling noise that does not alter recognition or management.

Examples:

- HR 120 -> 125 after touching the patient: generally educationally irrelevant.
- ECMO flow 150 -> 40 mL/kg/min after a turn: highly significant and must be obvious.

## 3.4 The learner must receive enough context to reason

A learner should not be expected to guess hidden history.

If the clinically relevant event was a recent turn, handoff/recent-events information must make that fact available without revealing the diagnosis.

## 3.5 Learner-facing labels must not reveal the diagnosis

The cockpit should show observable facts and neutral actions, not hidden complication names or grading.

## 3.6 Actions must produce feedback

Every meaningful learner action should create an observable record:

- what was done;
- what happened;
- whether there was no meaningful change.

Never show repeated anonymous “No meaningful clinical change” entries without identifying the action.

## 3.7 The patient must evolve with time

Severe loss of support cannot leave a highly ECMO-dependent patient looking normal indefinitely.

The trajectory/consequence systems must create coherent deterioration, stabilization, recovery, arrest, or death.

## 3.8 Scenarios must end

Endpoint conditions include at minimum:

- stabilization / objective achieved;
- patient death / irreversible catastrophic endpoint;
- scenario-specific completion;
- educator-defined time/termination conditions where appropriate.

## 3.9 “Restore previous position” is not magic

Position is now explicit state.

The engine tracks:

- current position;
- previous documented position;
- available positions;
- position history.

A learner may directly select a favorable position. “Return to previous documented position” is only a convenience operation that selects the stored prior position.

## 3.10 Clinical validation and software validation are different

Passing automated tests proves code behavior, not clinical truth.

Every formal training module ultimately needs:

- technical tests;
- expert clinical review;
- bench play;
- timing/threshold tuning;
- learner usability review.

---

# 4. Current Project State

## 4.1 Core engine: BUILT / ACTIVE DEVELOPMENT

Canonical runtime:

`ecmo-sim/src/engines/circuit-sandbox.mjs`

Core session contract supports:

- create session;
- snapshot/save state;
- learner presentation;
- instructor presentation;
- submit actions;
- advance simulated time.

The engine integrates monitoring, circuit mechanics, clinical events, consequences, trajectories, triggers, runtime orchestration, information timing, observations, position state, rhythm, labs, and endpoints.

## 4.2 Clinical Event / Complication System: BUILT

File:

`ecmo-sim/src/core/clinical-events.mjs`

Supports reusable complications with:

- initial states;
- activation;
- action rules;
- context-change rules;
- outcome classes;
- state transitions;
- time rules;
- effects on internal/display state;
- resolution;
- scoring metadata;
- hidden learner-facing diagnoses.

This is one of the most important architectural layers.

## 4.3 Clinical Knowledge Registry: BUILT / EXPANDING

File:

`ecmo-sim/src/core/clinical-knowledge-registry.mjs`

Separates reusable:

- complications;
- actions;
- observations;
- learning objectives/concepts.

This prevents scenarios from owning medical logic.

## 4.4 Clinical Consequence System: BUILT

File:

`ecmo-sim/src/core/clinical-consequence.mjs`

Provides coherent patient consequences from clinically important support failure rather than requiring every variable to be manually scripted.

## 4.5 Clinical Significance Filter: BUILT

File:

`ecmo-sim/src/core/clinical-significance.mjs`

Purpose:

distinguish educationally meaningful changes from noise.

This supports the project doctrine that not every tiny numerical movement deserves learner attention.

## 4.6 Clinical Trajectory / Endpoints: BUILT FOUNDATION

File:

`ecmo-sim/src/core/clinical-trajectory.mjs`

Tracks clinically meaningful dimensions and allows progression toward:

- deterioration;
- critical instability;
- arrest/death;
- stabilization/resolution.

This must continue to be expanded and clinically tuned.

## 4.7 Trigger Eligibility: BUILT

File:

`ecmo-sim/src/core/trigger-eligibility.mjs`

Allows complications to become eligible from generic policies rather than hard-coded scenario scripts.

Trigger concepts include:

- at-start;
- elapsed time;
- context;
- action-count/learner behavior.

## 4.8 Runtime Director: BUILT FOUNDATION

File:

`ecmo-sim/src/core/scenario-runtime-director.mjs`

Separates:

**what can happen medically**

from

**when/how complications are introduced into a scenario**.

This is critical for eventually allowing educator-selected objectives plus emergent complications caused by learner decisions.

## 4.9 Educator Scenario Builder: BUILT FOUNDATION

File:

`ecmo-sim/src/core/scenario-builder.mjs`

The intended final educator experience is a standardized form with dropdowns rather than code.

Current setup categories include concepts such as:

- patient/population;
- diagnosis/procedure;
- ECMO mode/cannulation;
- baseline support;
- starting condition;
- learning objective;
- selected concepts;
- difficulty/mode.

This needs a polished production UI and broader validation.

## 4.10 Information / Study Pipeline: BUILT FOUNDATION

Files include:

- `information-pipeline.mjs`
- `lab-queue.mjs`
- `observation-resolver.mjs`

Important design rule:

Turnaround times are placeholders until deliberately chosen.

Studies may have separate stages.

Example radiograph workflow:

`ordered -> bedside availability -> acquisition -> image immediately viewable -> formal interpretation later`

A bedside study may also be delayed by clinical context—for example, the learner may need to defer a nonessential portable X-ray while actively coding the patient.

## 4.11 Learner Disclosure: BUILT FOUNDATION

File:

`learner-disclosure.mjs`

Protects hidden diagnosis/grading from learner presentation while allowing observable consequences and results.

## 4.12 Rhythm Engine: BUILT FOUNDATION / NEEDS EXPANSION

File:

`rhythm.mjs`

Current rhythm trajectory includes escalation concepts such as:

sinus -> junctional -> ventricular tachycardia -> ventricular fibrillation

Existing thresholds remain partly placeholder/architecture-level.

Recovery interventions such as a complete ACLS/PALS rhythm-management action set are not yet fully implemented.

## 4.13 Patient Position State Engine: BUILT v2.1

File:

`patient-position.mjs`

This fixes a major conceptual bug discovered during bench testing.

Position is now generic state, not a medical cure button.

The scenario may map actual positions to case-specific effect classes:

- favorable;
- partial;
- adverse;
- neutral.

Reusable clinical knowledge determines what those classes mean for the active complication.

This prevents globally hard-coding claims such as “right side is always bad.”

---

# 5. Current Playable Troubleshooting Pack

Six Low-Flow Troubleshooting scenarios exist:

1. Preload loss / hypovolemia
2. Postoperative tamponade
3. Position-sensitive cannula drainage compromise
4. Drainage cannula / tubing kink
5. Mechanical circuit obstruction
6. Pump failure / loss of pump support

Learner-facing scenario names remain neutral.

A deterministic blind-selection mode also exists.

## Low-Flow 03 current acceptance case

This is the most recently bench-tested/hardened case.

Known handoff context:

- neonatal postoperative central VA ECMO;
- prior flow approximately 145–155 mL/kg/min;
- recent routine bedside turn;
- substantial flow reduction after repositioning;
- learner assumes care after the change.

Current case-specific position map:

- previous documented: Supine / Midline
- current: Right Tilt
- Supine / Midline -> favorable
- Left Tilt -> partial improvement
- Right Tilt -> adverse
- Head/Neck Adjusted -> neutral

These mappings are scenario configuration, not universal physiology.

The learner can therefore reason from history, try actual positions, and see graded consequences.

---

# 6. What Bench Testing Has Already Taught Us

Several important defects were found through actual phone/browser play rather than unit tests.

## Defect: scenario appeared to do nothing

Initial builds could run for two minutes with severe reduced ECMO flow and little meaningful patient deterioration.

**Lesson:** engine correctness is not enough. Support dependency must drive clinically coherent downstream consequences.

## Defect: anonymous no-change feedback

Repeated messages said only:

“No meaningful clinical change is observed.”

**Fix direction implemented:** action identity must be displayed with the consequence.

## Defect: ECG placeholder never became a useful waveform

A standalone bench build now renders an ECG waveform, but the final production monitor still requires dedicated UI/clinical validation across rhythms.

## Defect: learner lacked recent-event context

The learner could be expected to “restore prior position” without being told a turn had recently occurred.

**Fix:** structured handoff and recent-event history.

## Defect: generic turn versus restore-position magic button

“Turn/reposition patient” did not fix the problem, while “restore prior position” did.

**Fix v2.1:** explicit position state. The learner chooses a real position. Restore-previous uses the same state mechanism.

## Key development lesson

Automated tests must be paired with **bench acceptance scripts that simulate what a learner actually sees and does**.

---

# 7. Current Clinical Module Coverage

The project currently distinguishes roughly three maturity levels.

## Bench-ready / bench-partial low-flow modules

- hypovolemia / preload loss — bench-partial
- postoperative tamponade — bench-ready
- position-sensitive cannula drainage — bench-ready, recently revised
- drainage cannula/tubing kink — bench-ready
- mechanical circuit obstruction — bench-ready
- pump support failure — bench-ready

## Knowledge-ready modules

Reusable registry logic exists for a much broader set, including:

- air emergency;
- circuit breach/hemorrhage;
- oxygenator thrombosis/failure;
- sweep-gas failure;
- hemolysis;
- major bleeding;
- intracranial hemorrhage;
- thromboembolism/stroke;
- circuit/systemic thrombosis;
- anticoagulation management;
- VV recirculation;
- VA differential hypoxemia;
- VA LV distension;
- limb ischemia;
- pneumothorax/intrathoracic pressure;
- airway/ventilator failure;
- pulmonary hemorrhage;
- gas-exchange failure;
- arrhythmia/arrest;
- vasoplegia/shock;
- infection/sepsis;
- AKI/fluid overload;
- CKRT/ECMO interaction;
- metabolic/electrolyte emergency;
- neurologic deterioration;
- abdominal ischemic/compartment processes;
- pulmonary hypertensive crisis;
- congenital-circulation-specific problems;
- treatment/transfusion adverse events;
- transport/procedural/operational events.

“Knowledge-ready” does **not** mean ready for formal training. These modules still need dedicated visual cues, action pathways, timing, trajectories, scenario integration, and clinical bench validation.

The full inventory is retained in:

`MASTER_COMPLICATION_INVENTORY.md`

and the summarized implementation mapping in:

`CLINICAL_MODULE_COVERAGE.md`

---

# 8. Full Planned Product Architecture

The target product should have five major layers.

## Layer A — Educator Setup

One consistent form.

Educator selects/configures:

- patient population;
- age/weight;
- diagnosis/procedure;
- ECMO mode;
- cannulation/configuration;
- baseline support;
- starting hemodynamics/oxygenation;
- relevant labs/history;
- learning objectives;
- complications to teach;
- optional emergent complication pool;
- difficulty;
- guidance level;
- scenario duration/end conditions;
- timing profile.

The educator should not need to write code.

## Layer B — Scenario Compiler

The builder converts the form into a canonical scenario.

It resolves:

- objectives -> concepts;
- concepts -> relevant complication/action/observation knowledge;
- starting active conditions;
- eligible complications;
- trigger policies;
- runtime-director rules;
- patient support dependency;
- information/study timing;
- learner-safe briefing.

## Layer C — Learner Cockpit

The educator presses Enter/Launch.

The interface switches to learner mode.

Before Start:

- handoff;
- known history;
- recent events;
- baseline information.

At Start:

- scenario clock begins;
- ECG/monitor becomes live;
- ECMO console becomes active;
- controls/actions become available;
- information/results stream begins.

The learner sees only information reasonably available clinically.

## Layer D — Runtime Clinical Engine

During play:

`Current state + learner action + elapsed time + active complications + support dependency + trigger conditions`

produce:

`observable consequence + updated state + possible new complication + trajectory progression`

The runtime director may introduce eligible complications based on:

- educator plan;
- elapsed time;
- current context;
- learner actions;
- accumulated failures;
- emergent consequences.

## Layer E — Debrief / Comparative Analysis

At scenario end, produce a timeline and comparison:

### Expected pathway

What an ideal learner would reasonably have:

- recognized;
- assessed;
- prioritized;
- treated;
- reassessed.

### Actual pathway

What the learner actually:

- observed;
- ordered;
- changed;
- delayed;
- treated;
- worsened;
- corrected.

### Comparative analysis

Identify:

- correct actions;
- unnecessary actions;
- harmful actions;
- missed clues;
- delays;
- sequencing problems;
- successful recovery;
- preventable deterioration;
- complications caused or worsened by learner choices.

The debrief should explain **why the actual path produced the actual outcome**, not merely give a numerical score.

---

# 9. Full Development Trajectory

## PHASE 0 — Architecture Pivot
**Status: COMPLETE**

- abandon exhaustive true-physiology goal;
- adopt clinically meaningful cause/effect;
- establish reusable complication/action knowledge;
- prohibit scenario-specific medical logic.

## PHASE 1 — Clinical Spine
**Status: SUBSTANTIALLY COMPLETE FOUNDATION**

- clinical event system;
- outcome classes;
- consequence system;
- significance filtering;
- trajectories/endpoints;
- trigger eligibility;
- learner disclosure;
- runtime director;
- information pipeline;
- scenario builder.

## PHASE 2 — Low-Flow Vertical Slice
**Status: PLAYABLE / BENCH HARDENING**

- six low-flow cases;
- blind mode;
- learner handoff;
- meaningful deterioration;
- action-specific feedback;
- ECG display in standalone;
- explicit position state.

**Immediate remaining work:**
- bench-test all six cases end-to-end;
- correct clinical disconnects;
- validate that correct alternatives work when appropriate;
- ensure wrong actions have plausible outcomes;
- tune deterioration speed and support dependency;
- ensure all cases reach stabilization/death appropriately.

## PHASE 3 — Convert Knowledge-Ready Modules into Bench-Ready Modules
**Status: NEXT MAJOR BUILD**

Recommended order by clinical/educational value:

1. air/circuit emergency;
2. oxygenator and sweep-gas failure;
3. major bleeding/hemorrhage;
4. thrombosis/hemolysis;
5. VV recirculation;
6. VA differential hypoxemia;
7. LV distension;
8. pneumothorax/airway/ventilator failure;
9. neurologic emergency;
10. anticoagulation/titration;
11. renal/CKRT/metabolic;
12. infection/sepsis;
13. transport/procedural events;
14. congenital-circulation-specific modules.

Each module should pass the same pipeline:

`knowledge definition -> observable cues -> actions -> consequences -> time trajectory -> endpoint interaction -> automated tests -> bench scenario -> clinical review`

## PHASE 4 — Educator Form v1
**Status: FOUNDATION EXISTS; PRODUCTION UI NOT COMPLETE**

Build the standardized form and dropdown catalogs.

Requirements:

- same form every time;
- context-sensitive fields;
- objective selection;
- optional targeted complication selection;
- optional emergent complication pool;
- difficulty/orchestration settings;
- preview of learner-safe briefing;
- launch directly into cockpit.

## PHASE 5 — Study / Results Timing Calibration
**Status: MECHANICS BUILT; TIMES PLACEHOLDERS**

Create deliberate turnaround profiles for:

- ABG;
- CBC/coagulation/chemistry;
- DTT/anticoagulation studies;
- portable X-ray;
- echocardiography;
- CT/imaging;
- other bedside studies.

Separate:

- order delay;
- availability;
- acquisition;
- raw result visibility;
- formal interpretation.

Allow clinical conditions to delay nonessential acquisition.

## PHASE 6 — Learner Cockpit Production UI
**Status: PROTOTYPE/STANDALONE EXISTS**

Retain the established visual concept:

- patient monitor;
- ECG waveform;
- ECMO console;
- sliders/dials;
- intervention buttons;
- information/results feed.

Improve:

- responsive mobile/desktop layout;
- waveform realism;
- alarm behavior;
- ECMO pressure/flow displays;
- grouped action menus/tabs to reduce button overload;
- study ordering/results interface;
- medication/procedure workflows;
- patient-position control;
- accessibility.

Do not expose scenario labels that reveal diagnoses.

## PHASE 7 — Emergent Complication Graph
**Status: ARCHITECTURAL FOUNDATION EXISTS**

Allow learner choices to create downstream problems.

Examples conceptually:

- untreated low flow -> hypoperfusion -> lactate/organ injury -> arrest;
- excessive drainage stress -> hemolysis;
- delayed hemorrhage control -> preload collapse;
- poor anticoagulation decisions -> bleeding or thrombosis risk;
- procedural/transport choices -> mechanical complications.

Avoid deterministic “gotcha” scripting. Use clinically justified state/context relationships.

## PHASE 8 — Medication / Procedure Action Library
**Status: PARTIAL**

Build reusable actions around clinical intent, not exhaustive pharmacokinetics.

For each action define:

- indications/context;
- expected meaningful effect;
- ineffective contexts;
- harmful contexts;
- timing;
- observable response;
- reassessment expectations.

Include rhythm rescue, vasoactive management, fluids/blood, anticoagulation, ventilation/gas adjustments, ECMO emergency procedures, and other high-value actions.

## PHASE 9 — Endpoint and Recovery Hardening
**Status: FOUNDATION BUILT**

Create robust cumulative/catastrophic pathways to:

- stabilization;
- partial stabilization;
- refractory deterioration;
- arrest;
- death;
- irreversible neurologic/catastrophic outcome where appropriate.

No single arbitrary number should cause death unless clinically justified. Prefer cumulative state and duration.

## PHASE 10 — Debrief / Comparative Analysis Engine
**Status: PLANNED / CRITICAL**

Record every clinically relevant decision and state transition.

Generate:

- ideal/expected path;
- actual path;
- timing comparison;
- missed opportunities;
- harmful deviations;
- rescue actions;
- final outcome explanation.

This should become one of the defining features of the simulator.

## PHASE 11 — Clinical Validation Framework
**Status: REQUIRED BEFORE FORMAL USE**

For every module/scenario:

1. code tests;
2. clinical SME review;
3. bench play by ECMO-experienced clinician;
4. novice/learner usability test;
5. timing calibration;
6. edge-case/adversarial testing;
7. versioned sign-off.

Create a validation record per module.

## PHASE 12 — Content Scale-Up
**Status: FUTURE**

Once the engine and educator form are stable, create scenario libraries by:

- neonatal ECMO;
- pediatric ECMO;
- adult ECMO;
- VA;
- VV;
- ECPR;
- postcardiotomy;
- respiratory failure;
- transport;
- anticoagulation;
- CKRT interactions;
- emergencies.

Because medical logic is reusable, these should mostly be configurations—not new engines.

## PHASE 13 — Release / Deployment
**Status: FUTURE**

Target:

- installable/offline-friendly web application;
- educator mode;
- learner mode;
- scenario library;
- saved sessions;
- exportable debrief reports;
- versioned clinical knowledge;
- auditability of validated content.

---

# 10. Recommended Immediate Next Steps

Do **not** jump directly into dozens of new scenarios.

The strongest next sequence is:

1. Bench-test all six Low-Flow cases using a written acceptance checklist.
2. Fix every disconnect at the reusable engine/knowledge level.
3. Establish a formal “bench-ready module” definition.
4. Promote the next high-value complication family—air/circuit emergency—through that full process.
5. In parallel, begin the production educator form schema, but do not let UI work outrun the clinical engine.
6. Build the debrief event-log schema early, even before the polished debrief UI, so future scenarios automatically collect the data needed for comparison.

The major risk now is **breadth before validation**. The architecture already contains many knowledge-ready complications. Adding more definitions is less valuable than proving that each one behaves convincingly from the learner’s perspective.

---

# 11. Technical File Map

## Root documentation/data

- `HANDOFF.md` — prior cumulative technical/project handoff; includes v2.1 position-state notes.
- `COMPLETE_PROJECT_HANDOFF_v2.1.md` — this document; canonical high-level handoff.
- `MASTER_COMPLICATION_INVENTORY.md` — broad clinical complication inventory and maturity planning.
- `CLINICAL_COMPLICATION_MODULE_TAXONOMY.md` / `.json` — grouped module taxonomy.
- `CLINICAL_MODULE_COVERAGE.md` / `.json` — taxonomy-to-registry implementation/status mapping.
- `MODULE_VALIDATION_ROADMAP.md` — validation/build roadmap.
- `LOW_FLOW_TROUBLESHOOTING_PACK.md` — six-case playable pack description.

## Prototype/visual files

- `standalone-v2.1/index.html` — latest self-contained phone/browser bench build.
- `standalone-fixed/index.html` — prior standalone build retained for history/comparison.
- `ecmo-sandbox.jsx` — earlier visual sandbox/prototype.
- `ecmo-educator-workflow.jsx` — educator workflow prototype.
- `ecmo-low-flow-troubleshooting-pack.jsx` — low-flow launcher prototype.

## Canonical engine

`ecmo-sim/`

### Engines

- `src/engines/circuit-sandbox.mjs` — primary integrated runtime.
- `src/engines/contract.mjs` — engine/session contract.
- `src/engines/evidence-review.mjs` — generic scored evidence/decision checkpoint engine.

### Core

- `clinical-events.mjs` — reusable complication/event state and action/context rules.
- `clinical-knowledge-registry.mjs` — reusable clinical knowledge catalog.
- `clinical-module-scenario-library.mjs` — module scenario composition.
- `clinical-consequence.mjs` — downstream clinical consequence logic.
- `clinical-significance.mjs` — meaningful-change filtering.
- `clinical-trajectory.mjs` — deterioration/stabilization/endpoints.
- `emergent-eligibility.mjs` — emergent event eligibility.
- `trigger-eligibility.mjs` — generic trigger policies.
- `scenario-runtime-director.mjs` — runtime complication orchestration.
- `scenario-builder.mjs` — educator setup -> canonical scenario.
- `information-pipeline.mjs` — study/result timing and delivery.
- `lab-queue.mjs` — laboratory order/result mechanics.
- `observation-resolver.mjs` — observation resolution.
- `learner-disclosure.mjs` — learner-safe information boundary.
- `patient-position.mjs` — explicit current/previous position state.
- `physiology.mjs` — simplified monitored/circuit/latent coherence layer.
- `rhythm.mjs` — rhythm progression foundation.
- `titration-lookup.mjs` — protocol-based titration checkpoint logic.
- `troubleshooting-scenario-library.mjs` — six low-flow troubleshooting presets.

### Data

Contains scenario/reference/protocol data used by the engine. Preserve these files with the source.

### Tests

The `test/` directory is part of the product, not disposable scaffolding.

Current canonical v2.1 suite:

**98/98 passing**

It covers engine mechanics, clinical events, significance, trajectories, triggers, runtime director, scenario workflow, module coverage, low-flow cases, position state, information timing, titration, rhythm, and related behavior.

---

# 12. Canonical Build / How to Run

## Easiest bench test

Use:

`standalone-v2.1/index.html`

Open it in a modern browser after extracting the package.

For the most recently hardened behavior, run:

`Low-Flow Troubleshooting 03`

## Source tests

From the `ecmo-sim` directory with Node installed:

`node --test`

Expected canonical result at handoff:

`98 tests / 98 pass / 0 fail`

---

# 13. Known Limitations / Unresolved Questions

- Clinical timing values remain partly placeholders.
- Many thresholds and consequence magnitudes need expert validation.
- Some original physiology coefficients remain placeholders and should never be mistaken for validated physiologic equations.
- The production learner UI is not finished.
- The production educator form is not finished.
- Full medication/procedure libraries are incomplete.
- Rhythm rescue pathways are incomplete.
- Many modules are knowledge-ready but not bench-ready.
- Full debrief comparative analysis is not yet implemented.
- Formal clinical validation/sign-off framework is not yet implemented.
- Multi-complication interaction needs much more adversarial testing.
- Save/session/reporting/deployment workflow needs productization.
- Standalone builds are bench artifacts; canonical logic should remain in modular source, then be bundled into the UI.
- Documentation inherited from earlier versions may contain stale status statements (for example older README text describing fewer tests or no wired UI). This complete handoff supersedes those status statements while retaining them as project history.

---

# 14. Definition of Success

The finished simulator should allow an educator to configure a clinically meaningful case in minutes without programming.

A learner should then be able to:

- receive a realistic handoff;
- start the clock;
- observe a live monitor and ECMO circuit;
- assess the patient/circuit;
- order studies;
- perform interventions;
- make mistakes;
- cause or worsen complications when clinically plausible;
- recognize deterioration;
- rescue the patient—or fail to;
- reach a meaningful endpoint.

At the end, the simulator should explain:

> Here is what was happening, here is what an ideal clinical path would have looked like, here is what you actually did, here is how those decisions changed the patient’s course, and here is what to learn from the difference.

That—not mathematical imitation of every physiologic variable—is the project’s north star.

---

# 15. Canonical Continuation Rule

Future development should preserve this hierarchy:

**Clinical educational objective**
-> **reusable clinical knowledge**
-> **generic state/action/consequence engine**
-> **scenario configuration**
-> **learner-safe presentation**
-> **bench validation**
-> **clinical validation**

If a proposed feature requires scenario-specific code to make one case work, first ask whether the missing concept should instead become:

- generic state,
- reusable clinical knowledge,
- a trigger policy,
- an observation,
- a consequence relationship,
- or scenario configuration.

Only scenario-specific facts belong in scenarios.

---

# 16. Handoff Status

This package is intended to be sufficient for a new development thread to continue without relying on chat history.

**Canonical continuation point:** v2.1 explicit patient-position state, six-case Low-Flow Troubleshooting vertical slice, 98/98 tests passing.

**Recommended next action:** create and execute a formal six-case low-flow bench acceptance matrix before expanding the next complication family.
