# B6 EXACT COMPARISON CLOSURE
Date: 2026-07-22

Six patient-emergency primitives reviewed.
Arrhythmia/arrest uses current AHA rhythm-specific resuscitation context plus ELSO ECPR context.
Sepsis/vasoplegia uses current 2026 Surviving Sepsis Campaign where ELSO is not sufficiently specific.
AKI/fluid/electrolytes use ELSO renal/electrolyte guidance.
Pulmonary hypertensive/RV crisis remains partial pending stronger specialty corroboration.
No fixed medication doses, universal sepsis fluid volume, or unsupported deterioration timing was invented.
