# V1 FINAL SCENARIO-BY-SCENARIO ACCEPTANCE SWEEP
Date: 2026-07-22

## Result
PASS — 28 / 28 supported scenarios satisfy the common release acceptance contract.

## Inventory
- Low-flow troubleshooting: 6 / 6
- Circuit emergencies: 6 / 6
- VA ECMO: 4 / 4
- VV ECMO: 5 / 5
- Patient emergencies: 7 / 7

## Acceptance contract checked for every scenario
- canonical scenario builds successfully;
- prebrief lifecycle is present before start;
- learner receives startup context/handoff;
- rhythm state is populated;
- learner has an actionable intervention set;
- learner-facing startup content does not expose educator-only hidden complication/grading/pathway fields;
- scenario transitions to active runtime;
- monitored HR, MAP, SpO2 and ECMO RPM/flow are finite/populated after start;
- simulation clock advances.

## Finding
The first harness run exposed an identifier-contract nuance: low-flow runtime scenario IDs are intentionally namespaced (`troubleshooting-<templateId>`) rather than equal to the template ID. This was a test-harness assumption, not a simulator defect. Acceptance was corrected to verify canonical suffix mapping rather than flattening the runtime namespace.

## Regression
437 / 437 automated tests passing.

## Remaining gates
1. Target-device/browser visual confirmation of ECG and monitor rendering.
2. Final release hardening and packaging.
3. Expert clinical sign-off remains an external release gate; partial rules remain explicitly partial until approved.
