# M4 VA-01 DIFFERENTIAL HYPOXEMIA — PHYSIOLOGY PASS 2
Date: 2026-07-22

## Status
VA-01 now has discriminating site-specific oxygenation/mixing evidence rather than relying on a single generic PaO2 target.

## Implemented
- Right radial / upper-body oxygenation state.
- Lower-body/postductal oxygenation state.
- Initial differential pattern: upper body substantially hypoxemic while lower body remains strongly oxygenated.
- Assessment returns site-specific SpO2 and PaO2 evidence without naming North-South/Harlequin syndrome.
- Untreated progression worsens right-radial oxygenation while lower-body oxygenation remains relatively preserved.
- Cause-directed correction restores a matched upper/lower-body oxygenation pattern.
- Observation feedback is now allowed to provide rich dynamic evidence for selected assessment actions while preserving existing action-rule behavior elsewhere.

## Representative modeled evidence
Initial:
- right radial/upper-body SpO2 ~82%, PaO2 ~48 mmHg
- lower-body/postductal SpO2 ~98%, PaO2 ~180 mmHg

After unresolved progression:
- right radial/upper-body SpO2 ~75%, PaO2 ~38 mmHg
- lower body remains ~98% / ~175 mmHg

After effective correction:
- upper/lower oxygenation becomes acceptably matched.

These values are simulation placeholders pending later clinical validation/tuning; the architectural requirement is the site-specific differential and coherent direction of change.

## Regression
175 / 175 automated tests passing.

## Next gate
Wire the M4 VA scenario library and VA-01 actions/evidence into the standalone learner cockpit, then browser-accept VA-01 end to end before replicating the proven pattern to VA-02 through VA-04.
