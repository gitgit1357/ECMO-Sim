# NEXT EVIDENCE NEEDED — CLINICAL VALIDATION
Date: 2026-07-22

Feature development is frozen. The limiting resource is now authoritative clinical source content, not additional simulator architecture.

## Source priority
1. Current institution-specific ECMO policies/protocols.
2. Applicable full-text ELSO guidance for institutional gaps.
3. Explicit specialty guidance only where ELSO is insufficient for a cross-cutting rule.

## Queue
1. `complication:drainage-cannula-kink` — ELSO Guidelines General v1.4 — source content review pending
2. `complication:mechanical-circuit-obstruction` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
3. `complication:pump-support-failure` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
4. `complication:air-emergency` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
5. `complication:circuit-breach-hemorrhage` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
6. `complication:oxygenator-thrombosis-failure` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
7. `complication:sweep-gas-failure` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
8. `complication:hemolysis` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
9. `complication:major-bleeding` — ELSO Adult and Pediatric Anticoagulation Guidelines — source content review pending
10. `complication:intracranial-hemorrhage` — Neurological Monitoring and Management for Adult ECMO Patients — source content review pending
11. `complication:thromboembolism-stroke` — ELSO Guidelines General v1.4 — source content review pending
12. `complication:circuit-systemic-thrombosis` — ELSO Guidelines for Adult and Pediatric ECMO Circuits — source content review pending
13. `complication:anticoagulation-management` — ELSO Adult and Pediatric Anticoagulation Guidelines — source content review pending
14. `complication:vv-recirculation` — ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO — source content review pending
15. `complication:va-differential-hypoxemia` — ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients — source content review pending
16. `complication:va-lv-distension` — ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients — source content review pending
17. `complication:limb-ischemia` — ELSO Guidelines General v1.4 — source content review pending
18. `complication:pneumothorax-intrathoracic-pressure` — ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO — source content review pending
19. `complication:airway-ventilator-failure` — ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO — source content review pending
20. `complication:pulmonary-hemorrhage` — ELSO Guidelines General v1.4 — source content review pending
21. `complication:gas-exchange-failure` — ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO — source content review pending
22. `complication:arrhythmia-arrest` — ELSO Adult ECPR Interim Guideline Consensus Statement — source content review pending
23. `complication:vasoplegia-shock` — ELSO Guidelines General v1.4 — source content review pending
24. `complication:infection-sepsis` — ELSO Guidelines General v1.4 — source content review pending
25. `complication:aki-fluid-overload` — ELSO Guidelines for Fluid Overload, AKI, and Electrolyte Management — source content review pending
26. `complication:ckrt-ecmo-interaction` — ELSO Guidelines General v1.4 — source content review pending
27. `complication:metabolic-electrolyte-emergency` — ELSO Guidelines for Fluid Overload, AKI, and Electrolyte Management — source content review pending
28. `complication:neurologic-deterioration` — Neurological Monitoring and Management for Adult ECMO Patients — source content review pending
29. `complication:abdominal-ischemic-compartment` — ELSO Guidelines General v1.4 — source content review pending
30. `complication:pulmonary-hypertensive-crisis` — ELSO Guidelines General v1.4 — source content review pending
31. `complication:congenital-circulation-specific` — ELSO Guidelines General v1.4 — source content review pending
32. `complication:treatment-transfusion-adverse` — ELSO Guidelines General v1.4 — source content review pending
33. `complication:transport-procedural-operational` — ELSO Guidelines General v1.4 — source content review pending