# BATCH 6 — PATIENT EMERGENCIES RULE REVIEW
Date: 2026-07-22

Institutional protocols govern first; applicable ELSO guidance governs gaps. Patient emergencies may require non-ECMO specialty standards in addition to ELSO when ELSO is silent; such additions must be explicitly sourced rather than inferred.

### `complication:arrhythmia-arrest`
- Primary: **ELSO Adult ECPR Interim Guideline Consensus Statement**
- Domain: `adult-ecpr`
- Secondary: general
- Status: **preclinical; exact source comparison pending**

### `complication:vasoplegia-shock`
- Primary: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: none
- Status: **preclinical; exact source comparison pending**

### `complication:infection-sepsis`
- Primary: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: none
- Status: **preclinical; exact source comparison pending**

### `complication:aki-fluid-overload`
- Primary: **ELSO Guidelines for Fluid Overload, Acute Kidney Injury, and Electrolyte Management**
- Domain: `aki-fluid-electrolytes`
- Secondary: general
- Status: **preclinical; exact source comparison pending**

### `complication:metabolic-electrolyte-emergency`
- Primary: **ELSO Guidelines for Fluid Overload, Acute Kidney Injury, and Electrolyte Management**
- Domain: `aki-fluid-electrolytes`
- Secondary: general
- Status: **preclinical; exact source comparison pending**

### `complication:pulmonary-hypertensive-crisis`
- Primary: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: none
- Status: **preclinical; exact source comparison pending**
