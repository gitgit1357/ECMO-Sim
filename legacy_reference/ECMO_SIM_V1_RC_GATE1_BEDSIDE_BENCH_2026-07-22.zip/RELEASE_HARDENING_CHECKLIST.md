# RELEASE HARDENING CHECKLIST
Date: 2026-07-22

## Required before distributing a preclinical RC
- [x] V1 feature freeze documented.
- [x] Current standalone build identified.
- [x] Full automated regression passes.
- [x] Clinical status clearly marked preclinical / validation-in-progress.
- [x] Competency-ready claim explicitly prohibited.
- [x] Validation hierarchy documented: institution first, ELSO default for gaps.
- [x] 33/33 clinical rules covered by validation evidence ledgers.
- [x] Frozen pre-validation clinical baseline captured.
- [x] Critical package files hashed with SHA-256.
- [x] Evidence ingestion workflow present.
- [x] Source-vs-simulator comparison gates present.
- [x] Clinical change authorization requires traceable evidence.
- [ ] Institution-specific protocols ingested.
- [ ] Exact ELSO rule text extracted where institution is silent.
- [ ] Clinical changes reviewed and approved.
- [ ] Expert review complete.
- [ ] All clinically validated rules regression-verified.
- [ ] Competency-ready designation approved.

## Distribution label
This build may be described as:
**ECMO Simulator V1 — Feature Complete, Preclinical Release Candidate**

It may NOT be described as:
- clinically validated,
- competency ready,
- institutionally certified,
- ELSO certified.
