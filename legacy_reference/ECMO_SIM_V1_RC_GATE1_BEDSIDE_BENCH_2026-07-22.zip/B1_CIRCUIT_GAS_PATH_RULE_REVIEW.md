# BATCH 1 — CIRCUIT & GAS-PATH RULE-LEVEL REVIEW
Date: 2026-07-22

## Governing default
No institutional circuit protocol has yet been ingested, so the applicable ELSO circuit guideline is the governing default. The official ELSO guideline index lists **ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits**, last updated **February 2022**.

## Validation discipline
Source identity and domain applicability are verified. Exact simulator timings, thresholds, and action classifications are **not** promoted to ELSO-validated until compared against the actual applicable source text. Existing behavior is held rather than guessed.

### `air-emergency`
- Current explicit deterioration intervals detected: none
- Current action classifications detected: 0
- Source-level disposition: **pending exact rule extraction; no numeric change authorized**

### `circuit-breach-hemorrhage`
- Current explicit deterioration intervals detected: none
- Current action classifications detected: 0
- Source-level disposition: **pending exact rule extraction; no numeric change authorized**

### `hemolysis`
- Current explicit deterioration intervals detected: none
- Current action classifications detected: 0
- Source-level disposition: **pending exact rule extraction; no numeric change authorized**

### `oxygenator-thrombosis-failure`
- Current explicit deterioration intervals detected: none
- Current action classifications detected: 0
- Source-level disposition: **pending exact rule extraction; no numeric change authorized**

### `sweep-gas-failure`
- Current explicit deterioration intervals detected: none
- Current action classifications detected: 0
- Source-level disposition: **pending exact rule extraction; no numeric change authorized**
