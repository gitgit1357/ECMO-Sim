# CORE BUBBLE ALARM RESET CONTRACT
Date: 2026-07-22

Bubble detector alarm/interlock, alarm reset, and physical de-airing are separate states/actions.

1. Air reaching the return-limb detector alarms and stops pump flow.
2. The alarm can be reset/re-armed.
3. Reset does not remove residual air.
4. Residual air must be explicitly cleared/de-aired.
5. If RPM/flow is restored before residual air is cleared, air can reach the detector again and retrigger the alarm/interlock.
6. Explicit de-airing prevents that residual-air retrip.
