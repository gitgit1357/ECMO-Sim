# M4 VA ECMO — FOUNDATION PASS 1
Date: 2026-07-22

M4 has started under completion-first governance.

Implemented:
- Dedicated `va-ecmo-scenario-library.mjs`.
- Four locked V1 VA case families.
- Diagnosis-neutral handoff/recent-event/objective structure.
- VA-01 differential-hypoxemia proving path: assess upper/lower-body oxygenation -> recognize differential oxygenation -> cause-directed correction.
- Untreated VA-01 progression to worsened/critical states uses existing registry trajectory.
- M1-M3 remain frozen.

Regression: 173/173 passing.

Next gate:
Build VA-01 discriminating site-specific physiology/evidence (especially right-upper-body vs lower-body oxygenation/mixing), wire it into the learner cockpit, then browser-accept the proving case before replicating the pattern.
