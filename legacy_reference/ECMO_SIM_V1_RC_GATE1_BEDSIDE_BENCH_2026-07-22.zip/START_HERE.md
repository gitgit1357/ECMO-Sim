# START HERE — ECMO Simulator v2.1

This is the complete continuation package.

**Read `SESSION_ADDENDUM_2026-07-22.md` first if you're continuing from
after 2026-07-22** — it covers a round of bench-testing and bug-fixing
done on top of everything below, including a systemic bug (22 of 36
complications were silently inert) and three deeper architecture fixes.
Current verified state: 147/147 tests passing.

1. Read `COMPLETE_PROJECT_HANDOFF_v2.1.md` first.
2. Read `MASTER_COMPLICATION_INVENTORY.md` and `CLINICAL_MODULE_COVERAGE.md` for scope/status.
3. Use `standalone-v2.1/index.html` for the latest browser/phone bench build.
4. Use `ecmo-sim/` as the canonical modular source.
5. Run `node --test` inside `ecmo-sim/` to verify the canonical source. Handoff baseline: 98/98 passing (see the addendum for the current 147/147).
6. See `FILE_MANIFEST.md` for every included file.

Recommended continuation:
Bench-validate all six low-flow cases against a formal acceptance matrix before broadening the next complication family. (This was done in the addendum session — see there for what it found.)

Do not reintroduce scenario-specific medical logic. Preserve the separation among engine mechanics, reusable clinical knowledge, scenario configuration, learner presentation, and validation.

## COMPLETION-FIRST GOVERNANCE — ADOPTED JULY 22, 2026
Before starting new development, read `PROJECT_GOVERNANCE_COMPLETION_FIRST.md`.
It freezes the V1 milestone map, defines scope classifications and Definitions of Done, and establishes M2 — Low-Flow Vertical Slice as the current active milestone.
New nonessential ideas belong in `POST_V1_BACKLOG.md` until M12 V1 Feature Freeze.

## M2 Final Gate — Human UI Bench
M2 automated acceptance is complete (152/152 tests). Before M2 can be frozen, run `M2_FINAL_HUMAN_UI_BENCH.md` against `standalone-v2.2/index.html`. Do not begin M3 implementation until all six cases pass with no open DEFECT/BLOCKER.

## Milestone status update — 2026-07-22
- M2 Low-Flow Vertical Slice: **FROZEN**. See `M2_FREEZE_2026-07-22.md`.
- M3 Circuit Emergencies: **ACTIVE**. See `M3_CIRCUIT_EMERGENCIES_PLAN.md`.
- Current proving case: oxygenator thrombosis / membrane-lung failure.

## M3 Current Active Work
Oxygenator thrombosis/failure is the proving case. Engine physiology and discriminating evidence pass is complete (157/157 tests). Next gate: wire CE-03 into the learner cockpit/standalone path and perform browser acceptance before replicating the M3 pattern to the other five circuit emergencies.


## Current active build — M3 Cockpit Pass 3
Use `standalone-v2.3/index.html` for CE-03 oxygenator learner-cockpit acceptance. Regression status: 158/158 passing. M2 remains frozen.

## M3 CE-03 browser acceptance — PASS
CE-03 oxygenator thrombosis/membrane-lung failure has passed browser-driven vertical-slice acceptance. Use `standalone-v2.3/index.html`. The M3 pattern is now proven; next work is replication across CE-01, CE-02, CE-04, CE-05, and CE-06 without redesigning architecture. Regression: 158/158.

## M3 remaining cases — implementation complete
Use `standalone-v2.4/index.html` for six-case M3 acceptance. All six circuit-emergency families now have scenario context and definitive resolution paths. Regression: 165/165. Next gate: browser acceptance, then M3 freeze.

## M3 FROZEN — 2026-07-22
All six Circuit Emergency cases passed the M3 gate. Regression: 166/166. M3 may reopen only under the governance defect/blocker/clinical-correctness/downstream-incompatibility rule. Next active milestone: M4 — VA ECMO.

## M4 ACTIVE — VA ECMO Foundation Pass 1
Four V1 VA families are locked in `M4_VA_ECMO_PLAN.md`. VA-01 differential hypoxemia is the proving case. Regression: 173/173. Next: site-specific oxygenation/mixing evidence and cockpit vertical slice.

## M4 VA-01 Physiology Pass 2
VA-01 now models site-specific upper/lower-body oxygenation and progressive differential hypoxemia. Regression: 175/175. Next: standalone cockpit integration and browser acceptance.

## M4 VA-01 Cockpit Pass 3
Use `standalone-v2.5/index.html` for VA-01 browser acceptance. VA scenario library and site-specific differential-oxygenation actions are integrated. Regression: 176/176.

## M4 VA-01 proving case — ACCEPTED
VA-01 passed prompt and delayed-path acceptance in the current standalone build. Regression: 179/179. The VA pattern is proven; next work is replication to VA-02/03/04 without redesigning M4 architecture.

## M4 FROZEN — 2026-07-22
All four VA ECMO cases passed acceptance. Regression: 190/190. Active milestone is now M5 — VV ECMO.

## M5 FROZEN — 2026-07-22
Five VV presets representing four locked VV families passed acceptance. Regression: 207/207.

## M6 ACTIVE — Patient Emergencies
Six families locked in `M6_PATIENT_EMERGENCIES_PLAN.md`. PE-01 Arrhythmia/Arrest is the proving case.

## M6 FROZEN — 2026-07-22
All six Patient Emergency families passed the gate (seven presets). Regression: 229/229. Active milestone: M7 — Universal Scenario Lifecycle.

## M7 FROZEN — Universal Scenario Lifecycle
Cross-pack lifecycle validation passed. Regression: 236/236. Active milestone: M8 — Debrief System.

## M8 FROZEN — Debrief System
Structured expected-vs-actual decision analysis is implemented and learner-safe until endpoint. Regression: 240/240. Active milestone: M9 — Educator Scenario Creator.

## M9 FROZEN — Educator Scenario Creator
Supported scenario creation is wired into standalone-v3.0. Regression: 249/249. Active milestone: M10 — Validation Framework.

## M10 FROZEN — Validation Framework
Validation/version gating is implemented; all current cases remain explicitly preclinical pending clinical/timing validation. Regression: 253/253. Active milestone: M11 — Production Shell.

## V1 FEATURE FREEZE ACHIEVED — M12
The currently envisioned V1 feature trajectory is complete. Regression: 258/258. Current shell: `standalone-v3.1/index.html`. Do not reopen frozen architecture for polish. Active phase: refinement/validation/release hardening.

## Clinical validation authority hierarchy — LOCKED
Institution-specific ECMO protocols govern where available. ELSO guidance is fallback only for documented gaps. Unsupported rules remain unvalidated. See `CLINICAL_SOURCE_HIERARCHY_AND_CROSSWALK.md` and `clinical-source-registry.json`.

## ELSO DEFAULT CLARIFICATION — LOCKED
Where an applicable institutional protocol is absent, applicable ELSO standards/guidelines are the governing default. `ELSO_DEFAULT_RULE_DOMAIN_CROSSWALK.md` maps current complication families to governing ELSO domains. Rule-level numeric extraction/review remains required before a value is labeled clinically validated.
