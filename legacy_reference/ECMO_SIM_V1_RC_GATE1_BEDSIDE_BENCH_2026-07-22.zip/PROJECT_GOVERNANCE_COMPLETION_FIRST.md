# ECMO SIMULATOR — COMPLETION-FIRST GOVERNANCE CONTRACT
**Adopted:** July 22, 2026
**Status:** GOVERNING / NON-OPTIONAL until V1 Feature Freeze

## 1. Prime Directive
Complete the simulator as currently envisioned before substantial refinement, beautification, optimization, or scope expansion.

Development moves horizontally across the roadmap before moving vertically into polish. "Complete enough" means functional, architecturally sound, testable, clinically coherent at the intended abstraction level, and sufficient to support the next milestone. It does not mean final polish or formal clinical validation.

## 2. Scope Classification Gate
Every proposed change MUST be classified before implementation:
- BLOCKER — prevents a planned milestone from functioning or being tested.
- DEFECT — existing behavior is broken, misleading, clinically incoherent, unsafe for training logic, or violates a locked architecture rule.
- PLANNED SCOPE — explicitly required by the frozen V1 milestones below.
- POST-V1 — useful improvement, expansion, optimization, visual polish, or new capability not required for V1 feature completion.

Only BLOCKER, DEFECT, and PLANNED SCOPE work enters active development before V1 Feature Freeze. POST-V1 items are recorded in `POST_V1_BACKLOG.md` and deferred.

## 3. Non-Negotiable Guardrails
1. No unplanned feature expansion before V1 Feature Freeze.
2. Do not reopen a completed milestone because a better implementation is imaginable. Reopen only for a blocker, defect, clinical correctness issue, or downstream architectural incompatibility.
3. Every milestone has a Definition of Done. Once met, freeze it and advance.
4. Build breadth before depth. Do not overdevelop one complication family while planned domains remain absent.
5. Use one representative case to prove a new architectural capability, then reuse the proven architecture for the remaining planned cases.
6. No premature cosmetic polish. Fix usability blockers and misleading presentation now; defer aesthetic redesign, animations, advanced graphics, and cosmetic dashboards.
7. Clinical correctness is never cosmetic. Physiologically or clinically incoherent behavior is a DEFECT and may be fixed immediately.
8. No scenario-specific medical hacks. Reusable clinical behavior belongs in reusable knowledge/engine layers; scenarios configure truth and context.
9. Passing the Definition of Done means ADVANCE by default, not "keep improving."
10. The roadmap itself is controlled scope. New milestone-scale ideas go to POST-V1 unless required to complete an already-defined V1 milestone.
11. Preserve separation among engine mechanics, reusable clinical knowledge, scenario configuration, learner presentation, educator workflow, and validation/debrief.
12. Automated software tests establish coded behavior, not clinical truth. Formal competency claims require later clinical validation.

## 4. Frozen V1 Milestone Map

### M1 — Core Engine
**Status:** COMPLETE ENOUGH / FROZEN except blockers and defects.
**Done when:** Generic session/state, physiology display coherence, consequences, trajectories, triggers, information delivery, rhythm foundation, complication knowledge integration, endpoints foundation, and automated verification are operational.

### M2 — Low-Flow Vertical Slice
**Status:** ACTIVE.
**Required scope:** Six planned low-flow etiologies remain playable. Add the universal case lifecycle needed to turn the pack from an open-ended sandbox into a complete training slice.
**Definition of Done:**
- opening clinical handoff/recent-events context;
- learner objectives available without revealing diagnosis;
- active troubleshooting loop with action-specific feedback;
- explicit success/failure/completion state;
- basic learner debrief using existing logged data;
- all six low-flow cases pass technical tests and bench acceptance at the intended prototype level.
**Explicitly not required:** final UI polish, advanced analytics, final clinical timing validation, large numbers of variants.

### M3 — Circuit Emergencies
**Status:** QUEUED.
**Planned families:** air emergency; circuit breach/disconnection; oxygenator thrombosis/failure; sweep/gas-source failure; hemolysis; major bleeding.
**Definition of Done:** Each planned family is represented and playable through the generic architecture. One representative case (recommended: oxygenator thrombosis/failure) must first prove the domain end-to-end without bespoke scenario hacks.

### M4 — VA ECMO
**Status:** QUEUED.
**Planned families:** differential hypoxemia/Harlequin physiology; LV distension/inadequate unloading; limb ischemia; thrombosis.
**Definition of Done:** Each planned family is represented and playable with sufficient patient+circuit reasoning and appropriate information pathways.

### M5 — VV ECMO
**Status:** QUEUED.
**Planned families:** recirculation; oxygenator dysfunction; gas-exchange failure; pneumothorax/airway emergencies.
**Definition of Done:** Each planned family is represented and playable, supporting differential reasoning among patient, airway/ventilator, cannulation, circuit, and membrane lung causes.

### M6 — Patient Emergencies
**Status:** QUEUED.
**Planned families:** intracranial hemorrhage/stroke; arrhythmia/arrest; vasoplegia/sepsis; AKI/fluid overload; metabolic/electrolyte emergency; pulmonary hypertensive crisis.
**Definition of Done:** Each planned family is represented and playable. Rhythm/emergency intervention support is sufficient for the planned cases; do not expand into a universal critical-care simulator.

### M7 — Universal Scenario Lifecycle
**Status:** FOUNDATION BEGINS IN M2; COMPLETE HERE.
**Definition of Done:** A standardized start → handoff/objectives → active case → progression → resolution/failure → completion contract works across all supported domains without scenario-specific lifecycle code.

### M8 — Debrief System
**Status:** FOUNDATION EXISTS; UI/analysis incomplete.
**Definition of Done:** The learner can review an ordered action/timeline reconstruction, important evidence available at each stage, useful/ineffective/harmful actions, major delays/missed evidence, physiologic consequences, and final outcome. Basic educational explanation is required; sophisticated analytics are POST-V1.

### M9 — Educator Scenario Creator
**Status:** FOUNDATION/MOCKUP.
**Definition of Done:** An educator can assemble supported scenario configurations through a standardized interface without editing source code, using validated/available knowledge modules and scenario parameters.

### M10 — Validation Framework
**Status:** PARTIAL FOUNDATION.
**Definition of Done:** Every module can carry technical-test status, bench-test status, clinical-review status, timing/threshold-tuning status, learner-usability status, and version/validation status. The workflow exists even if not every module has reached formal competency-validation status.

### M11 — Production Shell
**Status:** FUTURE V1 SCOPE.
**Definition of Done:** Learner, educator, and minimal administration workflows are connected sufficiently for coherent end-to-end use. Build only the minimum shell needed for V1; enterprise features, elaborate dashboards, and institutional customization are POST-V1 unless required for basic operation.

### M12 — V1 FEATURE FREEZE
**Definition of Done:** All M1–M11 definitions of done are met; no planned subsystem is absent; canonical source, tests, documentation, handoff, and runnable build agree on the feature-complete state. At this gate, new feature work stops and structured refinement begins.

## 5. Post-Feature-Complete Refinement Order
Only after M12:
1. Clinical realism, timing, thresholds, and expert tuning.
2. Learner experience and instructional refinement.
3. UI/UX and visual polish.
4. Performance, accessibility, packaging, and deployment hardening.
5. Content expansion: additional cases, populations, variants, configurations, analytics, and optional features.
6. Release-candidate validation.

## 6. Active Completion Ledger
**CURRENT MILESTONE:** M2 — Low-Flow Vertical Slice

**ACTIVE WORK ONLY:**
- [IMPLEMENTED] opening clinical handoff/recent-events presentation;
- [IMPLEMENTED] learner objectives;
- [IMPLEMENTED] universal completion criteria and explicit case end state;
- [IMPLEMENTED] basic debrief presentation from existing log/action data;
- [ACTIVE GATE] six-case human bench acceptance after lifecycle integration.

**BLOCKERS:** None known at governance adoption.

**DO NOT EXPAND YET:** M3+ implementation except reusable architecture strictly required to complete M2.

**NEXT GATE:** M2 Definition of Done → freeze M2 → begin M3 Circuit Emergencies.

## 7. Decision Rule for Every Development Session
Before coding, answer in order:
1. What milestone are we currently completing?
2. Is the proposed work required by that milestone's Definition of Done?
3. If not, is it a blocker, defect, or clinical-correctness issue?
4. If no, record it in POST-V1 and continue the current milestone.
5. When the milestone Definition of Done passes, update the Completion Ledger, freeze the milestone, and advance.

This contract overrides informal urges to polish, broaden, or redesign before V1 Feature Freeze unless an explicit governance decision changes the frozen scope.
