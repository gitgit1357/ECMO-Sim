# CLINICAL VALIDATION BATCH PLAN
Date: 2026-07-22

Validation proceeds by clinical dependency, not by UI order. Institutional protocols supersede these ELSO defaults whenever applicable documents are ingested.

## B1 Circuit & gas-path emergencies
- `air-emergency`
- `circuit-breach-hemorrhage`
- `oxygenator-thrombosis-failure`
- `sweep-gas-failure`
- `hemolysis`

## B2 Low-flow / mechanical support

## B3 VV respiratory support
- `vv-recirculation`
- `gas-exchange-failure`
- `pneumothorax-intrathoracic-pressure`
- `airway-ventilator-failure`

## B4 VA/cardiac support
- `va-differential-hypoxemia`
- `va-lv-distension`

## B5 Bleeding / neurologic / anticoagulation
- `major-bleeding`
- `intracranial-hemorrhage`

## B6 Patient emergencies
- `arrhythmia-arrest`
- `vasoplegia-shock`
- `infection-sepsis`
- `aki-fluid-overload`
- `metabolic-electrolyte-emergency`
- `pulmonary-hypertensive-crisis`

## B7 General / remaining rules
- `abdominal-ischemic-compartment`
- `anticoagulation-management`
- `circuit-systemic-thrombosis`
- `ckrt-ecmo-interaction`
- `congenital-circulation-specific`
- `drainage-cannula-kink`
- `limb-ischemia`
- `mechanical-circuit-obstruction`
- `neurologic-deterioration`
- `pulmonary-hemorrhage`
- `pump-support-failure`
- `thromboembolism-stroke`
- `transport-procedural-operational`
- `treatment-transfusion-adverse`
