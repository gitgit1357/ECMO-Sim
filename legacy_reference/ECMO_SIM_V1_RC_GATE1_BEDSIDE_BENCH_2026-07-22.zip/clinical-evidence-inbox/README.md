# Clinical Evidence Inbox

Place authoritative clinical source documents or completed extraction JSON here.

Priority:
1. Current institution-specific ECMO protocols/policies.
2. Applicable ELSO full-text guidance for institutional gaps.
3. Specialty guidance only where ELSO does not adequately address a cross-cutting rule.

Do not treat filenames, abstracts, guideline indexes, or search snippets as sufficient evidence for exact numeric standards.

Use `CLINICAL_SOURCE_INGESTION_TEMPLATE.json` for structured extraction.
