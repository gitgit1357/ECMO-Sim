# CORE COCKPIT HARDENING STATUS
Date: 2026-07-22

PASS.

The universal ECMO cockpit contract has been hardened so that:
- bedside measurements refresh every simulation tick;
- RPM, flow target, sweep, FdO2, and clamp controls are not diagnosis-gated;
- clamp/unclamp behavior acts immediately;
- cockpit applicability is explicit through N/A rather than fabricated values;
- UI clearly separates continuous monitoring from immediate controls.

Full regression passes after hardening.
