# ECMO SIMULATOR V1 — CANONICAL HANDOFF
Date: 2026-07-22

## What this project is
A feature-complete ECMO simulation platform with reusable clinical primitives, scenario packs, educator workflow, structured debrief, validation governance, and a standalone browser build.

## Current release state
**Hardened Preclinical Release Candidate**

The V1 feature architecture is frozen. Clinical validation is in progress.

## Locked clinical authority hierarchy
1. Current institution-specific protocol/policy when applicable.
2. Applicable ELSO guidance as the governing default for institutional gaps.
3. Explicitly sourced specialty guidance only where ELSO is insufficient.
4. If no authoritative applicable source exists, the rule remains unvalidated.

## Completed
- M1–M12 V1 feature trajectory.
- Refinement Pass 1.
- 33/33 registry-level clinical rules mapped into validation evidence ledgers.
- B1–B7 validation preparation.
- Exact-comparison queue.
- Evidence ingestion and source-vs-simulator comparison pipeline.
- Anti-overclaim and clinical change-control gates.
- Frozen pre-validation clinical baseline.
- Release integrity hashing and representative scenario smoke tests.
- 328+ automated tests passing at this checkpoint.

## Not complete
- Institution-specific protocol ingestion.
- Exact rule-level ELSO extraction for institutional gaps.
- Evidence-supported clinical tuning across all rules.
- Expert clinical review/sign-off.
- Competency validation.

## Hard guardrails
Do not reopen V1 feature development during validation.
Do not add architecture merely to show progress.
Do not call a simulator constant an ELSO standard without exact source support.
Do not claim clinically validated, competency ready, institutionally certified, or ELSO certified until the corresponding gates are actually satisfied.

## Execution path from here
SOURCE INGESTION
→ RULE-LEVEL EXTRACTION
→ SOURCE/SIMULATOR COMPARISON
→ APPROVED TUNING
→ FULL REGRESSION
→ EXPERT REVIEW
→ RULE PROMOTION
→ CLINICAL VALIDATION RELEASE
→ COMPETENCY-READINESS WORK

## Primary runnable artifact
`standalone-v3.3/index.html`

## Primary source tree
`ecmo-sim/`

## Canonical status
`CANONICAL_PROJECT_STATUS.json`

This handoff supersedes older status summaries when they conflict with this checkpoint.
