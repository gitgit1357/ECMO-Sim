# BATCH 2 — LOW-FLOW / MECHANICAL SUPPORT RULE REVIEW
Date: 2026-07-22

## Governance
Institutional protocols govern when available. No applicable institutional source has yet been ingested; applicable ELSO general/circuit guidance therefore governs by default.

## Safety boundary
Low-flow troubleshooting is highly context dependent. Existing timing constants and intervention classifications are inventoried but are not called ELSO numeric standards without exact source support.

### `cannula-malposition`
- Governing ELSO domain: `circuits`
- Primary indexed source: **ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits**
- Current explicit timing values: none detected
- Current action classifications: 0
- Disposition: **preclinical; exact source comparison pending**

### `circuit-obstruction`
- Governing ELSO domain: `circuits`
- Primary indexed source: **ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits**
- Current explicit timing values: none detected
- Current action classifications: 0
- Disposition: **preclinical; exact source comparison pending**

### `hypovolemia-preload`
- Governing ELSO domain: `general`
- Primary indexed source: **ELSO Guidelines General v1.4**
- Current explicit timing values: none detected
- Current action classifications: 0
- Disposition: **preclinical; exact source comparison pending**

### `pump-failure`
- Governing ELSO domain: `circuits`
- Primary indexed source: **ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits**
- Current explicit timing values: none detected
- Current action classifications: 0
- Disposition: **preclinical; exact source comparison pending**

### `venous-drainage-insufficiency`
- Governing ELSO domain: `general`
- Primary indexed source: **ELSO Guidelines General v1.4**
- Current explicit timing values: none detected
- Current action classifications: 0
- Disposition: **preclinical; exact source comparison pending**
