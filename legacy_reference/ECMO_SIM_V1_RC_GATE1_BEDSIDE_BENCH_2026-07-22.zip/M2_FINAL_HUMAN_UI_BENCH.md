# M2 FINAL HUMAN UI BENCH — LOCKED ACCEPTANCE PROTOCOL
Date: 2026-07-22
Status: REQUIRED BEFORE M2 FREEZE

## Rule
This bench is judgment-based and cannot be replaced by automated tests. Only DEFECT or BLOCKER findings may trigger M2 code changes. Improvements that are merely desirable go to POST_V1_BACKLOG.

## Run target
Open `standalone-v2.2/index.html`.

## Test every Low-Flow case

### 1. Prebrief
- Clinically useful opening report/handoff appears before active play.
- Recent events are understandable without revealing the hidden diagnosis.
- Learner objectives are visible and diagnosis-neutral.
- Starting the case is obvious.

### 2. Active case
- ECG populates and remains visually coherent.
- Patient and circuit values are readable.
- Available actions fit the clinical context.
- Every intervention gives specific feedback stating what was done and what changed, or explicitly that no meaningful change occurred.
- Severe unresolved support loss does not leave the patient implausibly stable.
- Correct interventions produce coherent improvement.
- Incorrect or irrelevant interventions do not magically solve the case.

### 3. Completion
- Timely correct management can reach Patient Stabilized.
- Terminal deterioration produces an explicit failure endpoint where applicable.
- Controls lock after completion.
- No contradictory endpoint appears, such as Stabilized with VF/asystole.

### 4. Debrief
- Debrief appears after completion.
- Action history is understandable.
- The learner can identify actions, responses, and outcome.
- Hidden information is not disclosed prematurely during active play.

## Case-specific acceptance focus

### LF-01 — Hypovolemia / preload loss
PASS if preload-directed correction produces meaningful recovery and irrelevant actions do not.

### LF-02 — Postoperative tamponade
PASS if assessment/escalation/cause-directed management is distinguishable from simple volume depletion and the case does not reward a generic button-click cure.

### LF-03 — Position-sensitive drainage compromise
PASS if recent positioning is discoverable without revealing the answer; moving away from the problematic position and returning to a tolerated position behave coherently; feedback names the action actually performed.

### LF-04 — Drainage cannula/tubing kink
PASS if inspection/mechanical correction is the meaningful pathway and the UI clearly communicates inspection/correction results.

### LF-05 — Mechanical circuit obstruction
PASS if circuit findings and pressure/flow behavior support recognition and correction without diagnosis leakage.

### LF-06 — Pump failure/loss of support
PASS if prompt restoration can stabilize before arrest; delayed restoration after VF/asystole does not falsely declare stabilization; malignant rhythm requires rhythm rescue before success.

## Finding classification
Use exactly one:
- PASS
- DEFECT — planned behavior exists but is broken or clinically incorrect.
- BLOCKER — prevents M2 completion or makes a planned case unusable.
- POST-V1 — worthwhile improvement/polish not required for M2.

## Freeze rule
M2 may be marked FROZEN only when all six cases pass with no open DEFECT or BLOCKER.
