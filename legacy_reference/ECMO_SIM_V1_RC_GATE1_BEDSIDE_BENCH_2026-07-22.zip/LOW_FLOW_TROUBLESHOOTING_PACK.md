# Low-Flow Troubleshooting Pack

This interim playable pack is intended to provide useful troubleshooting scenarios while the larger clinical complication library is being developed.

## Included cases

- Low-Flow Troubleshooting 01 — educator target: preload loss / hypovolemia
- Low-Flow Troubleshooting 02 — educator target: postoperative tamponade
- Low-Flow Troubleshooting 03 — educator target: position-sensitive cannula drainage compromise
- Low-Flow Troubleshooting 04 — educator target: drainage cannula / tubing kink
- Low-Flow Troubleshooting 05 — educator target: mechanical circuit obstruction
- Low-Flow Troubleshooting 06 — educator target: pump failure / loss of pump support

Learner-facing labels intentionally do not reveal the target diagnosis.

## Blind mode

The educator may launch a seeded blind low-flow differential. The seed makes selection reproducible while the hidden cause remains inaccessible to the learner presentation.

## Visual launcher

`ecmo-low-flow-troubleshooting-pack.jsx`

The launcher uses the existing engine, registry, trajectory, disclosure, trigger, and endpoint systems. It does not contain its own copy of complication behavior.

## Important limitation

These scenarios are architecture/prototype training cases. Clinical thresholds, timing placeholders, and consequence magnitudes still require deliberate validation/tuning before formal clinical competency use.
