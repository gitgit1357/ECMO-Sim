# ECMO Simulator — Reusable Clinical Complication Module Taxonomy v1.1

The broad complication backlog is normalized into **36 reusable modules**. All 36 now have registry-backed clinical knowledge/state logic. This does **not** mean all 36 are clinically bench-validated: low-flow is the current bench-test pack; the others are knowledge-ready and require dedicated cue/timing/threshold validation.

| # | Module | Domain | Build status |
|---|---|---|---|
| 1 | Preload loss / hypovolemia / hemorrhagic volume loss | flow-support | built-partial |
| 2 | Cardiac tamponade / external cardiac compression | flow-support | built |
| 3 | Cannula malposition, migration, positional drainage compromise | cannula | built-partial |
| 4 | Cannula / external tubing kink or mechanical obstruction | cannula | built-partial |
| 5 | Circuit-path mechanical obstruction / kink / resistance | circuit | built |
| 6 | Pump failure / pump stop / loss of extracorporeal support | circuit | built |
| 7 | Air entrainment / bubble detection / air embolism risk | circuit | knowledge-ready |
| 8 | Circuit rupture / disconnection / catastrophic blood loss | circuit | knowledge-ready |
| 9 | Oxygenator thrombosis, rising resistance, membrane failure | oxygenator | knowledge-ready |
| 10 | Sweep gas / gas-source / blender failure | oxygenator | knowledge-ready |
| 11 | Clinically significant hemolysis / mechanical blood trauma | blood | knowledge-ready |
| 12 | Major bleeding / coagulopathic hemorrhage | bleeding | knowledge-ready |
| 13 | Intracranial hemorrhage | neurologic | knowledge-ready |
| 14 | Thromboembolism / ischemic stroke / systemic embolic event | thrombosis | knowledge-ready |
| 15 | Circuit, cannula, intracardiac, and aortic-root thrombosis | thrombosis | knowledge-ready |
| 16 | Anticoagulation under- or over-treatment / HIT / DIC context | anticoagulation | partial |
| 17 | VV ECMO recirculation / inadequate effective support | vv | knowledge-ready |
| 18 | VA differential hypoxemia / North-South syndrome | va | knowledge-ready |
| 19 | LV distension / inadequate unloading / pulmonary edema / root stasis | va | knowledge-ready |
| 20 | Peripheral cannulation limb ischemia / distal perfusion failure | vascular | knowledge-ready |
| 21 | Pneumothorax / tension physiology / high intrathoracic pressure affecting support | respiratory | knowledge-ready |
| 22 | Airway obstruction, ETT displacement, ventilator failure/disconnection | respiratory | knowledge-ready |
| 23 | Pulmonary hemorrhage | respiratory | knowledge-ready |
| 24 | Hypoxemia / hypercapnia / hypocapnia when clinically consequential | gas-exchange | knowledge-ready |
| 25 | Clinically significant arrhythmias / cardiovascular arrest | cardiac | partial |
| 26 | Vasoplegia / distributive or septic shock | hemodynamics | knowledge-ready |
| 27 | Infection / bloodstream infection / pneumonia / sepsis | infection | knowledge-ready |
| 28 | Acute kidney injury / oliguria / fluid overload | renal | knowledge-ready |
| 29 | CKRT/CRRT failure or clinically meaningful ECMO interaction | renal | knowledge-ready |
| 30 | Major metabolic / electrolyte emergency | metabolic | knowledge-ready |
| 31 | Seizure / hypoxic-ischemic injury / cerebral hypoperfusion / ICP crisis | neurologic | knowledge-ready |
| 32 | Abdominal compartment / bowel ischemia / hepatic shock injury | abdominal | knowledge-ready |
| 33 | Pulmonary hypertensive crisis / RV-pulmonary vascular emergency | cardiopulmonary | knowledge-ready |
| 34 | Congenital lesion / shunt / single-ventricle specific failure | congenital | knowledge-ready |
| 35 | Medication / transfusion / treatment-related clinically meaningful harm | treatment | knowledge-ready |
| 36 | Transport / positioning / procedure / diagnostic operational hazard | operations | partial |

See `CLINICAL_MODULE_COVERAGE.md` for bench-readiness details.
