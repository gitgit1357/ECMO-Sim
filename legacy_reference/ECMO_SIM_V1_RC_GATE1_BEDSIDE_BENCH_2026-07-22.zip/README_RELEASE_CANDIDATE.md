# ECMO SIMULATOR V1 — RELEASE CANDIDATE

## Canonical build
Open `standalone/index.html`.

`standalone/` is the release alias of the validated `standalone-v3.3/` build.
Older `standalone-v2.x` and `standalone-v3.0-v3.2` directories are retained only because the regression suite validates the project's migration/history chain. They are NOT release entry points.

## Status
- 28 / 28 supported scenarios passed final acceptance.
- Full regression passes.
- B1-B7 source-comparison sweep complete.
- Expert clinical sign-off remains pending.
- Target-device/browser visual confirmation of ECG/monitor rendering remains pending.
- Explicitly partial clinical rules remain partial.

Do not represent this package as a clinically signed-off production release until the two open release gates are closed.
