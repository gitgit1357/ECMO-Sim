# B4 EXACT COMPARISON CLOSURE
Date: 2026-07-22

Actual VA registry primitives reviewed: 3/3
- differential hypoxemia
- LV distension / inadequate unloading
- peripheral cannulation limb ischemia

Evidence-supported refinements:
- right-radial/proximal oxygenation monitoring explicitly governs differential-hypoxemia detection;
- native lung optimization and VAV-type escalation are represented as cause-directed options when upper-body hypoxemia persists;
- LV-unloading assessment explicitly uses pulse pressure/pulsatility, aortic-valve opening, LV/LA distension, stasis/smoke, filling pressures, and pulmonary edema;
- distal-limb monitoring explicitly includes clinical comparison, Doppler/flow, and NIRS where available;
- ELSO numeric references are stored as source evidence, not blindly converted into universal simulator thresholds.

Unchanged as placeholders:
- scenario deterioration timers;
- scenario-specific oxygenation numbers;
- internal severity labels.

All B4 rules remain pending expert clinical sign-off.

Next: B5 — Bleeding / Neurologic / Anticoagulation.

Regression: 361 / 361 passing.
