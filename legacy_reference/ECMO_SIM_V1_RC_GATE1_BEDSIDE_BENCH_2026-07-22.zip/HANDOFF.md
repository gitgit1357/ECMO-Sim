# HANDOFF — ECMO Circuit Sandbox / Simulation Test Platform

Written for whoever (or whatever AI) picks this up next, with no access to
prior conversation history. Read this file first, then `README.md` inside
`ecmo-sim/` for the engine internals.

## What this is

A training simulation platform for ECMO (extracorporeal membrane
oxygenation), built for a pediatric ECMO specialist's own team. Two
requirements set the whole architecture:

1. **Structured like the NBRC RRT Clinical Simulation Exam** — a hybrid of
   branching case navigation and scored decision points (not pure
   multiple-choice, not pure free-form).
2. **The simulation engine must be completely separate from any given
   scenario**, so many cases can run on one engine — the same pattern
   already proven out in the author's separate "Academy Suite" project (a
   multi-academy Linux/Networking/SOC/Recon training platform). Two files
   were forked verbatim from that project because the pattern already
   works: `src/engines/contract.mjs` (the engine/session abstraction) and
   `src/engines/evidence-review.mjs` (a generic scored-decision engine).

A second hard governing rule shaped the physiology model itself: **model
reality's information asymmetry**, not just its numbers. Monitored vitals
(HR, MAP, SpO2, CVP) update immediately when something changes. Lab values
(ABG, dTT, HepPTT, TEG, ATIII) are real in the model at all times but only
revealed to the trainee after being ordered and waiting out a turnaround —
unless a specific continuous surrogate monitor is equipped in that
scenario, in which case that one variable becomes real-time. Example: a
sweep-gas change instantly changes true PaCO2, but nothing on the monitor
shows it until an ABG is drawn and resulted, unless a transcutaneous CO2
monitor is equipped.

## Where things stand

**Tested and working** (`ecmo-sim/`, Node's built-in test runner, no
external deps beyond dev tooling):
- Full physiology engine: monitored vitals, latent labs with realistic
  turnaround delays, equipment-gated real-time surrogates.
- RPM-primary circuit control: the player dials in pump RPM, not flow.
  Flow is derived — it saturates toward a **cannula-size-limited ceiling**
  (diminishing returns as RPM rises) and gets clipped further by poor
  preload (low CVP → "chatter"). Circuit pressures (venous/pre-pump,
  pre-oxygenator, post-oxygenator, ΔP) are derived from that flow.
- A bubble-detector safety interlock: triggering it stops the pump (flow
  and pressures collapse to zero), matching real console behavior.
- Cardiac rhythm as a scenario/physiology-driven state machine (sinus →
  junctional → V-tach → V-fib), explicitly **not player-settable** —
  escalates on sustained hypoxia or loss of circuit flow, never
  auto-reverts. Rules are placeholder thresholds pending real clinical
  triggers.
- A real scored decision checkpoint: when an ordered dTT (bivalirudin
  level) results, the engine automatically opens a multiple-choice
  titration decision, scored against the **real percent-based titration
  table from the author's own institutional protocol** (transcribed into
  `src/data/anticoagulation-protocol.json`), including the below-goal-floor
  escalation sequence (increase → increase again → consult attending) and
  the renal-adjusted top band.
- 28 tests passing across 3 files: `test/circuit-sandbox.test.mjs`,
  `test/titration-checkpoint.test.mjs`, `test/rhythm.test.mjs`. Run with
  `cd ecmo-sim && node --test test/*.test.mjs`.

**A separate, standalone demo** (`ecmo-sandbox.jsx` at this handoff's
root): a single-file React artifact reimplementing the same engine logic
inline (Claude artifacts can't import local project files, so this is a
deliberate duplication, not a bug) with a bedside-monitor-styled UI —
sliders, an animated ECG trace with real per-rhythm waveform morphology,
lab ordering, the titration checkpoint modal, circuit mechanics readouts,
bubble detector button. **As of this handoff, its formulas and thresholds
match the tested engine** (same RPM/cannula curve, same rhythm thresholds,
same dTT coefficient) — they were deliberately kept in sync. If you change
one, change the other, or they will drift again (they had drifted once
before this handoff was written; ported back into `circuit-sandbox.mjs`
and `physiology.mjs` before packaging this). Open it by pasting it into a
Claude.ai chat as an artifact, or run it in any React/Vite/CRA setup — it
only imports `react` and `lucide-react`.

**Real institutional reference material, not yet built against:**
The author (a pediatric ECMO specialist / respiratory therapist) has an
extensive real ECMO reference binder from his hospital, shared as photos
in the original conversation (not re-transcribed into this handoff's files
beyond what's already in `anticoagulation-protocol.json`). It includes:
- Post-operative "Problem → Clinical Signs" tables for six other cardiac
  lesions beyond the one scenario built so far: Glenn, Fontan, complete AV
  canal, TAPVR, transposition of the great arteries, Truncus arteriosus,
  and Tetralogy of Fallot. Each is ready-made scenario content.
- A full ECMO pharmacology reference: real dosing, adverse effects, Y-site
  compatibility/incompatibility, and ECMO-circuit-specific
  pharmacokinetics — notably, several drugs (fentanyl, midazolam,
  precedex) show significant **sequestration in the ECMO circuit that
  changes over time** (e.g., midazolam down to 13% remaining at 24h in an
  ex-vivo circuit) — a real mechanic not yet built. Several drugs
  (epinephrine, norepinephrine, dopamine, vasopressin) are flagged "should
  not be infused through the ECMO circuit" — a natural safety checkpoint,
  same pattern as the titration one.
- If you need this material and don't have it, ask the author to re-share
  those photos — do not fabricate dosing, compatibility, or PK data for a
  real clinical training tool.

## Architecture reference (why it's built this way)

The engine/session contract (`contract.mjs`) is intentionally generic:
```
engine.createSession({ scenario, snapshot }) => {
  snapshot(),        // serialize current state
  presentation(),    // what the UI should render right now
  submit(action),     // apply a player action
  advance(seconds)    // (time-advance capability) move simulated time
}
```
Any new engine (e.g., a future `branching-scenario` case wrapper) plugs
into the same shape. `circuit-sandbox.mjs` is the only engine so far that
uses the `time-advance` capability; `evidence-review.mjs` is a stateless
single-decision engine used both directly (nothing currently does this)
and internally, embedded inside `circuit-sandbox.mjs`'s checkpoint
mechanism (it creates and drives its own internal `evidence-review`
session for the currently-open checkpoint).

Physiology (`physiology.mjs`) and rhythm (`rhythm.mjs`) are pure functions
with no knowledge of sessions, labs, or scenarios — this is deliberate, so
they're unit-testable in isolation and so a future case-authoring tool
could call them directly for preview/validation without spinning up a full
session.

## Immediate next steps, roughly in order of value

1. **A second scenario** in a different population/risk context, to prove
   the engine/content split actually generalizes rather than being
   quietly tuned to one case. The post-op consideration tables above are
   ready-made starting points.
2. **Case navigation / objectives / a "complete" state.** Right now this
   is an open-ended sandbox with one checkpoint type. Fork
   `branching-scenario.mjs` from the Academy Suite (not yet in this repo)
   to wrap the sandbox in sections with a defined start/objective/end.
3. **A drug-sequestration mechanic** using the real PK data described
   above — same dose behaves differently depending on circuit age.
4. **A line-selection safety checkpoint** (should this drug go through the
   ECMO circuit or a peripheral/central line?), same pattern as the
   titration checkpoint, using the "should not be infused through the
   ECMO circuit" flags from the pharmacology reference.
5. **Expand the med/drip list** beyond epi/norepi/bivalirudin using the
   full pharmacology reference (milrinone, dobutamine, nicardipine,
   phenylephrine, vasopressin, sedation/paralytics, electrolyte pushes).
6. **Calibrate real coefficients.** Everything in `DEFAULT_COEFFICIENTS`
   except the one dTT data point is a placeholder. Get real numbers from
   the author the same way the dTT slope was calibrated (ask for a
   real example: "at X we saw Y").

## What NOT to do

- Don't fabricate clinical dosing, PK, or protocol data that isn't
  provided. Every placeholder coefficient in this codebase is labeled as
  such in a comment — keep that discipline for anything new.
- Don't let the `.jsx` demo and the tested `.mjs` engine drift apart again
  without noting it — if you change the physiology in one, change it in
  the other, or flag the divergence explicitly like this document does.
- Don't add a way for the player to directly set rhythm — that was an
  explicit, deliberate design decision (rhythm is scenario/physiology-
  driven only), not an oversight to "fix."
EOF

---

## UPDATE — Clinical Event / Complication System implemented

The project now has a reusable `src/core/clinical-events.mjs` layer. This is the architectural pivot away from attempting to mathematically reproduce every physiological/drug effect and toward clinically plausible consequence modeling.

### Governing doctrine
The simulator should teach recognition, decision-making, treatment, reassessment, and consequences. It does not need exact pharmacokinetic or hemodynamic prediction. A trainee action is evaluated in the context of the active clinical event and classified as preferred, acceptable, temporizing, ineffective, harmful, or critical error. The engine then applies a plausible state transition and monitor/internal-state change.

### Implemented proof of concept
`src/data/scenario-hypovolemia.json` activates a reusable hypovolemia/preload-limitation complication:
- volume bolus -> preferred/therapeutic -> improves preload/perfusion and resolves event
- increased RPM -> harmful -> worsens venous drainage/preload state
- increased sweep -> ineffective -> no correction of the hemodynamic cause

Existing sandbox controls are bridged into the event layer, and future interventions can use `submit({type:'clinical-action', actionId:'...'})`.

### Verification
33/33 tests pass: the original 28 plus 5 new tests covering contextual therapeutic/harmful outcomes, engine integration, neutral fallback behavior, and snapshot/restore persistence.

### Recommended next build
Do **not** add many complications ad hoc yet. Harden the complication schema with one more qualitatively different event (tamponade is a strong candidate) that deliberately reuses some of the same actions—especially volume and RPM—but produces different outcomes. That will prove the contextual action model before expanding the library.

## Clinical Events v0.2 — Tamponade differential slice

Implemented a second reusable hidden complication to prove contextual cause/effect across identical trainee actions.

### Added
- `src/data/scenario-tamponade.json` (public scenario id deliberately diagnosis-neutral: `va-ecmo-low-flow-02`)
- Tamponade states: decompensating, temporized, suspected, diagnosed, worsened, critical, arrest, resolved
- Contextual action rules for volume, RPM escalation, sweep adjustment, hemodynamic assessment, bedside echo, and emergency pericardial decompression
- Temporary improvement that expires by time spent in the current state
- Critical deterioration/arrest progression with an emergency rescue path
- Hidden-complication privacy: trainee presentation, logs, and action results do not expose hidden event IDs/labels before diagnostic discovery
- Backward-compatible `stateEnteredAtSec` migration for v0.1 snapshots

### Architectural proof
The same `volume-bolus` action now produces different outcomes by hidden cause:
- Hypovolemia/preload limitation -> preferred/definitive, event resolves
- Tamponade -> temporizing only, underlying event persists and deteriorates again unless definitively treated

### Verification
40/40 Node tests passing, including all prior regression tests.

# v0.3 PIVOT — EDUCATOR WORKFLOW + INFORMATION PIPELINE

Implemented the agreed product flow:

Educator standardized form → Create Scenario → Learner Cockpit (frozen) → Start → live clock/monitor → information/results feed.

New core modules:
- `src/core/scenario-builder.mjs`: canonical form schema, learning objectives, educator-generated scenario builder.
- `src/core/information-pipeline.mjs`: reusable diagnostic/information lifecycle with explicit turnaround placeholders, blockers, raw-result availability, and delayed interpretation.

Important architectural rule: turnaround times remain placeholders until final values are deliberately approved. X-ray is modeled as a lifecycle, not one timer: it may be bedside-ready but blocked during an active code; once acquired the image may be immediately viewable while formal interpretation remains delayed.

Manual-start scenarios are completely frozen before START: no clock advancement or learner interaction is allowed.

Tests: 45/45 passing (40 prior + 5 new workflow/information tests).

# v0.6 — SCENARIO RUNTIME DIRECTOR

Implemented `ecmo-sim/src/core/scenario-runtime-director.mjs` as a generic orchestration layer between trigger/eligibility and clinical-event activation.

## Governing separation
- Trigger/Eligibility Engine answers: **which complications have become eligible?**
- Scenario Runtime Director answers: **when may an eligible complication enter the live case?**
- Clinical Knowledge Registry answers: **what does that complication do?**
- Clinical Event System answers: **how do actions/time change the active complication state?**

The director contains no diagnosis-specific medical behavior. It never contains rules such as “tamponade should start after X” or “RPM causes hemolysis.” Those relationships belong in validated clinical knowledge / eligibility policies.

## Runtime modes
Generic orchestration profiles now exist for `guided`, `adaptive`, and `dynamic`. They control only neutral pacing parameters such as maximum concurrent unresolved events and minimum spacing between event releases. These are orchestration placeholders/configuration, not clinical turnaround or physiology claims.

Important behavior: selecting multiple educator learning concepts no longer requires every selected complication to activate simultaneously at time zero. Eligible events are queued and released according to runtime mode/pacing and current unresolved-event load.

## Persistence / instructor visibility
The runtime queue, released-event history, and pacing state survive snapshot/restore. Full queue/release details are exposed only through instructor/debug presentation, not learner presentation.

## Verification
61/61 Node tests pass (56 prior + 5 new runtime-director tests). New coverage verifies queueing/concurrency, mode-driven orchestration independent of clinical knowledge, snapshot deduplication, strict separation from generated scenario behavior, and integration proving that multiple eligible at-start complications are not all activated at once in Adaptive mode.

# v0.7 — Emergent Eligibility + Clinical Trajectory / Endpoint Engine

## New architecture

### Learner-created / emergent eligibility
- Added `src/core/emergent-eligibility.mjs`.
- Generic rules may observe action counts, sustained clinical context, active-event states, and trajectory state.
- Rules only make complications **eligible**; the Scenario Runtime Director still controls release timing/concurrency.
- No new medical cause/effect rules are enabled by default. Relationships such as a specific action causing a specific secondary complication must be deliberately defined in the Clinical Knowledge Registry before use.

### Clinical trajectory and endpoints
- Added `src/core/clinical-trajectory.mjs`.
- Tracks high-level clinical burden across perfusion, oxygenation, ventilation, hemodynamics, neurologic risk, bleeding, and circuit support.
- Clinical-event definitions may contribute trajectory signals by internal event state.
- Endpoints are independent of educational score.
- Supported endpoint families now include sustained stabilization, patient death from catastrophic terminal conditions, death after unresolved arrest beyond a configurable rescue window, death after configurable cumulative critical exposure, and instructor/manual termination.
- Timing values are explicit simulation-policy placeholders and remain configurable.
- Arrest/critical states are not automatically terminal; rescue remains possible until endpoint criteria are met.
- Once an endpoint is reached, simulation advancement is frozen.

### Current knowledge mappings
- Existing hypovolemia and postoperative tamponade definitions now expose high-level trajectory state mappings.
- Tamponade arrest is represented as an arrest trajectory state, not instant death.

### Scenario builder
- Generated scenarios now include empty `emergentEligibilityRules` by default and configurable `endpointProfile` placeholders.
- This preserves the standardized educator form while allowing future validated clinical knowledge to populate emergent rules without scripting scenarios.

## Verification
- 70/70 tests passing.
- New tests cover sustained emergent prerequisites, reset of sustained eligibility, learner-action-created eligibility routed through the Runtime Director, cumulative critical death independent of score, arrest rescue windows, catastrophic endpoints, sustained stabilization, and instructor termination.


---

# v0.8 — Clinical Significance Layer

## Governing doctrine

**Simulate clinically meaningful change, not biological noise.**

A modeled effect should generally alter recognition, urgency, management, or outcome. Trivial biologic variation should not consume simulation complexity or distract the learner.

Examples:
- HR 120 → 125 after stimulation: background noise unless a specific learning objective makes it meaningful.
- ECMO flow 150 → 40 mL/kg/min after repositioning: critical clinical change.

## New core module

`src/core/clinical-significance.mjs`

Provides configurable significance classification:
- background
- noticeable
- significant
- critical

Thresholds are explicitly simulation-policy placeholders and must be validated/tuned before training deployment.

## First reusable interaction pattern: position-sensitive cannula

The low-flow troubleshooting knowledge library now includes:
- complication: `position-sensitive-cannula`
- action: `turn-patient`
- action: `restore-prior-position`
- observation: `position-flow-response`

Behavior remains context-dependent:
- No relevant active condition → turning produces no invented clinical effect.
- Position-sensitive cannula active → turning can cause severe drainage/support loss.
- Restoring the prior position can recover support.
- Increasing RPM during severe positional drainage compromise does not correct the underlying problem and can worsen instability.

This is reusable clinical knowledge, not scenario-specific scripting.

## Important implementation rule

Clinical significance is not the same as hidden diagnosis disclosure.
The instructor/debrief log may retain significance classification and internal reasoning.
The learner receives only observable consequences.

## Verification

76/76 Node tests passing, including:
- minor HR change classified as background
- 150 → 40 mL/kg/min indexed-flow collapse classified as critical
- aggregate significance ignores trivial HR noise while promoting critical flow change
- position-sensitive cannula interaction produces large flow loss after turn and recovery after restoring position
- turning without a relevant active condition produces no invented effect
- all prior regression tests remain passing


---

# v0.9 — Low-Flow Differential Expansion + Master Complication Inventory

## Low-flow knowledge now implemented

Reusable modules:
- hypovolemia / preload limitation
- postoperative tamponade
- position-sensitive cannula drainage compromise
- drainage cannula / tubing kink
- mechanical circuit obstruction
- pump failure / loss of pump support

The modules are deliberately differentiated by clinically meaningful observations and responses rather than sharing a generic "low flow" script.

## New reusable actions/observations

Actions include:
- inspect drainage cannula/tubing
- relieve cannula/tubing kink
- inspect circuit path
- correct accessible circuit obstruction
- prepare/initiate component exchange
- assess pump power/speed/alarms/output
- restore pump function / backup support

Observations include:
- visible cannula/tubing abnormality
- pressure pattern suggesting obstruction/resistance
- pump power/speed/alarm/output status

## Activation effects

The Clinical Event System now supports optional `activationEffects` owned by reusable complication knowledge. This lets an event establish a clinically meaningful initial condition at the moment it enters the case without copying behavior into scenario JSON.

## Master inventory

See `MASTER_COMPLICATION_INVENTORY.md`.

The inventory intentionally lists clinically meaningful complications without yet defining all trigger relationships. It is the backlog for systematic knowledge-library expansion.

## Verification

80/80 Node tests passing.


---

# v1.0 — Reusable Module Taxonomy + Playable Low-Flow Troubleshooting Pack

## Complication taxonomy

The broad 185-item complication inventory has been normalized into 36 reusable clinical modules.
See:
- `CLINICAL_COMPLICATION_MODULE_TAXONOMY.md`
- `CLINICAL_COMPLICATION_MODULE_TAXONOMY.json`

The taxonomy separates:
- underlying reusable clinical problems,
- manifestations,
- consequences,
- observations,
- operational constraints,
- and trigger relationships.

This prevents a symptom or downstream consequence from becoming a separate hard-coded scenario unless it truly requires independent state logic.

## Playable troubleshooting scenarios

New engine-backed library:
`ecmo-sim/src/core/troubleshooting-scenario-library.mjs`

New scenario pack manifest:
`ecmo-sim/src/data/low-flow-troubleshooting-pack.json`

Six implemented cases:
1. preload loss / hypovolemia
2. postoperative tamponade
3. position-sensitive cannula drainage compromise
4. drainage cannula / tubing kink
5. mechanical circuit obstruction
6. pump failure / loss of pump support

All cases:
- are registry-backed,
- contain no embedded medical behavior,
- start frozen until learner presses Start,
- use neutral learner labels,
- keep educator cause labels separate,
- use the same action/control surface,
- support blind differential selection.

## Blind differential mode

`buildBlindLowFlowTroubleshootingScenario({seed})`

A seed deterministically selects one implemented low-flow cause for reproducible teaching/testing while keeping the learner briefing diagnosis-neutral.

## Visual playable component

`ecmo-low-flow-troubleshooting-pack.jsx`

Provides:
- educator case launcher,
- optional blind differential mode,
- learner cockpit,
- live monitor/ECMO display,
- RPM slider,
- common troubleshooting actions,
- information/results feed,
- real-time scenario clock,
- endpoint display.

The React component calls the same `circuitSandboxEngine`; it does not duplicate complication behavior.

## Disclosure hardening

Learner presentation no longer exposes raw internal scenario IDs.
Troubleshooting learner catalogs use neutral case keys and labels.
Tests verify that hidden cause terms do not leak through learner briefing/presentation.

## Verification

85/85 Node tests passing.


---

# v1.1 — Full 36-Module Clinical Knowledge Library

## Scope completed

The normalized 36-module taxonomy is now fully represented in the Clinical Knowledge Registry.

- 6 previously bench-oriented low-flow modules retained
- 30 additional reusable modules added
- 36/36 normalized taxonomy families now mapped to registry implementations
- all modules can be instantiated as engine-backed, learner-neutral scenarios

## New module domains implemented

- air / circuit emergency
- circuit breach / hemorrhage
- oxygenator thrombosis / failure
- sweep / gas failure
- hemolysis
- major bleeding
- intracranial hemorrhage
- ischemic stroke / thromboembolism
- circuit/systemic thrombosis
- anticoagulation imbalance
- VV recirculation
- VA differential hypoxemia
- VA LV distension / unloading
- limb ischemia
- pneumothorax / tension physiology
- airway / ventilator failure
- pulmonary hemorrhage
- gas-exchange failure
- arrhythmia / arrest
- vasoplegia / shock
- infection / sepsis
- AKI / fluid overload
- CKRT/ECMO interaction
- metabolic / electrolyte emergency
- neurologic deterioration
- abdominal compartment / ischemia
- pulmonary hypertensive crisis
- congenital circulation-specific failure
- treatment / transfusion adverse event
- transport / procedural / operational hazard

## Applicability guard

Complication definitions may declare VA/VV applicability.
The registry compiler now rejects incompatible mode combinations rather than silently loading them.

## Scenario instantiation

New:
`ecmo-sim/src/core/clinical-module-scenario-library.mjs`

All 36 complication definitions can be generated as diagnosis-neutral engine-backed scenarios.

New manifest:
`ecmo-sim/src/data/clinical-module-scenario-pack.json`

## Validation status

Low-flow remains the dedicated bench-test pack.
The newly added modules are **knowledge-ready**, not yet automatically considered bench-validated.

Exact timing, thresholds, visual cues, and institution/population-specific behavior remain subject to deliberate clinical validation.

See:
- `CLINICAL_MODULE_COVERAGE.md`
- `MODULE_VALIDATION_ROADMAP.md`

## Verification

90/90 Node tests passing.


---

# v2.0 — Clinical Spine Repair

This release fixes the integration disconnect found during low-flow bench testing.

## Root cause

The previous standalone bench app used a simplified handwritten mini-runtime instead of the canonical modular `circuitSandboxEngine`. In addition, the modular engine's hidden trajectory state was not adequately coupled back to observable bedside physiology.

## Fixes

### One canonical runtime
The new standalone `standalone-fixed/index.html` contains a generated bundle of the actual modular engine and troubleshooting scenario library. It does not use the prior handwritten mini-engine.

### Clinical Consequence Engine
New: `src/core/clinical-consequence.mjs`

Bridges:
effective ECMO support -> patient dependency/reserve -> meaningful monitor/lab consequences -> trajectory.

This is categorical and policy-driven, not a digital-human physiology model.

### Hemodynamic baseline correction
`mapBaseline` and `hrBaseline` are treated as actual bedside baselines. Flow is no longer blindly added as a positive MAP bonus on top of an already-clinical MAP.

### Support loss now affects the patient
Severe sustained support loss can now produce:
- progressive MAP decline,
- compensatory HR change followed by decompensation if prolonged,
- contextual oxygenation effect rather than automatic desaturation,
- rising latent lactate,
- trajectory signals that agree with monitor deterioration.

### Observation Resolver
New: `src/core/observation-resolver.mjs`

Assessments now return findings, including useful negatives:
- pump function normal/abnormal,
- circuit path intact/obstructed,
- drainage cannula/tubing findings,
- current hemodynamic pattern.

"No treatment effect" is no longer treated as "no information gained."

### Handoff / recent events
Learner presentation now supports structured:
- `handoff`
- `recentEvents`

Low-Flow Troubleshooting 03 now explicitly tells the learner a recent turn preceded the low-flow/drainage problem.

### Action feedback
RPM changes, volume boluses, and assessments return action-specific observable feedback.

### Trigger metadata
Trigger -> director -> event activation now preserves metadata such as an intended initial clinical-event state.

## Acceptance case

Low-Flow Troubleshooting 03 is the clinical-spine acceptance case.

Expected behavior:
- known prior flow ~145–155 mL/kg/min,
- recent repositioning documented,
- live flow ~46 mL/kg/min,
- initially compensated bedside state,
- progressive MAP/HR consequences over ~2 simulated minutes if untreated,
- saturation may remain preserved in this VA support profile,
- assessments return useful positive/negative findings,
- restoring prior position returns flow toward baseline,
- monitor trends recover after support restoration.

## Verification

94/94 Node tests passing, including new end-to-end clinical-spine acceptance tests.


---

# v2.1 — Explicit Patient Position State

## Problem fixed

`Turn / reposition patient` and `Restore prior position` previously behaved like separate clinical interventions. Only the specially coded restore action resolved the position-sensitive cannula problem, creating a magic-button effect.

## New architecture

New core module:
`ecmo-sim/src/core/patient-position.mjs`

Tracks:
- current patient position
- previous documented position
- available positions
- position history
- scenario-specific position-effect classification

The position-state layer contains no medical behavior.

## Position consequence separation

The scenario may classify a position for a particular case as:
- favorable
- partial
- adverse
- neutral

The reusable `position-sensitive-cannula` complication defines what those effect classes do to drainage/support.

This avoids universal hard-coding such as "right side is always bad."

## Low-Flow 03 acceptance mapping

For the current bench case only:
- prior documented: supine / midline
- current at handoff: right tilt
- supine / midline: favorable
- left tilt: partial improvement
- right tilt: adverse
- head/neck adjustment: neutral

These are case configuration values, not global physiology rules.

## Learner interaction

The generic `Turn / reposition patient` action no longer secretly chooses a position.

The learner explicitly selects:
- Supine / Midline
- Left Tilt
- Right Tilt
- Adjust Head / Neck
- Return to Previous Documented Position

`Return to Previous Documented Position` simply sets the position state to the documented prior position. It has no separate healing logic.

## Verification

98/98 automated tests passing.

New tests verify:
- position is explicit learner-visible state
- partial position gives partial flow improvement
- direct selection of the favorable position and restore-previous produce the same result
- adverse repositioning reproduces support loss while the hidden condition remains active
- generic turn requires an explicit position
