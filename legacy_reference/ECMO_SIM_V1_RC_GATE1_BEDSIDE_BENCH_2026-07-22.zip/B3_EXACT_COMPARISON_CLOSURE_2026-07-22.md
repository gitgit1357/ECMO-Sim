# B3 EXACT COMPARISON CLOSURE
Date: 2026-07-22

B3 primitives reviewed: 5/5.
- VV recirculation — source-reviewed/refined
- shared oxygenator failure — B1 circuit evidence reused
- gas-exchange failure — source-reviewed/refined
- airway/ventilator failure — source-reviewed/refined
- pneumothorax/intrathoracic-pressure — reviewed but NOT promoted as ELSO-derived; specialty-source corroboration remains required

Important source-supported VV principles now reflected:
- assess effective oxygen delivery, not saturation alone;
- consider ECMO flow relative to cardiac output, recirculation, hemoglobin/oxygen content, and metabolic demand;
- suspect recirculation with oxygenated drainage blood or paradoxical worsening of systemic saturation as VV flow rises;
- do not assume higher commanded flow equals higher effective flow;
- preserve lung-protective ventilation and correct ECMO/cause mechanisms rather than indiscriminately escalating ventilator settings.

All scenario-specific recirculation fractions and deterioration timers remain preclinical placeholders unless separately supported.

Next: B4 — VA / Cardiac Support.
