# BATCH 4 — VA / CARDIAC SUPPORT RULE REVIEW
Date: 2026-07-22

## Governing default
Institutional VA ECMO protocols govern when available. With none ingested, applicable ELSO adult VA/cardiac guidance governs by default.

## Review emphasis
Differential hypoxemia, LV distension/pulmonary edema, limb ischemia, and related VA physiology must remain mechanism-based. Exact thresholds and intervention timing are not labeled ELSO standards until source-level comparison is complete.

### `va-differential-hypoxemia`
- Primary source: **ELSO Interim Guidelines for Venoarterial Extracorporeal Membrane Oxygenation in Adult Cardiac Patients**
- Secondary domains: none
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; exact source comparison pending**

### `va-lv-distension`
- Primary source: **ELSO Interim Guidelines for Venoarterial Extracorporeal Membrane Oxygenation in Adult Cardiac Patients**
- Secondary domains: general
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; exact source comparison pending**

### `limb-ischemia`
- Primary source: **ELSO Interim Guidelines for Venoarterial Extracorporeal Membrane Oxygenation in Adult Cardiac Patients**
- Secondary domains: circuits
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; exact source comparison pending**
