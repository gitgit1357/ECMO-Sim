# ECMO Simulator — Master Clinically Meaningful Complication Inventory

**Purpose:** define the simulator's intended complication surface area without yet defining every trigger.

## Inclusion rule

A complication belongs in the simulator when it can reasonably change:
- recognition,
- urgency,
- treatment,
- ECMO/circuit management,
- diagnostic strategy,
- patient trajectory,
- or outcome.

Minor biological noise that does not alter management should generally not be modeled.

## Status key

- **BUILT** — reusable clinical knowledge exists in the engine.
- **NEXT** — high-priority knowledge module to build.
- **PLANNED** — belongs in the clinical library but is not yet implemented.
- **CONTEXT** — usually represented as a patient/scenario context or secondary consequence rather than a standalone ECMO event.

---

# 1. Low-flow / inadequate-support differential

1. **Preload loss / hypovolemia** — BUILT
2. **Postoperative cardiac tamponade** — BUILT
3. **Position-sensitive cannula drainage compromise** — BUILT
4. **Drainage cannula / external tubing kink** — BUILT
5. **Mechanical circuit obstruction / kink** — BUILT
6. **Pump failure / loss of pump support** — BUILT
7. Acute hemorrhage causing preload loss — NEXT
8. Drainage cannula migration / partial dislodgement — NEXT
9. Drainage cannula intravascular obstruction / thrombus — NEXT
10. Venous return impairment from high intrathoracic pressure — NEXT
11. Tension pneumothorax causing impaired venous return/support — NEXT
12. Abdominal compartment syndrome impairing venous return — PLANNED
13. Severe vasodilation / venous pooling with inadequate effective preload — PLANNED
14. Cannula size / configuration inadequate for required support — CONTEXT
15. Progressive pump-head or circuit thrombotic resistance limiting flow — PLANNED

# 2. Cannula and access complications

16. Cannula malposition — NEXT
17. Cannula migration — NEXT
18. Cannula dislodgement / accidental decannulation — NEXT
19. Cannula-site hemorrhage — NEXT
20. Cannula-site hematoma — PLANNED
21. Vessel injury / perforation — PLANNED
22. Cardiac perforation related to cannula — PLANNED
23. Cannula-associated thrombosis — PLANNED
24. Venous congestion from drainage/return obstruction — PLANNED
25. Limb ischemia with peripheral VA ECMO — NEXT
26. Differential limb perfusion / distal perfusion catheter failure — PLANNED
27. Cannula-site infection — PLANNED

# 3. Circuit mechanical emergencies

28. Air entrainment into venous drainage limb — NEXT
29. Air detected in circuit / bubble alarm with pump stop — PARTIALLY BUILT
30. Air embolism risk / air reaching patient — NEXT
31. Circuit tubing rupture — NEXT
32. Circuit disconnection — NEXT
33. Major blood loss from circuit breach — NEXT
34. Pump stop / power failure — BUILT at generic pump-support level
35. Backup power / console transition failure — PLANNED
36. Pump-head malfunction — PLANNED
37. Pump-head thrombosis — PLANNED
38. Circuit tubing kink — BUILT within mechanical circuit obstruction
39. Pressure-monitoring line/sensor failure — PLANNED
40. Flow-probe failure / misleading flow reading — PLANNED
41. Heater / heat-exchanger malfunction — PLANNED
42. Dangerous patient temperature change from heat-control failure — PLANNED

# 4. Oxygenator / membrane-lung / gas-supply complications

43. Oxygenator thrombosis / clot burden — NEXT
44. Progressive oxygenator failure — NEXT
45. Rising transmembrane pressure / resistance — NEXT
46. Inadequate oxygen transfer — NEXT
47. Inadequate CO2 removal — NEXT
48. Sweep-gas disconnection / loss — NEXT
49. Gas-source failure — NEXT
50. Blender / gas-setting error — PLANNED
51. Water condensation / circuit handling issue when clinically consequential — PLANNED
52. Need for oxygenator or circuit exchange — NEXT

# 5. Gas exchange and respiratory complications

53. Hypoxemia despite ECMO support — NEXT
54. Hypercapnia from inadequate sweep / membrane performance — NEXT
55. Excessive CO2 removal / clinically significant hypocapnia — PLANNED
56. VV recirculation — NEXT
57. VV cannula position causing recirculation — NEXT
58. Differential hypoxemia / North-South (Harlequin) syndrome in peripheral VA ECMO — NEXT
59. Pneumothorax — NEXT
60. Tension pneumothorax — NEXT
61. Pulmonary hemorrhage — NEXT
62. Severe atelectasis / derecruitment when it changes management — PLANNED
63. Mucus plugging / acute airway obstruction — PLANNED
64. Endotracheal tube obstruction/displacement — PLANNED
65. Ventilator failure/disconnection when clinically consequential — PLANNED

# 6. Cardiac / hemodynamic complications

66. LV distension on VA ECMO — NEXT
67. Pulmonary edema secondary to LV distension — NEXT
68. Failure of aortic valve opening / severe stasis — NEXT
69. Intracardiac / aortic-root thrombus risk from stasis — NEXT
70. Right ventricular failure / inadequate venous return interaction — PLANNED
71. Refractory cardiogenic shock despite current support configuration — PLANNED
72. Clinically significant bradycardia — PLANNED
73. Tachyarrhythmia / SVT — PLANNED
74. Ventricular tachycardia — PARTIALLY BUILT as rhythm trajectory
75. Ventricular fibrillation — PARTIALLY BUILT as rhythm trajectory
76. PEA / cardiovascular arrest — PARTIALLY BUILT through trajectory/endpoints
77. Cardiac tamponade — BUILT
78. Hypertensive state that creates clinically significant risk/problem — PLANNED
79. Severe vasoplegia / distributive shock — PLANNED

# 7. Bleeding complications

80. Surgical-site bleeding — NEXT
81. Cannula-site bleeding — NEXT
82. Chest-tube / mediastinal bleeding — NEXT
83. Intracranial hemorrhage — NEXT
84. Pulmonary hemorrhage — NEXT
85. Gastrointestinal bleeding — PLANNED
86. Retroperitoneal bleeding — PLANNED
87. Hemothorax — PLANNED
88. Diffuse coagulopathic bleeding — NEXT
89. Massive hemorrhage / exsanguination — NEXT
90. Occult blood loss causing progressive preload failure — NEXT

# 8. Thrombotic / anticoagulation complications

91. Circuit clot burden — NEXT
92. Oxygenator thrombosis — NEXT
93. Pump-head thrombosis — PLANNED
94. Cannula thrombosis — PLANNED
95. Deep venous thrombosis — PLANNED
96. Arterial thrombosis / embolism — PLANNED
97. Intracardiac thrombosis — NEXT
98. Aortic-root thrombosis — NEXT
99. Ischemic stroke / cerebral infarction — NEXT
100. Limb ischemia from arterial thrombosis/cannulation — NEXT
101. Inadequate anticoagulation / subtherapeutic state — NEXT
102. Excess anticoagulation / bleeding risk — NEXT
103. Heparin-induced thrombocytopenia — PLANNED
104. Severe thrombocytopenia when management changes — PLANNED
105. DIC / consumptive coagulopathy — PLANNED

# 9. Hemolysis / blood trauma

106. Clinically significant hemolysis — NEXT
107. Hemolysis from excessive drainage stress / negative pressure — PLANNED relationship
108. Hemolysis from pump/circuit thrombosis — PLANNED relationship
109. Hemolysis from mechanical obstruction / high circuit stress — PLANNED relationship
110. Hemoglobinuria / dark urine as observable consequence — PLANNED observation
111. Secondary renal injury from severe hemolysis — PLANNED consequence

# 10. Neurologic complications

112. Intracranial hemorrhage — NEXT
113. Ischemic stroke — NEXT
114. Seizure / status epilepticus — NEXT
115. Hypoxic-ischemic brain injury — PLANNED
116. Cerebral hypoperfusion — PLANNED
117. Brain edema / increased intracranial pressure — PLANNED
118. Brain death / irreversible neurologic injury endpoint — PLANNED
119. Neonatal/pediatric IVH where appropriate — PLANNED
120. Acute pupil / neurologic examination change that demands action — PLANNED

# 11. Renal / fluid / metabolic complications

121. Acute kidney injury — NEXT
122. Oliguria / anuria — NEXT
123. Fluid overload — NEXT
124. CRRT/CKRT circuit failure or interruption — PLANNED
125. CRRT connection causing clinically significant ECMO interaction — PLANNED
126. Hyperkalemia — NEXT
127. Severe hypokalemia — PLANNED
128. Clinically significant ionized hypocalcemia — NEXT
129. Severe sodium derangement — PLANNED
130. Severe metabolic acidosis / rising lactate from inadequate perfusion — NEXT
131. Hypoglycemia / hyperglycemia only when clinically consequential — PLANNED
132. Clinically significant hypothermia / hyperthermia — PLANNED

# 12. Infectious complications

133. Bloodstream infection / CLABSI-like event — PLANNED
134. Cannula-site infection — PLANNED
135. Ventilator-associated / hospital-acquired pneumonia — PLANNED
136. Sepsis with hemodynamic deterioration — NEXT
137. Septic shock / vasoplegia — NEXT
138. Culture result delay and antimicrobial decision pathway — PLANNED

# 13. GI / hepatic / abdominal complications

139. Hepatic dysfunction from shock / congestion — PLANNED
140. GI bleeding — PLANNED
141. Mesenteric / bowel ischemia — PLANNED
142. Abdominal compartment syndrome — PLANNED
143. Feeding intolerance is excluded unless it changes acute management — EXCLUDED BY DEFAULT

# 14. VA-ECMO-specific high-value complications

144. Differential hypoxemia / North-South syndrome — NEXT
145. LV distension — NEXT
146. Pulmonary edema from inadequate LV unloading — NEXT
147. Aortic valve non-opening / root stasis — NEXT
148. Intracardiac or aortic-root thrombosis — NEXT
149. Limb ischemia — NEXT
150. Distal perfusion catheter failure — PLANNED
151. Inadequate systemic perfusion despite apparently adequate displayed flow — NEXT

# 15. VV-ECMO-specific high-value complications

152. Recirculation — NEXT
153. Drainage/return cannula malposition — NEXT
154. Inadequate flow relative to patient demand — NEXT
155. Oxygenator dysfunction — NEXT
156. Sudden severe desaturation from circuit or patient cause — NEXT
157. Native lung deterioration / pneumothorax causing acute instability — NEXT

# 16. ECPR / resuscitation-related complications

158. Persistent no-flow / inadequate flow state — NEXT
159. Refractory arrest — PARTIALLY BUILT via trajectory/endpoints
160. Failure to correct reversible arrest cause — NEXT
161. CPR-related hemorrhage / thoracic injury when clinically consequential — PLANNED
162. Severe hypoxic-ischemic injury after prolonged arrest — PLANNED

# 17. Congenital / pediatric context-specific problems

These should generally be modular patient-context knowledge rather than assumed in every ECMO case.

163. Systemic-to-pulmonary shunt obstruction — PLANNED
164. Excessive shunt runoff / pulmonary overcirculation — PLANNED
165. Single-ventricle systemic/pulmonary flow imbalance — PLANNED
166. Post-cardiotomy bleeding — NEXT
167. Residual surgical lesion causing inadequate output/support — PLANNED
168. Pulmonary hypertensive crisis — NEXT
169. Ductal-dependent physiology problem where relevant — PLANNED
170. Age/size-specific cannula flow limitation — CONTEXT

# 18. Medication / transfusion / treatment complications

171. Incorrect vasoactive choice causing clinically meaningful deterioration — PLANNED contextual interaction
172. Inadequate vasoactive support — PLANNED
173. Excess vasoactive support / severe tachyarrhythmia or afterload effect — PLANNED
174. Anticoagulant titration error — PARTIALLY BUILT through dTT checkpoint
175. Transfusion reaction — PLANNED
176. Massive transfusion complications when clinically meaningful — PLANNED
177. Electrolyte disturbance after blood products / resuscitation — PLANNED

# 19. Diagnostic / operational complications worth simulating

These are not always "medical complications," but they materially change decisions.

178. Delayed lab result — PIPELINE BUILT
179. Delayed imaging acquisition — PIPELINE BUILT
180. Procedure/imaging blocked during active code — PIPELINE BUILT
181. Raw imaging available before formal interpretation — PIPELINE BUILT
182. Misleading monitor/sensor reading from equipment failure — PLANNED
183. Delayed recognition/escalation — DEBRIEF/trajectory concept
184. Transport-related loss of support / cannula position change — PLANNED
185. Patient turning/repositioning causing clinically significant support change — BUILT

---

# Recommended build order after low-flow library

## Tier 1 — ECMO specialist emergencies
1. Air entrainment / air embolism risk
2. Oxygenator thrombosis/failure
3. Sweep/gas-source failure
4. Circuit rupture/disconnection and hemorrhage
5. Cannula migration/dislodgement
6. Acute major bleeding
7. Hemolysis
8. Differential hypoxemia (VA)
9. Recirculation (VV)
10. LV distension / inadequate unloading (VA)

## Tier 2 — patient emergencies that interact strongly with ECMO
11. Tension pneumothorax
12. Intracranial hemorrhage
13. Ischemic stroke
14. Sepsis/septic shock
15. Acute kidney injury/fluid overload
16. Pulmonary hemorrhage
17. Major arrhythmias/arrest rescue pathways
18. Pulmonary hypertensive crisis
19. Acute electrolyte emergencies
20. Post-cardiotomy hemorrhage

## Tier 3 — deeper longitudinal / advanced cases
21. Infection evolution
22. HIT/DIC/coagulopathy variants
23. Mesenteric ischemia
24. hepatic dysfunction
25. CRRT-ECMO interactions
26. congenital lesion-specific physiology/problems
27. transport complications
28. complex multi-complication dynamic cases

---

## Scope note

This inventory is intentionally broader than the currently coded library. It is a design backlog, not a claim that every listed event is equally common or should be available in every population, ECMO mode, cannulation strategy, or educator scenario.

The educator should select learning objectives; the engine should only draw from complications that are clinically compatible with the configured patient/context.
