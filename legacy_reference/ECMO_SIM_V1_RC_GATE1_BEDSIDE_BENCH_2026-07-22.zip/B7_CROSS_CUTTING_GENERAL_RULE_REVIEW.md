# BATCH 7 — CROSS-CUTTING / GENERAL RULE REVIEW
Date: 2026-07-22

## Governance
Institutional protocols govern first. Applicable ELSO guidance governs institutional gaps. Where ELSO does not define sufficient specialty-level detail, additional authoritative specialty guidance may supplement ELSO; such supplementation must be explicitly sourced and cannot silently replace the institution-first/ELSO-default hierarchy.

### `complication:abdominal-ischemic-compartment`
- Primary ELSO source: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: none
- Specialty-source supplementation may be required: yes
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:circuit-systemic-thrombosis`
- Primary ELSO source: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Domain: `anticoagulation`
- Secondary: circuits
- Specialty-source supplementation may be required: no
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:ckrt-ecmo-interaction`
- Primary ELSO source: **ELSO Guidelines for Fluid Overload, Acute Kidney Injury, and Electrolyte Management**
- Domain: `aki-fluid-electrolytes`
- Secondary: circuits
- Specialty-source supplementation may be required: no
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:congenital-circulation-specific`
- Primary ELSO source: **Guidelines for Pediatric Cardiac Failure**
- Domain: `pediatric-cardiac`
- Secondary: general
- Specialty-source supplementation may be required: yes
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:neurologic-deterioration`
- Primary ELSO source: **Neurological Monitoring and Management for Adult ECMO Patients**
- Domain: `adult-neurologic`
- Secondary: general
- Specialty-source supplementation may be required: no
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:thromboembolism-stroke`
- Primary ELSO source: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Domain: `anticoagulation`
- Secondary: adult-neurologic
- Specialty-source supplementation may be required: no
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:transport-procedural-operational`
- Primary ELSO source: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: circuits
- Specialty-source supplementation may be required: yes
- Status: **preclinical; exact source extraction/comparison pending**

### `complication:treatment-transfusion-adverse`
- Primary ELSO source: **ELSO Guidelines General v1.4**
- Domain: `general`
- Secondary: anticoagulation
- Specialty-source supplementation may be required: yes
- Status: **preclinical; exact source extraction/comparison pending**
