# M4 VA-01 — VERTICAL-SLICE ACCEPTANCE PASS 4
Date: 2026-07-22

## Gate result
PASS — VA-01 Differential Hypoxemia has completed the proving-case acceptance gate for the current standalone learner build.

## Verified
### Prebrief
- Diagnosis-neutral VA handoff loads.
- Four recent-event entries provide temporal context.
- Four VA-specific learner objectives are present.

### Discriminating evidence
- Initial right-radial/upper-body SpO2 ~82%, PaO2 ~48 mmHg.
- Lower-body/postductal SpO2 ~98%, PaO2 ~180 mmHg.
- Assessment explains the competing native/retrograde flow pattern without naming the syndrome.

### Delayed branch
- At 241 simulated seconds unresolved, right-radial/upper-body SpO2 falls to ~75%, PaO2 ~38 mmHg.
- Lower-body oxygenation remains relatively preserved (~98%, PaO2 ~175 mmHg).
- This preserves the intended trap: a lower-body saturation can appear reassuring while upper-body oxygen delivery worsens.

### Cause-directed correction
- Corrective management resolves the underlying event.
- Reassessment shows acceptably matched upper/lower-body oxygenation (~96% vs ~97%).

### Completion
- After sustained stability, lifecycle reaches `stabilized`.
- `complete=true`.
- Endpoint is `stabilized`.
- Standalone-v2.5 contains the current VA scenario library, site-specific physiology state, and VA-01 cockpit actions.

## Regression
179 / 179 automated tests passing.

## Gate decision
VA-01 proving pattern is ACCEPTED.
Do not further refine VA-01 before V1 completion except for DEFECT/BLOCKER/clinical-correctness/downstream-incompatibility findings.

## Next allowed work
Replicate the proven M4 architecture across:
- VA-02 LV distension / inadequate unloading
- VA-03 Peripheral cannulation limb ischemia
- VA-04 Circuit/cannula/intracardiac thrombosis
Then run four-case M4 acceptance and freeze M4.
