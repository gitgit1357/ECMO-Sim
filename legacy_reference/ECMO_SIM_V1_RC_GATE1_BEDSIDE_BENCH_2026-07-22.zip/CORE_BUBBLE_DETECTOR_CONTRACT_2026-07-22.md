# CORE BUBBLE DETECTOR CONTRACT — CORRECTED
Date: 2026-07-22

## Physical location
The bubble detector is on the ECMO return limb, downstream of the final pigtail/access point before blood returns to the patient.

## Detection semantics
- The detector does not represent generic knowledge that air exists somewhere in the circuit.
- Air upstream of the detector does not trigger the detector merely by existing.
- If upstream air is identified and removed before reaching the detector, no bubble-detector alarm/interlock should occur.
- The alarm/interlock activates only when air reaches the detector location on the return limb.

## Safety behavior
When air reaches the detector:
1. Detector status changes to ALARM.
2. The safety interlock stops pump flow.
3. The learner must manage the air source/circuit hazard before safe support can resume.

This behavior is part of the universal ECMO cockpit and is independent of the hidden scenario diagnosis.
