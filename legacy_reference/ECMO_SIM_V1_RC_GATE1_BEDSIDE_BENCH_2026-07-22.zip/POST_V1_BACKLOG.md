# ECMO SIMULATOR — POST-V1 BACKLOG

This file captures valuable ideas that are deliberately deferred under `PROJECT_GOVERNANCE_COMPLETION_FIRST.md` so they do not derail V1 feature completion.

## Seeded deferred items
- Advanced monitor graphics and cosmetic waveform enhancements beyond functional clinical readability.
- Broad UI visual redesign, themes, animations, and aesthetic dashboards.
- Sophisticated educator analytics beyond the basic V1 debrief/validation requirements.
- Large scenario-variant expansion after each planned clinical family is represented.
- Enterprise/institutional administration features not required for minimal end-to-end V1 operation.
- Additional populations, complication families, and optional realism layers outside the frozen V1 milestone map.

## Intake rule
Add new ideas here unless they are classified as BLOCKER, DEFECT, or PLANNED SCOPE under the governance contract. Do not implement backlog items before M12 V1 Feature Freeze without an explicit governance change.
