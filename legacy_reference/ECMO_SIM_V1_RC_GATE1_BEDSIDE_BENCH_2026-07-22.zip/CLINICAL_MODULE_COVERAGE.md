# Clinical Module Coverage — v1.1

**Status meaning:** `bench-ready` means the current low-flow interaction has a playable path and automated tests; `knowledge-ready` means reusable recognition/action/trajectory logic exists but still needs dedicated visual-cue, timing, and clinical bench validation before formal training use.

| Taxonomy module | Registry implementation | Status |
|---|---|---|
| `preload-volume-loss` | `hypovolemia`, `major-bleeding` | bench-partial |
| `tamponade-compression` | `postoperative-tamponade` | bench-ready |
| `cannula-position-drainage` | `position-sensitive-cannula` | bench-ready |
| `cannula-mechanical-obstruction` | `drainage-cannula-kink` | bench-ready |
| `circuit-mechanical-obstruction` | `mechanical-circuit-obstruction` | bench-ready |
| `pump-support-failure` | `pump-support-failure` | bench-ready |
| `air-emergency` | `air-emergency` | knowledge-ready |
| `circuit-breach-hemorrhage` | `circuit-breach-hemorrhage` | knowledge-ready |
| `oxygenator-thrombosis-failure` | `oxygenator-thrombosis-failure` | knowledge-ready |
| `sweep-gas-failure` | `sweep-gas-failure` | knowledge-ready |
| `hemolysis` | `hemolysis` | knowledge-ready |
| `major-bleeding` | `major-bleeding` | knowledge-ready |
| `intracranial-hemorrhage` | `intracranial-hemorrhage` | knowledge-ready |
| `thromboembolism-stroke` | `thromboembolism-stroke` | knowledge-ready |
| `circuit-systemic-thrombosis` | `circuit-systemic-thrombosis` | knowledge-ready |
| `anticoagulation-management` | `anticoagulation-management` | knowledge-ready-partial-protocol |
| `vv-recirculation` | `vv-recirculation` | knowledge-ready |
| `va-differential-hypoxemia` | `va-differential-hypoxemia` | knowledge-ready |
| `va-lv-distension` | `va-lv-distension` | knowledge-ready |
| `limb-ischemia` | `limb-ischemia` | knowledge-ready |
| `pneumothorax-intrathoracic-pressure` | `pneumothorax-intrathoracic-pressure` | knowledge-ready |
| `airway-ventilator-failure` | `airway-ventilator-failure` | knowledge-ready |
| `pulmonary-hemorrhage` | `pulmonary-hemorrhage` | knowledge-ready |
| `gas-exchange-failure` | `gas-exchange-failure` | knowledge-ready |
| `arrhythmia-arrest` | `arrhythmia-arrest` | knowledge-ready-partial-rhythm-engine |
| `vasoplegia-shock` | `vasoplegia-shock` | knowledge-ready |
| `infection-sepsis` | `infection-sepsis` | knowledge-ready |
| `aki-fluid-overload` | `aki-fluid-overload` | knowledge-ready |
| `ckrt-ecmo-interaction` | `ckrt-ecmo-interaction` | knowledge-ready |
| `metabolic-electrolyte-emergency` | `metabolic-electrolyte-emergency` | knowledge-ready |
| `neurologic-deterioration` | `neurologic-deterioration` | knowledge-ready |
| `abdominal-ischemic-compartment` | `abdominal-ischemic-compartment` | knowledge-ready |
| `pulmonary-hypertensive-crisis` | `pulmonary-hypertensive-crisis` | knowledge-ready |
| `congenital-circulation-specific` | `congenital-circulation-specific` | knowledge-ready |
| `treatment-transfusion-adverse` | `treatment-transfusion-adverse` | knowledge-ready |
| `transport-procedural-operational` | `transport-procedural-operational`, `position-sensitive-cannula` | knowledge-ready-partial |
