# M4 VA-01 — COCKPIT INTEGRATION PASS 3
Date: 2026-07-22

## Status
VA-01 Differential Hypoxemia is wired into the standalone learner cockpit in `standalone-v2.5/index.html`.

## Implemented
- Current M4 source modules rebuilt into standalone bundle.
- VA ECMO scenario library available in educator case launcher.
- VA-01 handoff, recent events, and VA learner objectives use scenario data.
- Cockpit actions exposed:
  - Assess upper/lower-body oxygenation
  - Correct upper-body oxygen delivery mismatch
- Dynamic right-radial vs lower-body SpO2/PaO2 evidence is supplied by the current observation resolver.
- Existing universal lifecycle/debrief shell is reused; no M4-specific lifecycle fork.
- Frozen M1-M3 cases remain in the build.

## Regression
176 / 176 automated tests passing.

## Next gate
Browser-driven VA-01 acceptance:
prebrief -> start -> assess site-specific oxygenation -> observe differential -> delay branch/progression -> cause-directed correction -> sustained stabilization -> completion/debrief.
Only DEFECT/BLOCKER findings may change M4 before replication.
