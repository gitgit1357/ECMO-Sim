# ELSO DEFAULT RULE-DOMAIN CROSSWALK
Date: 2026-07-22

Until an applicable institutional protocol is ingested, each current complication family is assigned to the most relevant ELSO governing domain. This is a provenance assignment, not yet a claim that every numeric simulator constant has been extracted from or validated against the source.

| Simulator rule | Governing default domain | Status |
|---|---|---|
| `complication:drainage-cannula-kink` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:mechanical-circuit-obstruction` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:pump-support-failure` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:air-emergency` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:circuit-breach-hemorrhage` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:oxygenator-thrombosis-failure` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:sweep-gas-failure` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:hemolysis` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:major-bleeding` | anticoagulation | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:intracranial-hemorrhage` | adult-neurologic | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:thromboembolism-stroke` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:circuit-systemic-thrombosis` | circuits | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:anticoagulation-management` | anticoagulation | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:vv-recirculation` | adult-vv-respiratory | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:va-differential-hypoxemia` | adult-va-cardiac | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:va-lv-distension` | adult-va-cardiac | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:limb-ischemia` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:pneumothorax-intrathoracic-pressure` | adult-vv-respiratory | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:airway-ventilator-failure` | adult-vv-respiratory | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:pulmonary-hemorrhage` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:gas-exchange-failure` | adult-vv-respiratory | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:arrhythmia-arrest` | adult-ecpr | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:vasoplegia-shock` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:infection-sepsis` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:aki-fluid-overload` | aki-fluid-electrolytes | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:ckrt-ecmo-interaction` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:metabolic-electrolyte-emergency` | aki-fluid-electrolytes | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:neurologic-deterioration` | adult-neurologic | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:abdominal-ischemic-compartment` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:pulmonary-hypertensive-crisis` | adult-va-cardiac | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:congenital-circulation-specific` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:treatment-transfusion-adverse` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |
| `complication:transport-procedural-operational` | general | ELSO-governed-default-pending-rule-level-extraction-and-review |