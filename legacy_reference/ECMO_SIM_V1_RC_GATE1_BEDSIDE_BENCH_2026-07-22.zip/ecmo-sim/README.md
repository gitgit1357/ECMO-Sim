# ECMO Circuit Sandbox — Engine

A physiology/circuit simulation engine for ECMO training, built as a
scenario-agnostic engine (matching the multi-academy Academy Suite pattern:
engine logic separate from case content) plus one real scored decision
checkpoint built from an actual institutional protocol.

**Status:** engine + data only, no suite shell/UI wired to it yet (see
`ecmo-sandbox.jsx` at the repo root for a standalone click-through demo —
read its header comment, it's a separate reimplementation, not this engine).
28 tests passing across 3 files (`node --test test/*.test.mjs`).

## Governing rule
Two channels, enforced in code and tested:

- **Monitored** (`physiology.mjs::deriveMonitoredVitals`) — HR, MAP, SpO2,
  CVP. Recomputed every `advance()` tick. Changing a setting or giving a
  med shows up here immediately (drips ease toward steady state over ~1 min
  so it isn't literally instantaneous, but it's not gated behind anything).
- **Circuit mechanics** (`physiology.mjs::deriveCircuitMechanics`) — the
  player sets **pump RPM**, not flow. Flow is derived: it rises with RPM
  but saturates toward a **cannula-size-limited ceiling** (diminishing
  returns), and gets clipped further if CVP (preload) runs low — a
  simplified stand-in for line chatter/suck-down. Pressures (venous/
  pre-pump, pre-oxygenator, post-oxygenator, ΔP) are derived from that flow.
- **Latent** (`physiology.mjs::deriveTrueLatent`) — PaO2, PaCO2, pH,
  lactate, Hgb, DTT (bivalirudin level), HepPTT, TEG r-time, ATIII. True in
  the model at all times, but only revealed through `lab-queue.mjs`: order
  it, wait out the turnaround, then it appears in `resultedLabs`.
- **Equipment-gated surrogates** — a scenario's `equipment` block (tcCO2,
  continuous SvO2, cerebral NIRS) can promote one latent variable into a
  real-time `surrogateReadings` field for that scenario only. No equipment,
  no shortcut.
- **Rhythm** (`rhythm.mjs`) — scenario/physiology-driven only. There is
  deliberately **no player action that sets it directly**. It escalates
  (sinus → junctional → V-tach → V-fib) on sustained hypoxia or loss of
  circuit flow, and never auto-reverts (real VT/VF doesn't resolve without
  an intervention this engine doesn't model yet — e.g. no defib action
  exists).
- **Bubble detector** — a safety interlock. Triggering it (`trigger-bubble-
  alarm`) stops the pump: flow and all three pressures collapse to zero,
  same as a real console.

## Files
- `src/engines/contract.mjs` — forked as-is from the Academy Suite, plus one
  addition: a `time-advance` capability (`advance(seconds)`), since a
  sandbox needs to move simulated time independent of any single action.
- `src/core/physiology.mjs` — pure functions, all coefficients in
  `DEFAULT_COEFFICIENTS`. **Every coefficient is a placeholder** except
  `dttPerMgKgHrBivalirudin`, which is calibrated from one real data point
  (0.31 mg/kg/hr → DTT 0.54 mcg/mL — get a second dose/result pair to check
  it's actually linear, not just anchored at one point). This is the file
  to correct against real protocols before trusting any of it for training.
  Also has `POPULATION_PRESETS.neonatal` / `.pediatric` for numbers that
  should differ by patient size.
- `src/core/rhythm.mjs` — the cardiac rhythm escalation rules, pure and
  independently tested (`test/rhythm.test.mjs`). Placeholder trigger logic
  (SpO2 and flow thresholds) — swap in real scenario-authored triggers when
  you have them.
- `src/core/lab-queue.mjs` — order/turnaround/reveal mechanics for labs.
- `src/core/titration-lookup.mjs` — the answer key for the dTT titration
  checkpoint, built from your real institutional protocol. Only two tables
  are implemented (neonate `standard`, neonate `hemorrhagicOrOperative`) —
  exactly what the protocol gave percent-steps for. Pediatric and neonate
  `highThrombosisRisk` only have goal bands (see
  `src/data/anticoagulation-protocol.json`), no titration steps, so calling
  this for those throws instead of guessing.
- `src/engines/evidence-review.mjs` — forked verbatim from the Academy
  Suite, unmodified. Generic single-decision, multiple-choice engine;
  `circuit-sandbox.mjs` delegates the titration checkpoint's scoring to it.
- `src/engines/circuit-sandbox.mjs` — the actual engine. Wires everything
  above into the `createSession → {snapshot, presentation, submit, advance}`
  contract. This is the file to read to see the whole thing wired together.
- `src/data/scenario-example.json` — content only, no logic. The shape a
  case author writes: starting settings, starting "true" patient state,
  cannula size, equipment, dTT risk context, starting rhythm.
- `src/data/anticoagulation-protocol.json` — faithful transcription of your
  institution's real bivalirudin/dTT titration protocol (goal bands by
  population and bleeding/thrombosis risk, the percent-based titration
  table, HepPTT/TEG schedules and goals, the trial-off heparin bridge,
  pigtail packing). Reference data — only the goal bands and titration
  steps are wired into code (`titration-lookup.mjs`); the rest is there for
  when you're ready to build against it.

## Session actions (`submit({ type, ... })`)
- `set-param` — `{ param, value }`. Settable params: `pumpRpm`,
  `sweepGasLpm`, `fdo2Percent`, `heaterTempC`, `epiMcgKgMin`,
  `norepiMcgKgMin`, `bivalirudinMgKgHr`. (No `rhythm` here — see above.)
- `bolus-volume` — `{ mlPerKg }`.
- `order-lab` — `{ labType }`. Types: `abg`, `dtt`, `hepptt`, `teg`,
  `atiii`.
- `answer-checkpoint` — `{ optionId }`. Only valid while
  `presentation().checkpoint` is non-null.
- `trigger-bubble-alarm` / `clear-bubble-alarm` — no payload.
- `dismiss-rhythm-announcement` — clears the announcement banner without
  changing the underlying rhythm.

Advance simulated time with `session.advance(seconds)` (capability
`time-advance`), independent of any single action.

## Known gaps (not yet built)
- Suite shell/UI — engine + data only right now.
- Case navigation / objectives / a defined "complete" state — this is an
  open-ended sandbox with one scored checkpoint type, not yet a full CSE
  section structure. The `branching-scenario` engine (in the Academy Suite,
  not yet forked here) is the natural wrapper for that.
- Only one scenario exists (`va-ecmo-post-sano-01`) — a second scenario in
  a different population/context would stress-test the engine/content
  split before building more on top of it.
- Scoring/pedagogy layer beyond per-checkpoint accept/reject.
- HepPTT/TEG/ATIII are orderable labs but pass-through values — no
  dose-response data links anything settable to them yet.
- The trial-off/low-flow heparin bridge (ACT-driven, separate from
  bivalirudin) isn't modeled as a distinct state — reference only.
- No recovery/intervention mechanic for rhythm (e.g. no defib action), so
  once VT/VF triggers there's no way back in-engine.
- Rhythm/no-flow trigger thresholds are placeholders (60s/150s/300s
  hypoxia, 20s/45s no-flow) — real trigger logic is a clinical call, not
  an engineering one.

## Clinical Event / Complication System
`src/core/clinical-events.mjs` adds the reusable clinical consequence layer between trainee actions and displayed patient state.

Design doctrine: **model clinically plausible cause-and-effect, not exhaustive human physiology.** Numerical monitor/lab values communicate a clinical state; they are not intended to prove it mathematically.

A scenario may declare `clinicalEvents`. Each event has:
- an `initialState` and optional `activeAtStart`
- contextual `actionRules`
- optional time-based state transitions
- outcome classes: `preferred`, `acceptable`, `temporizing`, `ineffective`, `harmful`, `critical-error`
- narrative feedback/rationale
- score changes
- patches to internal state/settings
- event-state transitions and resolution

The same trainee action can therefore have different consequences in different complications. Existing sandbox actions are already bridged into this layer for volume boluses, RPM increases, and sweep increases. A generic `clinical-action` action supports future interventions without putting complication logic into the physiology module.

`src/data/scenario-hypovolemia.json` is the first proof-of-concept complication case. In its active preload-limitation state:
- volume bolus is therapeutic and resolves the event
- increasing RPM is harmful and worsens the state
- increasing sweep is ineffective
- unrelated/unmodeled actions produce a neutral "no meaningful clinical change" response rather than invented physiology

Clinical-event state, score, history, and outcomes survive snapshot/restore.


## Clinical Event / Complication System

The simulator now supports reusable contextual complication definitions. The same trainee action can be classified differently according to the hidden clinical cause. Two reference cases are included:

- `scenario-hypovolemia.json`: volume is definitive therapy for preload limitation.
- `scenario-tamponade.json`: volume is only temporizing; assessment/echo can establish the diagnosis, and decompression is definitive.

Timed event progression is relative to **time entered into the current clinical state**, not merely time since the complication first activated. This allows temporary stabilization to expire predictably and survives snapshot/restore.

## v0.3 Educator → Learner workflow

This branch adds the architectural pivot discussed after the Clinical Event/Complication proof:

- `src/core/scenario-builder.mjs` — canonical educator setup schema and learning-objective catalog. Educator-generated scenarios use `requiresManualStart: true`.
- `src/core/information-pipeline.mjs` — generic request/acquisition/result/interpretation pipeline with explicit timing placeholders and acquisition blockers.
- `ecmo-educator-workflow.jsx` (package root parent) — visual prototype showing the standard setup form transitioning into the dark learner cockpit with Start boundary and Information/Results feed.

### Diagnostic timing doctrine
Do not hard-code final turnaround claims yet. Timing is separated into:
1. request → acquisition ready
2. acquisition → raw result/image available
3. raw result → formal interpretation

Portable X-ray demonstrates the intended behavior: bedside acquisition can be blocked by an `active-code` context, the raw image can be available immediately after acquisition, and the formal interpretation can arrive later.

## Clinical Knowledge Registry (v0.4)

Educator-generated scenarios are declarative. They reference reusable clinical knowledge by ID through `clinicalKnowledgePlan`; they do not contain copied complication behavior.

The default registry is in `src/core/clinical-knowledge-registry.mjs` and currently indexes:

- complications
- learner actions
- observations/information sources
- learning objectives and concept-to-knowledge mappings

`circuit-sandbox.mjs` resolves registry-backed complication definitions at session creation. Legacy scenarios with embedded `clinicalEvents` remain supported for compatibility.

## v0.5 learner disclosure and trigger architecture

Learner-facing output is intentionally narrower than instructor/debug output. Use `session.presentation()` for the learner cockpit and `session.instructorPresentation()` only for educator/debug/debrief tooling. Do not render instructor payloads in the learner HUD.

Educator-generated clinical complications are activated through `clinicalKnowledgePlan.triggerPolicies`. Trigger policies are generic activation rules; complication behavior remains centralized in the Clinical Knowledge Registry.

## Scenario Runtime Director (v0.6)

`src/core/scenario-runtime-director.mjs` sits between generic trigger eligibility and clinical-event activation. It queues eligible complication IDs and decides when to release them based on neutral orchestration constraints (simulation mode, event spacing, and unresolved-event concurrency). It deliberately knows nothing about the medical behavior of any complication.

Flow:
`educator setup -> knowledge IDs -> trigger eligibility -> runtime director -> clinical event activation -> learner-visible consequences`

Do not put diagnosis-specific trigger logic or complication behavior into the runtime director.

## v0.7: Emergent complications and clinical endpoints

The engine now separates four distinct concepts:

1. **Clinical knowledge** — what a complication/action means.
2. **Eligibility** — whether planned or learner-created conditions make a complication possible.
3. **Runtime direction** — when an eligible complication is allowed to enter the live case.
4. **Clinical trajectory/endpoints** — whether the aggregate patient course is recovering, deteriorating, in arrest, stabilized, terminal, or manually ended.

Patient death and stabilization are never determined by score. Endpoint timing values are configurable simulation-policy placeholders rather than claims of exact clinical timing.


## v0.8 Clinical significance

The engine now includes a configurable Clinical Significance Layer. It is designed to suppress trivial biological noise and prioritize changes that alter clinical reasoning, urgency, management, or outcome. The first reusable interaction is position-dependent cannula drainage compromise triggered by patient repositioning when that hidden condition is present.


## v0.9 Low-flow differential

The reusable low-flow library now differentiates preload loss, tamponade, position-sensitive cannula compromise, mechanical cannula/tubing kink, circuit obstruction, and pump-support failure. A project-wide clinically meaningful complication inventory is included at the package root.


## v1.0 Troubleshooting scenario pack

The project now includes a six-case low-flow troubleshooting pack and a blind differential launcher. Use `src/core/troubleshooting-scenario-library.mjs` to create engine-backed cases. `../ecmo-low-flow-troubleshooting-pack.jsx` is the visual educator/learner launcher prototype that drives the same engine.


## v1.1 Full clinical knowledge library

All 36 normalized complication families now have registry-backed clinical knowledge/state definitions. The low-flow pack remains the current bench-ready pack; the rest are knowledge-ready and can be instantiated through `src/core/clinical-module-scenario-library.mjs` for subsequent dedicated cue/timing/threshold validation.


## v2.0 Clinical spine repair

The engine now includes a Clinical Consequence Engine and Observation Resolver. Hidden complication/support state is coupled to meaningful monitor/lab consequences, assessments return actionable findings, and structured handoff/recent-event context is available to learners. The standalone bench build is generated from the canonical modular engine rather than a separate handwritten mini-runtime.


## v2.1 Explicit patient position state

Patient repositioning is now modeled as state rather than a magic action. The learner selects an actual position, the scenario stores current/previous position, and reusable clinical knowledge evaluates the consequence. `Restore previous position` is simply a convenience command that selects the documented previous position.
