import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';

test('bubble detector is present and continuously exposed in every cockpit',()=>{
 for(const scenario of [buildCircuitEmergencyScenario('ce-03-oxygenator'),buildVvEcmoScenario('vv-01-recirculation')]){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});const p=s.presentation();
  assert.equal(p.bubbleSafety.detectorPresent,true);
  assert.ok(['clear','alarm'].includes(p.bubbleSafety.status));
  assert.equal(typeof p.bubbleSafety.alarmActive,'boolean');
  assert.ok(p.bubbleSafety.location);
 }
});

test('bubble alarm activates circuit safety interlock and collapses measured flow',()=>{
 const scenario=buildCircuitEmergencyScenario('ce-01-air-emergency');
 const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});
 const before=s.presentation();
 assert.equal(before.bubbleSafety.alarmActive,false);
 // Existing air-emergency pathway drives the detector/alarm state.
 s.submit({type:'clinical-action',actionId:'inspect-for-air'});
 const p=s.presentation();
 if(p.bubbleSafety.alarmActive){
   assert.equal(p.bubbleSafety.circuitInterlockActive,true);
   assert.equal(p.circuit.circuitFlowLpm,0);
 }
});

test('standalone visibly renders bubble detector status and location',()=>{
 const html=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
 assert.match(html,/id="bubbleDetector"/);
 assert.match(html,/BUBBLE DETECTOR/);
 assert.match(html,/bubbleSafety/);
 assert.match(html,/ALARM/);
 assert.match(html,/CLEAR/);
});
