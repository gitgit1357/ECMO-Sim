import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync(new URL('../../B7_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B7_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
test('B7 covers eight cross-cutting primitives',()=>assert.equal(d.length,8));
test('transport rule remains program-specific rather than hard-coded as one universal checklist',()=>{const x=r.find(x=>x.ruleId.endsWith('transport-procedural-operational'));assert.match(x.disposition['exact operational sequence'],/program specific/i);});
test('stroke rule does not encode universal thrombolysis',()=>{const x=r.find(x=>x.ruleId.endsWith('thromboembolism-stroke'));assert.match(x.disposition['universal thrombolysis rule'],/not encoded/i);});
test('CKRT rule avoids universal connection configuration',()=>{const x=r.find(x=>x.ruleId.endsWith('ckrt-ecmo-interaction'));assert.match(x.disposition['universal connection configuration'],/not encoded/i);});
test('abdominal and treatment/transfusion rules remain partial',()=>{for(const id of ['abdominal-ischemic-compartment','treatment-transfusion-adverse']){const x=d.find(x=>x.ruleId.endsWith(id));assert.equal(x.changeAuthorized,false);}});
