import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v3.1/index.html',import.meta.url),'utf8');
test('M11 shell connects educator, learner, and admin/content-governance surfaces',()=>{
 for(const x of ['EDUCATOR CREATOR','ADMIN / VALIDATION','LEARNER COCKPIT','createEducatorScenario','validationCatalog','validationSummary','RETURN TO EDUCATOR LAUNCHER'])assert.match(h,new RegExp(x));
});
test('admin shell clearly prevents false competency-ready claims',()=>{assert.match(h,/none may be labeled competency-ready until clinical and timing validation are complete/i);assert.match(h,/validationSummary:getValidationSummary/);assert.match(h,/validationSummaryEl\.innerHTML/);});
