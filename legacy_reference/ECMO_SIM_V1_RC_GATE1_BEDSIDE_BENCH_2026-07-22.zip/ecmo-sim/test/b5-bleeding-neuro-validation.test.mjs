import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const l=JSON.parse(fs.readFileSync(new URL('../../B5_BLEEDING_NEURO_ANTICOAG_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
test('B5 discovers actual bleeding/neurologic registry primitives',()=>{assert.ok(l.length>=2);assert.ok(l.some(x=>/bleed|hemorr/i.test(x.ruleId)));});
test('B5 requires cross-guideline review',()=>assert.ok(l.every(x=>x.crossGuidelineReviewRequired===true)));
test('B5 includes anticoagulation governance for hemorrhagic/neuro rules',()=>assert.ok(l.every(x=>x.elsoDomain==='anticoagulation'||x.secondaryDomains.includes('anticoagulation'))));
test('B5 passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(l);assert.equal(v.valid,true,v.errors.join(';'));});
