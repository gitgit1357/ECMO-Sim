import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const reg=JSON.parse(fs.readFileSync(new URL('../../clinical-source-registry.json',import.meta.url),'utf8'));
test('institutional gaps default to ELSO governance in registry',()=>{
 assert.match(reg.policyClarification,/ELSO.*govern.*institutional gaps/i);
 assert.ok(reg.rules.length>0);
 assert.ok(reg.rules.every(r=>r.governingAuthority==='elso'));
 assert.ok(reg.rules.every(r=>r.elsoSource));
});
test('ELSO governance assignment does not falsely mark numeric rules clinically validated',()=>{
 assert.ok(reg.rules.every(r=>r.clinicallyValidated===false));
 assert.ok(reg.rules.every(r=>/pending-rule-level-extraction-and-review/.test(r.status)));
});
