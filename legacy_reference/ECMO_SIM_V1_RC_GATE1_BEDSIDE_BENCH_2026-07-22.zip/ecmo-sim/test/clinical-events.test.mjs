import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { createClinicalEventSystem } from '../src/core/clinical-events.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

const hypovolemiaScenario = JSON.parse(fs.readFileSync(new URL('../src/data/scenario-hypovolemia.json', import.meta.url)));
const tamponadeScenario = JSON.parse(fs.readFileSync(new URL('../src/data/scenario-tamponade.json', import.meta.url)));

test('clinical event maps an action to a contextual therapeutic outcome', () => {
  const internal = { cvpBaseline: 2, mapBaseline: 30, trueLatent: { lactateMmolL: 5 } };
  const system = createClinicalEventSystem(hypovolemiaScenario.clinicalEvents);
  const outcome = system.evaluateAction('volume-bolus', { timeSec: 10, internal, settings: {} });
  assert.equal(outcome.outcome, 'preferred');
  assert.equal(outcome.resolved, true);
  assert.equal(internal.cvpBaseline, 7);
  assert.equal(system.presentation().score, 15);
});

test('same complication can classify a wrong intervention as harmful', () => {
  const internal = { cvpBaseline: 2, mapBaseline: 34, trueLatent: { lactateMmolL: 4.8 } };
  const system = createClinicalEventSystem(hypovolemiaScenario.clinicalEvents);
  const outcome = system.evaluateAction('increase-rpm', { timeSec: 10, internal, settings: {} });
  assert.equal(outcome.outcome, 'harmful');
  assert.equal(internal.cvpBaseline, 1);
  assert.equal(internal.mapBaseline, 31);
  assert.equal(system.snapshot().active['hypovolemia'].state, 'worsened');
});

test('sandbox wires existing volume action through clinical event system', () => {
  const session = circuitSandboxEngine.createSession({ scenario: hypovolemiaScenario });
  assert.equal(session.snapshot().clinicalEventState.active['hypovolemia'].state, 'decompensating');
  const result = session.submit({ type: 'bolus-volume', mlPerKg: 10 });
  assert.equal(result.status, 'applied');
  assert.match(result.feedback, /chatter resolves/i);
  assert.equal(session.snapshot().clinicalEventState.active['hypovolemia'].resolvedAtSec != null, true);
});

test('sandbox classifies increasing RPM contextually and persists event state through snapshot restore', () => {
  const session = circuitSandboxEngine.createSession({ scenario: hypovolemiaScenario });
  const result = session.submit({ type: 'set-param', param: 'pumpRpm', value: 1500 });
  assert.equal(result.status, 'applied');
  const restored = circuitSandboxEngine.createSession({ scenario: hypovolemiaScenario, snapshot: session.snapshot() });
  assert.equal(restored.snapshot().clinicalEventState.active['hypovolemia'].state, 'worsened');
  assert.equal(restored.instructorPresentation().clinicalEvents.score, -10);
});

test('generic clinical actions default to neutral when no active rule handles them', () => {
  const session = circuitSandboxEngine.createSession({ scenario: hypovolemiaScenario });
  const result = session.submit({ type: 'clinical-action', actionId: 'inspect-pupils' });
  assert.equal(result.status, 'no-specific-effect');
  assert.match(result.feedback, /no meaningful clinical change/i);
});


test('same volume action diverges by hidden cause: therapeutic in hypovolemia, only temporizing in tamponade', () => {
  const hypovolemia = circuitSandboxEngine.createSession({ scenario: hypovolemiaScenario });
  const tamponade = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  const h = hypovolemia.submit({ type: 'bolus-volume', mlPerKg: 10 });
  const t = tamponade.submit({ type: 'bolus-volume', mlPerKg: 10 });
  assert.equal(h.status, 'applied');
  assert.equal(t.status, 'applied');
  assert.equal(h.clinicalOutcome, undefined);
  assert.equal(t.clinicalOutcome, undefined);
  assert.equal(hypovolemia.snapshot().clinicalEventState.active['hypovolemia'].resolvedAtSec != null, true);
  assert.equal(tamponade.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'temporized');
});

test('tamponade diagnostic path can progress from assessment to echo confirmation to definitive resolution', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  const assess = session.submit({ type: 'clinical-action', actionId: 'assess-hemodynamics' });
  assert.equal(assess.status, 'applied');
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'suspected');
  const echo = session.submit({ type: 'clinical-action', actionId: 'order-echo' });
  assert.equal(echo.status, 'applied');
  assert.match(echo.feedback, /confirming tamponade/i);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'diagnosed');
  const definitive = session.submit({ type: 'clinical-action', actionId: 'pericardial-decompression' });
  assert.equal(definitive.status, 'applied');
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].resolvedAtSec != null, true);
  assert.equal(session.instructorPresentation().clinicalEvents.score, 37);
});

test('tamponade temporizing benefit expires based on time in state, not time since complication activation', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  session.advance(600); // complication has been active for a long time
  const volume = session.submit({ type: 'bolus-volume', mlPerKg: 10 });
  assert.equal(volume.status, 'applied');
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'temporized');
  session.advance(119);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'temporized');
  session.advance(1);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'decompensating');
});

test('tamponade state-entry timer survives snapshot restore', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  session.advance(300);
  session.submit({ type: 'bolus-volume', mlPerKg: 10 });
  session.advance(60);
  const restored = circuitSandboxEngine.createSession({ scenario: tamponadeScenario, snapshot: session.snapshot() });
  assert.equal(restored.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'temporized');
  restored.advance(59);
  assert.equal(restored.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'temporized');
  restored.advance(1);
  assert.equal(restored.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'decompensating');
});

test('untreated worsened tamponade can progress through critical deterioration to arrest', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  const rpm = session.submit({ type: 'set-param', param: 'pumpRpm', value: 1600 });
  assert.equal(rpm.status, 'applied');
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'worsened');
  session.advance(60);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'critical');
  session.advance(90);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'arrest');
});


test('hidden complication identity is not exposed through trainee presentation, submit outcome, or log', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  const initial = JSON.stringify(session.presentation()).toLowerCase();
  assert.equal(initial.includes('tamponade'), false);
  const action = session.submit({ type: 'clinical-action', actionId: 'assess-hemodynamics' });
  assert.equal(action.clinicalOutcome, undefined);
  assert.equal(action.rationale, undefined);
  assert.equal(['preferred','acceptable','temporizing','ineffective','harmful','critical-error'].includes(action.status), false);
  const after = JSON.stringify(session.presentation()).toLowerCase();
  assert.equal(after.includes('postoperative-tamponade'), false);
  assert.equal(after.includes('tamponade'), false);
});

test('critical tamponade remains rescuable with emergency definitive treatment', () => {
  const session = circuitSandboxEngine.createSession({ scenario: tamponadeScenario });
  session.submit({ type: 'set-param', param: 'pumpRpm', value: 1600 });
  session.advance(60);
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state, 'critical');
  const rescue = session.submit({ type: 'clinical-action', actionId: 'pericardial-decompression' });
  assert.equal(rescue.status, 'applied');
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].resolvedAtSec != null, true);
});
