import test from 'node:test';
import assert from 'node:assert/strict';
import { buildLowFlowTroubleshootingScenario } from '../src/core/troubleshooting-scenario-library.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

test('position-dependent low-flow case begins with learner-known recent turn context', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  const p=s.presentation();
  assert.match(p.handoff.currentConcern,/recent turn/i);
  assert.ok(p.recentEvents.some(x=>/turned|repositioned/i.test(x.text)));
});

test('severe sustained low flow produces progressive coherent monitor deterioration', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  s.submit({type:'start-scenario'});
  const start=s.presentation();
  assert.ok(start.circuit.flowIndexMlKgMin < 60);
  assert.equal(start.monitored.hr,120);
  assert.equal(start.monitored.map,50);

  s.advance(120);
  const later=s.presentation();
  assert.ok(later.monitored.map <= 45, `expected meaningful MAP decline, got ${later.monitored.map}`);
  assert.ok(later.monitored.hr >= 128, `expected compensatory HR change, got ${later.monitored.hr}`);
  // In this VA profile native pulmonary contribution is preserved, so saturation may remain normal even while perfusion deteriorates.
  assert.ok(later.monitored.spo2 >= 90, `oxygenation should not be forced to fall merely because VA flow is low; got ${later.monitored.spo2}`);
  assert.equal(s.instructorPresentation().trajectory.last.label,'critical');
});

test('assessment actions return useful positive or negative findings instead of anonymous no-change', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  s.submit({type:'start-scenario'});
  const pump=s.submit({type:'clinical-action',actionId:'assess-pump-function'}).feedback;
  const circuit=s.submit({type:'clinical-action',actionId:'inspect-circuit-path'}).feedback;
  const drainage=s.submit({type:'clinical-action',actionId:'inspect-drainage-cannula'}).feedback;
  assert.match(pump,/powered and running/i);
  assert.match(circuit,/no external tubing kink/i);
  assert.match(drainage,/drainage is unstable/i);
  for (const msg of [pump,circuit,drainage]) assert.doesNotMatch(msg,/No meaningful clinical change/i);
});

test('restoring prior position recovers flow and patient monitor trends toward recovery', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  s.submit({type:'start-scenario'});
  s.advance(120);
  const bad=s.presentation();
  const r=s.submit({type:'clinical-action',actionId:'restore-prior-position'});
  assert.match(r.feedback,/flow returns toward/i);
  const immediate=s.presentation();
  assert.ok(immediate.circuit.flowIndexMlKgMin > bad.circuit.flowIndexMlKgMin * 2.5);
  s.advance(60);
  const recovered=s.presentation();
  assert.ok(recovered.monitored.map > bad.monitored.map);
  assert.ok(recovered.monitored.hr < bad.monitored.hr);
});
