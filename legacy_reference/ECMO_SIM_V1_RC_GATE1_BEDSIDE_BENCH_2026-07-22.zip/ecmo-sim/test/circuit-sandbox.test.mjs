import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import scenario from '../src/data/scenario-example.json' with { type: 'json' };

test('epinephrine bump is reflected on the monitor immediately (within one short tick)', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  const before = session.presentation().monitored.hr;
  session.submit({ type: 'set-param', param: 'epiMcgKgMin', value: 0.15 });
  session.advance(15); // 15 simulated seconds — a monitor doesn't wait for a lab
  const after = session.presentation().monitored.hr;
  assert.ok(after > before, `expected HR to rise immediately after epi increase, got ${before} -> ${after}`);
});

test('sweep gas increase is invisible on every monitor with no tcCO2 equipped, until an ABG results', () => {
  const session = circuitSandboxEngine.createSession({ scenario }); // scenario has transcutaneousCO2: false
  session.submit({ type: 'set-param', param: 'sweepGasLpm', value: 6 });
  session.advance(60);

  const mid = session.presentation();
  assert.deepEqual(mid.surrogateReadings, {}, 'no surrogate CO2 reading should be exposed without tcCO2 equipment');
  assert.equal(mid.resultedLabs.length, 0, 'no lab has been ordered yet, so nothing should be resulted');

  session.submit({ type: 'order-lab', labType: 'abg' });
  const justOrdered = session.presentation();
  assert.equal(justOrdered.pendingLabs.length, 1, 'ABG should be pending immediately after ordering');
  assert.equal(justOrdered.resultedLabs.length, 0, 'ABG should not be resulted before turnaround elapses');

  session.advance(60); // not enough time yet (ABG turnaround default is 4 min)
  assert.equal(session.presentation().resultedLabs.length, 0, 'ABG should still be pending before turnaround elapses');

  session.advance(4 * 60 + 1); // now past turnaround
  const resulted = session.presentation();
  assert.equal(resulted.resultedLabs.length, 1, 'ABG should be resulted once turnaround has elapsed');
  assert.ok(resulted.resultedLabs[0].values.paco2 < 40, 'the resulted PaCO2 should reflect the higher sweep gas flow');
});

test('flow is derived from RPM (not directly settable), and is weight-indexed for the readout', () => {
  const heavier = { ...scenario, initialInternal: { ...scenario.initialInternal, weightKg: 8 } }; // same RPM/cannula, double the weight
  const lightSession = circuitSandboxEngine.createSession({ scenario });
  const heavySession = circuitSandboxEngine.createSession({ scenario: heavier });
  const light = lightSession.presentation();
  const heavy = heavySession.presentation();
  assert.equal(light.circuit.measuredFlowLpm, heavy.circuit.measuredFlowLpm, 'same RPM/cannula/CVP should produce the same absolute flow regardless of weight');
  assert.ok(heavy.circuit.flowIndexMlKgMin < light.circuit.flowIndexMlKgMin, 'the heavier patient should read a lower weight-indexed flow for the same absolute flow');
  assert.ok(Math.abs(light.circuit.flowIndexMlKgMin - heavy.circuit.flowIndexMlKgMin * 2) < 5, 'roughly double weight should roughly halve the index');
});

test('flow shows diminishing returns as RPM rises, bounded by the cannula ceiling', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'set-param', param: 'pumpRpm', value: 500 });
  const low = session.presentation().circuit.measuredFlowLpm;
  session.submit({ type: 'set-param', param: 'pumpRpm', value: 2500 });
  const mid = session.presentation().circuit.measuredFlowLpm;
  session.submit({ type: 'set-param', param: 'pumpRpm', value: 4000 });
  const high = session.presentation().circuit.measuredFlowLpm;
  const firstGain = mid - low;
  const secondGain = high - mid;
  assert.ok(secondGain < firstGain, `expected diminishing returns, got gains of ${firstGain} then ${secondGain}`);
  assert.ok(high < session.presentation().circuit.maxFlowForCannula + 0.05, 'flow should stay bounded near the cannula ceiling even at very high RPM');
});

test('a bigger cannula raises the achievable flow ceiling at the same RPM', () => {
  const biggerCannula = { ...scenario, initialInternal: { ...scenario.initialInternal, cannulaFr: 14 } };
  const smallSession = circuitSandboxEngine.createSession({ scenario });
  const bigSession = circuitSandboxEngine.createSession({ scenario: biggerCannula });
  assert.ok(bigSession.presentation().circuit.measuredFlowLpm > smallSession.presentation().circuit.measuredFlowLpm, 'a larger cannula should allow more flow at the same RPM');
});

test('the bubble detector alarm stops the pump — flow and all three pressures collapse to zero — and clearing it resumes', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  const before = session.presentation().circuit;
  assert.ok(before.measuredFlowLpm > 0, 'sanity check: flow should be nonzero before the alarm');

  session.submit({ type: 'trigger-bubble-alarm' });
  const duringAlarm = session.presentation();
  assert.equal(duringAlarm.bubbleDetector, 'alarm');
  assert.equal(duringAlarm.circuit.measuredFlowLpm, 0);
  assert.equal(duringAlarm.circuit.venousPressure, 0);
  assert.equal(duringAlarm.circuit.postOxyPressure, 0);

  session.submit({ type: 'clear-bubble-alarm' });
  const afterClear = session.presentation();
  assert.equal(afterClear.bubbleDetector, 'clear');
  assert.ok(afterClear.circuit.measuredFlowLpm > 0, 'flow should resume once the alarm is cleared');
});

test('rhythm has no player-facing set action — only sustained hypoxia or loss of flow can change it', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  const attempt = session.submit({ type: 'set-rhythm', rhythm: 'vfib' });
  assert.equal(attempt.status, 'invalid', 'there should be no way for a player action to directly set rhythm');
  assert.equal(session.presentation().rhythm, 'sinus');
});

test('sustained critical hypoxia escalates rhythm sinus -> junctional -> vtach, with an announcement', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'set-param', param: 'fdo2Percent', value: 21 }); // drop oxygenation hard
  session.advance(65); // past the 60s hypoxia-to-junctional threshold, assuming SpO2 is now under the ceiling
  const afterFirst = session.presentation();
  // Only assert the escalation happened if hypoxia actually crossed the SpO2 ceiling at this FdO2 — guard with a direct check.
  if (afterFirst.monitored.spo2 < 60) {
    assert.equal(afterFirst.rhythm, 'junctional');
    assert.ok(afterFirst.rhythmAnnouncement && afterFirst.rhythmAnnouncement.includes('junctional'));
    session.advance(90); // total ~155s of hypoxia, past the 150s hypoxia-to-vtach threshold
    assert.equal(session.presentation().rhythm, 'vtach');
  }
});

test('loss of circuit flow (bubble alarm) escalates rhythm toward vtach then vfib, and never auto-reverts', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'trigger-bubble-alarm' });
  session.advance(25); // past the 20s no-flow-to-vtach threshold
  assert.equal(session.presentation().rhythm, 'vtach');
  session.advance(25); // total 50s, past the 45s no-flow-to-vfib threshold
  assert.equal(session.presentation().rhythm, 'vfib');
  session.submit({ type: 'clear-bubble-alarm' });
  session.advance(60); // flow restored, but rhythm should NOT auto-revert
  assert.equal(session.presentation().rhythm, 'vfib', 'rhythm should never auto-revert without a real intervention, which this engine does not model yet');
});

test('bivalirudin dose is reflected in DTT only after ordering the lab and waiting turnaround, matching a real calibration point', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'set-param', param: 'bivalirudinMgKgHr', value: 0.31 }); // Frank's real neonatal case: 0.31 mg/kg/hr -> DTT 0.54
  session.advance(30);
  session.submit({ type: 'order-lab', labType: 'dtt' });
  const justOrdered = session.presentation();
  assert.equal(justOrdered.resultedLabs.length, 0, 'DTT should not be resulted before turnaround elapses');
  session.advance(25 * 60 + 1);
  const result = session.presentation().resultedLabs.find((o) => o.type === 'dtt');
  assert.ok(result, 'DTT should be resulted after turnaround');
  assert.ok(Math.abs(result.values.dttMcgMl - 0.54) < 0.02, `expected DTT near 0.54 at 0.31 mg/kg/hr, got ${result.values.dttMcgMl}`);
});

test('HepPTT, TEG, and ATIII are orderable labs that follow the same order-then-wait rule', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'order-lab', labType: 'hepptt' });
  session.submit({ type: 'order-lab', labType: 'teg' });
  session.submit({ type: 'order-lab', labType: 'atiii' });
  const justOrdered = session.presentation();
  assert.equal(justOrdered.pendingLabs.length, 3, 'all three should be pending immediately after ordering');
  session.advance(45 * 60 + 1); // past even the slowest (ATIII) turnaround
  const resulted = session.presentation().resultedLabs.map((o) => o.type).sort();
  assert.deepEqual(resulted, ['atiii', 'hepptt', 'teg'], 'all three should be resulted once their turnarounds have elapsed');
});

test('an auto-triggered checkpoint appears when a dTT results, and answering it clears it', () => {
  const session = circuitSandboxEngine.createSession({ scenario }); // scenario has dttRiskContext: 'standard', starting bival at 0.31 -> dTT 0.54
  session.submit({ type: 'order-lab', labType: 'dtt' });
  session.advance(25 * 60 + 1);

  const withCheckpoint = session.presentation();
  assert.ok(withCheckpoint.checkpoint, 'a checkpoint should auto-open once the dTT results');
  assert.equal(withCheckpoint.checkpoint.correctOption ?? undefined, undefined, 'the correct answer should not be leaked in the presentation');
  assert.equal(withCheckpoint.checkpoint.complete, false);

  const noChangeOption = withCheckpoint.checkpoint.options.find((o) => o.id === 'no-change');
  assert.ok(noChangeOption, 'no-change should be one of the presented options for a dTT of 0.54 (standard goal 0.5-1.0)');

  const answer = session.submit({ type: 'answer-checkpoint', optionId: 'no-change' });
  assert.equal(answer.status, 'accepted');
  assert.equal(session.presentation().checkpoint, null, 'the checkpoint should clear once answered');
});

test('answering a checkpoint does not spawn another one from the same lab result', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'order-lab', labType: 'dtt' });
  session.advance(25 * 60 + 1);
  session.submit({ type: 'answer-checkpoint', optionId: 'no-change' });
  session.advance(60); // time moving forward alone shouldn't resurrect the same checkpoint
  assert.equal(session.presentation().checkpoint, null);
});

test('a checkpoint round-trips through snapshot/restore mid-answer', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'order-lab', labType: 'dtt' });
  session.advance(25 * 60 + 1);
  const saved = session.snapshot();

  const restored = circuitSandboxEngine.createSession({ scenario, snapshot: saved });
  assert.ok(restored.presentation().checkpoint, 'the open checkpoint should survive a snapshot/restore round trip');
  const answer = restored.submit({ type: 'answer-checkpoint', optionId: 'no-change' });
  assert.equal(answer.status, 'accepted');
});

test('a scenario with transcutaneous CO2 equipped exposes PaCO2 as a real-time surrogate', () => {
  const equippedScenario = { ...scenario, equipment: { ...scenario.equipment, transcutaneousCO2: true } };
  const session = circuitSandboxEngine.createSession({ scenario: equippedScenario });
  session.submit({ type: 'set-param', param: 'sweepGasLpm', value: 6 });
  session.advance(10);
  const presentation = session.presentation();
  assert.ok('paco2Surrogate' in presentation.surrogateReadings, 'tcCO2-equipped scenario should expose a live PaCO2 surrogate without any lab order');
});

test('instructorPresentation exposes a debrief summary built from real session activity, hidden from the learner presentation', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'set-param', param: 'bivalirudinMgKgHr', value: 0.31 });
  session.submit({ type: 'order-lab', labType: 'dtt' });
  session.advance(25 * 60 + 1);
  session.submit({ type: 'answer-checkpoint', optionId: 'no-change' });

  const instructor = session.instructorPresentation();
  assert.ok(instructor.debrief, 'instructorPresentation should expose a debrief summary');
  assert.ok(instructor.debrief.entryCount > 0);
  assert.ok(Array.isArray(instructor.log) && instructor.log.length === instructor.debrief.entryCount, 'the full instructor log and the summary should agree on how much happened');

  const learnerPresentation = session.presentation();
  assert.ok(!('debrief' in learnerPresentation), 'the debrief summary is instructor-only, not part of the learner presentation');
});

test('a full debrief snapshot/restore round trip preserves the summary exactly', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'set-param', param: 'epiMcgKgMin', value: 0.1 });
  session.advance(30);
  const saved = session.snapshot();

  const restored = circuitSandboxEngine.createSession({ scenario, snapshot: saved });
  const before = session.instructorPresentation().debrief;
  const after = restored.instructorPresentation().debrief;
  assert.deepEqual(after, before);
});

test('learner presentation exposes availableActions derived from the registry, not a hardcoded list, and it changes with the scenario', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  const view = session.presentation();
  assert.ok(Array.isArray(view.availableActions));
  assert.ok(view.availableActions.length > 0);
  assert.ok(!view.availableActions.some((a) => a.category === 'ecmo-control'), 'RPM/sweep actions are already exposed via sliders, not buttons');
  for (const button of view.availableActions) {
    assert.equal(typeof button.id, 'string');
    assert.equal(typeof button.label, 'string');
  }
});

test('rhythm rescue is reachable end-to-end: escalate to vfib via loss of flow, then defibrillate back to sinus', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'trigger-bubble-alarm' }); // kills flow -> drives the no-flow rhythm escalation
  session.advance(50); // past the 45s no-flow-to-vfib threshold
  assert.equal(session.presentation().rhythm, 'vfib');

  session.submit({ type: 'clear-bubble-alarm' }); // restore flow so the rescue actually "sticks"
  const result = session.submit({ type: 'clinical-action', actionId: 'defibrillate' });
  assert.equal(result.status, 'applied');
  assert.equal(session.presentation().rhythm, 'sinus');
});

test('rescue actions are always offered as buttons, not only after something has already gone wrong', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  const ids = session.presentation().availableActions.map((a) => a.id);
  for (const rescueId of ['assess-rhythm', 'defibrillate', 'synchronized-cardioversion', 'administer-arrest-epinephrine', 'begin-chest-compressions']) {
    assert.ok(ids.includes(rescueId), `expected "${rescueId}" to always be available, not just after an arrest`);
  }
});

test('an inappropriate rescue action (defibrillating a normal sinus rhythm) is scored harmful and leaves the rhythm unchanged', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  assert.equal(session.presentation().rhythm, 'sinus');
  const result = session.submit({ type: 'clinical-action', actionId: 'defibrillate' });
  assert.equal(result.status, 'applied');
  assert.equal(session.presentation().rhythm, 'sinus', 'an inappropriate shock must not itself change the rhythm');

  const instructor = session.instructorPresentation();
  const rescueEntry = instructor.log.find((e) => e.kind === 'rhythm-rescue-action');
  assert.equal(rescueEntry.outcomeClass, 'harmful');
});

test('a rescue conversion recurs on the next tick if the underlying driver was never corrected — not a bug, a real consequence', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type: 'trigger-bubble-alarm' });
  session.advance(50);
  assert.equal(session.presentation().rhythm, 'vfib');

  // Defibrillate WITHOUT clearing the bubble alarm first — flow is still lost.
  session.submit({ type: 'clinical-action', actionId: 'defibrillate' });
  assert.equal(session.presentation().rhythm, 'sinus', 'the shock itself should still convert the rhythm');

  session.advance(50); // noFlowSeconds keeps accumulating since flow was never restored
  assert.equal(session.presentation().rhythm, 'vfib', 'an uncorrected cause should re-escalate rather than staying falsely stable');
});

test('the monitor reflects overall patient condition, not just hypoxia/no-flow: a case that reaches a death trajectory endpoint shows asystole, not sinus', () => {
  const session = circuitSandboxEngine.createSession({ scenario });
  // Drive a generic, sustained no-flow situation to force a death endpoint via the trajectory system.
  session.submit({ type: 'trigger-bubble-alarm' });
  session.advance(700); // long enough to cross both the rhythm no-flow ladder and the trajectory's cumulative-critical death threshold
  const view = session.presentation();
  if (session.instructorPresentation().trajectory.endpoint?.type === 'death') {
    assert.equal(view.rhythm, 'asystole', 'a dead patient must show a terminal rhythm on the monitor, not sinus');
  }
});
