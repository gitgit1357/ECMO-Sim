import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';

const air=JSON.parse(fs.readFileSync(new URL('../../B1_AIR_EMERGENCY_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
const hem=JSON.parse(fs.readFileSync(new URL('../../B1_HEMOLYSIS_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
const dossiers=JSON.parse(fs.readFileSync(new URL('../../B1_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));

test('air emergency retains source-control pathway and source review records massive-air safety',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});s.submit({type:'start-scenario'});
 assert.match(s.submit({type:'clinical-action',actionId:'inspect-for-air'}).feedback,/air/i);
 s.submit({type:'clinical-action',actionId:'isolate-air-source'});
 s.submit({type:'clinical-action',actionId:'manage-air-emergency'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['air-emergency'].state,'resolved');
 assert.match(air.sourceParaphrase.join(' '),/immediate circuit clamping/i);
 assert.match(air.sourceParaphrase.join(' '),/not be hand-cranked/i);
});

test('hemolysis evidence keeps cause-directed correction and no invented universal numeric threshold',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-05-hemolysis')});s.submit({type:'start-scenario'});
 assert.match(s.submit({type:'clinical-action',actionId:'assess-hemolysis'}).feedback,/hemolysis/i);
 s.submit({type:'clinical-action',actionId:'correct-hemolysis-source'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['hemolysis'].state,'resolved');
 assert.match(hem.simulatorComparison.numericHemolysisThreshold,/not added/i);
});

test('circuit-breach progression is promoted only after traceable source review and still awaits expert signoff',()=>{
 const d=dossiers.find(x=>x.ruleId==='complication:circuit-breach-hemorrhage');
 assert.equal(d.sourceContentReviewed,true);
 assert.equal(d.sourceApplicabilityConfirmed,true);
 assert.equal(d.changeAuthorized,true);
 assert.match(d.reviewerStatus,/expert-clinical-signoff/i);
});

test('air and hemolysis deterioration timings remain placeholders',()=>{
 assert.match(air.simulatorComparison["90SecondCriticalProgression"],/placeholder/i);
 assert.match(hem.simulatorComparison["300Then180SecondProgression"],/placeholder/i);
});
