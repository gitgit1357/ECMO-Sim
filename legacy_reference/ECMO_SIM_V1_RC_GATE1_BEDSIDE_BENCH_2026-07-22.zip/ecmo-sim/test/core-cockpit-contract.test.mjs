import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';

test('every scenario exposes always-on ECMO cockpit monitoring and controls independent of diagnosis',()=>{
 for(const scenario of [buildLowFlowTroubleshootingScenario('lf-01-preload'),buildVvEcmoScenario('vv-01-recirculation')]){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});const p=s.presentation();
  for(const k of ['pumpRpm','circuitFlowLpm','venousPressure','preOxyPressure','postOxyPressure','deltaP'])assert.ok(k in p.circuit,k);
  for(const k of ['hr','map','cvp','spo2','tempC','bp'])assert.ok(k in p.monitored,k);
  for(const k of ['hgbGdl','hctPercent','svo2Percent'])assert.ok(Number.isFinite(p.cdi[k]),k);
  for(const k of ['pumpRpm','flowTarget','sweepGasLpm','fdo2Percent','circuitClamp'])assert.equal(p.continuousControls[k],true,k);
 }
});
test('neonatal cockpit exposes pre/post ductal SpO2 and shunt flow when configured',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-01-preload')});s.submit({type:'start-scenario'});const p=s.presentation();
 assert.ok(Number.isFinite(p.monitored.preDuctalSpo2));assert.ok(Number.isFinite(p.monitored.postDuctalSpo2));assert.ok(Number.isFinite(p.circuit.shuntFlowLpm));
});
test('flow target can be changed immediately even when not the correct clinical action',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-01-preload')});s.submit({type:'start-scenario'});const before=s.presentation();
 const r=s.submit({type:'set-flow-target',flowIndexMlKgMin:150});const after=s.presentation();
 assert.equal(r.accepted,true);assert.notEqual(after.circuit.pumpRpm,before.circuit.pumpRpm);
});
test('sweep and FdO2 remain immediately adjustable in every scenario',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});
 assert.equal(s.submit({type:'set-param',param:'sweepGasLpm',value:6}).accepted,true);
 assert.equal(s.submit({type:'set-param',param:'fdo2Percent',value:80}).accepted,true);
 assert.equal(s.presentation().settings.fdo2Percent,80);
});
test('circuit clamp is always available and interrupts measured circuit flow immediately',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});
 assert.ok(s.presentation().circuit.circuitFlowLpm>0);
 s.submit({type:'set-circuit-clamp',clamped:true});assert.equal(s.presentation().circuit.circuitFlowLpm,0);assert.equal(s.presentation().circuit.flowIndexMlKgMin,0);assert.equal(s.presentation().circuit.clamped,true);
 s.submit({type:'set-circuit-clamp',clamped:false});assert.ok(s.presentation().circuit.circuitFlowLpm>0);
});
