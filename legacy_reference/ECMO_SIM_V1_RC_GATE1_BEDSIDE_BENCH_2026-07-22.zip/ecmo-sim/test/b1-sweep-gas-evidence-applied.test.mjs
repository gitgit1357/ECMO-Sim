import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
const ev=JSON.parse(fs.readFileSync(new URL('../../B1_SWEEP_GAS_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));

test('sweep-gas evidence retains gas-path verification and restoration as preferred pathway',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-04-sweep-gas')});s.submit({type:'start-scenario'});
 let r=s.submit({type:'clinical-action',actionId:'increase-sweep'});assert.match(r.feedback,/does not help/i);
 r=s.submit({type:'clinical-action',actionId:'verify-sweep-gas'});assert.match(r.feedback,/loss or interruption/i);
 r=s.submit({type:'clinical-action',actionId:'restore-sweep-gas'});assert.match(r.feedback,/CO2 removal recovers/i);
});
test('sweep-gas source review records manufacturer-limit safety without inventing numeric limit',()=>{
 assert.match(ev.simulatorComparison.manufacturerLimitSafety,/added/i);
 assert.equal(ev.sourceContentReviewed,true);
 assert.match(ev.simulatorComparison.deteriorationTiming150Then90Sec,/placeholder/i);
});
