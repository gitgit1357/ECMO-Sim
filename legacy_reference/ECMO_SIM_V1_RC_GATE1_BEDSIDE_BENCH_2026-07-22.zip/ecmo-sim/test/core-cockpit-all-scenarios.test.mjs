import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const groups=[
 [buildLowFlowTroubleshootingScenario,['lf-01-preload','lf-02-tamponade','lf-03-position','lf-04-kink','lf-05-circuit-obstruction','lf-06-pump-failure']],
 [buildCircuitEmergencyScenario,['ce-01-air-emergency','ce-02-circuit-breach','ce-03-oxygenator','ce-04-sweep-gas','ce-05-hemolysis','ce-06-major-bleeding']],
 [buildVaEcmoScenario,['va-01-differential-hypoxemia','va-02-lv-distension','va-03-limb-ischemia','va-04-thrombosis']],
 [buildVvEcmoScenario,['vv-01-recirculation','vv-02-oxygenator','vv-03-gas-exchange','vv-04-pneumothorax','vv-04-airway']],
 [buildPatientEmergencyScenario,['pe-01-arrhythmia-arrest','pe-02-ich','pe-03-vasoplegia','pe-03-sepsis','pe-04-aki-fluid','pe-05-metabolic','pe-06-ph-crisis']]
];
for(const [builder,ids] of groups)for(const id of ids)test(`${id} inherits universal ECMO cockpit contract`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:builder(id)});s.submit({type:'start-scenario'});const p=s.presentation();
 assert.ok(p.continuousControls&&Object.values(p.continuousControls).every(Boolean));
 assert.ok(p.monitored.bp&&Number.isFinite(p.monitored.bp.systolic)&&Number.isFinite(p.monitored.bp.diastolic)&&Number.isFinite(p.monitored.bp.map));
 for(const k of ['circuitFlowLpm','venousPressure','preOxyPressure','postOxyPressure','deltaP'])assert.ok(Number.isFinite(p.circuit[k]),k);
 for(const k of ['hgbGdl','hctPercent','svo2Percent'])assert.ok(Number.isFinite(p.cdi[k]),k);
});
