import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { buildCircuitEmergencyScenario } from '../src/core/circuit-emergency-scenario-library.mjs';

const cases=[
 ['ce-01-air-emergency',['inspect-for-air','isolate-air-source','manage-air-emergency']],
 ['ce-02-circuit-breach',['control-circuit-breach','restore-circuit-integrity']],
 ['ce-04-sweep-gas',['verify-sweep-gas','restore-sweep-gas']],
 ['ce-05-hemolysis',['assess-hemolysis','correct-hemolysis-source']],
 ['ce-06-major-bleeding',['control-major-bleeding','reduce-anticoagulation','control-major-bleeding']]
];

for(const [id,actions] of cases){
 test(`${id} has a learner-neutral evidence-to-definitive-management resolution path`,()=>{
   const scenario=buildCircuitEmergencyScenario(id);
   assert.ok((scenario.recentEvents||[]).length>=2);
   const session=circuitSandboxEngine.createSession({scenario});
   session.submit({type:'start-scenario'});
   for(const actionId of actions){
     const r=session.submit({type:'clinical-action',actionId});
     assert.ok(r.feedback,`${id} ${actionId} should return feedback`);
   }
   const active=session.instructorPresentation().clinicalEventState.active;
   const comp=scenario.educatorScenarioMetadata.intendedComplicationId;
   assert.equal(active[comp].state,'resolved',`${id} should resolve after definitive pathway`);
 });
}

test('air emergency worsens rapidly if untreated',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});
 s.submit({type:'start-scenario'}); s.advance(91);
 assert.equal(s.instructorPresentation().clinicalEventState.active['air-emergency'].state,'critical');
});

test('sweep gas failure worsens hypercarbia if untreated',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-04-sweep-gas')});
 s.submit({type:'start-scenario'}); s.advance(151);
 assert.equal(s.instructorPresentation().clinicalEventState.active['sweep-gas-failure'].state,'worsened');
});

test('major bleeding permits anticoagulation reassessment after initial hemorrhage control',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-06-major-bleeding')});
 s.submit({type:'start-scenario'});
 s.submit({type:'clinical-action',actionId:'control-major-bleeding'});
 const r=s.submit({type:'clinical-action',actionId:'reduce-anticoagulation'});
 assert.match(r.feedback,/Anticoagulation is reassessed/i);
});
