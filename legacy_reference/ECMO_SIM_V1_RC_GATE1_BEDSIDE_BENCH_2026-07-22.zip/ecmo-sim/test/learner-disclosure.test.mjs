import test from 'node:test';
import assert from 'node:assert/strict';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { assertNoDiagnosticLeakage } from '../src/core/learner-disclosure.mjs';

const setup = {
  patient:{population:'neonatal',weightKg:4,diagnosis:'HLHS',procedure:'Norwood/Sano'},
  ecmo:{mode:'VA',cannulation:'central',cannulaFr:10,pumpRpm:1200,sweepGasLpm:2,fdo2Percent:50},
  startingCondition:{hemodynamics:'unstable',renalFunction:'normal'},
  education:{primaryObjective:'low-flow-troubleshooting',concepts:['tamponade-recognition'],mode:'adaptive',difficulty:'intermediate'}
};

test('learner presentation does not expose educator objective, hidden complication, score, or event state', () => {
  const scenario = buildScenarioFromSetup(setup,{id:'neutral-case-01'});
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const learner = session.presentation();
  const scan = assertNoDiagnosticLeakage(learner,[
    'tamponade','tamponade-recognition','low-flow-troubleshooting','postoperative-tamponade','decompensating','preferred','harmful'
  ]);
  assert.equal(scan.ok,true,`leaked: ${scan.hits.join(', ')}`);
  assert.equal(Object.hasOwn(learner,'clinicalEvents'),false);
});

test('live learner action response contains observable consequence but not grading classification or rationale', () => {
  const scenario = buildScenarioFromSetup(setup,{id:'neutral-case-02'});
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const result = session.submit({type:'bolus-volume',mlPerKg:10});
  assert.equal(result.status,'applied');
  assert.equal(result.rationale,undefined);
  assert.equal(result.clinicalOutcome,undefined);
  assert.equal(JSON.stringify(result).toLowerCase().includes('tamponade'),false);
  assert.match(result.feedback,/temporary improvement/i);
  assert.equal(session.instructorPresentation().clinicalEvents.lastOutcome.outcome,'temporizing');
});

test('internal trigger and grading metadata remains available to instructor/debrief view', () => {
  const scenario = buildScenarioFromSetup(setup,{id:'neutral-case-03'});
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  session.submit({type:'bolus-volume',mlPerKg:10});
  const instructor = session.instructorPresentation();
  assert.equal(instructor.learningPlan.primaryObjective,'low-flow-troubleshooting');
  assert.equal(instructor.clinicalEventState.active['postoperative-tamponade'].state,'temporized');
  assert.equal(instructor.clinicalEvents.lastOutcome.outcome,'temporizing');
});
