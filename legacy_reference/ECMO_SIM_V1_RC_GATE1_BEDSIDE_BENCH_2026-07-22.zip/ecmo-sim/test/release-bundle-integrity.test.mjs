import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
test('standalone v3.3 bundled require targets are embedded',()=>{
 const defs=new Set([...h.matchAll(/['"]([^'"]+\.mjs)['"]:function\(module,exports,require\)/g)].map(m=>m[1]));
 const reqs=new Set([...h.matchAll(/require\(["']([^"']+\.mjs)["']\)/g)].map(m=>m[1]));
 const missing=[...reqs].filter(x=>!defs.has(x));
 assert.deepEqual(missing,[]);
});
test('standalone v3.3 contains no active-feature stale title',()=>{
 assert.match(h,/V1 Feature Complete/);assert.doesNotMatch(h,/<title>[^<]*Low-Flow Troubleshooting/i);
});
