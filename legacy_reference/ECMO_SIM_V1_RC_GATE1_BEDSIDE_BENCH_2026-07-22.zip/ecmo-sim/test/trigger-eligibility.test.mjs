import test from 'node:test';
import assert from 'node:assert/strict';
import { createTriggerEligibilityEngine } from '../src/core/trigger-eligibility.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

test('generic trigger engine supports at-start, time, context, and action-count eligibility without clinical hard-coding', () => {
  const t=createTriggerEligibilityEngine([
    {id:'a',complicationId:'x',type:'at-start'},
    {id:'b',complicationId:'y',type:'time-window',eligibleAfterSec:30},
    {id:'c',complicationId:'z',type:'context',requiresContext:{'active-code':true}},
    {id:'d',complicationId:'q',type:'action-count',actionId:'increase-rpm',count:2}
  ]);
  assert.deepEqual(t.evaluate({started:false,timeSec:0,clinicalContext:{}}),[]);
  assert.deepEqual(t.evaluate({started:true,timeSec:0,clinicalContext:{}}).map(x=>x.complicationId),['x']);
  assert.deepEqual(t.evaluate({started:true,timeSec:29,clinicalContext:{}}),[]);
  assert.deepEqual(t.evaluate({started:true,timeSec:30,clinicalContext:{}}).map(x=>x.complicationId),['y']);
  assert.deepEqual(t.evaluate({started:true,timeSec:31,clinicalContext:{'active-code':true}}).map(x=>x.complicationId),['z']);
  t.recordAction('increase-rpm'); t.recordAction('increase-rpm');
  assert.deepEqual(t.evaluate({started:true,timeSec:31,clinicalContext:{}}).map(x=>x.complicationId),['q']);
});

test('educator scenario activates selected complication through trigger policy rather than embedded or copied rules', () => {
  const scenario=buildScenarioFromSetup({
    patient:{population:'neonatal',weightKg:4},ecmo:{cannulaFr:10},startingCondition:{},
    education:{primaryObjective:'low-flow-troubleshooting',concepts:['tamponade-recognition'],mode:'adaptive'}
  },{id:'trigger-backed-case'});
  assert.equal(scenario.clinicalKnowledgePlan.activateAtStartIds,undefined);
  assert.equal(scenario.clinicalKnowledgePlan.triggerPolicies[0].type,'at-start');
  const session=circuitSandboxEngine.createSession({scenario});
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'],undefined);
  session.submit({type:'start-scenario'});
  assert.equal(session.snapshot().clinicalEventState.active['postoperative-tamponade'].state,'decompensating');
});

test('trigger state survives save/restore without firing the same policy twice', () => {
  const scenario=buildScenarioFromSetup({
    patient:{population:'neonatal',weightKg:4},ecmo:{cannulaFr:10},startingCondition:{},
    education:{primaryObjective:'low-flow-troubleshooting',concepts:['preload-limitation'],mode:'adaptive'}
  },{id:'trigger-save'});
  const s=circuitSandboxEngine.createSession({scenario});
  s.submit({type:'start-scenario'});
  const saved=s.snapshot();
  const restored=circuitSandboxEngine.createSession({scenario,snapshot:saved});
  restored.advance(5);
  assert.equal(restored.instructorPresentation().triggers.firedPolicyIds.length,1);
  assert.equal(Object.keys(restored.snapshot().clinicalEventState.active).length,1);
});
