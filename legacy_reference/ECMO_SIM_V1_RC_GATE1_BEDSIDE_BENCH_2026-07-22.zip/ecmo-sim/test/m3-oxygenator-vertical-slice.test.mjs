import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { buildCircuitEmergencyScenario } from '../src/core/circuit-emergency-scenario-library.mjs';

test('oxygenator vertical slice shows discriminating pressure/gas evidence and progressive worsening',()=>{
  const scenario=buildCircuitEmergencyScenario('ce-03-oxygenator');
  const session=circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const p0=session.presentation();
  assert.ok(p0.circuit.deltaP > 60, `expected elevated deltaP, got ${p0.circuit.deltaP}`);
  const d0=session.presentation().circuit.deltaP;
  session.advance(301);
  const d1=session.presentation().circuit.deltaP;
  assert.ok(d1 > d0, `expected progressive deltaP rise ${d0} -> ${d1}`);
  assert.equal(session.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'].state,'worsened');
  const assess=session.submit({type:'clinical-action',actionId:'assess-oxygenator'});
  assert.match(assess.feedback,/pressure gradient is approximately/i);
  assert.match(assess.feedback,/pre-oxygenator PaO2/i);
  assert.match(assess.feedback,/post-oxygenator PaO2/i);
});

test('increasing sweep is temporizing only; exchange normalizes resistance and resolves event',()=>{
  const scenario=buildCircuitEmergencyScenario('ce-03-oxygenator');
  const session=circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const before=session.presentation().circuit.deltaP;
  const sweep=session.submit({type:'clinical-action',actionId:'increase-sweep'});
  assert.match(sweep.feedback,/limited|incomplete/i);
  assert.notEqual(session.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'].state,'resolved');
  const exchange=session.submit({type:'clinical-action',actionId:'exchange-oxygenator'});
  assert.match(exchange.feedback,/exchanged/i);
  const after=session.presentation().circuit.deltaP;
  assert.ok(after < before, `expected deltaP normalization ${before} -> ${after}`);
  assert.equal(session.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'].state,'resolved');
});
