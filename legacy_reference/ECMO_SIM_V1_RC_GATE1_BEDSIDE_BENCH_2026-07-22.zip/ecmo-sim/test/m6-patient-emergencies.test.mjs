import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {PATIENT_EMERGENCY_PRESETS,buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

test('M6 locks six families represented by seven presets',()=>assert.equal(PATIENT_EMERGENCY_PRESETS.length,7));
for(const p of PATIENT_EMERGENCY_PRESETS)test(`${p.id} builds a single-complication learner-neutral patient emergency`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario(p.id)});const pre=s.presentation();
 assert.ok(pre.learnerBriefing);assert.equal(pre.learnerObjectives.length,4);assert.equal(JSON.stringify(pre).includes(p.educatorLabel),false);s.submit({type:'start-scenario'});
 assert.equal(s.instructorPresentation().clinicalEventState.active[p.complicationId].state,'active');
});
test('PE-01 begins in VF and cannot falsely stabilize while malignant rhythm persists',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-01-arrhythmia-arrest')});s.submit({type:'start-scenario'});
 assert.equal(s.presentation().rhythm,'vfib');
 s.submit({type:'clinical-action',actionId:'resuscitate-arrest'});s.advance(121);
 assert.notEqual(s.presentation().endpoint?.type,'stabilized');
});
test('PE-01 rhythm rescue plus arrest resolution reaches genuine stabilization',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-01-arrhythmia-arrest')});s.submit({type:'start-scenario'});
 assert.match(s.submit({type:'clinical-action',actionId:'assess-rhythm'}).feedback,/V-Fib/i);
 assert.match(s.submit({type:'clinical-action',actionId:'defibrillate'}).feedback,/terminates ventricular fibrillation/i);
 assert.equal(s.presentation().rhythm,'sinus');
 s.submit({type:'clinical-action',actionId:'resuscitate-arrest'});s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
test('PE-02 ICH has a complete acute-threat-control pathway',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-02-ich')});s.submit({type:'start-scenario'});
 assert.match(s.submit({type:'clinical-action',actionId:'neuro-assessment'}).feedback,/acute examination change/i);
 s.submit({type:'clinical-action',actionId:'urgent-neuro-imaging'});s.submit({type:'clinical-action',actionId:'reduce-anticoagulation'});
 const r=s.submit({type:'clinical-action',actionId:'treat-neurologic-emergency'});assert.match(r.feedback,/immediate deterioration threat is controlled/i);
 s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
