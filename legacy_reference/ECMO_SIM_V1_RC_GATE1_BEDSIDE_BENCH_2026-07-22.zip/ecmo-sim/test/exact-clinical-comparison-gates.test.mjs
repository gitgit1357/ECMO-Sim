import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {authorizeClinicalChange,evidenceHash} from '../src/core/clinical-change-control.mjs';
const q=JSON.parse(fs.readFileSync(new URL('../../exact-clinical-comparison-queue.json',import.meta.url),'utf8'));
const d=JSON.parse(fs.readFileSync(new URL('../../B1_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
test('exact comparison queue covers all 33 clinical rules',()=>assert.equal(q.length,33));
test('no rule enters exact-comparison phase pre-authorized for clinical changes',()=>assert.ok(q.every(x=>x.clinicalChangeAuthorized===false)));
test('B1 dossiers never contain unsupported source statements or unauthorized changes',()=>{
 assert.equal(d.length,5);
 const reviewed=d.filter(x=>x.sourceContentReviewed===true);
 const pending=d.filter(x=>x.sourceContentReviewed!==true);
 assert.ok(pending.every(x=>x.sourceStatementParaphrase===null&&x.changeAuthorized===false));
 assert.ok(reviewed.every(x=>x.sourceStatementParaphrase&&x.sourceLocator&&x.changeAuthorized===true));
});
test('clinical change authorization requires reviewed traceable evidence plus approval',()=>{
 const bad=authorizeClinicalChange({sourceContentReviewed:true,sourceApplicabilityConfirmed:true,comparisonDisposition:'revise',changeApproved:true,sourceTitle:'x'});
 assert.equal(bad.authorized,false);
 const good=authorizeClinicalChange({sourceContentReviewed:true,sourceApplicabilityConfirmed:true,comparisonDisposition:'revise',changeApproved:true,sourceTitle:'x',sourceLocator:'p.1'});
 assert.equal(good.authorized,true);
});
test('evidence hash is stable',()=>assert.equal(evidenceHash('abc'),evidenceHash('abc')));
