import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v3.2/index.html',import.meta.url),'utf8');
test('refinement v3.2 groups educator templates by clinical pack',()=>{for(const x of ['optgroup','Low-Flow Troubleshooting','Circuit Emergencies','VA ECMO','VV ECMO','Patient Emergencies'])assert.match(h,new RegExp(x));});
test('learner action wall is filtered by scenario-safe availableActions',()=>{assert.match(h,/renderActionAvailability/);assert.match(h,/p\.availableActions/);assert.match(h,/b\.style\.display=show/);});
