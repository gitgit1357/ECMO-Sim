import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';

test('bubble alarm can be reset but residual air remains hazardous',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});s.submit({type:'start-scenario'});
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 let p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,true);assert.equal(p.bubbleSafety.residualAirUpstream,true);
 const r=s.submit({type:'reset-bubble-detector-alarm'});assert.match(r.feedback,/residual air has not been cleared/i);
 p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,false);assert.equal(p.bubbleSafety.resetArmed,true);
});

test('restoring RPM after reset retrips detector if air was not explicitly cleared',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});s.submit({type:'start-scenario'});
 s.submit({type:'set-param',param:'pumpRpm',value:0});
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 s.submit({type:'reset-bubble-detector-alarm'});
 s.submit({type:'set-param',param:'pumpRpm',value:1500});
 const p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,true);assert.equal(p.circuit.circuitFlowLpm,0);
});

test('explicit de-airing prevents retrip when flow is restored',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});s.submit({type:'start-scenario'});
 s.submit({type:'set-param',param:'pumpRpm',value:0});
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 s.submit({type:'reset-bubble-detector-alarm'});
 s.submit({type:'clear-circuit-air'});
 s.submit({type:'set-param',param:'pumpRpm',value:1500});
 const p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,false);assert.equal(p.bubbleSafety.residualAirUpstream,false);assert.ok(p.circuit.circuitFlowLpm>0);
});
