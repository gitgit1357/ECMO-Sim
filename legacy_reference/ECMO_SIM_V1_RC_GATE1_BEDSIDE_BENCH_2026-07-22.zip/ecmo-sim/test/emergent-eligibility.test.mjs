import test from 'node:test';
import assert from 'node:assert/strict';
import { createEmergentEligibilityEngine } from '../src/core/emergent-eligibility.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';


test('generic emergent eligibility can require sustained learner-created conditions', () => {
  const engine = createEmergentEligibilityEngine([{
    id:'rule-x', complicationId:'x', sustainForSec:30,
    all:[{source:'clinicalContext',path:'drainageStress',op:'eq',value:true}]
  }]);
  assert.equal(engine.evaluate({timeSec:0,clinicalContext:{drainageStress:true}}).length,0);
  assert.equal(engine.evaluate({timeSec:29,clinicalContext:{drainageStress:true}}).length,0);
  assert.equal(engine.evaluate({timeSec:30,clinicalContext:{drainageStress:true}})[0].complicationId,'x');
});

test('breaking a sustained condition resets its eligibility timer', () => {
  const engine = createEmergentEligibilityEngine([{
    id:'rule-x', complicationId:'x', sustainForSec:30,
    all:[{source:'clinicalContext',path:'stress',op:'eq',value:true}]
  }]);
  engine.evaluate({timeSec:0,clinicalContext:{stress:true}});
  engine.evaluate({timeSec:20,clinicalContext:{stress:false}});
  assert.equal(engine.evaluate({timeSec:40,clinicalContext:{stress:true}}).length,0);
  assert.equal(engine.evaluate({timeSec:70,clinicalContext:{stress:true}}).length,1);
});

test('learner action history can make an initially unplanned complication eligible and director-controlled', () => {
  const setup = {
    patient:{population:'neonatal',weightKg:3.4}, ecmo:{cannulaFr:10,pumpRpm:1400},
    startingCondition:{renalFunction:'normal'},
    education:{primaryObjective:'low-flow-troubleshooting',concepts:['preload-limitation'],mode:'dynamic'}
  };
  const scenario = buildScenarioFromSetup(setup,{id:'emergent-runtime'});
  scenario.clinicalKnowledgePlan.allowedComplicationIds.push('postoperative-tamponade');
  scenario.clinicalKnowledgePlan.emergentEligibilityRules = [{
    id:'test-action-created', complicationId:'postoperative-tamponade',
    all:[{source:'actionCounts',path:'increase-rpm',op:'gte',value:2}]
  }];
  scenario.runtimeDirector.profile = {maxConcurrentEvents:2,minEventSpacingSec:0};
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  session.submit({type:'set-param',param:'pumpRpm',value:1500});
  session.submit({type:'set-param',param:'pumpRpm',value:1600});
  const internal = session.instructorPresentation();
  assert.equal(internal.emergentEligibility.firedRuleIds.includes('test-action-created'),true);
  assert.equal(Boolean(internal.clinicalEventState.active['postoperative-tamponade']),true);
  assert.equal(JSON.stringify(session.presentation()).includes('postoperative-tamponade'),false);
});
