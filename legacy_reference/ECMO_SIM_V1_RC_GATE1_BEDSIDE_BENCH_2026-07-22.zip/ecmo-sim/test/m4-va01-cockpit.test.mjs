import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const html=fs.readFileSync(new URL('../../standalone-v2.5/index.html',import.meta.url),'utf8');
test('standalone v2.5 exposes VA scenario library and VA-01 actions',()=>{
 assert.match(html,/listVaEcmoScenarios/);assert.match(html,/buildVaEcmoScenario/);assert.match(html,/vaCases/);
 assert.match(html,/assess-differential-hypoxemia/);assert.match(html,/correct-differential-hypoxemia/);
});