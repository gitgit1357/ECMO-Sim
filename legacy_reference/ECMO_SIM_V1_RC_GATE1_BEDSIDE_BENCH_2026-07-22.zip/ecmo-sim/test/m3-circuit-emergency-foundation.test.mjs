import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { listCircuitEmergencyScenarios, buildCircuitEmergencyScenario } from '../src/core/circuit-emergency-scenario-library.mjs';

test('M3 circuit emergency pack defines the six locked V1 case families',()=>{
  const cases=listCircuitEmergencyScenarios({audience:'educator'});
  assert.equal(cases.length,6);
  assert.deepEqual(cases.map(x=>x.complicationId),[
    'air-emergency','circuit-breach-hemorrhage','oxygenator-thrombosis-failure','sweep-gas-failure','hemolysis','major-bleeding'
  ]);
});

test('all six M3 presets instantiate diagnosis-neutral engine-backed scenarios',()=>{
  for(const item of listCircuitEmergencyScenarios({audience:'educator'})){
    const scenario=buildCircuitEmergencyScenario(item.id);
    const session=circuitSandboxEngine.createSession({scenario});
    const learner=JSON.stringify(session.presentation()).toLowerCase();
    assert.equal(learner.includes(item.complicationId.toLowerCase()),false,`leaked ${item.complicationId}`);
    const start=session.submit({type:'start-scenario'});
    assert.equal(start.status,'started');
    assert.ok(session.instructorPresentation().clinicalEventState.active[item.complicationId]);
  }
});

test('oxygenator failure proving case exposes assessment then definitive exchange path without diagnosis leakage',()=>{
  const scenario=buildCircuitEmergencyScenario('ce-03-oxygenator');
  const session=circuitSandboxEngine.createSession({scenario});
  assert.doesNotMatch(JSON.stringify(session.presentation()),/oxygenator thrombosis|membrane-lung failure/i);
  session.submit({type:'start-scenario'});
  const initial=session.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'];
  assert.equal(initial.state,'active');
  const assess=session.submit({type:'clinical-action',actionId:'assess-oxygenator'});
  assert.match(assess.feedback,/performance|resistance|pressure/i);
  const recognized=session.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'];
  assert.equal(recognized.state,'recognized');
  const exchange=session.submit({type:'clinical-action',actionId:'exchange-oxygenator'});
  assert.match(exchange.feedback,/exchanged|gas transfer returns/i);
  const instructor=session.instructorPresentation();
  assert.equal(instructor.clinicalEventState.active['oxygenator-thrombosis-failure'].state,'resolved');
  assert.equal(instructor.clinicalEventState.active['oxygenator-thrombosis-failure'].resolvedAtSec,0);
});
