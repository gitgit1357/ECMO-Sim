import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const l=JSON.parse(fs.readFileSync(new URL('../../B6_PATIENT_EMERGENCIES_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
test('B6 contains patient-emergency registry primitives',()=>assert.ok(l.length>=5));
test('B6 uses explicit ELSO domain routing rather than one generic source',()=>{const d=new Set(l.map(x=>x.elsoDomain));assert.ok(d.has('general'));assert.ok(d.has('aki-fluid-electrolytes')||d.has('adult-ecpr'));});
test('B6 passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(l);assert.equal(v.valid,true,v.errors.join(';'));});
test('B6 authorizes no unsupported numeric changes',()=>assert.ok(l.every(x=>!x.numericStandardClaimAllowed&&!x.simulationChangeAuthorized)));
