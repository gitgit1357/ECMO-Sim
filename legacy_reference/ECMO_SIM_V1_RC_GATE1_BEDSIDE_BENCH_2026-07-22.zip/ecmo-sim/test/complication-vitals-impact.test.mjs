import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { listAllClinicalModuleScenarios, buildClinicalModuleScenario } from '../src/core/clinical-module-scenario-library.mjs';

// This test formalizes the exact defect class found and fixed in
// hypovolemia/tamponade: a complication that produces NO ongoing change
// to monitored vitals (HR/MAP/SpO2/CVP) if left completely untreated,
// however long you wait. Per the project's own stated rule ("the patient
// must evolve with time") and Frank's explicit directive that the monitor
// is the only information a learner has, every complication should
// eventually fail this test — not stay on the allowlist forever.
//
// The allowlist below is deliberately explicit and visible rather than a
// silent gap: anything NOT on it must show real, ongoing monitor change.
// Add to this list only when you've confirmed a complication is
// legitimately inert (e.g., recovery/case scoring will happen through
// something other than continuous circuit physiology — check
// case-by-case, don't assume). Remove an id from this list the moment
// it's fixed; shrinking this list over time IS the roadmap.
//
// Audited 2026-07 (empirically, not just from reading definitions):
// comparing monitored vitals at t=15s (after the one-time PaO2
// initialization settles) to t=900s, fully untreated.
//
// 2026-07 update: 21 of the original 22 were given real activationEffects
// and/or timeRules and moved off this list. Only one remains, and it's
// legitimately fine as currently used, not silently broken:
const KNOWN_INERT_COMPLICATIONS = new Set([
  'position-sensitive-cannula' // relies on scenario-level patientPositionProfile wiring (already correct for its one real use, lf-03) rather than its own activationEffects — fine as used today, but silently inert if reused in a new scenario without that wiring
]);

test(`every complication NOT on the known-inert allowlist shows real, ongoing monitor change if left untreated (currently ${KNOWN_INERT_COMPLICATIONS.size} of 36 are still on that list)`, () => {
  const cases = listAllClinicalModuleScenarios({ audience: 'educator' });
  assert.equal(cases.length, 36, 'this test assumes the full 36-complication registry — update it if that count changes deliberately');

  for (const item of cases) {
    if (KNOWN_INERT_COMPLICATIONS.has(item.id)) continue;
    const scenario = buildClinicalModuleScenario(item.id);
    const session = circuitSandboxEngine.createSession({ scenario });
    session.submit({ type: 'start-scenario' });
    session.advance(15); // let the one-time PaO2 recompute settle before measuring
    const before = session.presentation().monitored;
    session.advance(885);
    const after = session.presentation().monitored;
    const changed = before.hr !== after.hr || before.map !== after.map || before.spo2 !== after.spo2 || before.cvp !== after.cvp;
    assert.ok(changed, `${item.id}: expected ongoing monitor change over 15 untreated minutes — if this is a new, legitimate finding, either fix it or add it to KNOWN_INERT_COMPLICATIONS with a reason`);
  }
});

test('the known-inert allowlist only shrinks or stays the same across commits, never grows silently', () => {
  // A blunt guardrail: if this number goes up, someone added a new
  // complication (or broke an existing one) without addressing the
  // "does it actually do anything" question. That's fine to do
  // deliberately (add a reason above) but should never happen by accident.
  assert.ok(KNOWN_INERT_COMPLICATIONS.size <= 1, `the inert-complication count grew to ${KNOWN_INERT_COMPLICATIONS.size} — was this deliberate?`);
});

test('every complication with an arrest:true trajectory state actually forces rhythm to vfib the moment arrest becomes true', () => {
  const arrestFlaggedIds = [
    'arrhythmia-arrest', 'metabolic-electrolyte-emergency', 'congenital-circulation-specific',
    'treatment-transfusion-adverse', 'pulmonary-hypertensive-crisis'
  ];
  for (const id of arrestFlaggedIds) {
    const scenario = buildClinicalModuleScenario(id);
    const session = circuitSandboxEngine.createSession({ scenario });
    session.submit({ type: 'start-scenario' });
    let arrestSeenAt = null;
    let rhythmAtArrest = null;
    for (let t = 0; t < 600 && !arrestSeenAt; t += 15) {
      session.advance(15);
      const last = session.instructorPresentation().trajectory.last;
      if (last.arrest) { arrestSeenAt = t + 15; rhythmAtArrest = session.presentation().rhythm; }
    }
    assert.ok(arrestSeenAt, `${id}: expected the arrest flag to become true within 10 untreated minutes`);
    assert.equal(rhythmAtArrest, 'vfib', `${id}: rhythm should jump to vfib the moment arrest becomes true, not lag behind`);
  }
});
