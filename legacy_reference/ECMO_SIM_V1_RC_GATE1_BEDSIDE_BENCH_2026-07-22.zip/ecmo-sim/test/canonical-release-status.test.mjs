import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {auditStatusText} from '../src/core/documentation-status-auditor.mjs';
const s=JSON.parse(fs.readFileSync(new URL('../../CANONICAL_PROJECT_STATUS.json',import.meta.url),'utf8'));
test('canonical status remains hardened preclinical',()=>{assert.equal(s.releaseStatus,'hardened-preclinical-release-candidate');assert.equal(s.competencyReady,false);});
test('canonical authority hierarchy preserves institution first and ELSO default gaps',()=>assert.match(s.governance,/Institutional.*ELSO.*gaps/i));
test('auditor accepts explicit negative competency claim',()=>assert.deepEqual(auditStatusText('This build is not competency-ready.'),[]));
test('auditor flags unsupported positive certification claim',()=>assert.ok(auditStatusText('This build is ELSO certified.').length>0));
