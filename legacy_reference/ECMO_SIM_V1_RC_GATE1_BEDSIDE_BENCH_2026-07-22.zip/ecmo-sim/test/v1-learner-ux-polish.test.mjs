import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';

test('position actions tell learner current and documented pre-event positions',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});s.submit({type:'start-scenario'});
 const p=s.presentation();const turn=p.availableActions.find(x=>x.id==='turn-patient');const restore=p.availableActions.find(x=>x.id==='restore-prior-position');
 assert.match(turn.label,/current:/i);assert.match(restore.label,/documented pre-event position/i);assert.match(restore.label,/\(/);
});
test('generic turn explains that it is not the same as restoring pre-event position',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'turn-patient'});assert.match(r.feedback,/Current position:/);assert.match(r.feedback,/does not imply returning/i);
});
test('position no-change feedback states the intervention performed',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-01-preload')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'set-patient-position',position:'left-tilt'});assert.match(r.feedback,/repositioned from .* to left tilt/i);assert.match(r.feedback,/After this intervention, no meaningful change/i);
});
