import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const cases=[
 ['lf-01-preload',buildLowFlowTroubleshootingScenario,'low-flow'],
 ['ce-01-air-emergency',buildCircuitEmergencyScenario,'circuit'],
 ['ce-03-oxygenator',buildCircuitEmergencyScenario,'circuit'],
 ['va-01-differential-hypoxemia',buildVaEcmoScenario,'va'],
 ['va-02-lv-distension',buildVaEcmoScenario,'va'],
 ['vv-01-recirculation',buildVvEcmoScenario,'vv'],
 ['vv-04-airway',buildVvEcmoScenario,'vv'],
 ['pe-01-arrhythmia-arrest',buildPatientEmergencyScenario,'patient'],
 ['pe-03-sepsis',buildPatientEmergencyScenario,'patient'],
 ['pe-04-aki-fluid',buildPatientEmergencyScenario,'patient']
];

for(const [id,builder,family] of cases){
 test(`${id} integrated bench: prebrief -> live -> actionable`,()=>{
  const s=circuitSandboxEngine.createSession({scenario:builder(id)});
  let p=s.presentation();
  assert.equal(p.lifecycle.status,'prebrief');
  assert.ok((p.availableActions||[]).length>0);
  s.submit({type:'start-scenario'});
  p=s.presentation();
  assert.equal(p.lifecycle.status,'active');
  assert.ok((p.availableActions||[]).length>0);
  const text=JSON.stringify(p.learnerBriefing||{})+' '+JSON.stringify(p.handoff||{});
  assert.doesNotMatch(text,/diagnosis|the cause is|confirmed .*failure/i);
 });
}

test('oxygenator rescue remains cause-directed and resolves event',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-03-oxygenator')});s.submit({type:'start-scenario'});
 s.submit({type:'clinical-action',actionId:'assess-oxygenator'});
 let a=s.submit({type:'clinical-action',actionId:'increase-sweep'});
 assert.match(a.feedback,/limited|incomplete|tempor/i);
 s.submit({type:'clinical-action',actionId:'exchange-oxygenator'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['oxygenator-thrombosis-failure'].state,'resolved');
});

test('VV recirculation does not resolve with blind RPM increase but does with cause correction',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});
 const a=s.submit({type:'clinical-action',actionId:'increase-rpm'});
 assert.match(a.feedback,/does not reliably improve|may worsen/i);
 assert.notEqual(s.instructorPresentation().clinicalEventState.active['vv-recirculation'].state,'resolved');
 s.submit({type:'clinical-action',actionId:'correct-recirculation'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['vv-recirculation'].state,'resolved');
});

test('VA LV distension penalizes indiscriminate volume and resolves with unloading',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-02-lv-distension')});s.submit({type:'start-scenario'});
 const a=s.submit({type:'clinical-action',actionId:'volume-bolus'});
 assert.match(a.feedback,/worsens congestion/i);
 s.submit({type:'clinical-action',actionId:'initiate-lv-unloading'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['va-lv-distension'].state,'resolved');
});

test('patient sepsis requires treatment rather than cultures alone',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-03-sepsis')});s.submit({type:'start-scenario'});
 s.submit({type:'clinical-action',actionId:'obtain-cultures'});
 assert.notEqual(s.instructorPresentation().clinicalEventState.active['infection-sepsis'].state,'resolved');
 s.submit({type:'clinical-action',actionId:'treat-sepsis'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['infection-sepsis'].state,'resolved');
});
