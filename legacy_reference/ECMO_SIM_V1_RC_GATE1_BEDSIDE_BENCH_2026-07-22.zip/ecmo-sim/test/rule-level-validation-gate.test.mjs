import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {ruleValidationState,canClaimElsoNumericStandard} from '../src/core/clinical-validation-gate.mjs';
const registry=JSON.parse(fs.readFileSync(new URL('../../clinical-source-registry.json',import.meta.url),'utf8'));
test('ELSO domain assignment alone never equals clinical validation',()=>{
 assert.ok(registry.rules.every(r=>ruleValidationState(r).clinicallyValidated===false));
});
test('clinical validation requires source extraction, expert review, and regression',()=>{
 assert.equal(ruleValidationState({sourceAssigned:true,ruleExtracted:true,expertReviewed:true,regressionVerified:true}).clinicallyValidated,true);
 assert.equal(ruleValidationState({sourceAssigned:true,ruleExtracted:true,expertReviewed:false,regressionVerified:true}).clinicallyValidated,false);
});
test('numeric ELSO standard claim requires exact source support',()=>{
 assert.equal(canClaimElsoNumericStandard({exactSourceSupport:false}),false);
 assert.equal(canClaimElsoNumericStandard({exactSourceSupport:true}),true);
});
