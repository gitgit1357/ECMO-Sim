import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {VA_ECMO_PRESETS,buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';

const plans={
 'va-01-differential-hypoxemia':['assess-differential-hypoxemia','correct-differential-hypoxemia'],
 'va-02-lv-distension':['assess-lv-distension','initiate-lv-unloading'],
 'va-03-limb-ischemia':['assess-limb-perfusion','restore-limb-perfusion'],
 'va-04-thrombosis':['assess-thrombosis','manage-thrombosis']
};
for(const preset of VA_ECMO_PRESETS){
 test(`${preset.id} passes M4 completion gate`,()=>{
   const sc=buildVaEcmoScenario(preset.id);const s=circuitSandboxEngine.createSession({scenario:sc});
   const pre=s.presentation();assert.ok(pre.learnerBriefing);assert.ok(pre.recentEvents.length>=3);assert.equal(pre.learnerObjectives.length,4);
   assert.equal(JSON.stringify(pre).includes(preset.educatorLabel),false);
   s.submit({type:'start-scenario'});
   for(const actionId of plans[preset.id]){const r=s.submit({type:'clinical-action',actionId});assert.ok(r.feedback);}
   assert.equal(s.instructorPresentation().clinicalEventState.active[preset.complicationId].state,'resolved');
   s.advance(121);const end=s.presentation();assert.equal(end.lifecycle.status,'stabilized');assert.equal(end.complete,true);assert.equal(end.endpoint.type,'stabilized');
 });
}
