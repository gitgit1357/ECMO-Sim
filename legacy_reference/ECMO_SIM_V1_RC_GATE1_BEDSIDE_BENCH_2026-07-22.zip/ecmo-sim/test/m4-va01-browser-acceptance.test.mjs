import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
test('VA-01 accepted prompt pathway reaches stabilized endpoint after sustained stability',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});
 let r=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});assert.match(r.feedback,/right radial\/upper-body SpO2 about 82%/i);
 s.submit({type:'clinical-action',actionId:'correct-differential-hypoxemia'});s.advance(121);
 const p=s.presentation();assert.equal(p.lifecycle.status,'stabilized');assert.equal(p.lifecycle.complete,true);assert.equal(p.endpoint.type,'stabilized');
});
test('VA-01 accepted delayed pathway demonstrates worsening upper-body differential before rescue',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});s.advance(241);
 const r=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});assert.match(r.feedback,/upper-body SpO2 about 75%/i);assert.match(r.feedback,/lower-body\/postductal SpO2 is about 98%/i);
 s.submit({type:'clinical-action',actionId:'correct-differential-hypoxemia'});s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
test('standalone v2.5 contains current VA-01 bundle and cockpit actions',()=>{const h=fs.readFileSync(new URL('../../standalone-v2.5/index.html',import.meta.url),'utf8');for(const x of ['rightRadialSpo2Target','buildVaEcmoScenario','assess-differential-hypoxemia','correct-differential-hypoxemia'])assert.match(h,new RegExp(x));});
