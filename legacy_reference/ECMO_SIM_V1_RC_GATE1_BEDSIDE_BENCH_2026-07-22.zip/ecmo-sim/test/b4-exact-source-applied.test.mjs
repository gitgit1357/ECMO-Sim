import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync(new URL('../../B4_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B4_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));

test('B4 exact comparison covers all three VA primitives',()=>{assert.equal(d.length,3);for(const id of ['va-differential-hypoxemia','va-lv-distension','limb-ischemia'])assert.ok(d.some(x=>x.ruleId.endsWith(id)));});
test('differential hypoxemia source review requires right-radial/proximal monitoring',()=>{const x=r.find(x=>x.ruleId.endsWith('va-differential-hypoxemia'));assert.match(x.principles.join(' '),/right arm\/right radial/i);assert.match(x.disposition['VAV escalation if necessary'],/source-supported/i);});
test('LV distension evidence retains exact pulse-pressure references as evidence not universal simulator cutoffs',()=>{const x=r.find(x=>x.ruleId.endsWith('va-lv-distension'));assert.ok(x.exactSourceNumbers.some(n=>/5–10/.test(String(n.valueRange))));assert.match(x.disposition['180/90-second progression'],/placeholder/i);});
test('limb ischemia evidence records source numeric monitoring references',()=>{const x=r.find(x=>x.ruleId.endsWith('limb-ischemia'));assert.ok(x.exactSourceNumbers.some(n=>n.name==='distalPerfusionFlowTarget'&&n.value==='>=100'));assert.ok(x.exactSourceNumbers.some(n=>n.name==='bilateralNirsDifference'));});
test('all B4 rules remain pending expert clinical signoff',()=>assert.ok(d.every(x=>/expert-clinical-signoff/.test(x.reviewerStatus))));
