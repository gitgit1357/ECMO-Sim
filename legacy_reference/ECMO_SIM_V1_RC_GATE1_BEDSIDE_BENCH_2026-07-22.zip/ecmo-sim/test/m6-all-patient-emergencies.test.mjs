import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {PATIENT_EMERGENCY_PRESETS,buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const plans={
 'pe-01-arrhythmia-arrest':['assess-rhythm','defibrillate','resuscitate-arrest'],
 'pe-02-ich':['neuro-assessment','urgent-neuro-imaging','reduce-anticoagulation','treat-neurologic-emergency'],
 'pe-03-vasoplegia':['assess-shock','treat-vasoplegia'],
 'pe-03-sepsis':['obtain-cultures','treat-sepsis'],
 'pe-04-aki-fluid':['assess-renal-fluid','manage-fluid-overload'],
 'pe-05-metabolic':['assess-electrolytes','correct-electrolyte-emergency'],
 'pe-06-ph-crisis':['assess-pulmonary-hypertension','treat-pulmonary-hypertension']
};
for(const p of PATIENT_EMERGENCY_PRESETS)test(`${p.id} passes M6 resolution/completion gate`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario(p.id)});const pre=s.presentation();
 assert.ok(pre.learnerBriefing);assert.ok(pre.recentEvents.length>=2);assert.equal(pre.learnerObjectives.length,4);assert.equal(JSON.stringify(pre).includes(p.educatorLabel),false);
 const ids=new Set((pre.availableActions||[]).map(x=>x.id));
 assert.ok(ids.has('assess-rhythm'));assert.ok(ids.has('assess-shock'));assert.ok(ids.has('assess-renal-fluid')); // broad differential, not case-specific buttons
 s.submit({type:'start-scenario'});
 for(const actionId of plans[p.id]){const r=s.submit({type:'clinical-action',actionId});assert.ok(r.feedback);}
 assert.equal(s.instructorPresentation().clinicalEventState.active[p.complicationId].state,'resolved');
 s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
test('PE-04 exposes quantitative renal/fluid evidence',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-04-aki-fluid')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-renal-fluid'});assert.match(r.feedback,/0.3 mL\/kg\/hr/i);assert.match(r.feedback,/\+12%/);
});
test('PE-05 exposes actionable electrolyte evidence',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-05-metabolic')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-electrolytes'});assert.match(r.feedback,/K about 7.1 mmol\/L/i);
});
test('PE-06 distinguishes RV/pulmonary vascular crisis from circuit malfunction',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildPatientEmergencyScenario('pe-06-ph-crisis')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-pulmonary-hypertension'});assert.match(r.feedback,/RV pressure-overload\/pulmonary hypertensive crisis/i);assert.match(r.feedback,/technically functioning ECMO support/i);
});
