import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
test('VA-01 exposes discriminating right-radial versus lower-body oxygenation evidence',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});
 assert.match(r.feedback,/right radial\/upper-body SpO2 about 82%/i);assert.match(r.feedback,/lower-body\/postductal SpO2 is about 98%/i);
 assert.doesNotMatch(r.feedback,/North-South|Harlequin/i);
});
test('VA-01 site-specific upper-body oxygenation worsens with delay and normalizes after correction',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});s.advance(241);
 let r=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});assert.match(r.feedback,/about 75%/);
 s.submit({type:'clinical-action',actionId:'correct-differential-hypoxemia'});
 r=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});assert.match(r.feedback,/acceptably matched/i);assert.match(r.feedback,/about 96%/);
});
