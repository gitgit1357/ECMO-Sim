import test from 'node:test';
import assert from 'node:assert/strict';
import { createScenarioRuntimeDirector } from '../src/core/scenario-runtime-director.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

const setup = {
  patient: { population:'neonatal', weightKg:3.4, diagnosis:'HLHS', procedure:'Norwood/Sano' },
  ecmo: { mode:'VA', cannulation:'central', cannulaFr:10, pumpRpm:1450, sweepGasLpm:0.4, fdo2Percent:100 },
  startingCondition: { hemodynamics:'stable', volumeStatus:'appropriate', renalFunction:'normal' },
  education: { primaryObjective:'low-flow-troubleshooting', concepts:['preload-limitation','tamponade-recognition'], mode:'adaptive', difficulty:'intermediate' }
};

test('runtime director queues eligible events and respects concurrent-event limit', () => {
  const director = createScenarioRuntimeDirector({ mode:'adaptive', profile:{ minEventSpacingSec:0, maxConcurrentEvents:1 } });
  director.enqueue([
    { id:'a', complicationId:'hypovolemia', atSec:0 },
    { id:'b', complicationId:'postoperative-tamponade', atSec:0 }
  ]);
  const first = director.evaluate({ timeSec:0, activeUnresolvedCount:0 });
  assert.equal(first.length, 1);
  const blocked = director.evaluate({ timeSec:10, activeUnresolvedCount:1 });
  assert.equal(blocked.length, 0);
  const second = director.evaluate({ timeSec:10, activeUnresolvedCount:0 });
  assert.equal(second.length, 1);
});

test('director mode changes orchestration capacity without clinical knowledge', () => {
  const director = createScenarioRuntimeDirector({ mode:'dynamic', profile:{ minEventSpacingSec:0 } });
  director.enqueue([{complicationId:'x',atSec:0},{complicationId:'y',atSec:0}]);
  const releases = director.evaluate({timeSec:0,activeUnresolvedCount:0});
  assert.equal(releases.length, 2);
});

test('snapshot restore does not release the same complication twice', () => {
  const one = createScenarioRuntimeDirector({mode:'guided'});
  one.enqueue([{id:'elig-1',complicationId:'x',atSec:0}]);
  one.evaluate({timeSec:0,activeUnresolvedCount:0});
  const two = createScenarioRuntimeDirector({mode:'guided', snapshot:one.snapshot()});
  two.enqueue([{id:'elig-2',complicationId:'x',atSec:10}]);
  assert.equal(two.evaluate({timeSec:10,activeUnresolvedCount:0}).length,0);
});

test('educator scenario stores runtime orchestration separately from clinical knowledge', () => {
  const scenario = buildScenarioFromSetup(setup,{id:'runtime-test'});
  assert.equal(scenario.runtimeDirector.mode,'adaptive');
  assert.equal(scenario.clinicalKnowledgePlan.triggerPolicies.length,2);
  assert.equal('clinicalEvents' in scenario,false);
  assert.equal(JSON.stringify(scenario).includes('actionRules'),false);
});

test('engine routes eligible complications through director instead of activating all at start', () => {
  const scenario = buildScenarioFromSetup(setup,{id:'runtime-engine-test'});
  scenario.runtimeDirector.profile = { minEventSpacingSec:0, maxConcurrentEvents:1 };
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const instructor = session.instructorPresentation();
  const active = Object.entries(instructor.clinicalEventState.active).filter(([,v])=>v.resolvedAtSec==null);
  assert.equal(active.length,1);
  assert.equal(instructor.runtimeDirector.queue.length,1);
  assert.equal(session.presentation().log.some((entry)=>JSON.stringify(entry).includes('postoperative-tamponade')),false);
});
