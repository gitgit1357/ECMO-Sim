import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';

const cases=[
 ['va-02-lv-distension','assess-lv-distension','initiate-lv-unloading','va-lv-distension',/LV distension/i],
 ['va-03-limb-ischemia','assess-limb-perfusion','restore-limb-perfusion','limb-ischemia',/distal pulse status/i],
 ['va-04-thrombosis','assess-thrombosis','manage-thrombosis','circuit-systemic-thrombosis',/Thrombosis assessment/i],
];
for(const [id,assess,fix,comp,pattern] of cases){
 test(`${id} exposes discriminating evidence and resolves with cause-directed management`,()=>{
  const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario(id)});s.submit({type:'start-scenario'});
  const a=s.submit({type:'clinical-action',actionId:assess});assert.match(a.feedback,pattern);
  const b=s.submit({type:'clinical-action',actionId:fix});assert.ok(b.feedback);
  assert.equal(s.instructorPresentation().clinicalEventState.active[comp].state,'resolved');
  s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
 });
}
test('VA-02 untreated LV distension worsens before correction',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-02-lv-distension')});s.submit({type:'start-scenario'});s.advance(181);
 const r=s.submit({type:'clinical-action',actionId:'assess-lv-distension'});assert.match(r.feedback,/severe LV distension/i);assert.match(r.feedback,/absent-or-intermittent/i);
});
test('VA-03 untreated limb ischemia develops worsening distal findings',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-03-limb-ischemia')});s.submit({type:'start-scenario'});s.advance(301);
 const r=s.submit({type:'clinical-action',actionId:'assess-limb-perfusion'});assert.match(r.feedback,/cold/i);assert.match(r.feedback,/dusky-mottled/i);
});
test('VA-04 RPM escalation does not resolve thrombosis',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-04-thrombosis')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'increase-rpm'});assert.match(r.feedback,/does not remove thrombotic obstruction/i);
 assert.notEqual(s.instructorPresentation().clinicalEventState.active['circuit-systemic-thrombosis'].state,'resolved');
});
