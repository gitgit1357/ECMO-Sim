import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v3.0/index.html',import.meta.url),'utf8');
test('standalone v3.0 provides supported educator scenario creator controls',()=>{for(const x of ['createEducatorScenario','difficultySelect','directorModeSelect','recentEventNote','BUILD & LOAD LEARNER COCKPIT','createdFromSupportedTemplate'])assert.match(h,new RegExp(x));});
test('creator UI does not expose unsupported free-form complication injection',()=>{assert.doesNotMatch(h,/customComplicationId|eval\(|arbitrary complication/i);});
