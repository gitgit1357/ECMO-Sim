import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';

function session(){
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-01-preload')});
 s.submit({type:'start-scenario'});return s;
}

test('G1.1 reference neonatal VA cockpit has complete bedside baseline',()=>{
 const p=session().presentation();
 assert.ok(Number.isFinite(p.monitored.hr));
 assert.ok(Number.isFinite(p.monitored.bp.systolic)&&Number.isFinite(p.monitored.bp.diastolic)&&Number.isFinite(p.monitored.bp.map));
 assert.ok(Number.isFinite(p.monitored.preDuctalSpo2)&&Number.isFinite(p.monitored.postDuctalSpo2));
 assert.ok(Number.isFinite(p.monitored.cvp)&&Number.isFinite(p.monitored.tempC));
 for(const k of ['pumpRpm','circuitFlowLpm','arterialFlowLpm','shuntFlowLpm','venousPressure','preOxyPressure','postOxyPressure','deltaP']) assert.ok(Number.isFinite(p.circuit[k]),k);
 for(const k of ['hgbGdl','hctPercent','svo2Percent']) assert.ok(Number.isFinite(p.cdi[k]),k);
 assert.equal(p.bubbleSafety.detectorPresent,true);
});

test('G1.2 RPM is freely adjustable and measured flow responds',()=>{
 const s=session(),a=s.presentation();
 const r=s.submit({type:'set-param',param:'pumpRpm',value:a.settings.pumpRpm+500});const b=s.presentation();
 assert.equal(r.accepted,true);assert.equal(b.settings.pumpRpm,a.settings.pumpRpm+500);assert.notEqual(b.circuit.circuitFlowLpm,a.circuit.circuitFlowLpm);
});

test('G1.3 aggressive RPM increase in low preload is allowed rather than blocked',()=>{
 const s=session();
 const r=s.submit({type:'set-param',param:'pumpRpm',value:5000});
 assert.equal(r.accepted,true);
 const p=s.presentation();assert.equal(p.settings.pumpRpm,5000);
 assert.ok(Number.isFinite(p.circuit.venousPressure));
});

test('G1.4 sweep and FdO2 are independently and immediately adjustable',()=>{
 const s=session();
 assert.equal(s.submit({type:'set-param',param:'sweepGasLpm',value:0}).accepted,true);
 assert.equal(s.presentation().settings.sweepGasLpm,0);
 assert.equal(s.submit({type:'set-param',param:'fdo2Percent',value:21}).accepted,true);
 assert.equal(s.presentation().settings.fdo2Percent,21);
});

test('G1.5 clamp is always available and immediately removes extracorporeal flow',()=>{
 const s=session();assert.ok(s.presentation().circuit.circuitFlowLpm>0);
 s.submit({type:'set-circuit-clamp',clamped:true});let p=s.presentation();
 assert.equal(p.circuit.circuitFlowLpm,0);assert.equal(p.circuit.flowIndexMlKgMin,0);assert.equal(p.circuit.clamped,true);
 s.submit({type:'set-circuit-clamp',clamped:false});p=s.presentation();assert.equal(p.circuit.clamped,false);
});

test('G1.6 flow target is available as a pump-mediated control',()=>{
 const s=session(),a=s.presentation();
 const r=s.submit({type:'set-flow-target',flowIndexMlKgMin:150});const b=s.presentation();
 assert.equal(r.accepted,true);assert.notEqual(b.circuit.pumpRpm,a.circuit.pumpRpm);
});

test('G1.7 bubble detector reset does not equal de-airing and residual air retrips',()=>{
 const s=session();
 s.submit({type:'set-param',param:'pumpRpm',value:0});
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 assert.equal(s.presentation().bubbleSafety.alarmActive,true);
 s.submit({type:'reset-bubble-detector-alarm'});
 let p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,false);assert.equal(p.bubbleSafety.residualAirUpstream,true);
 s.submit({type:'set-param',param:'pumpRpm',value:1800});
 p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,true);assert.equal(p.circuit.circuitFlowLpm,0);
});

test('G1.8 explicit de-airing permits successful restart without retrip',()=>{
 const s=session();
 s.submit({type:'set-param',param:'pumpRpm',value:0});
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 s.submit({type:'clear-circuit-air'});
 s.submit({type:'reset-bubble-detector-alarm'});
 s.submit({type:'set-param',param:'pumpRpm',value:1800});
 const p=s.presentation();assert.equal(p.bubbleSafety.alarmActive,false);assert.ok(p.circuit.circuitFlowLpm>0);
});

test('G1.9 cockpit remains live after repeated arbitrary control manipulation',()=>{
 const s=session();
 const actions=[
  {type:'set-param',param:'pumpRpm',value:800},{type:'set-param',param:'pumpRpm',value:3200},
  {type:'set-param',param:'sweepGasLpm',value:0},{type:'set-param',param:'sweepGasLpm',value:10},
  {type:'set-param',param:'fdo2Percent',value:21},{type:'set-param',param:'fdo2Percent',value:100},
  {type:'set-circuit-clamp',clamped:true},{type:'set-circuit-clamp',clamped:false}
 ];
 for(const a of actions) assert.equal(s.submit(a).accepted,true);
 const t=s.presentation().timeSec;s.advance(5);const p=s.presentation();
 assert.equal(p.timeSec,t+5);assert.ok(Number.isFinite(p.monitored.hr));assert.ok(Number.isFinite(p.circuit.venousPressure));
});
