import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync(new URL('../../B6_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B6_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
test('B6 covers six patient-emergency primitives',()=>assert.equal(d.length,6));
test('sepsis uses current 2026 specialty standard without fixed fluid volume',()=>{const x=r.find(x=>x.ruleId.endsWith('infection-sepsis'));assert.match(x.sources.join(' '),/2026/);assert.match(x.disposition['fixed fluid volume'],/not encoded/i);});
test('AKI values remain exemplars',()=>{const x=r.find(x=>x.ruleId.endsWith('aki-fluid-overload'));assert.match(x.disposition['0.3 mL/kg/hr and +12%'],/scenario exemplars/i);});
test('electrolyte emergency avoids universal drug sequence',()=>{const x=r.find(x=>x.ruleId.endsWith('metabolic-electrolyte-emergency'));assert.match(x.disposition['exact drug sequence'],/not encoded/i);});
test('PH crisis remains partial',()=>{const x=d.find(x=>x.ruleId.endsWith('pulmonary-hypertensive-crisis'));assert.equal(x.changeAuthorized,false);});
