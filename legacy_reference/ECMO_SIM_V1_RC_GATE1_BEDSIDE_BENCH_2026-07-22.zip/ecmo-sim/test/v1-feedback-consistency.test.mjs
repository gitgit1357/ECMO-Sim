import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';

test('unmatched clinical action feedback names what learner did and avoids anonymous no-change',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-01-preload')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-limb-perfusion'});
 assert.ok(r.feedback.length>25);assert.doesNotMatch(r.feedback,/^No (meaningful|specific)/i);assert.match(r.feedback,/performed|assess|perfusion/i);
});
test('clinical registry does not contain bare anonymous action-rule feedback',()=>{
 const txt=fs.readFileSync(new URL('../src/core/clinical-knowledge-registry.mjs',import.meta.url),'utf8');
 const vals=[...txt.matchAll(/feedback[:=]['"]([^'"]*)['"]/g)].map(m=>m[1].trim());
 for(const f of vals){assert.notEqual(f.toLowerCase(),'no change');assert.notEqual(f.toLowerCase(),'no meaningful change');}
});
