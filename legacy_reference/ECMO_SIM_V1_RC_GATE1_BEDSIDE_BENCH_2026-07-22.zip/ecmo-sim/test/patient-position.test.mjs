import test from 'node:test';
import assert from 'node:assert/strict';
import { buildLowFlowTroubleshootingScenario } from '../src/core/troubleshooting-scenario-library.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

test('position state is explicit in the learner presentation', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  const p=s.presentation();
  assert.equal(p.patientPosition.current,'right-tilt');
  assert.equal(p.patientPosition.previousDocumented,'supine-midline');
  assert.ok(p.patientPosition.available.includes('left-tilt'));
});

test('partial position change partially improves flow without magically resolving the problem', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  s.submit({type:'start-scenario'});
  const before=s.presentation().circuit.flowIndexMlKgMin;
  const r=s.submit({type:'set-patient-position',position:'left-tilt'});
  const after=s.presentation().circuit.flowIndexMlKgMin;
  assert.equal(s.presentation().patientPosition.current,'left-tilt');
  assert.ok(after>before,`expected improvement ${before}->${after}`);
  assert.ok(after<140,`expected incomplete recovery, got ${after}`);
  assert.match(r.feedback,/improves drainage/i);
  assert.equal(s.instructorPresentation().clinicalEventState.active['position-sensitive-cannula'].resolvedAtSec,null);
});

test('directly selecting the favorable prior position and restore-previous use the same underlying state mechanism', () => {
  const scenario=buildLowFlowTroubleshootingScenario('lf-03-position');

  const direct=circuitSandboxEngine.createSession({scenario});
  direct.submit({type:'start-scenario'});
  const directResult=direct.submit({type:'set-patient-position',position:'supine-midline'});
  const directFlow=direct.presentation().circuit.flowIndexMlKgMin;

  const restored=circuitSandboxEngine.createSession({scenario});
  restored.submit({type:'start-scenario'});
  const restoreResult=restored.submit({type:'restore-previous-position'});
  const restoredFlow=restored.presentation().circuit.flowIndexMlKgMin;

  assert.equal(direct.presentation().patientPosition.current,'supine-midline');
  assert.equal(restored.presentation().patientPosition.current,'supine-midline');
  assert.equal(directFlow,restoredFlow);
  assert.ok(directFlow>140);
  assert.match(directResult.feedback,/drainage stabilizes/i);
  assert.match(restoreResult.feedback,/drainage stabilizes/i);
});

test('returning to the adverse position reproduces adverse support only while the hidden condition remains unresolved', () => {
  const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-03-position')});
  s.submit({type:'start-scenario'});
  const initial=s.presentation().circuit.flowIndexMlKgMin;
  s.submit({type:'set-patient-position',position:'left-tilt'});
  const partial=s.presentation().circuit.flowIndexMlKgMin;
  s.submit({type:'set-patient-position',position:'right-tilt'});
  const adverse=s.presentation().circuit.flowIndexMlKgMin;
  assert.ok(partial>initial);
  assert.ok(adverse<partial);
});
