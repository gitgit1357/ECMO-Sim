import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {computeReleaseReadiness,releaseClaimGuard} from '../src/core/release-readiness.mjs';
const s=JSON.parse(fs.readFileSync(new URL('../../release-readiness-manifest.json',import.meta.url),'utf8'));
test('current release manifest remains validation-in-progress',()=>{assert.equal(s.releaseLevel,'validation-in-progress');assert.equal(s.clinicallyValidatedRules,0);});
test('readiness cannot claim clinical validation before all rules pass',()=>{const r=computeReleaseReadiness({rules:[{clinicallyValidated:false}]});assert.equal(releaseClaimGuard(r,'clinically-validated').allowed,false);});
test('competency-ready requires every rule clinically validated and competency ready',()=>{const r=computeReleaseReadiness({rules:[{clinicallyValidated:true,competencyReady:false}]});assert.equal(r.mayClaimClinicallyValidated,true);assert.equal(r.mayClaimCompetencyReady,false);});
test('all current registry rules remain represented in validation coverage',()=>assert.equal(s.validationCoverage.covered,s.validationCoverage.total));
