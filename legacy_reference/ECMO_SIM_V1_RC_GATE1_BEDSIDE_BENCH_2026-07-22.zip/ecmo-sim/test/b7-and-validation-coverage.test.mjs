import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const b7=JSON.parse(fs.readFileSync(new URL('../../B7_CROSS_CUTTING_GENERAL_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
const c=JSON.parse(fs.readFileSync(new URL('../../clinical-validation-coverage-report.json',import.meta.url),'utf8'));
test('B7 covers all previously remaining cross-cutting rules',()=>assert.equal(b7.length,8));
test('B7 passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(b7);assert.equal(v.valid,true,v.errors.join(';'));});
test('all current registry rules now appear in at least one validation evidence ledger',()=>{assert.equal(c.uncoveredRules.length,0);assert.equal(c.coveredRules,c.totalRegistryRules);});
test('specialty supplementation is explicit rather than silently invented',()=>assert.ok(b7.some(x=>x.specialtySourceMayBeRequired===true)));
