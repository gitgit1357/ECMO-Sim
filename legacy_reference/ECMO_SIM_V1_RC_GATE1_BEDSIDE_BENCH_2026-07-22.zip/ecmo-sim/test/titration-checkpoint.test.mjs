import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveTitrationAction, buildTitrationMission } from '../src/core/titration-lookup.mjs';
import { evidenceReviewEngine } from '../src/engines/evidence-review.mjs';

test('dTT 0.54 (Frank\'s real data point) resolves to no-change under the neonate standard goal', () => {
  const result = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 0.54 });
  assert.equal(result.action, 'no-change');
});

test('dTT 0.35 resolves to increase15 under the neonate standard table', () => {
  const result = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 0.35 });
  assert.equal(result.action, 'increase15');
});

test('a below-floor dTT escalates across repeated low readings: increase, increase again, then consult attending', () => {
  const first = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 0.2, attemptNumber: 1 });
  const second = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 0.2, attemptNumber: 2 });
  const third = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 0.2, attemptNumber: 3 });
  assert.equal(first.action, 'increase20-recheck');
  assert.equal(second.action, 'increase20-second');
  assert.equal(third.action, 'consult-attending');
});

test('a dTT above 1.5 in the standard table requires renal function to resolve, and resolves correctly when given', () => {
  assert.throws(() => resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 1.8 }));
  const normal = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 1.8, renalFunction: 'normal' });
  const severe = resolveTitrationAction({ population: 'neonate', riskContext: 'standard', dtt: 1.8, renalFunction: 'severe' });
  assert.equal(normal.action, 'decrease20');
  assert.equal(severe.action, 'decrease30');
});

test('hemorrhagic/operative context uses its own (tighter) goal band, not the standard one', () => {
  // 0.54 is "no change" under standard, but is above the 0.5 ceiling for hemorrhagic/operative
  const result = resolveTitrationAction({ population: 'neonate', riskContext: 'hemorrhagicOrOperative', dtt: 0.54 });
  assert.equal(result.action, 'decrease10');
});

test('pediatric and neonate high-thrombosis-risk contexts are refused, not guessed at', () => {
  assert.throws(() => resolveTitrationAction({ population: 'pediatric', riskContext: 'standard', dtt: 1.5 }));
  assert.throws(() => resolveTitrationAction({ population: 'neonate', riskContext: 'highThrombosisRisk', dtt: 1.5 }));
});

test('buildTitrationMission produces a mission the (forked) evidence-review engine can actually score', () => {
  const mission = buildTitrationMission({ population: 'neonate', riskContext: 'standard', dtt: 0.54 });
  assert.equal(mission.correctOption, 'no-change');
  assert.ok(mission.options.some((o) => o.id === 'no-change'), 'the correct option must be present among the choices');
  assert.ok(mission.options.length >= 2, 'should present more than one option');

  const session = evidenceReviewEngine.createSession({ mission });
  const wrongOption = mission.options.find((o) => o.id !== 'no-change');
  const wrongResult = session.submit(wrongOption.id);
  assert.equal(wrongResult.status, 'rejected');

  const rightResult = session.submit('no-change');
  assert.equal(rightResult.status, 'accepted');
  assert.equal(session.presentation().complete, true);
});
