import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync(new URL('../../B2_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B2_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
test('B2 exact comparison covers the three actual reusable registry primitives',()=>{assert.equal(d.length,3);for(const id of ['drainage-cannula-kink','mechanical-circuit-obstruction','pump-support-failure'])assert.ok(d.some(x=>x.ruleId.endsWith(id)));});
test('all B2 primitives have traceable source review and await expert signoff',()=>assert.ok(d.every(x=>x.sourceContentReviewed&&x.sourceApplicabilityConfirmed&&/expert-clinical-signoff/.test(x.reviewerStatus))));
test('B2 does not invent exact numeric standards',()=>assert.ok(d.every(x=>x.sourceSupportsExactNumericValue===false)));
test('pump failure 60-second progression remains placeholder',()=>{const x=r.find(x=>x.ruleId.endsWith('pump-support-failure'));assert.match(x.disposition['60-second-progression'],/placeholder/i);});
test('B2 drainage mechanics explicitly reject blind RPM escalation for fixed restriction',()=>{const x=r.find(x=>x.ruleId.endsWith('drainage-cannula-kink'));assert.match(x.disposition['increase-rpm'],/harmful/i);});
