import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
const ev=JSON.parse(fs.readFileSync(new URL('../../B1_OXYGENATOR_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
test('oxygenator assessment explicitly uses trend/device/flow context rather than universal delta-P cutoff',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-03-oxygenator')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-oxygenator'});
 assert.match(r.feedback,/established device\/flow trend/i);assert.match(r.feedback,/rather than as a universal absolute cutoff/i);
});
test('oxygenator evidence record preserves ELSO >300 post-oxygenator reference without treating it as sole exchange trigger',()=>{
 assert.equal(ev.simulatorDisposition.postOxyPao2ResolvedTarget,450);
 assert.match(ev.simulatorDisposition.postOxyPao2ResolvedTargetDisposition,/>300 mmHg/);
 assert.match(ev.validatedQualitativePrinciples.join(' '),/not a standalone universal change-out threshold/i);
});
test('oxygenator deterioration timing remains explicitly unvalidated placeholder',()=>assert.match(ev.simulatorDisposition.deteriorationTiming,/placeholder/i));
