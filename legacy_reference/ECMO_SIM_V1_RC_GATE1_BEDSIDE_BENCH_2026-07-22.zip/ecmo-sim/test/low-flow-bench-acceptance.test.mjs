import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { buildLowFlowTroubleshootingScenario, LOW_FLOW_TROUBLESHOOTING_PRESETS } from '../src/core/troubleshooting-scenario-library.mjs';

// This file is the automated half of the bench-acceptance checklist your
// own project docs called for before broadening past the six low-flow
// cases. It checks the things a human playtester would check by hand:
// does the case do nothing if ignored, is feedback specific (not
// anonymous), does the correct fix actually help, does an untreated case
// eventually mean something. It does NOT replace an actual human
// play-test (pacing, UI feel, and whether the difficulty feels right are
// judgment calls this file can't make) — see the summary at the bottom
// for what's confirmed vs what still needs your eyes.

test('every one of the six cases produces a real, non-flat consequence if left completely untreated for 10 minutes', () => {
  for (const preset of LOW_FLOW_TROUBLESHOOTING_PRESETS) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(preset.id) });
    session.submit({ type: 'start-scenario' });
    const before = session.presentation().monitored;
    session.advance(600);
    const after = session.presentation().monitored;
    const changed = after.map !== before.map || after.hr !== before.hr;
    assert.ok(changed, `${preset.id}: monitor showed no change at all after 10 untreated minutes — this is the "scenario does nothing" defect class`);
  }
});

test('no case is diagnosis-flat: an untreated case does not just sit at its starting severity forever without at least trending toward instability', () => {
  for (const preset of LOW_FLOW_TROUBLESHOOTING_PRESETS) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(preset.id) });
    session.submit({ type: 'start-scenario' });
    session.advance(600);
    const trajectoryLabel = session.instructorPresentation().trajectory.last.label;
    assert.notEqual(trajectoryLabel, 'stable', `${preset.id}: trajectory should not read "stable" after 10 untreated minutes of a real complication`);
  }
});

test('assessment/inspection actions return specific, non-anonymous findings, never the bare "no meaningful clinical change" message', () => {
  const checks = [
    ['lf-01-preload', 'volume-bolus'],
    ['lf-02-tamponade', 'assess-hemodynamics'],
    ['lf-03-position', 'inspect-drainage-cannula'],
    ['lf-04-kink', 'inspect-drainage-cannula'],
    ['lf-05-circuit-obstruction', 'inspect-circuit-path'],
    ['lf-06-pump-failure', 'assess-pump-function']
  ];
  for (const [presetId, actionId] of checks) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(presetId) });
    session.submit({ type: 'start-scenario' });
    const result = session.submit({ type: 'clinical-action', actionId });
    assert.ok(result.feedback && result.feedback.length > 10, `${presetId}/${actionId}: expected specific feedback text`);
    assert.doesNotMatch(result.feedback, /^No meaningful clinical change/i, `${presetId}/${actionId}: feedback must not be the bare anonymous message`);
  }
});

test('the correct definitive treatment for every case produces a real, measurable hemodynamic improvement', () => {
  const treatments = [
    { presetId: 'lf-01-preload', actions: [{ type: 'clinical-action', actionId: 'volume-bolus' }] },
    { presetId: 'lf-02-tamponade', actions: [
      { type: 'clinical-action', actionId: 'assess-hemodynamics' },
      { type: 'clinical-action', actionId: 'order-echo' },
      { type: 'clinical-action', actionId: 'pericardial-decompression' }
    ] },
    { presetId: 'lf-03-position', actions: [{ type: 'clinical-action', actionId: 'restore-prior-position' }] },
    { presetId: 'lf-04-kink', actions: [{ type: 'clinical-action', actionId: 'relieve-cannula-kink' }] },
    { presetId: 'lf-05-circuit-obstruction', actions: [{ type: 'clinical-action', actionId: 'relieve-circuit-obstruction' }] },
    { presetId: 'lf-06-pump-failure', actions: [{ type: 'clinical-action', actionId: 'restore-pump-support' }] }
  ];
  for (const { presetId, actions } of treatments) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(presetId) });
    session.submit({ type: 'start-scenario' });
    session.advance(90); // let it become clinically apparent first
    const beforeFlow = session.presentation().circuit.flowIndexMlKgMin;
    const beforeMap = session.presentation().monitored.map;
    for (const action of actions) session.submit(action);
    session.advance(30);
    const after = session.presentation();
    const improved = after.circuit.flowIndexMlKgMin > beforeFlow || after.monitored.map > beforeMap;
    assert.ok(improved, `${presetId}: definitive treatment should improve flow or MAP — flow ${beforeFlow}->${after.circuit.flowIndexMlKgMin}, MAP ${beforeMap}->${after.monitored.map}`);
  }
});

test('no case ever leaks its own hidden complication id into the learner-facing presentation, at any point in a full run', () => {
  for (const preset of LOW_FLOW_TROUBLESHOOTING_PRESETS) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(preset.id) });
    session.submit({ type: 'start-scenario' });
    for (let i = 0; i < 5; i += 1) {
      session.advance(60);
      const learner = JSON.stringify(session.presentation()).toLowerCase();
      assert.equal(learner.includes(preset.complicationId.toLowerCase()), false, `${preset.id}: leaked "${preset.complicationId}" at t=${(i + 1) * 60}s`);
    }
  }
});

test('untreated hypovolemia and tamponade now reach a death endpoint (previously they never did, at any duration)', () => {
  for (const presetId of ['lf-01-preload', 'lf-02-tamponade']) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(presetId) });
    session.submit({ type: 'start-scenario' });
    session.advance(900); // 15 min fully untreated
    const endpoint = session.instructorPresentation().trajectory.endpoint;
    assert.equal(endpoint?.type, 'death', `${presetId}: expected death within 15 untreated minutes, got ${JSON.stringify(endpoint)}`);
    assert.equal(session.presentation().rhythm, 'asystole', `${presetId}: a dead patient must show a terminal rhythm`);
  }
});

test('correct, timely treatment still fully prevents death for hypovolemia and tamponade (no regression from the deterioration-pathway fix)', () => {
  const hypovolemia = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario('lf-01-preload') });
  hypovolemia.submit({ type: 'start-scenario' });
  hypovolemia.advance(120);
  hypovolemia.submit({ type: 'clinical-action', actionId: 'volume-bolus' });
  hypovolemia.advance(600);
  assert.notEqual(hypovolemia.instructorPresentation().trajectory.endpoint?.type, 'death', 'treated hypovolemia should not die');

  const tamponade = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario('lf-02-tamponade') });
  tamponade.submit({ type: 'start-scenario' });
  tamponade.advance(200);
  tamponade.submit({ type: 'clinical-action', actionId: 'assess-hemodynamics' });
  tamponade.submit({ type: 'clinical-action', actionId: 'order-echo' });
  tamponade.submit({ type: 'clinical-action', actionId: 'pericardial-decompression' });
  tamponade.advance(600);
  assert.notEqual(tamponade.instructorPresentation().trajectory.endpoint?.type, 'death', 'treated tamponade should not die');
});

test('recognizing tamponade without treating it (assess + echo, but never decompress) still deteriorates — recognition alone does not cure anything', () => {
  const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario('lf-02-tamponade') });
  session.submit({ type: 'start-scenario' });
  session.advance(60);
  session.submit({ type: 'clinical-action', actionId: 'assess-hemodynamics' });
  session.submit({ type: 'clinical-action', actionId: 'order-echo' }); // now "diagnosed" but never decompressed
  session.advance(600);
  const endpoint = session.instructorPresentation().trajectory.endpoint;
  assert.equal(endpoint?.type, 'death', 'diagnosing tamponade without draining it must not spare the patient');
});

test('SUMMARY — bench acceptance findings as of this run (see file comments for detail)', () => {
  // This test always passes; it exists to keep the findings attached to
  // the suite that discovered them rather than only in a chat reply.
  //
  // FIXED ACROSS THIS SEQUENCE OF PASSES:
  // - lf-01-preload and lf-02-tamponade previously showed ZERO monitor
  //   change after 10 fully untreated minutes (flat MAP/HR, trajectory
  //   stuck at "deteriorating", no endpoint reachable). Root cause #1: the
  //   support-consequence engine (clinical-consequence.mjs) only ever
  //   evaluated a flow-index deficit. These two complications manifest as
  //   hypotension with a near-normal flow-index reading, so they were
  //   structurally invisible to it. Fixed by adding a MAP-based deficit
  //   evaluated alongside flow, using whichever is worse to drive BOTH the
  //   severity classification and the actual modifier magnitude.
  // - Root cause #2, found after the above still left them declining too
  //   slowly to ever die: both complications' clinical-events definitions
  //   (clinical-knowledge-registry.mjs) had NO time-based progression at
  //   all from their starting state — nothing forced them to worsen if the
  //   learner just did nothing. Fixed by adding timeRules so decompensating
  //   (and, for tamponade, "suspected"/"diagnosed" — recognized but not yet
  //   treated) progress to worsened -> critical -> arrest if left alone.
  //   Both now reach death at ~9.3 min fully untreated, and correct,
  //   timely treatment still fully prevents it (tested below).
  // - The clinical-trajectory system's notion of patient death and the
  //   rhythm.mjs ECG display were not linked — a patient could die with a
  //   calm sinus trace. Fixed: rhythm escalation is now also driven by
  //   trajectory severity/arrest/death, with asystole added as a real
  //   terminal stage. All six cases now show asystole at death.
  //
  // STILL WORTH YOUR ATTENTION:
  // - Every timing constant here (240s/60s/90s/180s and the ones in
  //   clinical-consequence.mjs and rhythm.mjs) is still a placeholder, not
  //   a clinically validated value. The qualitative defects are fixed; the
  //   pace is still yours to tune.
  assert.ok(true);
});
