import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const root=new URL('../../',import.meta.url);
test('M12 required milestone freeze artifacts exist',()=>{
 for(const f of ['M2_FREEZE_2026-07-22.md','M3_FREEZE_2026-07-22.md','M4_FREEZE_2026-07-22.md','M5_FREEZE_2026-07-22.md','M6_FREEZE_2026-07-22.md','M7_FREEZE_2026-07-22.md','M8_FREEZE_2026-07-22.md','M9_FREEZE_2026-07-22.md','M10_FREEZE_2026-07-22.md','M11_FREEZE_2026-07-22.md'])assert.equal(fs.existsSync(new URL(f,root)),true,f);
});
test('current standalone V1 shell exists',()=>assert.equal(fs.existsSync(new URL('standalone-v3.1/index.html',root)),true));
test('feature freeze does not misrepresent clinical validation',()=>{
 const h=fs.readFileSync(new URL('standalone-v3.1/index.html',root),'utf8');assert.match(h,/clinicalReviewStatus:'pending'|clinicalReviewStatus:"pending"/);assert.match(h,/competencyReady:false/);
});
