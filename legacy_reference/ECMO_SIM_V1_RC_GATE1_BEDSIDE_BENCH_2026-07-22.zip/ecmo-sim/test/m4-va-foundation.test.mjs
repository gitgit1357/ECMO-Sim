import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {VA_ECMO_PRESETS,listVaEcmoScenarios,buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
test('M4 locks four VA case families',()=>{assert.equal(VA_ECMO_PRESETS.length,4);assert.equal(listVaEcmoScenarios().length,4);});
for(const p of VA_ECMO_PRESETS)test(`${p.id} builds learner-neutral VA scenario`,()=>{
 const sc=buildVaEcmoScenario(p.id);assert.equal(sc.educatorSetup.ecmo.mode,'VA');assert.ok(sc.recentEvents.length>=3);assert.equal(sc.learnerObjectives.length,4);
 assert.equal(JSON.stringify(sc).includes(p.educatorLabel),true);
 const s=circuitSandboxEngine.createSession({scenario:sc});const lp=s.presentation();assert.equal(JSON.stringify(lp).includes(p.educatorLabel),false);
 s.submit({type:'start-scenario'});assert.equal(s.instructorPresentation().clinicalEventState.active[p.complicationId].state,'active');
});
test('VA-01 differential hypoxemia proving path recognizes and resolves cause-directed management',()=>{
 const sc=buildVaEcmoScenario('va-01-differential-hypoxemia');const s=circuitSandboxEngine.createSession({scenario:sc});s.submit({type:'start-scenario'});
 const a=s.submit({type:'clinical-action',actionId:'assess-differential-hypoxemia'});assert.match(a.feedback,/Site-specific oxygenation assessment/i);
 assert.equal(s.instructorPresentation().clinicalEventState.active['va-differential-hypoxemia'].state,'recognized');
 const b=s.submit({type:'clinical-action',actionId:'correct-differential-hypoxemia'});assert.match(b.feedback,/upper-body circulation/i);
 assert.equal(s.instructorPresentation().clinicalEventState.active['va-differential-hypoxemia'].state,'resolved');
});
test('VA-01 worsens when upper-body hypoxemia remains untreated',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});s.advance(241);
 assert.equal(s.instructorPresentation().clinicalEventState.active['va-differential-hypoxemia'].state,'worsened');
});
