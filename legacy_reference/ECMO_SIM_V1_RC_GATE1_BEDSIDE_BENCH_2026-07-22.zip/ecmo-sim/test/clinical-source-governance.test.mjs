import test from 'node:test';
import assert from 'node:assert/strict';
import {resolveClinicalAuthority, clinicalRuleRecord} from '../src/core/clinical-source-governance.mjs';

test('institutional protocol always governs when available',()=>{
 const r=resolveClinicalAuthority({
  institutionalSource:{available:true,title:'Institution ECMO Policy v2'},
  elsoSource:{available:true,title:'ELSO guideline'}
 });
 assert.equal(r.authority,'institution');
 assert.equal(r.fallbackUsed,false);
 assert.equal(r.source.title,'Institution ECMO Policy v2');
});

test('ELSO is used only as documented fallback when institution source absent',()=>{
 const r=resolveClinicalAuthority({
  institutionalSource:{available:false},
  elsoSource:{available:true,title:'ELSO guideline'}
 });
 assert.equal(r.authority,'elso');
 assert.equal(r.fallbackUsed,true);
});

test('unsupported rules remain explicitly unvalidated',()=>{
 const r=clinicalRuleRecord({ruleId:'x',currentSimulationValue:120});
 assert.equal(r.governingAuthority,'unvalidated');
 assert.equal(r.validationEligible,false);
 assert.equal(r.clinicallyValidated,false);
});

test('reviewer validated status cannot override absence of an authoritative source',()=>{
 const r=clinicalRuleRecord({ruleId:'x',reviewerStatus:'validated'});
 assert.equal(r.clinicallyValidated,false);
});
