import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {educatorScenarioCatalog,createEducatorScenario} from '../src/core/educator-scenario-creator.mjs';

test('educator creator exposes all supported packs/templates',()=>{
 const c=educatorScenarioCatalog();assert.equal(c.length,5);assert.ok(c.every(p=>p.templates.length>0));
 assert.ok(c.some(p=>p.id==='low-flow'));assert.ok(c.some(p=>p.id==='patient'));
});
for(const id of ['lf-01-preload','ce-03-oxygenator','va-01-differential-hypoxemia','vv-01-recirculation','pe-01-arrhythmia-arrest']){
 test(`educator creator builds supported ${id} without source editing`,()=>{
  const sc=createEducatorScenario({templateId:id,difficulty:'advanced',mode:'adaptive',recentEventNote:'Instructor-added contextual handoff note.'});
  assert.equal(sc.educatorCreatorMetadata.createdFromSupportedTemplate,true);assert.equal(sc.learningPlan.difficulty,'advanced');assert.equal(sc.learningPlan.mode,'adaptive');
  assert.ok(sc.recentEvents.some(x=>x.text==='Instructor-added contextual handoff note.'));
  const s=circuitSandboxEngine.createSession({scenario:sc});assert.ok(s.presentation().learnerBriefing);
 });
}
test('educator creator rejects unsupported free-form templates and invalid modes',()=>{
 assert.throws(()=>createEducatorScenario({templateId:'invented-dangerous-case'}),/Unsupported educator scenario template/);
 assert.throws(()=>createEducatorScenario({templateId:'lf-01-preload',mode:'anything'}),/Unsupported education mode/);
});
