import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const l=JSON.parse(fs.readFileSync(new URL('../../B3_VV_RESPIRATORY_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
test('B3 VV ledger has all discovered VV/shared respiratory primitives',()=>{assert.ok(l.length>=4);for(const id of ['vv-recirculation','oxygenator-thrombosis-failure','gas-exchange-failure','pneumothorax-intrathoracic-pressure','airway-ventilator-failure'])assert.ok(l.some(x=>x.ruleId.endsWith(id)),id);});
test('shared oxygenator rule remains circuit-primary with VV secondary applicability',()=>{const x=l.find(x=>x.ruleId.endsWith('oxygenator-thrombosis-failure'));assert.equal(x.elsoDomain,'circuits');assert.ok(x.secondaryDomains.includes('adult-vv-respiratory'));});
test('B3 evidence ledger passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(l);assert.equal(v.valid,true,v.errors.join(';'));});
test('B3 authorizes no unsupported numeric changes',()=>assert.ok(l.every(x=>!x.numericStandardClaimAllowed&&!x.simulationChangeAuthorized)));
