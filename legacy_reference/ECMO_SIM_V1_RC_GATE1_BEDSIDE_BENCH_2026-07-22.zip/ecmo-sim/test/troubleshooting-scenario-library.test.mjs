import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import {
  listLowFlowTroubleshootingScenarios,
  buildLowFlowTroubleshootingScenario,
  buildBlindLowFlowTroubleshootingScenario
} from '../src/core/troubleshooting-scenario-library.mjs';

test('troubleshooting pack exposes educator labels separately from learner-neutral labels', () => {
  const educator=listLowFlowTroubleshootingScenarios({audience:'educator'});
  const learner=listLowFlowTroubleshootingScenarios({audience:'learner'});
  assert.equal(educator.length,6);
  assert.equal(learner.length,6);
  assert.match(educator[1].label,/tamponade/i);
  assert.equal(JSON.stringify(learner).toLowerCase().includes('tamponade'),false);
  assert.equal(JSON.stringify(learner).toLowerCase().includes('hypovolemia'),false);
});

test('each troubleshooting preset builds one exact registry-backed complication without embedded behavior', () => {
  for (const item of listLowFlowTroubleshootingScenarios({audience:'educator'})) {
    const scenario=buildLowFlowTroubleshootingScenario(item.id);
    assert.deepEqual(scenario.clinicalKnowledgePlan.requiredComplicationIds,[item.complicationId]);
    assert.equal(Object.hasOwn(scenario,'clinicalEvents'),false);
    assert.equal(scenario.clinicalKnowledgePlan.triggerPolicies.length,1);
  }
});

test('learner presentation exposes neutral briefing but not educator scenario metadata', () => {
  const scenario=buildLowFlowTroubleshootingScenario('lf-02-tamponade');
  const session=circuitSandboxEngine.createSession({scenario});
  const view=session.presentation();
  const serialized=JSON.stringify(view).toLowerCase();
  assert.match(view.learnerBriefing.caseLabel,/low-flow troubleshooting 02/i);
  assert.equal(serialized.includes('tamponade'),false);
  assert.equal(serialized.includes('educatorscenariometadata'),false);
  assert.equal(serialized.includes('intendedcomplicationid'),false);
});

test('blind low-flow scenario selection is deterministic by seed and remains learner-blind', () => {
  const a=buildBlindLowFlowTroubleshootingScenario({seed:'alpha'});
  const b=buildBlindLowFlowTroubleshootingScenario({seed:'alpha'});
  const c=buildBlindLowFlowTroubleshootingScenario({seed:'beta'});
  assert.equal(a.educatorScenarioMetadata.intendedComplicationId,b.educatorScenarioMetadata.intendedComplicationId);
  assert.equal(a.learnerBriefing.caseLabel,'Blind Low-Flow Troubleshooting');
  const session=circuitSandboxEngine.createSession({scenario:a});
  const serialized=JSON.stringify(session.presentation()).toLowerCase();
  assert.equal(serialized.includes(a.educatorScenarioMetadata.intendedComplicationId.toLowerCase()),false);
  assert.ok(c.educatorScenarioMetadata.intendedComplicationId);
});

test('all six troubleshooting scenarios can start and enter a live clinical state', () => {
  for (const item of listLowFlowTroubleshootingScenarios({audience:'educator'})) {
    const scenario=buildLowFlowTroubleshootingScenario(item.id);
    const session=circuitSandboxEngine.createSession({scenario});
    assert.equal(session.presentation().started,false);
    const start=session.submit({type:'start-scenario'});
    assert.equal(start.status,'started');
    assert.equal(session.presentation().started,true);
    assert.ok(session.instructorPresentation().clinicalEventState.active[item.complicationId],`expected active ${item.complicationId}`);
  }
});
