import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const l=JSON.parse(fs.readFileSync(new URL('../../B4_VA_CARDIAC_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
test('B4 contains VA/cardiac registry primitives',()=>{assert.equal(l.length,3);for(const id of ['va-differential-hypoxemia','va-lv-distension','limb-ischemia'])assert.ok(l.some(x=>x.ruleId.endsWith(id)),id);});
test('B4 defaults to ELSO adult VA/cardiac governance',()=>assert.ok(l.every(x=>x.elsoDomain==='adult-va-cardiac'&&x.governingAuthority==='elso')));
test('B4 ledger passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(l);assert.equal(v.valid,true,v.errors.join(';'));});
test('B4 authorizes no unsupported numeric changes',()=>assert.ok(l.every(x=>!x.numericStandardClaimAllowed&&!x.simulationChangeAuthorized)));
