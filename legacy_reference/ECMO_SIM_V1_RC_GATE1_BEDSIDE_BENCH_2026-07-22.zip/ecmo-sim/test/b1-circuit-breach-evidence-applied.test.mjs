import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const ev=JSON.parse(fs.readFileSync(new URL('../../B1_CIRCUIT_BREACH_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
const d=JSON.parse(fs.readFileSync(new URL('../../B1_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
test('circuit breach avoids invented universal clamp sequence',()=>assert.match(ev.simulatorDisposition.fixedUniversalClampSequence,/avoided/i));
test('circuit breach timing remains unpromoted placeholder',()=>assert.match(ev.simulatorDisposition.deteriorationTiming,/placeholder/i));
test('all five B1 dossiers now have source review records',()=>{assert.equal(d.length,5);assert.ok(d.every(x=>x.sourceContentReviewed===true&&x.sourceApplicabilityConfirmed===true));});
test('all B1 evidence-applied rules still await expert clinical signoff',()=>assert.ok(d.every(x=>/expert-clinical-signoff/.test(x.reviewerStatus))));
