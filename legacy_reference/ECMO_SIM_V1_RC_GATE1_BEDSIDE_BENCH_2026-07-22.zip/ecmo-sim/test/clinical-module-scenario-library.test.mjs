import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { listAllClinicalModuleScenarios, buildClinicalModuleScenario } from '../src/core/clinical-module-scenario-library.mjs';

test('all 36 reusable complication definitions can be instantiated as neutral engine-backed scenarios', () => {
  const cases=listAllClinicalModuleScenarios({audience:'educator'});
  assert.equal(cases.length,36);
  for(const item of cases){
    const scenario=buildClinicalModuleScenario(item.id);
    assert.deepEqual(scenario.clinicalKnowledgePlan.requiredComplicationIds,[item.id]);
    assert.equal(Object.hasOwn(scenario,'clinicalEvents'),false);
    const session=circuitSandboxEngine.createSession({scenario});
    const learner=JSON.stringify(session.presentation()).toLowerCase();
    assert.equal(learner.includes(item.id.toLowerCase()),false);
    const start=session.submit({type:'start-scenario'});
    assert.equal(start.status,'started');
    assert.ok(session.instructorPresentation().clinicalEventState.active[item.id]);
  }
});

test('learner module catalog contains neutral labels only', () => {
  const learner=JSON.stringify(listAllClinicalModuleScenarios({audience:'learner'})).toLowerCase();
  for(const forbidden of ['tamponade','hemolysis','stroke','sepsis','pneumothorax','pump failure']){
    assert.equal(learner.includes(forbidden),false,`leaked ${forbidden}`);
  }
});
