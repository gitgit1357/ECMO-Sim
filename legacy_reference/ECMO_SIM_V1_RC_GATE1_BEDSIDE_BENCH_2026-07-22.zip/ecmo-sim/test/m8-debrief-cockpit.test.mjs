import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v2.9/index.html',import.meta.url),'utf8');
test('standalone v2.9 renders structured decision analysis after endpoint',()=>{assert.match(h,/['\"]src\/core\/debrief-analysis\.mjs['\"]:function\(module,exports,require\)/);for(const x of ['debriefAnalysis','Decision analysis','Expected pathway vs. actions taken','improvementOpportunities','learnerDebrief','buildLearnerDebriefAnalysis'])assert.match(h,new RegExp(x));});
