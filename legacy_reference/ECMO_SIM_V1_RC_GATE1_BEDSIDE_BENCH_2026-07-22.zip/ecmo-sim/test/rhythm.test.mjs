import test from 'node:test';
import assert from 'node:assert/strict';
import { resolveRhythmEscalation, resolveRhythmRescueAction, RHYTHM_ORDER } from '../src/core/rhythm.mjs';

test('no escalation below any threshold', () => {
  const result = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 10, noFlowSeconds: 0 });
  assert.equal(result, null);
});

test('hypoxia crossing 60s escalates sinus to junctional', () => {
  const result = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 61, noFlowSeconds: 0 });
  assert.equal(result.rhythm, 'junctional');
  assert.match(result.reason, /hypoxia/);
});

test('a single long tick can jump straight to the deserved stage rather than requiring incremental steps', () => {
  const result = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 400, noFlowSeconds: 0 });
  assert.equal(result.rhythm, 'vfib');
});

test('no-flow escalates faster than hypoxia (loss of circuit support is more acute)', () => {
  const toVtach = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 0, noFlowSeconds: 21 });
  assert.equal(toVtach.rhythm, 'vtach');
  const toVfib = resolveRhythmEscalation({ rhythm: 'vtach', hypoxiaSeconds: 0, noFlowSeconds: 46 });
  assert.equal(toVfib.rhythm, 'vfib');
});

test('never de-escalates: a rhythm past the deserved stage returns null even if conditions look mild now', () => {
  const result = resolveRhythmEscalation({ rhythm: 'vfib', hypoxiaSeconds: 0, noFlowSeconds: 0 });
  assert.equal(result, null);
});

test('sustained critical trajectory (not just hypoxia or lost flow) also escalates rhythm — the monitor must reflect overall patient condition', () => {
  const result = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 0, noFlowSeconds: 0, criticalTrajectorySeconds: 61 });
  assert.equal(result.rhythm, 'junctional');
  assert.match(result.reason, /critical instability/);
});

test('an active cardiac arrest (from clinical-trajectory) forces at least vfib immediately, with no timer required', () => {
  const result = resolveRhythmEscalation({ rhythm: 'sinus', hypoxiaSeconds: 0, noFlowSeconds: 0, arrestActive: true });
  assert.equal(result.rhythm, 'vfib');
  assert.equal(result.reason, 'cardiac arrest');
});

test('a death endpoint forces asystole even from vfib — a dying patient must show a terminal rhythm, not a shockable one', () => {
  const result = resolveRhythmEscalation({ rhythm: 'vfib', hypoxiaSeconds: 0, noFlowSeconds: 0, endpointType: 'death' });
  assert.equal(result.rhythm, 'asystole');
});

test('a death endpoint on an already-asystole patient returns null (nothing further to escalate to)', () => {
  const result = resolveRhythmEscalation({ rhythm: 'asystole', hypoxiaSeconds: 0, noFlowSeconds: 0, endpointType: 'death' });
  assert.equal(result, null);
});

test('epinephrine is the primary (preferred) treatment for asystole and can restore organized activity, unlike its adjunct-only role in vtach/vfib', () => {
  const result = resolveRhythmRescueAction('administer-arrest-epinephrine', 'asystole');
  assert.equal(result.outcome, 'preferred');
  assert.equal(result.nextRhythm, 'junctional');
});

test('defibrillation and synchronized cardioversion are not indicated for asystole (a non-shockable rhythm)', () => {
  assert.equal(resolveRhythmRescueAction('defibrillate', 'asystole').outcome, 'harmful');
  assert.equal(resolveRhythmRescueAction('synchronized-cardioversion', 'asystole').outcome, 'harmful');
});

test('defibrillate is preferred and converts vfib to sinus; acceptable-but-less-ideal for vtach', () => {
  const onVfib = resolveRhythmRescueAction('defibrillate', 'vfib');
  assert.equal(onVfib.outcome, 'preferred');
  assert.equal(onVfib.nextRhythm, 'sinus');

  const onVtach = resolveRhythmRescueAction('defibrillate', 'vtach');
  assert.equal(onVtach.outcome, 'acceptable');
  assert.equal(onVtach.nextRhythm, 'sinus');
});

test('defibrillate is harmful and does not change an organized, perfusing rhythm', () => {
  const onSinus = resolveRhythmRescueAction('defibrillate', 'sinus');
  assert.equal(onSinus.outcome, 'harmful');
  assert.equal(onSinus.nextRhythm, 'sinus');

  const onJunctional = resolveRhythmRescueAction('defibrillate', 'junctional');
  assert.equal(onJunctional.outcome, 'harmful');
  assert.equal(onJunctional.nextRhythm, 'junctional');
});

test('synchronized cardioversion is preferred for vtach but ineffective for vfib (no QRS to sync to)', () => {
  const onVtach = resolveRhythmRescueAction('synchronized-cardioversion', 'vtach');
  assert.equal(onVtach.outcome, 'preferred');
  assert.equal(onVtach.nextRhythm, 'sinus');

  const onVfib = resolveRhythmRescueAction('synchronized-cardioversion', 'vfib');
  assert.equal(onVfib.outcome, 'ineffective');
  assert.equal(onVfib.nextRhythm, 'vfib', 'an ineffective action must not silently convert the rhythm anyway');
});

test('arrest-dose epinephrine is an acceptable adjunct in vtach/vfib but does not itself convert the rhythm', () => {
  const result = resolveRhythmRescueAction('administer-arrest-epinephrine', 'vfib');
  assert.equal(result.outcome, 'acceptable');
  assert.equal(result.nextRhythm, 'vfib');
});

test('chest compressions: ineffective when ECMO flow is adequate, preferred when flow is lost, regardless of rhythm', () => {
  const withFlow = resolveRhythmRescueAction('begin-chest-compressions', 'vfib', { circuitFlowAdequate: true });
  assert.equal(withFlow.outcome, 'ineffective');

  const withoutFlow = resolveRhythmRescueAction('begin-chest-compressions', 'vfib', { circuitFlowAdequate: false });
  assert.equal(withoutFlow.outcome, 'preferred');

  const sinusWithoutFlow = resolveRhythmRescueAction('begin-chest-compressions', 'sinus', { circuitFlowAdequate: false });
  assert.equal(sinusWithoutFlow.outcome, 'preferred', 'flow loss makes compressions appropriate regardless of the rhythm label itself');
});

test('an unrecognized actionId resolves to null so a caller can fall through to other handling', () => {
  assert.equal(resolveRhythmRescueAction('not-a-real-action', 'vfib'), null);
});

test('RHYTHM_ORDER is the single source of truth for escalation order', () => {
  assert.deepEqual(RHYTHM_ORDER, ['sinus', 'junctional', 'vtach', 'vfib', 'asystole']);
});
