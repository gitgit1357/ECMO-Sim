import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';

test('air emergency bubble detector lifecycle is physically coherent',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});
 s.submit({type:'start-scenario'});

 // Upstream air by itself does not mean detector alarm.
 let p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,false);

 // Air reaches sensor -> alarm/interlock.
 s.submit({type:'set-bubble-detector-state',status:'alarm',residualAirUpstream:true});
 p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,true);
 assert.equal(p.circuit.circuitFlowLpm,0);

 // Reset alone is not de-airing.
 s.submit({type:'reset-bubble-detector-alarm'});
 p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,false);
 assert.equal(p.bubbleSafety.residualAirUpstream,true);
 assert.equal(p.bubbleSafety.resetArmed,true);

 // Restoring flow with residual air retrips.
 s.submit({type:'set-param',param:'pumpRpm',value:1800});
 p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,true);
 assert.equal(p.circuit.circuitFlowLpm,0);

 // De-air, reset, restore -> stays clear.
 s.submit({type:'clear-circuit-air'});
 s.submit({type:'reset-bubble-detector-alarm'});
 s.submit({type:'set-param',param:'pumpRpm',value:1800});
 p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,false);
 assert.equal(p.bubbleSafety.residualAirUpstream,false);
});
