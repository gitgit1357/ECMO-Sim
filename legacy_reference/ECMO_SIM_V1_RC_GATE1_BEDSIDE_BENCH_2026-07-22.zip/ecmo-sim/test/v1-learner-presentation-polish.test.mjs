import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';
const cases=[
 ['lf-01-preload',buildLowFlowTroubleshootingScenario],['ce-01-air-emergency',buildCircuitEmergencyScenario],
 ['va-01-differential-hypoxemia',buildVaEcmoScenario],['vv-01-recirculation',buildVvEcmoScenario],['pe-01-arrhythmia-arrest',buildPatientEmergencyScenario]
];
for(const [id,b] of cases)test(`${id} exposes startup context and rhythm to learner presentation`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:b(id)});const p=s.presentation();
 assert.ok(p.learnerBriefing||p.handoff,`${id} needs startup context`);
 assert.ok(typeof p.rhythm==='string'&&p.rhythm.length>0,`${id} needs populated rhythm state`);
});
