import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';

test('M8 debrief compares expected vs actual pathway after endpoint only',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-03-oxygenator')});assert.equal(s.learnerDebrief(),null);
 s.submit({type:'start-scenario'});s.submit({type:'clinical-action',actionId:'assess-oxygenator'});s.submit({type:'clinical-action',actionId:'increase-sweep'});s.submit({type:'clinical-action',actionId:'exchange-oxygenator'});s.advance(121);
 const d=s.learnerDebrief();assert.ok(d);assert.match(d.analysis.clinicalProblem,/Oxygenator thrombosis/i);
 assert.ok(d.analysis.expectedPathway.some(x=>x.actionId==='assess-oxygenator'&&x.performed));
 assert.ok(d.analysis.expectedPathway.some(x=>x.actionId==='exchange-oxygenator'&&x.performed));
 assert.ok(d.analysis.temporizingActionsPerformed.includes('increase-sweep'));
 assert.equal(typeof d.analysis.timeToFirstAssessmentSec,'number');
});
test('M8 debrief identifies missed preferred actions and harmful actions',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-05-circuit-obstruction')});s.submit({type:'start-scenario'});
 s.submit({type:'clinical-action',actionId:'increase-rpm'});s.submit({type:'clinical-action',actionId:'relieve-circuit-obstruction'});s.advance(121);
 const d=s.learnerDebrief();assert.ok(d.analysis.harmfulActionsPerformed.includes('increase-rpm'));
 assert.ok(d.analysis.missedPreferredActions.includes('inspect-circuit-path'));
});
test('M8 debrief keeps hidden diagnosis unavailable before completion',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-03-oxygenator')});s.submit({type:'start-scenario'});
 assert.equal(s.learnerDebrief(),null);assert.equal(JSON.stringify(s.presentation()).includes('Oxygenator thrombosis / membrane-lung failure'),false);
});
