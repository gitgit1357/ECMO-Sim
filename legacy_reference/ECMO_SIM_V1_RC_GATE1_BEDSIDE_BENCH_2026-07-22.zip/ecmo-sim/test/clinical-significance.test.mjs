import test from 'node:test';
import assert from 'node:assert/strict';
import { classifyClinicalChange, evaluateClinicalSignificance } from '../src/core/clinical-significance.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

const setup = {
  patient: { population:'neonatal', weightKg:4, diagnosis:'HLHS', procedure:'Norwood/Sano' },
  ecmo: { mode:'VA', cannulation:'central', cannulaFr:10, pumpRpm:1800, sweepGasLpm:2, fdo2Percent:50 },
  startingCondition: { hemodynamics:'unstable', renalFunction:'normal' },
  education: { primaryObjective:'low-flow-troubleshooting', concepts:['cannula-malposition'], mode:'adaptive', difficulty:'intermediate' }
};

test('minor HR movement is classified as background noise', () => {
  const result = classifyClinicalChange('hr', 120, 125);
  assert.equal(result.significance, 'background');
});

test('large indexed-flow collapse is classified as critical', () => {
  const result = classifyClinicalChange('flowIndexMlKgMin', 150, 40);
  assert.equal(result.significance, 'critical');
});

test('aggregate significance promotes the highest clinically meaningful change', () => {
  const result = evaluateClinicalSignificance(
    { hr:120, map:55, spo2:96, cvp:8, flowIndexMlKgMin:150 },
    { hr:125, map:44, spo2:95, cvp:8, flowIndexMlKgMin:40 }
  );
  assert.equal(result.significance, 'critical');
  assert.equal(result.meaningfulChanges.some((x) => x.metric === 'hr'), false);
  assert.equal(result.meaningfulChanges.some((x) => x.metric === 'flowIndexMlKgMin' && x.significance === 'critical'), true);
});

test('generic turn requires an explicit position rather than acting as a magic intervention', () => {
  const scenario = buildScenarioFromSetup(setup, { id:'position-sensitive-case' });
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type:'start-scenario' });
  const result = session.submit({ type:'clinical-action', actionId:'turn-patient' });
  assert.equal(result.status, 'position-selection-required');
  assert.ok(Array.isArray(result.positionOptions));
  assert.ok(result.positionOptions.includes('supine-midline'));
});

test('changing position without a configured position-response relationship does not invent physiology', () => {
  const neutralSetup = { ...setup, education:{...setup.education, concepts:['circuit-obstruction']} };
  const scenario = buildScenarioFromSetup(neutralSetup, { id:'neutral-turn-case' });
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type:'start-scenario' });
  const before = session.presentation().circuit.flowIndexMlKgMin;
  const result = session.submit({ type:'set-patient-position', position:'left-tilt' });
  const after = session.presentation().circuit.flowIndexMlKgMin;
  assert.equal(result.status, 'applied');
  assert.equal(after, before);
  assert.match(result.feedback, /no meaningful change/i);
});
