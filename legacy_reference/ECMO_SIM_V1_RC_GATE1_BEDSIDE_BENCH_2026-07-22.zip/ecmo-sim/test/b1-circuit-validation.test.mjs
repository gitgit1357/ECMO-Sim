import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {sourceVerificationState} from '../src/core/clinical-validation-gate.mjs';
const ledger=JSON.parse(fs.readFileSync(new URL('../../B1_CIRCUIT_GAS_PATH_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
const manifest=JSON.parse(fs.readFileSync(new URL('../../clinical-validation-manifest.json',import.meta.url),'utf8'));
test('B1 has five circuit/gas-path evidence records with official ELSO source identity verified',()=>{
 assert.equal(ledger.length,5);assert.ok(ledger.every(x=>x.sourceIdentityVerified));assert.ok(ledger.every(x=>/Circuits/.test(x.primaryGuideline)));
});
test('B1 does not falsely convert source assignment into numeric clinical validation',()=>{
 assert.ok(ledger.every(x=>x.numericStandardClaimAllowed===false));assert.ok(ledger.every(x=>x.simulationChangeAuthorized===false));
});
test('source verification remains distinct from exact rule validation',()=>{
 const b1=manifest.filter(x=>ledger.some(y=>y.ruleId===x.ruleId));assert.ok(b1.every(x=>sourceVerificationState(x).sourceIdentityVerified));assert.ok(b1.every(x=>sourceVerificationState(x).exactRuleValidated===false));
});
