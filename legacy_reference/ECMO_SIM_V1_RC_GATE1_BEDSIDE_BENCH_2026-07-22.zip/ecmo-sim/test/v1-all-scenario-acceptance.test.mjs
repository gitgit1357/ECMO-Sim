import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const families=[
 ['low-flow',buildLowFlowTroubleshootingScenario,['lf-01-preload','lf-02-tamponade','lf-03-position','lf-04-kink','lf-05-circuit-obstruction','lf-06-pump-failure']],
 ['circuit',buildCircuitEmergencyScenario,['ce-01-air-emergency','ce-02-circuit-breach','ce-03-oxygenator','ce-04-sweep-gas','ce-05-hemolysis','ce-06-major-bleeding']],
 ['va',buildVaEcmoScenario,['va-01-differential-hypoxemia','va-02-lv-distension','va-03-limb-ischemia','va-04-thrombosis']],
 ['vv',buildVvEcmoScenario,['vv-01-recirculation','vv-02-oxygenator','vv-03-gas-exchange','vv-04-pneumothorax','vv-04-airway']],
 ['patient',buildPatientEmergencyScenario,['pe-01-arrhythmia-arrest','pe-02-ich','pe-03-vasoplegia','pe-03-sepsis','pe-04-aki-fluid','pe-05-metabolic','pe-06-ph-crisis']]
];

for(const [family,builder,ids] of families)for(const id of ids)test(`${id} final acceptance contract`,()=>{
 const scenario=builder(id);assert.ok(scenario.id===id||scenario.id.endsWith(id),`canonical runtime id for ${id}`);
 const s=circuitSandboxEngine.createSession({scenario});let p=s.presentation();
 assert.equal(p.lifecycle.status,'prebrief');assert.ok(p.learnerBriefing||p.handoff,'startup context');
 assert.ok(typeof p.rhythm==='string'&&p.rhythm.length,'rhythm');
 assert.ok(Array.isArray(p.availableActions)&&p.availableActions.length,'actions');
 const learnerText=JSON.stringify({brief:p.learnerBriefing,handoff:p.handoff,recent:p.recentEvents});
 assert.doesNotMatch(learnerText,/hiddenComplication|correctAction|expectedPathway|grading/i,'no educator leakage');
 const start=s.submit({type:'start-scenario'});assert.ok(start);
 p=s.presentation();assert.equal(p.lifecycle.status,'active');assert.equal(p.started,true);
 assert.ok(Number.isFinite(p.monitored.hr));assert.ok(Number.isFinite(p.monitored.map));assert.ok(Number.isFinite(p.monitored.spo2));
 assert.ok(Number.isFinite(p.circuit.pumpRpm));assert.ok(Number.isFinite(p.circuit.flowIndexMlKgMin));
 s.advance(1);p=s.presentation();assert.equal(p.timeSec,1);
});

test('acceptance inventory contains exactly 28 supported scenarios',()=>{
 assert.equal(families.reduce((n,x)=>n+x[2].length,0),28);
});
