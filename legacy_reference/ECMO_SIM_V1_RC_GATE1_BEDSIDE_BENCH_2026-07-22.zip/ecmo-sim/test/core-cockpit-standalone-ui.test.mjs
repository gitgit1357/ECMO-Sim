import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const html=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
test('standalone exposes continuous core ECMO monitors',()=>{
 for(const id of ['bp','hr','spo2','cvp','temp','preSpo2','postSpo2','rpm','flowLpm','flow','arterialFlow','shuntFlow','venous','preOxy','postOxy','dp','cdiHgb','cdiHct','cdiSvo2'])assert.ok(html.includes(`id="${id}"`),id);
});
test('standalone exposes always-available ECMO controls',()=>{
 for(const id of ['rpmSlider','flowTarget','sweepSlider','fdo2Slider','clampBtn'])assert.ok(html.includes(`id="${id}"`),id);
 assert.match(html,/set-flow-target/);assert.match(html,/set-circuit-clamp/);assert.match(html,/param:'sweepGasLpm'/);assert.match(html,/param:'fdo2Percent'/);
});
test('standalone labels pre/post oxygenation explicitly as ductal',()=>{
 assert.match(html,/PRE-DUCTAL SpO₂/);assert.match(html,/POST-DUCTAL SpO₂/);
});
