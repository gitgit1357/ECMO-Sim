import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {VV_ECMO_PRESETS,buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
test('M5 locks four VV families represented by five presets',()=>assert.equal(VV_ECMO_PRESETS.length,5));
for(const p of VV_ECMO_PRESETS)test(`${p.id} builds a single-complication learner-neutral VV scenario`,()=>{
 const sc=buildVvEcmoScenario(p.id);assert.equal(sc.educatorSetup.ecmo.mode,'VV');assert.ok(sc.recentEvents.length>=3);assert.equal(sc.learnerObjectives.length,4);
 const s=circuitSandboxEngine.createSession({scenario:sc});assert.equal(JSON.stringify(s.presentation()).includes(p.educatorLabel),false);s.submit({type:'start-scenario'});
 assert.equal(s.instructorPresentation().clinicalEventState.active[p.complicationId].state,'active');
});
test('VV-01 recirculation exposes discriminating saturation/recirculation evidence and resolves',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});
 let r=s.submit({type:'clinical-action',actionId:'assess-recirculation'});assert.match(r.feedback,/recirculated fraction about 48%/i);assert.match(r.feedback,/drainage\/pre-oxygenator saturation about 86%/i);assert.match(r.feedback,/systemic SpO2 is only about 84%/i);
 s.submit({type:'clinical-action',actionId:'correct-recirculation'});r=s.submit({type:'clinical-action',actionId:'assess-recirculation'});assert.match(r.feedback,/improved effective support/i);assert.match(r.feedback,/about 18%/);
 s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
test('VV-01 indiscriminate RPM escalation does not solve recirculation',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});const r=s.submit({type:'clinical-action',actionId:'increase-rpm'});
 assert.match(r.feedback,/may worsen recirculation/i);assert.notEqual(s.instructorPresentation().clinicalEventState.active['vv-recirculation'].state,'resolved');
});
