import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';import path from 'node:path';
const ROOT=path.resolve(new URL('../../',import.meta.url).pathname);
const files=fs.readdirSync(ROOT).filter(x=>/^B\d+_EXACT_COMPARISON_DOSSIERS\.json$/.test(x));
test('all exact-comparison dossiers carry explicit reviewer status',()=>{
 assert.ok(files.length>=7);
 for(const f of files){const d=JSON.parse(fs.readFileSync(path.join(ROOT,f),'utf8'));for(const x of d)assert.ok(x.reviewerStatus,`${f} ${x.ruleId}`);}
});
test('unpromoted/partial rules remain explicitly marked pending rather than validated',()=>{
 const partial=[];
 for(const f of files){for(const x of JSON.parse(fs.readFileSync(path.join(ROOT,f),'utf8')))if(x.changeAuthorized===false)partial.push(x);}
 assert.ok(partial.length>=1);for(const x of partial)assert.match(x.reviewerStatus,/pending|specialty/i);
});
test('validation artifacts do not claim placeholder timers are ELSO standards',()=>{
 for(const f of fs.readdirSync(ROOT).filter(x=>/^B\d+_EXACT.*\.(json|md)$/.test(x))){
   const s=fs.readFileSync(path.join(ROOT,f),'utf8');
   assert.doesNotMatch(s,/\d+\s*(?:second|seconds|sec|min|minute|minutes).{0,80}(?:ELSO standard|ELSO requirement|required by ELSO)/i,f);
 }
});
