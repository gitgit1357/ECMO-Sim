import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';

test('circuit cases expose broad circuit-emergency differential actions rather than case-specific set',()=>{
 const p=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-03-oxygenator')}).presentation();
 const ids=new Set(p.availableActions.map(x=>x.id));for(const x of ['inspect-for-air','control-circuit-breach','assess-oxygenator','verify-sweep-gas','assess-hemolysis','control-major-bleeding'])assert.ok(ids.has(x),x);
});
test('VV cases expose broad VV differential actions rather than revealing recirculation diagnosis',()=>{
 const p=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')}).presentation();
 const ids=new Set(p.availableActions.map(x=>x.id));for(const x of ['assess-recirculation','assess-oxygenator','assess-gas-exchange','assess-thorax','assess-airway-ventilator'])assert.ok(ids.has(x),x);
});
