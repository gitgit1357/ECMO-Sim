import test from 'node:test';
import assert from 'node:assert/strict';
import { createDebriefLog } from '../src/core/debrief-log.mjs';

test('record() assigns a canonical id/sequence/category without dropping the caller\'s original fields', () => {
  const log = createDebriefLog();
  const entry = log.record({ atSec: 12, kind: 'set-param', param: 'pumpRpm', value: 1800 });
  assert.equal(entry.id, 'debrief-1');
  assert.equal(entry.sequence, 1);
  assert.equal(entry.category, 'action');
  assert.equal(entry.param, 'pumpRpm');
  assert.equal(entry.value, 1800);
  assert.equal(entry.outcomeClass, null);
});

test('unmapped kinds fall back to category "other" rather than throwing', () => {
  const log = createDebriefLog();
  const entry = log.record({ atSec: 0, kind: 'some-future-kind-not-in-the-table' });
  assert.equal(entry.category, 'other');
});

test('outcomeClass is inferred from either an "outcome" or "outcomeClass" field, and left null otherwise', () => {
  const log = createDebriefLog();
  const fromOutcome = log.record({ atSec: 1, kind: 'clinical-action-outcome', eventId: 'hypovolemia', outcome: 'preferred', scoreDelta: 10 });
  const fromExplicit = log.record({ atSec: 2, kind: 'clinical-action-outcome', eventId: 'hypovolemia', outcomeClass: 'harmful' });
  const neither = log.record({ atSec: 3, kind: 'scenario-started' });
  assert.equal(fromOutcome.outcomeClass, 'preferred');
  assert.equal(fromExplicit.outcomeClass, 'harmful');
  assert.equal(neither.outcomeClass, null);
});

test('instructorTimeline returns everything; learnerTimeline hides diagnostic kinds and strips forbidden fields', () => {
  const log = createDebriefLog();
  log.record({ kind: 'scenario-started', atSec: 0 });
  log.record({ kind: 'clinical-action-outcome', atSec: 5, eventId: 'postoperative-tamponade', outcome: 'harmful', scoreDelta: -10, rationale: 'secret rationale' });
  log.record({ kind: 'set-param', atSec: 6, param: 'pumpRpm', value: 1900 });

  const instructor = log.instructorTimeline();
  assert.equal(instructor.length, 3);
  assert.ok(instructor.some((e) => e.eventId === 'postoperative-tamponade'));

  const learner = log.learnerTimeline();
  assert.equal(learner.length, 2, 'the hidden clinical-action-outcome kind should not reach the learner');
  assert.ok(!learner.some((e) => e.kind === 'clinical-action-outcome'));
  assert.ok(!JSON.stringify(learner).includes('postoperative-tamponade'), 'no diagnosis leakage into the learner timeline');
});

test('learnerTimeline(limit) applies the limit before sanitizing, matching prior circuit-sandbox behavior', () => {
  const log = createDebriefLog();
  for (let i = 0; i < 5; i += 1) log.record({ kind: 'set-param', atSec: i, param: 'pumpRpm', value: i });
  const limited = log.learnerTimeline(2);
  assert.equal(limited.length, 2);
  assert.equal(limited[0].value, 3);
  assert.equal(limited[1].value, 4);
});

test('summary() totals score, counts outcome classes, and tracks one row per complication encountered', () => {
  const log = createDebriefLog();
  log.record({ kind: 'scenario-started', atSec: 0 });
  log.record({ kind: 'clinical-action-outcome', atSec: 10, eventId: 'hypovolemia', outcome: 'ineffective', scoreDelta: -2 });
  log.record({ kind: 'clinical-action-outcome', atSec: 40, eventId: 'hypovolemia', outcome: 'preferred', scoreDelta: 10, resolved: true });
  log.record({ kind: 'clinical-action-outcome', atSec: 45, eventId: 'postoperative-tamponade', outcome: 'harmful', scoreDelta: -5 });
  log.record({ kind: 'set-param', atSec: 46, param: 'pumpRpm', value: 2000 });
  log.record({ kind: 'scenario-endpoint', atSec: 200, endpoint: { type: 'stabilized', reason: 'sustained-clinical-stability', atSec: 200 } });

  const summary = log.summary();
  assert.equal(summary.totalScore, 3); // -2 + 10 - 5
  assert.deepEqual(summary.outcomeClassCounts, { ineffective: 1, preferred: 1, harmful: 1 });
  assert.equal(summary.scenarioStartedAtSec, 0);
  assert.equal(summary.actionCount, 1);
  assert.equal(summary.endpoint.type, 'stabilized');

  const hypovolemia = summary.complications.find((c) => c.eventId === 'hypovolemia');
  assert.equal(hypovolemia.firstSeenAtSec, 10);
  assert.equal(hypovolemia.resolvedAtSec, 40);
  assert.equal(hypovolemia.scoredOutcomeCount, 2);

  const tamponade = summary.complications.find((c) => c.eventId === 'postoperative-tamponade');
  assert.equal(tamponade.resolvedAtSec, null, 'not marked resolved, so should stay null');
});

test('snapshot/restore round-trips the full entry history and continues numbering sequence correctly', () => {
  const log = createDebriefLog();
  log.record({ kind: 'scenario-started', atSec: 0 });
  log.record({ kind: 'set-param', atSec: 5, param: 'pumpRpm', value: 1700 });
  const saved = log.snapshot();

  const restored = createDebriefLog(saved);
  assert.equal(restored.instructorTimeline().length, 2);
  const next = restored.record({ kind: 'set-param', atSec: 10, param: 'pumpRpm', value: 1800 });
  assert.equal(next.id, 'debrief-3', 'sequence numbering should continue rather than restart after restore');
});
