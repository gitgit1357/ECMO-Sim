import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';
import {verifyReleaseManifest} from '../src/core/release-package-verifier.mjs';

const reps=[
 ['M2',buildLowFlowTroubleshootingScenario('lf-01-preload')],
 ['M3',buildCircuitEmergencyScenario('ce-03-oxygenator')],
 ['M4',buildVaEcmoScenario('va-01-differential-hypoxemia')],
 ['M5',buildVvEcmoScenario('vv-01-recirculation')],
 ['M6',buildPatientEmergencyScenario('pe-01-arrhythmia-arrest')]
];

for(const [label,scenario] of reps){
 test(`${label} representative scenario still creates a valid prebrief session`,()=>{
  const s=circuitSandboxEngine.createSession({scenario});
  const p=s.presentation();
  assert.equal(p.lifecycle.status,'prebrief');
  assert.ok(p.learnerBriefing);
  assert.ok(Array.isArray(p.availableActions));
 });
}

test('release integrity manifest is internally valid',()=>{
 const m=JSON.parse(fs.readFileSync(new URL('../../RELEASE_INTEGRITY_MANIFEST.json',import.meta.url),'utf8'));
 const v=verifyReleaseManifest(m);
 assert.equal(v.valid,true,v.errors.join('; '));
});

test('standalone current build is present and labeled preclinical-safe',()=>{
 const h=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
 assert.match(h,/V1 Feature Complete/);
 assert.match(h,/validation|preclinical|competency-ready/i);
});
