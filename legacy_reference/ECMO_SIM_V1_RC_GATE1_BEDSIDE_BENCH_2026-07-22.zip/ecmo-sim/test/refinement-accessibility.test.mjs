import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
test('refinement v3.3 removes stale low-flow-only shell labeling',()=>{assert.match(h,/ECMO Simulation Platform — V1 Feature Complete/);assert.doesNotMatch(h,/active M3 Circuit Emergency proving case/);});
test('irrelevant positioning panel is hidden outside low-flow family',()=>{assert.match(h,/id="positionPanel"/);assert.match(h,/currentFamily==='low-flow'/);});
test('dynamic feedback/debrief regions use polite live announcements',()=>{assert.match(h,/id="feed" aria-live="polite"/);assert.match(h,/id="completionPanel" aria-live="polite"/);});
