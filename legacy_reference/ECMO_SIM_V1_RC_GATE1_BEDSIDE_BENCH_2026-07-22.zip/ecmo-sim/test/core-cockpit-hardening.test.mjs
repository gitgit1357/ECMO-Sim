import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const samples=[
 buildLowFlowTroubleshootingScenario('lf-01-preload'),
 buildCircuitEmergencyScenario('ce-03-oxygenator'),
 buildVaEcmoScenario('va-01-differential-hypoxemia'),
 buildVvEcmoScenario('vv-01-recirculation'),
 buildPatientEmergencyScenario('pe-03-sepsis')
];

test('continuous cockpit values refresh every simulation tick',()=>{
 for(const scenario of samples){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});
  const a=s.presentation();s.advance(1);const b=s.presentation();
  assert.equal(b.timeSec,a.timeSec+1);
  for(const path of [
   ['monitored','hr'],['monitored','bp'],['monitored','cvp'],['monitored','tempC'],
   ['circuit','pumpRpm'],['circuit','circuitFlowLpm'],['circuit','venousPressure'],
   ['circuit','preOxyPressure'],['circuit','postOxyPressure'],['circuit','deltaP'],
   ['cdi','hgbGdl'],['cdi','hctPercent'],['cdi','svo2Percent']
  ]) assert.ok(path.reduce((o,k)=>o?.[k],b)!==undefined,`${scenario.id} ${path.join('.')}`);
 }
});

test('RPM, sweep and FdO2 changes are immediate and not scenario-gated',()=>{
 for(const scenario of samples){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});
  const p=s.presentation();
  assert.equal(s.submit({type:'set-param',param:'pumpRpm',value:p.settings.pumpRpm+100}).accepted,true);
  assert.equal(s.submit({type:'set-param',param:'sweepGasLpm',value:p.settings.sweepGasLpm+0.5}).accepted,true);
  assert.equal(s.submit({type:'set-param',param:'fdo2Percent',value:Math.max(21,p.settings.fdo2Percent-5)}).accepted,true);
 }
});

test('clamp always acts immediately and independently of hidden diagnosis',()=>{
 for(const scenario of samples){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});
  s.submit({type:'set-circuit-clamp',clamped:true});let p=s.presentation();
  assert.equal(p.circuit.clamped,true);assert.equal(p.circuit.circuitFlowLpm,0);assert.equal(p.circuit.flowIndexMlKgMin,0);
  s.submit({type:'set-circuit-clamp',clamped:false});p=s.presentation();
  assert.equal(p.circuit.clamped,false);
 }
});

test('flow target control remains available even when clinically harmful or ineffective',()=>{
 for(const scenario of samples){
  const s=circuitSandboxEngine.createSession({scenario});s.submit({type:'start-scenario'});
  assert.equal(s.submit({type:'set-flow-target',flowIndexMlKgMin:180}).accepted,true);
 }
});
