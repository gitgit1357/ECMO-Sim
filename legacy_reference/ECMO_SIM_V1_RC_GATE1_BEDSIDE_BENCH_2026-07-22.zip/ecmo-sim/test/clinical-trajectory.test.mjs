import test from 'node:test';
import assert from 'node:assert/strict';
import { createClinicalTrajectoryEngine } from '../src/core/clinical-trajectory.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

const critical = [{dimensions:{perfusion:'critical',hemodynamics:'critical'}}];
const arrest = [{dimensions:{perfusion:'absent',hemodynamics:'absent'},arrest:true}];

test('cumulative critical deterioration can reach death independent of score', () => {
  const t = createClinicalTrajectoryEngine({profile:{cumulativeCriticalExposureSec:60,arrestRescueWindowSec:999}});
  t.evaluate({timeSec:0,signals:critical,unresolvedEventCount:1,started:true});
  const endpoint = t.evaluate({timeSec:60,signals:critical,unresolvedEventCount:1,started:true});
  assert.equal(endpoint.type,'death');
  assert.equal(endpoint.reason,'cumulative-critical-deterioration');
});

test('arrest remains rescuable before the configured rescue window expires', () => {
  const t = createClinicalTrajectoryEngine({profile:{arrestRescueWindowSec:60,cumulativeCriticalExposureSec:9999,stabilizationWindowSec:30}});
  t.evaluate({timeSec:0,signals:arrest,unresolvedEventCount:1,started:true});
  assert.equal(t.evaluate({timeSec:45,signals:arrest,unresolvedEventCount:1,started:true}),null);
  t.evaluate({timeSec:45,signals:[],unresolvedEventCount:0,started:true});
  assert.equal(t.evaluate({timeSec:75,signals:[],unresolvedEventCount:0,started:true}).type,'stabilized');
});

test('unresolved arrest beyond rescue window reaches death', () => {
  const t = createClinicalTrajectoryEngine({profile:{arrestRescueWindowSec:60,cumulativeCriticalExposureSec:9999}});
  t.evaluate({timeSec:0,signals:arrest,unresolvedEventCount:1,started:true});
  assert.equal(t.evaluate({timeSec:60,signals:arrest,unresolvedEventCount:1,started:true}).type,'death');
});

test('catastrophic terminal signal can end immediately while ordinary critical state does not', () => {
  const t = createClinicalTrajectoryEngine({profile:{cumulativeCriticalExposureSec:9999}});
  assert.equal(t.evaluate({timeSec:0,signals:critical,unresolvedEventCount:1,started:true}),null);
  const endpoint = t.evaluate({timeSec:1,signals:[{catastrophicTerminal:true}],unresolvedEventCount:1,started:true});
  assert.equal(endpoint.type,'death');
  assert.equal(endpoint.reason,'catastrophic-terminal-condition');
});

test('engine requires sustained stability after resolving a complication before completing', () => {
  const setup = {
    patient:{population:'neonatal',weightKg:3.4}, ecmo:{cannulaFr:10,pumpRpm:1400},
    startingCondition:{renalFunction:'normal'},
    education:{primaryObjective:'low-flow-troubleshooting',concepts:['preload-limitation'],mode:'guided'},
    endpointProfile:{stabilizationWindowSec:30,cumulativeCriticalExposureSec:9999}
  };
  const scenario = buildScenarioFromSetup(setup,{id:'stabilization-integration'});
  const session = circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  session.submit({type:'bolus-volume',mlPerKg:10});
  assert.equal(session.presentation().complete,false);
  session.advance(29);
  assert.equal(session.presentation().complete,false);
  session.advance(1);
  assert.equal(session.presentation().complete,true);
  assert.equal(session.presentation().endpoint.type,'stabilized');
});

test('instructor can terminate without classifying the patient as dead or stabilized', () => {
  const setup = {
    patient:{population:'neonatal',weightKg:3.4}, ecmo:{cannulaFr:10,pumpRpm:1400},
    startingCondition:{renalFunction:'normal'}, education:{mode:'guided'}
  };
  const session = circuitSandboxEngine.createSession({scenario:buildScenarioFromSetup(setup,{id:'manual-end'})});
  session.submit({type:'start-scenario'});
  const result = session.submit({type:'end-scenario',reason:'teaching complete'});
  assert.equal(result.status,'instructor-terminated');
  assert.equal(session.presentation().endpoint.type,'instructor-terminated');
});
