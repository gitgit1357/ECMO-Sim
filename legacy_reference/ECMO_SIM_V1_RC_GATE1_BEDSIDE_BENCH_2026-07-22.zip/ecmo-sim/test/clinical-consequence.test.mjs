import test from 'node:test';
import assert from 'node:assert/strict';
import { createClinicalConsequenceEngine, DEFAULT_SUPPORT_PROFILE } from '../src/core/clinical-consequence.mjs';

test('a normal flow index with a low MAP is classified as impaired, not adequate — the bug this fix targets', () => {
  const engine = createClinicalConsequenceEngine({ profile: { baselineFlowIndexMlKgMin: 150 } });
  const result = engine.evaluate({ timeSec: 0, flowIndexMlKgMin: 150, map: 35, started: true, internal: {} });
  assert.equal(result.flowClass, 'adequate');
  assert.equal(result.mapClass, 'impaired');
  assert.equal(result.supportClass, 'impaired', 'the worse of the two classes must win, not just the flow-based one');
});

test('the deficit MAGNITUDE (not just the classification) reflects the worse ratio — a normal flow with low MAP must still produce a nonzero modifier over time', () => {
  const engine = createClinicalConsequenceEngine({ profile: { baselineFlowIndexMlKgMin: 150 } });
  engine.evaluate({ timeSec: 0, flowIndexMlKgMin: 150, map: 35, started: true, internal: {} });
  const later = engine.evaluate({ timeSec: 120, flowIndexMlKgMin: 150, map: 35, started: true, internal: {} });
  assert.ok(later.mapModifier < 0, `expected a real negative MAP modifier once the deficit has been present a while, got ${later.mapModifier}`);
});

test('a normal MAP with reduced flow still classifies as impaired via the flow pathway (existing behavior preserved)', () => {
  const engine = createClinicalConsequenceEngine({ profile: { baselineFlowIndexMlKgMin: 150 } });
  const result = engine.evaluate({ timeSec: 0, flowIndexMlKgMin: 80, map: 50, started: true, internal: {} });
  assert.equal(result.mapClass, 'adequate');
  assert.notEqual(result.flowClass, 'adequate');
  assert.notEqual(result.supportClass, 'adequate');
});

test('both adequate flow and adequate MAP together classify as fully adequate', () => {
  const engine = createClinicalConsequenceEngine({ profile: { baselineFlowIndexMlKgMin: 150 } });
  const result = engine.evaluate({ timeSec: 0, flowIndexMlKgMin: 150, map: 50, started: true, internal: {} });
  assert.equal(result.supportClass, 'adequate');
  assert.equal(result.mapModifier, 0);
  assert.equal(result.hrModifier, 0);
});

test('omitting map entirely falls back to flow-only classification (backward compatible with any caller that does not pass it)', () => {
  const engine = createClinicalConsequenceEngine({ profile: { baselineFlowIndexMlKgMin: 150 } });
  const result = engine.evaluate({ timeSec: 0, flowIndexMlKgMin: 150, started: true, internal: {} });
  assert.equal(result.supportClass, 'adequate');
});

test('DEFAULT_SUPPORT_PROFILE.adequateMapTarget is high enough that this codebase\'s own "unstable" baseline MAP (35) actually registers a deficit', () => {
  // This is the exact bug that shipped once already: a target of 45 put
  // 35/45=0.778 just inside "adequate" (threshold 0.75) and silently
  // defeated the whole fix. Pin the constant's behavior directly so a
  // future edit can't reintroduce that by accident.
  const ratio = 35 / DEFAULT_SUPPORT_PROFILE.adequateMapTarget;
  assert.ok(ratio < 0.75, `a MAP of 35 must not classify as "adequate" against the default target; ratio was ${ratio}`);
});
