import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';

test('bubble detector lives on return limb downstream of final pigtail',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});
 s.submit({type:'start-scenario'});const p=s.presentation();
 assert.equal(p.bubbleSafety.location,'return-limb-downstream-of-final-pigtail');
 assert.equal(p.bubbleSafety.detectsOnlyAtSensorLocation,true);
 assert.equal(p.bubbleSafety.upstreamAirDoesNotAlarmUntilItReachesSensor,true);
});

test('air only trips detector/interlock when it reaches detector state',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});
 s.submit({type:'start-scenario'});
 let p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,false);
 const before=p.circuit.circuitFlowLpm;
 assert.ok(before>0);

 // Simulate upstream air that has not yet reached sensor: detector remains clear.
 p=s.presentation();
 assert.equal(p.bubbleSafety.status,'clear');
 assert.ok(p.circuit.circuitFlowLpm>0);

 // Once air reaches sensor location, alarm/interlock activates.
 s.submit({type:'set-bubble-detector-state',status:'alarm',source:'test'});
 p=s.presentation();
 assert.equal(p.bubbleSafety.alarmActive,true);
 assert.equal(p.bubbleSafety.circuitInterlockActive,true);
 assert.equal(p.circuit.circuitFlowLpm,0);
});

test('clearing detector state restores detector clear status',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildCircuitEmergencyScenario('ce-01-air-emergency')});
 s.submit({type:'start-scenario'});
 s.submit({type:'set-bubble-detector-state',status:'alarm'});
 s.submit({type:'set-bubble-detector-state',status:'clear'});
 const p=s.presentation();
 assert.equal(p.bubbleSafety.status,'clear');
 assert.equal(p.bubbleSafety.alarmActive,false);
});
