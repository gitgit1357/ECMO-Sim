import test from 'node:test';
import assert from 'node:assert/strict';
import { defaultClinicalKnowledgeRegistry } from '../src/core/clinical-knowledge-registry.mjs';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

const baseSetup = {
  patient: { population:'neonatal', weightKg:4, diagnosis:'HLHS', procedure:'Norwood/Sano' },
  ecmo: { mode:'VA', cannulation:'central', cannulaFr:10, pumpRpm:1200, sweepGasLpm:2, fdo2Percent:50 },
  startingCondition: { hemodynamics:'unstable', renalFunction:'normal' },
  education: { primaryObjective:'low-flow-troubleshooting', concepts:['tamponade-recognition'], mode:'adaptive', difficulty:'intermediate' }
};

test('objective resolves educator concepts into reusable knowledge IDs', () => {
  const resolved = defaultClinicalKnowledgeRegistry.resolveObjective('low-flow-troubleshooting', ['tamponade-recognition']);
  assert.deepEqual(resolved.complicationIds, ['postoperative-tamponade']);
  assert.ok(resolved.actionIds.includes('order-echo'));
  assert.ok(resolved.observationIds.includes('bedside-echo'));
});

test('educator-generated scenario references knowledge IDs instead of embedding complication behavior', () => {
  const scenario = buildScenarioFromSetup(baseSetup, { id:'registry-case' });
  assert.deepEqual(scenario.clinicalKnowledgePlan.requiredComplicationIds, ['postoperative-tamponade']);
  assert.equal(Object.hasOwn(scenario, 'clinicalEvents'), false);
  assert.equal(JSON.stringify(scenario).includes('pericardial collection is urgently decompressed'), false);
});

test('engine resolves registry-backed complication behavior at runtime', () => {
  const scenario = buildScenarioFromSetup(baseSetup, { id:'runtime-registry-case' });
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type:'start-scenario' });
  const volume = session.submit({ type:'bolus-volume', mlPerKg:10 });
  assert.equal(volume.status, 'applied');
  assert.match(volume.feedback, /temporary improvement/i);
  assert.equal(session.instructorPresentation().clinicalEvents.lastOutcome.outcome, 'temporizing');
});

test('same reusable complication definition can be used by multiple generated scenarios without copying rules', () => {
  const a = buildScenarioFromSetup(baseSetup, { id:'case-a' });
  const b = buildScenarioFromSetup({ ...baseSetup, patient:{...baseSetup.patient, weightKg:7} }, { id:'case-b' });
  assert.deepEqual(a.clinicalKnowledgePlan.requiredComplicationIds, b.clinicalKnowledgePlan.requiredComplicationIds);
  assert.equal(Object.hasOwn(a, 'clinicalEvents'), false);
  assert.equal(Object.hasOwn(b, 'clinicalEvents'), false);
});

test('low-flow objective now resolves all major differential families to reusable knowledge', () => {
  const resolved = defaultClinicalKnowledgeRegistry.resolveObjective(
    'low-flow-troubleshooting',
    ['preload-limitation','tamponade-recognition','cannula-malposition','circuit-obstruction','pump-failure']
  );
  for (const id of ['hypovolemia','postoperative-tamponade','position-sensitive-cannula','drainage-cannula-kink','mechanical-circuit-obstruction','pump-support-failure']) {
    assert.ok(resolved.complicationIds.includes(id), `expected ${id}`);
  }
});

test('cannula-malposition concept resolves to reusable positional and mechanical drainage knowledge', () => {
  const resolved = defaultClinicalKnowledgeRegistry.resolveObjective('low-flow-troubleshooting', ['cannula-malposition']);
  assert.ok(resolved.complicationIds.includes('position-sensitive-cannula'));
  assert.ok(resolved.complicationIds.includes('drainage-cannula-kink'));
  assert.ok(resolved.actionIds.includes('turn-patient'));
  assert.ok(resolved.actionIds.includes('restore-prior-position'));
  assert.ok(resolved.actionIds.includes('inspect-drainage-cannula'));
  assert.ok(resolved.observationIds.includes('position-flow-response'));
});

test('resolveLearnerActionButtons returns learner-safe descriptors and excludes ecmo-control category', () => {
  const buttons = defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons(['volume-bolus', 'increase-rpm', 'assess-hemodynamics']);
  const ids = buttons.map((b) => b.id);
  assert.ok(ids.includes('volume-bolus'));
  assert.ok(ids.includes('assess-hemodynamics'));
  assert.ok(!ids.includes('increase-rpm'), 'ecmo-control actions are already exposed via the RPM/sweep sliders, not a separate button');
  for (const button of buttons) {
    assert.deepEqual(Object.keys(button).sort(), ['category', 'id', 'label']);
  }
});

test('resolveLearnerActionButtons skips unknown ids and de-duplicates repeats rather than throwing', () => {
  const buttons = defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons(['volume-bolus', 'volume-bolus', 'not-a-real-action']);
  assert.equal(buttons.length, 1);
  assert.equal(buttons[0].id, 'volume-bolus');
});

test('resolveLearnerActionButtons hides any action whose id names a hidden complication, even with no differential to dilute it', () => {
  const withoutFilter = defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons(['inspect-for-air', 'isolate-air-source', 'manage-air-emergency']);
  assert.ok(withoutFilter.some((b) => b.id === 'manage-air-emergency'));

  const withFilter = defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons(
    ['inspect-for-air', 'isolate-air-source', 'manage-air-emergency'],
    { hiddenComplicationIds: ['air-emergency'] }
  );
  assert.ok(!withFilter.some((b) => b.id === 'manage-air-emergency'), 'an action id that literally names the hidden complication must be filtered');
  assert.ok(withFilter.some((b) => b.id === 'inspect-for-air'), 'actions that do not name the complication should still appear');
});

test('every one of the 72 actionIds referenced by any complication is registered with a label and category (no dead references)', () => {
  const complications = defaultClinicalKnowledgeRegistry.list('complication');
  const referenced = new Set();
  for (const c of complications) (c.definition.actionRules ?? []).forEach((r) => referenced.add(r.actionId));
  for (const actionId of referenced) {
    assert.ok(defaultClinicalKnowledgeRegistry.get('action', actionId), `actionId "${actionId}" is referenced by a complication but missing from the action catalog`);
  }
});
