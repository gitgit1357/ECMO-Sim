import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const d=JSON.parse(fs.readFileSync(new URL('../../B5_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B5_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));

test('B5 covers five bleeding/neuro/anticoagulation primitives',()=>assert.equal(d.length,5));
test('major bleeding evidence records temporary UFH-hold example without making it universal',()=>{
 const x=r.find(x=>x.ruleId.endsWith('major-bleeding'));assert.ok(x.exactSourceNumbers.some(n=>n.name==='UFH-hold-example'));assert.match(x.disposition['reduce-anticoagulation'],/context-dependent/i);
});
test('ICH evidence keeps >2 day cessation specific to VV rather than generalizing to VA',()=>{
 const x=r.find(x=>x.ruleId.endsWith('intracranial-hemorrhage'));const n=x.exactSourceNumbers.find(n=>n.name==='VV-ICH-anticoagulation-cessation');assert.equal(n.value,'>2');assert.match(n.qualifier,/not generalized to VA/i);
});
test('ICH review does not invent universal anticoagulation reversal',()=>{
 const x=r.find(x=>x.ruleId.endsWith('intracranial-hemorrhage'));assert.match(x.disposition['automatic reversal'],/not added/i);
});
test('anticoagulation management explicitly avoids a single-test universal target',()=>{
 const x=r.find(x=>x.ruleId.endsWith('anticoagulation-management'));assert.match(x.disposition['single-test universal target'],/avoided/i);
});
test('pulmonary hemorrhage remains partial pending specialty-source corroboration',()=>{
 const x=d.find(x=>x.ruleId.endsWith('pulmonary-hemorrhage'));assert.equal(x.changeAuthorized,false);assert.match(x.reviewerStatus,/specialty-source/i);
});
