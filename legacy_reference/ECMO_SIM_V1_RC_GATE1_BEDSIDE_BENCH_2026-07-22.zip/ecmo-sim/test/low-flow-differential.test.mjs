import test from 'node:test';
import assert from 'node:assert/strict';
import { buildScenarioFromSetup } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

function setupFor(concept) {
  return {
    patient:{population:'neonatal',weightKg:4,diagnosis:'HLHS',procedure:'Norwood/Sano'},
    ecmo:{mode:'VA',cannulation:'central',cannulaFr:10,pumpRpm:1800,sweepGasLpm:2,fdo2Percent:50},
    startingCondition:{hemodynamics:'unstable',renalFunction:'normal'},
    education:{primaryObjective:'low-flow-troubleshooting',concepts:[concept],mode:'guided',difficulty:'intermediate'}
  };
}

test('drainage cannula kink enters as major low-flow state and direct correction restores support', () => {
  const scenario=buildScenarioFromSetup(setupFor('cannula-malposition'),{id:'kink-low-flow'});
  // Guided concept contains two candidates; director releases one. For deterministic module testing,
  // compile a hand-selected registry-backed plan containing only the kink.
  scenario.clinicalKnowledgePlan.requiredComplicationIds=['drainage-cannula-kink'];
  scenario.clinicalKnowledgePlan.allowedComplicationIds=['drainage-cannula-kink'];
  scenario.clinicalKnowledgePlan.triggerPolicies=[{id:'teach-kink',complicationId:'drainage-cannula-kink',type:'at-start'}];
  const s=circuitSandboxEngine.createSession({scenario});
  s.submit({type:'start-scenario'});
  const low=s.presentation().circuit.flowIndexMlKgMin;
  assert.ok(low < 100, `expected clinically important flow reduction, got ${low}`);
  const inspect=s.submit({type:'clinical-action',actionId:'inspect-drainage-cannula'});
  assert.match(inspect.feedback,/mechanical abnormality/i);
  const fix=s.submit({type:'clinical-action',actionId:'relieve-cannula-kink'});
  assert.match(fix.feedback,/flow returns/i);
  assert.ok(s.presentation().circuit.flowIndexMlKgMin > low * 2);
});

test('mechanical circuit obstruction remains low despite RPM escalation and improves when corrected', () => {
  const scenario=buildScenarioFromSetup(setupFor('circuit-obstruction'),{id:'circuit-obstruction-low-flow'});
  const s=circuitSandboxEngine.createSession({scenario});
  s.submit({type:'start-scenario'});
  const low=s.presentation().circuit.flowIndexMlKgMin;
  const rpm=s.submit({type:'set-param',param:'pumpRpm',value:2600});
  assert.match(rpm.feedback,/adequate flow is not restored/i);
  const stillLow=s.presentation().circuit.flowIndexMlKgMin;
  assert.ok(stillLow < 120);
  const inspect=s.submit({type:'clinical-action',actionId:'inspect-circuit-path'});
  assert.match(inspect.feedback,/resistance|obstruction/i);
  const fix=s.submit({type:'clinical-action',actionId:'relieve-circuit-obstruction'});
  assert.match(fix.feedback,/flow and effective support recover/i);
  assert.ok(s.presentation().circuit.flowIndexMlKgMin > Math.max(low,stillLow));
});

test('pump support failure produces loss of flow and requires pump-restoration pathway', () => {
  const scenario=buildScenarioFromSetup(setupFor('pump-failure'),{id:'pump-failure-low-flow'});
  const s=circuitSandboxEngine.createSession({scenario});
  s.submit({type:'start-scenario'});
  assert.equal(s.presentation().circuit.flowIndexMlKgMin,0);
  const rpm=s.submit({type:'set-param',param:'pumpRpm',value:3000});
  assert.match(rpm.feedback,/does not restore effective pump output/i);
  assert.equal(s.presentation().circuit.flowIndexMlKgMin,0);
  const assess=s.submit({type:'clinical-action',actionId:'assess-pump-function'});
  assert.match(assess.feedback,/loss of effective pump support/i);
  const restore=s.submit({type:'clinical-action',actionId:'restore-pump-support'});
  assert.match(restore.feedback,/pump support is restored/i);
  assert.ok(s.presentation().circuit.flowIndexMlKgMin>0);
});

test('low-flow modules remain registry knowledge rather than embedded scenario behavior', () => {
  const scenario=buildScenarioFromSetup(setupFor('circuit-obstruction'),{id:'no-hardcode'});
  const serialized=JSON.stringify(scenario);
  assert.equal(serialized.includes('The accessible mechanical obstruction is corrected'),false);
  assert.deepEqual(scenario.clinicalKnowledgePlan.requiredComplicationIds,['mechanical-circuit-obstruction']);
});
