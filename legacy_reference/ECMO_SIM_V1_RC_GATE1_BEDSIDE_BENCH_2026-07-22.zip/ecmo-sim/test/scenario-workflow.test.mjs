import test from 'node:test';
import assert from 'node:assert/strict';
import { createInformationPipeline, TIMING_PLACEHOLDERS } from '../src/core/information-pipeline.mjs';
import { buildScenarioFromSetup, LEARNING_OBJECTIVES } from '../src/core/scenario-builder.mjs';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';

test('turnaround defaults are explicit placeholders rather than invented final times', () => {
  assert.equal(TIMING_PLACEHOLDERS.abg.requestToAcquisitionSec, null);
  assert.equal(TIMING_PLACEHOLDERS.xray.rawResultToInterpretationSec, null);
  assert.equal(TIMING_PLACEHOLDERS.xray.acquisitionToRawResultSec, 0);
});

test('xray can be bedside-ready but blocked by an active code, then acquired when code clears', () => {
  const p = createInformationPipeline({ timingProfile:{ xray:{ requestToAcquisitionSec:30, acquisitionToRawResultSec:0, rawResultToInterpretationSec:300 } } });
  const req = p.request('xray',{ timeSec:0,label:'Portable chest X-ray',payload:{rawResult:'image',interpretation:'formal read'} });
  p.tick(30, {'active-code':true});
  assert.equal(p.presentation().requests[0].status,'blocked');
  p.tick(60, {'active-code':false});
  assert.equal(p.presentation().requests[0].status,'ready-for-acquisition');
  const acq=p.acquire(req.id,{timeSec:60,context:{'active-code':false}});
  assert.equal(acq.ok,true);
  assert.equal(p.presentation().requests[0].status,'raw-available','image should be immediately reviewable once shot');
  p.tick(359,{});
  assert.equal(p.presentation().requests[0].status,'raw-available');
  p.tick(360,{});
  assert.equal(p.presentation().requests[0].status,'interpreted','formal interpretation can arrive later');
});

test('educator builder emits the same canonical structure and selected learning plan', () => {
  const setup={patient:{population:'neonatal',weightKg:3.4,diagnosis:'HLHS',procedure:'Norwood/Sano'},ecmo:{mode:'VA',cannulation:'central',cannulaFr:10,pumpRpm:1450,sweepGasLpm:.4,fdo2Percent:100},startingCondition:{hemodynamics:'stable',renalFunction:'normal'},education:{primaryObjective:'low-flow-troubleshooting',concepts:['tamponade-recognition'],mode:'adaptive',difficulty:'intermediate'}};
  const s=buildScenarioFromSetup(setup,{id:'built-case'});
  assert.equal(s.requiresManualStart,true);
  assert.equal(s.learningPlan.primaryObjective,'low-flow-troubleshooting');
  assert.deepEqual(s.learningPlan.concepts,['tamponade-recognition']);
  assert.ok(LEARNING_OBJECTIVES['low-flow-troubleshooting'].concepts.includes('tamponade-recognition'));
});

test('educator-generated scenario remains frozen until Start Scenario', () => {
  const scenario=buildScenarioFromSetup({patient:{population:'neonatal',weightKg:4},ecmo:{cannulaFr:10},startingCondition:{},education:{}},{id:'manual-start'});
  const session=circuitSandboxEngine.createSession({scenario});
  assert.equal(session.presentation().started,false);
  session.advance(300);
  assert.equal(session.presentation().timeSec,0);
  const denied=session.submit({type:'set-param',param:'pumpRpm',value:1800});
  assert.equal(denied.status,'not-started');
  session.submit({type:'start-scenario'});
  session.advance(30);
  assert.equal(session.presentation().timeSec,30);
});

test('study information pipeline is exposed in learner presentation and survives snapshot restore', () => {
  const scenario=buildScenarioFromSetup({patient:{population:'neonatal',weightKg:4},ecmo:{cannulaFr:10},startingCondition:{},education:{},informationTimingProfile:{xray:{requestToAcquisitionSec:0,acquisitionToRawResultSec:0,rawResultToInterpretationSec:120}}},{id:'info-case'});
  const session=circuitSandboxEngine.createSession({scenario});
  session.submit({type:'start-scenario'});
  const ordered=session.submit({type:'order-study',studyType:'xray',label:'Portable chest X-ray',payload:{rawResult:'image available',interpretation:'formal read'}});
  session.submit({type:'set-clinical-context',key:'active-code',value:true});
  session.advance(1);
  assert.equal(session.presentation().information.requests[0].status,'blocked');
  const saved=session.snapshot();
  const restored=circuitSandboxEngine.createSession({scenario,snapshot:saved});
  assert.equal(restored.presentation().information.requests[0].status,'blocked');
  restored.submit({type:'set-clinical-context',key:'active-code',value:false});
  const reqId=restored.presentation().information.requests[0].id;
  restored.submit({type:'acquire-study',requestId:reqId});
  assert.equal(restored.presentation().information.requests[0].status,'raw-available');
});
