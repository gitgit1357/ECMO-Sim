import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validationProgress,promoteValidationRecord} from '../src/core/clinical-validation-progress.mjs';
const m=JSON.parse(fs.readFileSync(new URL('../../clinical-validation-manifest.json',import.meta.url),'utf8'));
test('manifest covers every current rule and starts preclinical',()=>{assert.ok(m.length>=30);assert.ok(m.every(x=>x.releaseStatus==='preclinical-not-competency-ready'));});
test('progress reports source assignment separately from clinical validation',()=>{const p=validationProgress(m);assert.equal(p.gateCounts.sourceAssigned,p.total);assert.equal(p.fullyValidated,0);});
test('promotion requires every validation gate',()=>{const r=structuredClone(m[0]);assert.equal(promoteValidationRecord(r).clinicallyValidated,false);for(const k of Object.keys(r.gates))r.gates[k]=true;assert.equal(promoteValidationRecord(r).clinicallyValidated,true);});
