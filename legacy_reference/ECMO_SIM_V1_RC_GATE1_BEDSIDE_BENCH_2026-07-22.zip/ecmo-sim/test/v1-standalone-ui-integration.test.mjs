import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const html=fs.readFileSync(new URL('../../standalone-v3.3/index.html',import.meta.url),'utf8');
test('standalone explicitly binds ECG canvas instead of relying on named-window globals',()=>{
 assert.match(html,/const ecgCanvas=document\.getElementById\('ecg'\)/);
 assert.match(html,/const cv=ecgCanvas;if\(!cv\)return/);
 assert.doesNotMatch(html,/const cv=ecg,ctx=/);
});
test('standalone explicitly binds primary vital display elements',()=>{
 for(const id of ['clock','hr','map','spo2','cvp','rpm','flow','venous','dp'])assert.ok(html.includes(`getElementById('${id}')`),id);
});
test('ECG renderer has explicit asystole, vfib, vtach and junctional branches',()=>{
 for(const rhythm of ['asystole','vfib','vtach','junctional'])assert.match(html,new RegExp(`rhythm==='${rhythm}'`));
});
test('ECG renderer is called from presentation rhythm and monitored HR',()=>assert.match(html,/drawECG\(started\?m\.hr:0,p\.rhythm\|\|'sinus'\)/));
