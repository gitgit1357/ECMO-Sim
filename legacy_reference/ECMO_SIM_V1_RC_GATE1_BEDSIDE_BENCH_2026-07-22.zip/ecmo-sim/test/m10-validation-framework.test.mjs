import test from 'node:test';import assert from 'node:assert/strict';
import {validationCatalog,validationSummary,evaluateCompetencyReadiness,applyValidationUpdate,clinicalReviewChecklist} from '../src/core/validation-framework.mjs';
test('validation catalog covers every supported educator template',()=>{
 const rows=validationCatalog(),s=validationSummary();assert.ok(rows.length>20);assert.equal(rows.length,s.totalTemplates);assert.equal(s.technicalPassed,s.totalTemplates);assert.equal(s.benchAccepted,s.totalTemplates);
});
test('preclinical templates are never falsely labeled competency ready',()=>{
 const rows=validationCatalog();assert.ok(rows.every(r=>r.clinicalReviewStatus==='pending'));assert.ok(rows.every(r=>r.competencyReady===false));assert.equal(validationSummary().clinicalValidated,0);
});
test('competency readiness requires all four validation gates',()=>{
 const r=validationCatalog()[0];assert.equal(evaluateCompetencyReadiness(r),false);
 const v=applyValidationUpdate(r,{clinicalReviewStatus:'validated',timingValidationStatus:'validated'});assert.equal(v.competencyReady,true);
});
test('clinical review checklist explicitly covers physiology, actions, endpoints, versioning',()=>{
 const text=clinicalReviewChecklist().join(' ');for(const x of ['action classifications','timing','physiologic thresholds','endpoint','version'])assert.match(text,new RegExp(x,'i'));
});
