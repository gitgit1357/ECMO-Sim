import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const groups=[
 ['low-flow',buildLowFlowTroubleshootingScenario,['lf-01-preload','lf-02-tamponade','lf-03-position','lf-04-kink','lf-05-circuit-obstruction','lf-06-pump-failure']],
 ['circuit',buildCircuitEmergencyScenario,['ce-01-air-emergency','ce-02-circuit-breach','ce-03-oxygenator','ce-04-sweep-gas','ce-05-hemolysis','ce-06-major-bleeding']],
 ['va',buildVaEcmoScenario,['va-01-differential-hypoxemia','va-02-lv-distension','va-03-limb-ischemia','va-04-thrombosis']],
 ['vv',buildVvEcmoScenario,['vv-01-recirculation','vv-02-oxygenator','vv-03-gas-exchange','vv-04-pneumothorax','vv-04-airway']],
 ['patient',buildPatientEmergencyScenario,['pe-01-arrhythmia-arrest','pe-02-ich','pe-03-vasoplegia','pe-03-sepsis','pe-04-aki-fluid','pe-05-metabolic','pe-06-ph-crisis']]
];

for(const [family,builder,ids] of groups) for(const id of ids) test(`${id} post-cockpit acceptance`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:builder(id)});
 let p=s.presentation();
 assert.equal(p.lifecycle.status,'prebrief');
 assert.ok(p.learnerBriefing||p.handoff);
 s.submit({type:'start-scenario'});
 p=s.presentation();
 assert.equal(p.lifecycle.status,'active');

 // Always-on bedside data.
 assert.ok(Number.isFinite(p.monitored.hr));
 assert.ok(Number.isFinite(p.monitored.bp.systolic));
 assert.ok(Number.isFinite(p.monitored.bp.diastolic));
 assert.ok(Number.isFinite(p.monitored.bp.map));
 assert.ok(Number.isFinite(p.monitored.cvp));
 assert.ok(Number.isFinite(p.monitored.spo2));
 assert.ok(Number.isFinite(p.monitored.tempC));

 // Always-on ECMO cockpit.
 for(const k of ['pumpRpm','circuitFlowLpm','flowIndexMlKgMin','venousPressure','preOxyPressure','postOxyPressure','deltaP']) {
   assert.ok(Number.isFinite(p.circuit[k]),`${id}:${k}`);
 }
 for(const k of ['hgbGdl','hctPercent','svo2Percent']) assert.ok(Number.isFinite(p.cdi[k]),`${id}:${k}`);
 assert.equal(p.bubbleSafety.detectorPresent,true);
 assert.equal(p.bubbleSafety.location,'return-limb-downstream-of-final-pigtail');

 // Routine controls must always remain available.
 for(const k of ['pumpRpm','flowTarget','sweepGasLpm','fdo2Percent','circuitClamp']) assert.equal(p.continuousControls[k],true);

 // Control smoke test: change, then restore baseline where practical.
 const rpm=p.settings.pumpRpm;
 assert.equal(s.submit({type:'set-param',param:'pumpRpm',value:rpm+50}).accepted,true);
 assert.equal(s.submit({type:'set-param',param:'pumpRpm',value:rpm}).accepted,true);
 assert.equal(s.submit({type:'set-param',param:'sweepGasLpm',value:p.settings.sweepGasLpm}).accepted,true);
 assert.equal(s.submit({type:'set-param',param:'fdo2Percent',value:p.settings.fdo2Percent}).accepted,true);

 // Clamp/unclamp must function irrespective of diagnosis.
 s.submit({type:'set-circuit-clamp',clamped:true});
 assert.equal(s.presentation().circuit.circuitFlowLpm,0);
 s.submit({type:'set-circuit-clamp',clamped:false});

 // Time/state continues after cockpit interactions.
 const t=s.presentation().timeSec;s.advance(1);assert.equal(s.presentation().timeSec,t+1);
});

test('all 28 supported scenarios covered',()=>assert.equal(groups.reduce((n,g)=>n+g[2].length,0),28));
