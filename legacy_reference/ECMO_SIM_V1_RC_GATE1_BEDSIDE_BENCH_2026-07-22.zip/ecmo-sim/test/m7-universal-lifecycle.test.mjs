import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildLowFlowTroubleshootingScenario} from '../src/core/troubleshooting-scenario-library.mjs';
import {buildCircuitEmergencyScenario} from '../src/core/circuit-emergency-scenario-library.mjs';
import {buildVaEcmoScenario} from '../src/core/va-ecmo-scenario-library.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
import {buildPatientEmergencyScenario} from '../src/core/patient-emergency-scenario-library.mjs';

const reps=[
 ['M2',()=>buildLowFlowTroubleshootingScenario('lf-01-preload'),['volume-bolus']],
 ['M3',()=>buildCircuitEmergencyScenario('ce-03-oxygenator'),['assess-oxygenator','exchange-oxygenator']],
 ['M4',()=>buildVaEcmoScenario('va-01-differential-hypoxemia'),['assess-differential-hypoxemia','correct-differential-hypoxemia']],
 ['M5',()=>buildVvEcmoScenario('vv-01-recirculation'),['assess-recirculation','correct-recirculation']],
 ['M6',()=>buildPatientEmergencyScenario('pe-01-arrhythmia-arrest'),['assess-rhythm','defibrillate','resuscitate-arrest']]
];
for(const [label,build,actions] of reps)test(`${label} follows universal prebrief -> active -> stabilized lifecycle`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:build()});let p=s.presentation();
 assert.equal(p.lifecycle.status,'prebrief');assert.equal(p.complete,false);assert.ok(p.learnerBriefing);
 s.submit({type:'start-scenario'});p=s.presentation();assert.equal(p.lifecycle.status,'active');assert.equal(p.complete,false);
 for(const actionId of actions)s.submit({type:'clinical-action',actionId});
 s.advance(121);p=s.presentation();assert.equal(p.lifecycle.status,'stabilized');assert.equal(p.complete,true);assert.equal(p.endpoint.type,'stabilized');
});
test('terminal deterioration produces a universal completed failure endpoint',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildLowFlowTroubleshootingScenario('lf-06-pump-failure')});s.submit({type:'start-scenario'});s.advance(2000);
 const p=s.presentation();assert.equal(p.complete,true);assert.ok(['death'].includes(p.endpoint.type));assert.equal(p.lifecycle.status,'death');
});
test('completed scenarios reject further meaningful manipulation through UI lifecycle lock contract',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVaEcmoScenario('va-01-differential-hypoxemia')});s.submit({type:'start-scenario'});s.submit({type:'clinical-action',actionId:'correct-differential-hypoxemia'});s.advance(121);
 assert.equal(s.presentation().complete,true);
});
