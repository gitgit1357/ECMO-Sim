import test from 'node:test';
import assert from 'node:assert/strict';
import { circuitSandboxEngine } from '../src/engines/circuit-sandbox.mjs';
import { buildLowFlowTroubleshootingScenario, LOW_FLOW_TROUBLESHOOTING_PRESETS } from '../src/core/troubleshooting-scenario-library.mjs';

test('M2: all six low-flow cases expose diagnosis-neutral handoff and learner objectives before start', () => {
  for (const preset of LOW_FLOW_TROUBLESHOOTING_PRESETS) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(preset.id) });
    const p = session.presentation();
    assert.equal(p.lifecycle.status, 'prebrief');
    assert.ok(p.handoff?.summary?.length > 20, `${preset.id}: missing handoff summary`);
    assert.ok(Array.isArray(p.learnerObjectives) && p.learnerObjectives.length >= 4, `${preset.id}: missing learner objectives`);
    const safe = JSON.stringify({ handoff:p.handoff, objectives:p.learnerObjectives }).toLowerCase();
    assert.equal(safe.includes(preset.complicationId.toLowerCase()), false, `${preset.id}: prebrief leaked hidden diagnosis`);
  }
});

test('M2: lifecycle transitions prebrief -> active -> explicit failure and unlocks debrief only after completion', () => {
  const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario('lf-01-preload') });
  assert.equal(session.learnerDebrief(), null, 'debrief must not reveal instructor/session analysis before case completion');
  session.submit({ type:'start-scenario' });
  assert.equal(session.presentation().lifecycle.status, 'active');
  session.advance(900);
  assert.equal(session.presentation().complete, true);
  assert.equal(session.presentation().lifecycle.status, 'death');
  const d = session.learnerDebrief();
  assert.equal(d.outcome, 'death');
  assert.ok(Array.isArray(d.timeline) && d.timeline.length > 0);
  assert.ok(Array.isArray(d.objectives) && d.objectives.length >= 4);
});

test('M2: successful treatment reaches an explicit stabilized endpoint and produces a learner debrief', () => {
  const scenario = buildLowFlowTroubleshootingScenario('lf-04-kink');
  scenario.endpointProfile = { ...(scenario.endpointProfile ?? {}), stabilizationWindowSec: 30 };
  const session = circuitSandboxEngine.createSession({ scenario });
  session.submit({ type:'start-scenario' });
  session.advance(30);
  session.submit({ type:'clinical-action', actionId:'relieve-cannula-kink' });
  session.advance(180);
  assert.equal(session.presentation().endpoint?.type, 'stabilized');
  assert.equal(session.presentation().lifecycle.status, 'stabilized');
  const d = session.learnerDebrief();
  assert.equal(d.outcome, 'stabilized');
  assert.ok(d.actionReview.length >= 1);
});

test('M2 acceptance: every low-flow case has a reachable clinically coherent success endpoint on the intended pathway', () => {
  const pathways = [
    ['lf-01-preload', ['volume-bolus']],
    ['lf-02-tamponade', ['assess-hemodynamics','order-echo','pericardial-decompression']],
    ['lf-03-position', ['restore-prior-position']],
    ['lf-04-kink', ['relieve-cannula-kink']],
    ['lf-05-circuit-obstruction', ['relieve-circuit-obstruction']],
    ['lf-06-pump-failure', ['restore-pump-support']]
  ];
  for (const [presetId, actions] of pathways) {
    const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario(presetId) });
    session.submit({ type:'start-scenario' });
    session.advance(10); // prompt but not instantaneous learner recognition
    for (const actionId of actions) session.submit({ type:'clinical-action', actionId });
    session.advance(600);
    const p = session.presentation();
    assert.equal(p.endpoint?.type, 'stabilized', `${presetId}: intended timely pathway must reach stabilized`);
    assert.notEqual(p.rhythm, 'vfib', `${presetId}: stabilized endpoint cannot coexist with VF`);
    assert.notEqual(p.rhythm, 'asystole', `${presetId}: stabilized endpoint cannot coexist with asystole`);
    assert.ok(session.learnerDebrief(), `${presetId}: stabilized case must unlock learner debrief`);
  }
});

test('M2 acceptance: restoring pump support after VF does not falsely declare stabilization until the malignant rhythm is treated', () => {
  const session = circuitSandboxEngine.createSession({ scenario: buildLowFlowTroubleshootingScenario('lf-06-pump-failure') });
  session.submit({ type:'start-scenario' });
  session.advance(45);
  assert.equal(session.presentation().rhythm, 'vfib');
  session.submit({ type:'clinical-action', actionId:'restore-pump-support' });
  session.advance(130);
  assert.notEqual(session.presentation().endpoint?.type, 'stabilized', 'VF must block a success endpoint even after pump flow is restored');
  session.submit({ type:'clinical-action', actionId:'defibrillate' });
  session.advance(1); // establish the post-rescue stable state before timing the stabilization window
  session.advance(180);
  assert.equal(session.presentation().endpoint?.type, 'stabilized', 'restored support plus successful rhythm rescue should allow stabilization');
  assert.equal(session.presentation().rhythm, 'sinus');
});
