import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import { defaultClinicalKnowledgeRegistry } from '../src/core/clinical-knowledge-registry.mjs';

const coverage = JSON.parse(fs.readFileSync(new URL('../../CLINICAL_MODULE_COVERAGE.json', import.meta.url)));

test('all 36 normalized taxonomy modules map to one or more registry complication implementations', () => {
  assert.equal(coverage.normalizedModuleCount, 36);
  assert.equal(coverage.coverage.length, 36);
  for (const item of coverage.coverage) {
    assert.ok(item.registryComplicationIds.length > 0, `missing registry mapping for ${item.taxonomyId}`);
    for (const id of item.registryComplicationIds) {
      assert.ok(defaultClinicalKnowledgeRegistry.get('complication', id), `missing complication knowledge ${id}`);
    }
  }
});

test('VA-only modules reject VV compilation and VV recirculation rejects VA compilation', () => {
  assert.throws(
    () => defaultClinicalKnowledgeRegistry.compileComplications(['va-differential-hypoxemia'], { ecmoMode:'VV' }),
    /not applicable/
  );
  assert.throws(
    () => defaultClinicalKnowledgeRegistry.compileComplications(['vv-recirculation'], { ecmoMode:'VA' }),
    /not applicable/
  );
  assert.equal(defaultClinicalKnowledgeRegistry.compileComplications(['va-differential-hypoxemia'], { ecmoMode:'VA' }).length, 1);
  assert.equal(defaultClinicalKnowledgeRegistry.compileComplications(['vv-recirculation'], { ecmoMode:'VV' }).length, 1);
});

test('new complication definitions are reusable knowledge, hidden from learner by default, and carry placeholder timing status', () => {
  const ids = ['air-emergency','oxygenator-thrombosis-failure','hemolysis','intracranial-hemorrhage','va-lv-distension','infection-sepsis'];
  for (const id of ids) {
    const entry = defaultClinicalKnowledgeRegistry.get('complication', id);
    assert.equal(entry.definition.hidden, true);
    assert.equal(entry.definition.timingPolicyStatus, 'placeholder-until-validated');
    assert.ok(Array.isArray(entry.definition.actionRules) && entry.definition.actionRules.length > 0);
  }
});
