import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';
const d=JSON.parse(fs.readFileSync(new URL('../../B3_EXACT_COMPARISON_DOSSIERS.json',import.meta.url),'utf8'));
const r=JSON.parse(fs.readFileSync(new URL('../../B3_EXACT_SOURCE_COMPARISON.json',import.meta.url),'utf8'));
test('B3 covers five VV/shared primitives',()=>assert.equal(d.length,5));
test('recirculation source review records paradoxical worsening with increased VV flow',()=>{
 const x=r.find(x=>x.ruleId.endsWith('vv-recirculation'));assert.match(x.principles.join(' '),/paradoxical fall/i);
});
test('recirculation fractions remain simulation exemplars not universal ELSO thresholds',()=>{
 const x=r.find(x=>x.ruleId.endsWith('vv-recirculation'));assert.match(x.disposition['48%-18% recirculation fractions'],/simulation exemplars/i);
});
test('gas-exchange review emphasizes oxygen delivery rather than saturation alone',()=>{
 const x=r.find(x=>x.ruleId.endsWith('gas-exchange-failure'));assert.match(x.principles.join(' '),/saturation alone is not equivalent to oxygen delivery/i);
});
test('pneumothorax rule is not falsely promoted as ELSO-derived',()=>{
 const x=d.find(x=>x.ruleId.endsWith('pneumothorax-intrathoracic-pressure'));assert.equal(x.changeAuthorized,false);assert.match(x.reviewerStatus,/specialty-source/i);
});
test('VV recirculation case still resolves through cause-directed correction',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-01-recirculation')});s.submit({type:'start-scenario'});
 s.submit({type:'clinical-action',actionId:'assess-recirculation'});s.submit({type:'clinical-action',actionId:'correct-recirculation'});
 assert.equal(s.instructorPresentation().clinicalEventState.active['vv-recirculation'].state,'resolved');
});
