import test from 'node:test';import assert from 'node:assert/strict';
import {circuitSandboxEngine} from '../src/engines/circuit-sandbox.mjs';
import {VV_ECMO_PRESETS,buildVvEcmoScenario} from '../src/core/vv-ecmo-scenario-library.mjs';

const plans={
 'vv-01-recirculation':['assess-recirculation','correct-recirculation'],
 'vv-02-oxygenator':['assess-oxygenator','exchange-oxygenator'],
 'vv-03-gas-exchange':['assess-gas-exchange','correct-gas-exchange'],
 'vv-04-pneumothorax':['assess-thorax','decompress-chest'],
 'vv-04-airway':['assess-airway-ventilator','restore-airway-ventilation']
};
for(const p of VV_ECMO_PRESETS)test(`${p.id} passes VV resolution/completion path`,()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario(p.id)});const pre=s.presentation();
 assert.ok(pre.learnerBriefing);assert.ok(pre.recentEvents.length>=3);assert.equal(pre.learnerObjectives.length,4);assert.equal(JSON.stringify(pre).includes(p.educatorLabel),false);
 s.submit({type:'start-scenario'});
 for(const actionId of plans[p.id]){const r=s.submit({type:'clinical-action',actionId});assert.ok(r.feedback);}
 assert.equal(s.instructorPresentation().clinicalEventState.active[p.complicationId].state,'resolved');
 s.advance(121);assert.equal(s.presentation().endpoint.type,'stabilized');
});
test('VV-03 gas exchange assessment returns physiologic evidence',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-03-gas-exchange')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-gas-exchange'});assert.match(r.feedback,/PaO2 about 55/i);assert.match(r.feedback,/PaCO2 about 60/i);
});
test('VV-04 pneumothorax distinguishes patient-side tension mechanics',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-04-pneumothorax')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-thorax'});assert.match(r.feedback,/impaired venous return and ECMO drainage/i);
});
test('VV-04 airway distinguishes mechanical ventilation failure from circuit-only problem',()=>{
 const s=circuitSandboxEngine.createSession({scenario:buildVvEcmoScenario('vv-04-airway')});s.submit({type:'start-scenario'});
 const r=s.submit({type:'clinical-action',actionId:'assess-airway-ventilator'});assert.match(r.feedback,/correctable mechanical ventilation failure/i);assert.match(r.feedback,/circuit itself does not explain/i);
});
