import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
const h=fs.readFileSync(new URL('../../standalone-v2.6/index.html',import.meta.url),'utf8');
test('standalone v2.6 contains all four M4 VA actions and current evidence engine',()=>{
 for(const x of ['assess-differential-hypoxemia','correct-differential-hypoxemia','assess-lv-distension','initiate-lv-unloading','assess-limb-perfusion','restore-limb-perfusion','assess-thrombosis','manage-thrombosis','lvDistensionGrade','distalPulseStatus','thrombusBurdenGrade']) assert.match(h,new RegExp(x));
});
