import test from 'node:test';import assert from 'node:assert/strict';import fs from 'node:fs';
import {validateEvidenceLedger} from '../src/core/validation-ledger-validator.mjs';
const l=JSON.parse(fs.readFileSync(new URL('../../B2_LOW_FLOW_MECHANICAL_EVIDENCE_LEDGER.json',import.meta.url),'utf8'));
test('B2 contains three registry-level low-flow/mechanical validation records',()=>assert.equal(l.length,3));
test('B2 uses ELSO general/circuit defaults while institutional sources are absent',()=>{
 assert.ok(l.every(x=>x.governingAuthority==='elso'));assert.ok(l.every(x=>['general','circuits'].includes(x.elsoDomain)));
});
test('B2 evidence ledger passes anti-overclaim validation',()=>{const v=validateEvidenceLedger(l);assert.equal(v.valid,true,v.errors.join(';'));});
test('B2 authorizes no unsupported numeric claims or simulation changes',()=>assert.ok(l.every(x=>!x.numericStandardClaimAllowed&&!x.simulationChangeAuthorized)));
