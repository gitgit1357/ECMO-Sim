import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const html=fs.readFileSync(new URL('../../standalone-v2.4/index.html',import.meta.url),'utf8');
test('standalone v2.3 exposes circuit emergency scenario library and CE-03 actions',()=>{
 assert.match(html,/listCircuitEmergencyScenarios/);
 assert.match(html,/buildCircuitEmergencyScenario/);
 assert.match(html,/assess-oxygenator/);
 assert.match(html,/increase-sweep/);
 assert.match(html,/exchange-oxygenator/);
 assert.match(html,/circuitCases/);
 assert.match(html,/inspect-for-air/);
 assert.match(html,/control-circuit-breach/);
 assert.match(html,/verify-sweep-gas/);
 assert.match(html,/assess-hemolysis/);
 assert.match(html,/control-major-bleeding/);
});
