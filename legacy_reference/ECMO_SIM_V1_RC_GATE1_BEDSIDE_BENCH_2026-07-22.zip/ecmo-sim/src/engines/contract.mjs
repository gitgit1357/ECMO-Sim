// Forked from Academy Suite's engine contract (src/engines/contract.mjs).
// Kept intact on purpose: this abstraction is the "engine separate from
// scenario" pattern the whole project is built on. One addition:
// a 'time-advance' capability, because a sandbox needs to move simulated
// time forward independent of any single submitted action.

export const ACTIVITY_ENGINE_API_VERSION = 1;

const SESSION_METHODS_BY_CAPABILITY = Object.freeze({
  editor: ['saveEditor'],
  completion: ['complete'],
  'outcome-validation': ['evaluate'],
  'condition-evaluation': ['evaluateCondition'],
  'time-advance': ['advance'] // NEW: sandbox engines can advance sim time independent of submit()
});

function assertText(value, field) {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`Activity engine ${field} must be a non-empty string.`);
}

function assertFunction(value, field, engineId) {
  if (typeof value !== 'function') throw new Error(`Activity engine "${engineId}" must implement ${field}().`);
}

function sessionDescriptor(engineOrId, capabilities = []) {
  if (engineOrId && typeof engineOrId === 'object') {
    return { id: engineOrId.id ?? 'unknown', capabilities: engineOrId.capabilities ?? [] };
  }
  return { id: engineOrId ?? 'unknown', capabilities };
}

export function validateActivitySession(session, engineOrId = 'unknown', capabilities = []) {
  const descriptor = sessionDescriptor(engineOrId, capabilities);
  if (!session || typeof session !== 'object' || Array.isArray(session)) {
    throw new Error(`Activity engine "${descriptor.id}" returned an invalid session.`);
  }
  for (const method of ['snapshot', 'presentation', 'submit']) {
    assertFunction(session[method], method, descriptor.id);
  }
  for (const capability of descriptor.capabilities) {
    for (const method of SESSION_METHODS_BY_CAPABILITY[capability] ?? []) {
      assertFunction(session[method], method, descriptor.id);
    }
  }
  return session;
}

export function validateActivityEngine(engine) {
  if (!engine || typeof engine !== 'object' || Array.isArray(engine)) throw new Error('Activity engine must be an object.');
  assertText(engine.id, 'id');
  assertText(engine.label, 'label');
  if (!/^[a-z0-9][a-z0-9-]*$/.test(engine.id)) throw new Error(`Activity engine id "${engine.id}" is invalid.`);
  if (Number(engine.apiVersion) !== ACTIVITY_ENGINE_API_VERSION) {
    throw new Error(`Activity engine "${engine.id}" uses unsupported API version ${engine.apiVersion}.`);
  }
  if (!Array.isArray(engine.capabilities) || engine.capabilities.length === 0) {
    throw new Error(`Activity engine "${engine.id}" must declare capabilities.`);
  }
  if (engine.capabilities.includes('session')) {
    assertFunction(engine.createSession, 'createSession', engine.id);
  }
  if (engine.capabilities.includes('submission')) {
    assertFunction(engine.evaluateSubmission, 'evaluateSubmission', engine.id);
  }
  return engine;
}

export function defineActivityEngine(definition) {
  validateActivityEngine(definition);
  const capabilities = Object.freeze([...definition.capabilities]);
  const engine = { ...definition, capabilities };
  if (capabilities.includes('session')) {
    const createSession = definition.createSession;
    engine.createSession = (spec = {}) => validateActivitySession(createSession(spec), engine);
  }
  return Object.freeze(engine);
}

export function createEngineRegistry(initial = []) {
  const engines = new Map();

  function register(engine) {
    validateActivityEngine(engine);
    if (engines.has(engine.id)) throw new Error(`Activity engine "${engine.id}" is already registered.`);
    engines.set(engine.id, engine);
    return engine;
  }

  function get(id) {
    const engine = engines.get(id);
    if (!engine) throw new Error(`Activity engine "${id}" is not registered.`);
    return engine;
  }

  function has(id) { return engines.has(id); }
  function list() { return [...engines.values()]; }
  function ids() { return [...engines.keys()]; }

  initial.forEach(register);
  return Object.freeze({ register, get, has, list, ids });
}
