import { defineActivityEngine } from './contract.mjs';
import { deriveMonitoredVitals, deriveTrueLatent, deriveCircuitMechanics, advanceInternal, DEFAULT_COEFFICIENTS } from '../core/physiology.mjs';
import { createLabQueue, DEFAULT_TURNAROUND_SEC } from '../core/lab-queue.mjs';
import { buildTitrationMission, isBelowGoalFloor } from '../core/titration-lookup.mjs';
import { evidenceReviewEngine } from './evidence-review.mjs';
import { resolveRhythmEscalation, resolveRhythmRescueAction, RHYTHM_RESCUE_ACTIONS, DEFAULT_RHYTHM_THRESHOLDS } from '../core/rhythm.mjs';
import { createClinicalEventSystem } from '../core/clinical-events.mjs';
import { createInformationPipeline } from '../core/information-pipeline.mjs';
import { defaultClinicalKnowledgeRegistry } from '../core/clinical-knowledge-registry.mjs';
import { sanitizeLearnerLog, sanitizeLearnerActionResult } from '../core/learner-disclosure.mjs';
import { createTriggerEligibilityEngine } from '../core/trigger-eligibility.mjs';
import { createScenarioRuntimeDirector } from '../core/scenario-runtime-director.mjs';
import { createEmergentEligibilityEngine } from '../core/emergent-eligibility.mjs';
import { createClinicalTrajectoryEngine } from '../core/clinical-trajectory.mjs';
import { evaluateClinicalSignificance, shouldSurfaceClinicalChange } from '../core/clinical-significance.mjs';
import { createClinicalConsequenceEngine } from '../core/clinical-consequence.mjs';
import { resolveObservation } from '../core/observation-resolver.mjs';
import { createPatientPositionState } from '../core/patient-position.mjs';
import { createDebriefLog } from '../core/debrief-log.mjs';
import { buildLearnerDebriefAnalysis } from '../core/debrief-analysis.mjs';

function clone(value) { return JSON.parse(JSON.stringify(value)); }

const SETTABLE_PARAMS = new Set([
  'pumpRpm', 'sweepGasLpm', 'fdo2Percent', 'heaterTempC',
  'epiMcgKgMin', 'norepiMcgKgMin', 'bivalirudinMgKgHr'
]);

// titration-lookup.mjs uses clinical terminology ("neonate") as its table
// key; scenario authors may write "neonatal" — normalize here rather than
// forcing every scenario JSON to match the lookup module's exact spelling.
const POPULATION_ALIASES = { neonatal: 'neonate', neonate: 'neonate', pediatric: 'pediatric' };

// A latent variable only becomes a real-time reading if the scenario's
// equipment list says so. This is the one place that decides that —
// everywhere else just asks "is this field in `monitoredSurrogates`?"
function equipmentSurrogates(equipment = {}) {
  const surrogates = {};
  if (equipment.transcutaneousCO2) surrogates.paco2 = true;
  if (equipment.continuousSvo2) surrogates.svo2 = true;
  if (equipment.cerebralNirs) surrogates.nirs = true;
  return surrogates;
}

export const circuitSandboxEngine = defineActivityEngine({
  id: 'circuit-sandbox',
  label: 'ECMO Circuit Sandbox',
  apiVersion: 1,
  capabilities: ['session', 'time-advance'],
  createSession({ scenario, snapshot } = {}) {
    if (!scenario?.id || !scenario?.initialSettings || !scenario?.initialInternal) {
      throw new Error('Circuit Sandbox requires a scenario with initialSettings and initialInternal.');
    }
    if (!scenario.initialInternal.weightKg) {
      throw new Error('Circuit Sandbox requires initialInternal.weightKg for weight-indexed flow.');
    }
    if (!scenario.initialInternal.cannulaFr) {
      throw new Error('Circuit Sandbox requires initialInternal.cannulaFr (fixed once cannulated, not player-adjustable).');
    }
    const coeffs = { ...DEFAULT_COEFFICIENTS, ...(scenario.coefficientOverrides ?? {}) };
    const turnaround = { ...DEFAULT_TURNAROUND_SEC, ...(scenario.turnaroundOverridesSec ?? {}) };
    const rhythmThresholds = { ...DEFAULT_RHYTHM_THRESHOLDS, ...(scenario.rhythmThresholdOverrides ?? {}) };
    const equipment = scenario.equipment ?? {};
    const surrogates = equipmentSurrogates(equipment);
    const titrationPopulation = POPULATION_ALIASES[scenario.population] ?? scenario.population;
    const titrationRiskContext = scenario.dttRiskContext;
    const renalFunction = scenario.renalFunction ?? 'normal';

    const state = {
      version: 2,
      scenarioId: scenario.id,
      timeSec: Number(snapshot?.timeSec ?? 0),
      settings: { ...scenario.initialSettings, ...(snapshot?.settings ?? {}) },
      internal: snapshot?.internal ? clone(snapshot.internal) : clone(scenario.initialInternal),
      dttAttemptStreak: Number(snapshot?.dttAttemptStreak ?? 0),
      checkpointedLabIds: Array.isArray(snapshot?.checkpointedLabIds) ? [...snapshot.checkpointedLabIds] : [],
      // The active checkpoint, if any: { mission, dtt, engineSnapshot }.
      // Rebuilt into a live evidence-review session on demand rather than
      // held as a closure, so it survives snapshot/restore the same way
      // the outer session does.
      checkpoint: snapshot?.checkpoint ? clone(snapshot.checkpoint) : null,
      // Rhythm is scenario/physiology-driven only — there is deliberately
      // no action type anywhere below that lets a player set it directly.
      rhythm: snapshot?.rhythm ?? scenario.initialRhythm ?? 'sinus',
      rhythmAnnouncement: snapshot?.rhythmAnnouncement ?? null,
      hypoxiaSeconds: Number(snapshot?.hypoxiaSeconds ?? 0),
      noFlowSeconds: Number(snapshot?.noFlowSeconds ?? 0),
      criticalTrajectorySeconds: Number(snapshot?.criticalTrajectorySeconds ?? 0),
      bubbleDetector: snapshot?.bubbleDetector ?? 'clear',
      residualAirUpstream: Boolean(snapshot?.residualAirUpstream ?? false),
      bubbleAlarmResetArmed: Boolean(snapshot?.bubbleAlarmResetArmed ?? false),
      circuitClamped: Boolean(snapshot?.circuitClamped ?? false),
      started: snapshot?.started ?? !scenario.requiresManualStart,
      clinicalContext: { ...(snapshot?.clinicalContext ?? {}) }
    };
    const labQueue = createLabQueue(snapshot?.labOrders ?? []);
    const knowledgePlan = scenario.clinicalKnowledgePlan ?? null;
    const registryEvents = knowledgePlan
      ? defaultClinicalKnowledgeRegistry.compileComplications(
          [...new Set([...(knowledgePlan.requiredComplicationIds ?? []), ...(knowledgePlan.allowedComplicationIds ?? [])])],
          { activateIds: [], ecmoMode: scenario.educatorSetup?.ecmo?.mode ?? scenario.ecmoMode ?? null }
        )
      : [];
    // Backward compatibility: hand-authored legacy scenarios may still carry
    // embedded clinicalEvents. Educator-generated scenarios use registry IDs.
    const clinicalEventDefinitions = registryEvents.length ? registryEvents : (scenario.clinicalEvents ?? []);
    const clinicalEvents = createClinicalEventSystem(clinicalEventDefinitions, snapshot?.clinicalEventState ?? null);
    const triggers = createTriggerEligibilityEngine(knowledgePlan?.triggerPolicies ?? [], snapshot?.triggerState ?? null);
    const runtimeDirector = createScenarioRuntimeDirector({
      mode: scenario.runtimeDirector?.mode ?? scenario.learningPlan?.mode ?? 'adaptive',
      profile: scenario.runtimeDirector?.profile ?? {},
      snapshot: snapshot?.runtimeDirectorState ?? null
    });
    const emergentEligibility = createEmergentEligibilityEngine(
      knowledgePlan?.emergentEligibilityRules ?? scenario.emergentEligibilityRules ?? [],
      snapshot?.emergentEligibilityState ?? null
    );
    const trajectory = createClinicalTrajectoryEngine({
      profile: scenario.endpointProfile ?? {},
      snapshot: snapshot?.trajectoryState ?? null
    });
    const consequences = createClinicalConsequenceEngine({
      profile: scenario.patientSupportProfile ?? {},
      snapshot: snapshot?.clinicalConsequenceState ?? null
    });
    const information = createInformationPipeline({ timingProfile: scenario.informationTimingProfile ?? {}, snapshot: snapshot?.informationState ?? null });
    const patientPosition = createPatientPositionState({
      profile: scenario.patientPositionProfile ?? {},
      snapshot: snapshot?.patientPositionState ?? null
    });
    const debriefLog = createDebriefLog(snapshot?.debriefLog ?? null);

    function pushLog(entry) {
      debriefLog.record({ atSec: state.timeSec, ...entry });
    }


    function unresolvedClinicalEventCount() {
      const snap = clinicalEvents.snapshot();
      return Object.values(snap.active ?? {}).filter((eventState) => eventState.resolvedAtSec == null).length;
    }

    function evaluateTriggers() {
      const eligible = triggers.evaluate({
        timeSec: state.timeSec,
        clinicalContext: state.clinicalContext,
        started: state.started
      });
      const queued = runtimeDirector.enqueue(eligible);
      for (const candidate of queued) pushLog({ kind: 'runtime-event-eligible', ...candidate });
      const releases = runtimeDirector.evaluate({
        timeSec: state.timeSec,
        activeUnresolvedCount: unresolvedClinicalEventCount(),
        started: state.started,
        clinicalContext: state.clinicalContext
      });
      for (const release of releases) {
        clinicalEvents.activate(release.complicationId, state.timeSec, release.metadata?.initialState ?? null, { internal: state.internal, settings: state.settings });
        pushLog({ kind: 'runtime-event-released', ...release });
      }
      return releases;
    }

    function eventStateContext() {
      const snap = clinicalEvents.snapshot();
      return Object.fromEntries(Object.entries(snap.active ?? {}).map(([id, value]) => [id, {
        state: value.state,
        resolved: value.resolvedAtSec != null
      }]));
    }

    function evaluateConsequences() {
      const monitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
      return consequences.evaluate({
        timeSec: state.timeSec,
        flowIndexMlKgMin: monitored.flowIndexMlKgMin,
        map: monitored.map,
        started: state.started,
        internal: state.internal
      });
    }

    function combinedTrajectorySignals() {
      const signals = clinicalEvents.trajectorySignals();
      const consequenceSignal = consequences.presentation()?.trajectorySignal;
      if (consequenceSignal) signals.push(consequenceSignal);

      // A malignant non-perfusing rhythm is itself a patient-state signal.
      // Without this, a corrected mechanical cause could satisfy the generic
      // stabilization timer while the monitor still showed VF/asystole. That
      // creates a clinically contradictory success endpoint. Keep VT separate
      // because this simplified rhythm model does not encode pulse status.
      if (state.rhythm === 'vfib' || state.rhythm === 'asystole') {
        signals.push({
          source: 'rhythm-state',
          arrest: true,
          dimensions: { hemodynamics: 'absent', perfusion: 'absent' }
        });
      }
      return signals;
    }

    function evaluateTrajectory(forceEndpoint = null) {
      const endpoint = trajectory.evaluate({
        timeSec: state.timeSec,
        signals: combinedTrajectorySignals(),
        unresolvedEventCount: unresolvedClinicalEventCount(),
        started: state.started,
        forceEndpoint
      });
      if (endpoint && !debriefLog.instructorTimeline().some((entry) => entry.kind === 'scenario-endpoint' && entry.endpoint?.type === endpoint.type)) {
        pushLog({ kind: 'scenario-endpoint', endpoint: clone(endpoint) });
      }
      return endpoint;
    }

    function evaluateEmergentEligibility() {
      const candidates = emergentEligibility.evaluate({
        timeSec: state.timeSec,
        clinicalContext: state.clinicalContext,
        eventStates: eventStateContext(),
        trajectory: trajectory.instructorPresentation().last
      });
      const queued = runtimeDirector.enqueue(candidates);
      for (const candidate of queued) pushLog({ kind: 'runtime-event-eligible', ...candidate });
      if (!queued.length) return [];
      const releases = runtimeDirector.evaluate({
        timeSec: state.timeSec,
        activeUnresolvedCount: unresolvedClinicalEventCount(),
        started: state.started,
        clinicalContext: state.clinicalContext
      });
      for (const release of releases) {
        clinicalEvents.activate(release.complicationId, state.timeSec, release.metadata?.initialState ?? null, { internal: state.internal, settings: state.settings });
        pushLog({ kind: 'runtime-event-released', ...release });
      }
      return releases;
    }

    function liveCheckpointSession() {
      if (!state.checkpoint) return null;
      return evidenceReviewEngine.createSession({ mission: state.checkpoint.mission, snapshot: state.checkpoint.engineSnapshot });
    }

    // Called right after labQueue.tick() on every advance(). If a dTT just
    // resulted and no checkpoint is currently open, turn it into a scored
    // titration decision using Frank's real protocol. Silently skips (with
    // a log note) for population/riskContext combos the protocol didn't
    // give us percent-steps for — never fabricates a table.
    function maybeSpawnCheckpoint() {
      if (state.checkpoint) return; // one at a time — answer the open one first
      if (!titrationRiskContext) return; // scenario didn't declare a risk context, so no checkpoints at all
      const freshDtt = labQueue.resulted().find((o) => o.type === 'dtt' && !state.checkpointedLabIds.includes(o.id));
      if (!freshDtt) return;
      state.checkpointedLabIds.push(freshDtt.id);
      const dtt = freshDtt.values.dttMcgMl;
      try {
        const belowFloor = isBelowGoalFloor({ population: titrationPopulation, riskContext: titrationRiskContext, dtt });
        const attemptNumber = belowFloor ? state.dttAttemptStreak + 1 : 1;
        const mission = buildTitrationMission({
          population: titrationPopulation, riskContext: titrationRiskContext, dtt, attemptNumber, renalFunction
        });
        state.dttAttemptStreak = belowFloor ? attemptNumber : 0;
        const freshSession = evidenceReviewEngine.createSession({ mission });
        state.checkpoint = { mission, dtt, engineSnapshot: freshSession.snapshot() };
        pushLog({ kind: 'checkpoint-opened', labId: freshDtt.id, dtt });
      } catch (err) {
        pushLog({ kind: 'checkpoint-skipped', labId: freshDtt.id, dtt, reason: err.message });
      }
    }

    function presentation() {
      const monitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
      const circuit = deriveCircuitMechanics(monitored.flowLpm, state.bubbleDetector === 'alarm' || state.circuitClamped, state.timeSec, coeffs, state.internal);
      const trueLatent = state.internal.trueLatent;
      const ecmoMode = scenario.educatorSetup?.ecmo?.mode ?? scenario.ecmoMode ?? null;
      const population = scenario.population ?? scenario.educatorSetup?.patient?.population ?? null;
      const pulsePressure = Math.max(2, Number(state.internal.pulsePressureMmHg ?? (String(ecmoMode).toUpperCase()==='VA' ? 10 : 28)));
      const systolic = Math.round(monitored.map + (2/3)*pulsePressure);
      const diastolic = Math.round(monitored.map - (1/3)*pulsePressure);
      const isNeonatalOrPediatric = ['neonatal','neonate','pediatric'].includes(String(population).toLowerCase());
      const preDuctalSpo2 = isNeonatalOrPediatric ? Math.round(Math.max(40,Math.min(100, monitored.spo2 + Number(state.internal.preDuctalSpo2Offset ?? 0)))) : null;
      const postDuctalSpo2 = isNeonatalOrPediatric ? Math.round(Math.max(40,Math.min(100, monitored.spo2 + Number(state.internal.postDuctalSpo2Offset ?? 0)))) : null;
      const hgb = Number(trueLatent.hgbGdl ?? 12);
      const hct = Math.round(hgb * 3 * 10) / 10;
      const flowAdequacy = monitored.maxFlowForCannula > 0 ? circuit.measuredFlowLpm / monitored.maxFlowForCannula : 0;
      const lactate = Number(trueLatent.lactateMmolL ?? 2);
      const svo2 = Math.round(Math.max(25,Math.min(90, Number(trueLatent.svo2Percent ?? (48 + 32*flowAdequacy + 0.18*(monitored.map-40) - 2.5*Math.max(0,lactate-2))))));
      const arterialFlowLpm = String(ecmoMode).toUpperCase()==='VA'
        ? Math.round(Number(state.internal.arterialFlowLpm ?? circuit.measuredFlowLpm)*100)/100 : null;
      const shuntFlowLpm = state.internal.shuntFlowLpm == null ? null : Math.round(Number(state.internal.shuntFlowLpm)*100)/100;
      const surrogateReadings = {};
      if (surrogates.paco2) surrogateReadings.paco2Surrogate = Math.round(trueLatent.paco2);
      const checkpointSession = liveCheckpointSession();
      return {
        kind: 'circuit-sandbox',
        learnerBriefing: clone(scenario.learnerBriefing ?? null),
        timeSec: state.timeSec,
        started: state.started,
        settings: clone(state.settings),
        monitored: {
          hr: monitored.hr,
          bp: { systolic, diastolic, map: monitored.map },
          map: monitored.map,
          cvp: monitored.cvp,
          spo2: monitored.spo2,
          preDuctalSpo2,
          postDuctalSpo2,
          tempC: monitored.tempC
        },
        cdi: { hgbGdl: Math.round(hgb*10)/10, hctPercent:hct, svo2Percent:svo2 },
        circuit: {
          pumpRpm: monitored.pumpRpm,
          measuredFlowLpm: circuit.measuredFlowLpm,
          circuitFlowLpm: circuit.measuredFlowLpm,
          arterialFlowLpm,
          shuntFlowLpm,
          flowIndexMlKgMin: monitored.flowIndexMlKgMin,
          maxFlowForCannula: monitored.maxFlowForCannula,
          cannulaFr: state.internal.cannulaFr,
          chatter: monitored.chatter,
          venousPressure: circuit.venousPressure,
          preOxyPressure: circuit.preOxyPressure,
          postOxyPressure: circuit.postOxyPressure,
          deltaP: circuit.deltaP,
          clamped: state.circuitClamped
        },
        continuousControls: {
          pumpRpm:true,
          flowTarget:true,
          sweepGasLpm:true,
          fdo2Percent:true,
          circuitClamp:true
        },
        bubbleDetector: state.bubbleDetector,
        bubbleSafety: {
          detectorPresent: true,
          status: state.bubbleDetector,
          alarmActive: state.bubbleDetector === 'alarm',
          circuitInterlockActive: state.bubbleDetector === 'alarm',
          location: equipment.bubbleDetectorLocation ?? 'return-limb-downstream-of-final-pigtail',
          detectsOnlyAtSensorLocation: true,
          upstreamAirDoesNotAlarmUntilItReachesSensor: true,
          residualAirUpstream: state.residualAirUpstream,
          resetRequiredAfterAlarm: state.bubbleDetector === 'alarm',
          resetArmed: state.bubbleAlarmResetArmed
        },
        rhythm: state.rhythm,
        rhythmAnnouncement: state.rhythmAnnouncement,
        surrogateReadings,           // only populated for equipped surrogates — everything else must be ordered
        pendingLabs: labQueue.pending(state.timeSec).map(({ values, ...rest }) => rest), // hide values until revealed
        resultedLabs: labQueue.resulted(),
        information: information.presentation(),
        checkpoint: checkpointSession ? checkpointSession.presentation() : null,
        equipment: clone(equipment),
        log: sanitizeLearnerLog(debriefLog.instructorTimeline().slice(-20)),
        endpoint: trajectory.presentation().endpoint ? { type: trajectory.presentation().endpoint.type } : null,
        supportStatus: { class: consequences.presentation().supportClass },
        recentEvents: clone(scenario.recentEvents ?? []),
        handoff: clone(scenario.handoff ?? null),
        learnerObjectives: clone(scenario.learnerObjectives ?? []),
        lifecycle: {
          status: trajectory.presentation().endpoint?.type ?? (state.started ? 'active' : 'prebrief'),
          complete: trajectory.presentation().endpoint != null
        },
        patientPosition: patientPosition.learnerPresentation(),
        // Registry-driven, not hardcoded per UI. Deliberately resolved from
        // the whole learning OBJECTIVE with no concept filter (the full
        // differential's toolbox), not from this scenario's own narrow
        // clinicalKnowledgePlan.actionIds — that narrow list is exactly the
        // answer for a single-complication scenario, so using it directly
        // would hint at the hidden diagnosis through the button set itself.
        // Position actions are always offered since patient-position state
        // always exists, regardless of scenario.
        availableActions: defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons([
          ...(scenario.learningPlan?.primaryObjective
            ? defaultClinicalKnowledgeRegistry.resolveObjective(scenario.learningPlan.primaryObjective, []).actionIds
            : (scenario.clinicalKnowledgePlan?.actionIds ?? [])),
          'turn-patient', 'restore-prior-position',
          'assess-rhythm', 'defibrillate', 'synchronized-cardioversion', 'administer-arrest-epinephrine', 'begin-chest-compressions'
        ], {
          hiddenComplicationIds: [
            ...(scenario.clinicalKnowledgePlan?.requiredComplicationIds ?? []),
            ...(scenario.clinicalKnowledgePlan?.allowedComplicationIds ?? [])
          ]
        }).map((action)=>{
          if (action.id === 'turn-patient') return { ...action, label:`Turn / reposition patient (current: ${patientPosition.learnerPresentation().current.replaceAll('-',' ')})` };
          if (action.id === 'restore-prior-position') return { ...action, label:`Return to documented pre-event position (${patientPosition.learnerPresentation().previousDocumented.replaceAll('-',' ')}) and reassess circuit` };
          return action;
        }),
        complete: trajectory.presentation().endpoint != null,
        options: [] // sandbox has no fixed option list; actions come via submit()
      };
    }

    function clinicallyRelevantSnapshot() {
      const monitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
      return {
        hr: monitored.hr,
        map: monitored.map,
        spo2: monitored.spo2,
        cvp: monitored.cvp,
        flowIndexMlKgMin: monitored.flowIndexMlKgMin
      };
    }


    function applyPatientPosition(position, source = 'learner') {
      const before = clinicallyRelevantSnapshot();
      const change = patientPosition.setPosition(position, { timeSec: state.timeSec, source });
      const outcome = clinicalEvents.evaluateContextChange('patient-position-effect', change.effectClass, {
        timeSec: state.timeSec,
        internal: state.internal,
        settings: state.settings
      });
      evaluateConsequences();
      const after = clinicallyRelevantSnapshot();
      const significance = evaluateClinicalSignificance(before, after, scenario.clinicalSignificanceProfile);
      pushLog({
        kind:'patient-position-change',
        from:change.from,
        to:change.to,
        effectClass:change.effectClass,
        clinicalSignificance:significance,
        outcome: outcome ? { feedback:outcome.feedback, outcome:outcome.outcome } : null
      });
      evaluateTrajectory();
      const positionLabel = change.to.replaceAll('-',' ');
      const feedback = outcome?.feedback
        ? `Patient repositioned from ${change.from.replaceAll('-',' ')} to ${positionLabel}. ${outcome.feedback}`
        : `Patient repositioned from ${change.from.replaceAll('-',' ')} to ${positionLabel}. After this intervention, no meaningful change in drainage or ECMO support is observed.`;
      return { feedback, position:change.to };
    }

    function restorePreviousPatientPosition() {
      const target = patientPosition.learnerPresentation().previousDocumented;
      return applyPatientPosition(target, 'restore-previous');
    }

    function evaluateClinicalAction(actionId) {
      const before = clinicallyRelevantSnapshot();
      triggers.recordAction(actionId);
      emergentEligibility.recordAction(actionId);
      evaluateTriggers();
      const outcome = clinicalEvents.evaluateAction(actionId, {
        timeSec: state.timeSec,
        internal: state.internal,
        settings: state.settings
      });
      evaluateConsequences();
      const after = clinicallyRelevantSnapshot();
      const significance = evaluateClinicalSignificance(before, after, scenario.clinicalSignificanceProfile);
      if (outcome) pushLog({ kind: 'clinical-action-outcome', ...outcome, clinicalSignificance: significance });
      else if (shouldSurfaceClinicalChange(significance)) pushLog({ kind:'clinically-significant-change', actionId, clinicalSignificance: significance });
      evaluateTrajectory();
      evaluateEmergentEligibility();
      evaluateTrajectory();
      if (!outcome) return null;
      let feedback = outcome.feedback ?? '';
      if (actionId === 'assess-oxygenator') {
        const monitoredNow = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
        const circuitNow = deriveCircuitMechanics(monitoredNow.flowLpm, state.bubbleDetector === 'alarm' || state.circuitClamped, state.timeSec, coeffs, state.internal);
        const finding = resolveObservation(actionId, {
          eventSnapshot: clinicalEvents.snapshot(),
          circuit: { ...circuitNow, flowIndexMlKgMin: monitoredNow.flowIndexMlKgMin, chatter: monitoredNow.chatter },
          monitored: monitoredNow,
          internal: state.internal,
          scenario
        });
        if (finding) feedback = `${feedback} ${finding}`.trim();
      }
      // Keep grading classification, rationale, score, event state, hidden
      // diagnosis, and significance classification inside instructor/snapshot
      // data. The live learner gets only the observable consequence.
      return { feedback };
    }

    return {
      instructorPresentation() {
        return {
          scenarioId: scenario.id,
          timeSec: state.timeSec,
          started: state.started,
          clinicalEvents: clinicalEvents.presentation(),
          clinicalEventState: clinicalEvents.snapshot(),
          learningPlan: clone(scenario.learningPlan ?? null),
          clinicalKnowledgePlan: clone(scenario.clinicalKnowledgePlan ?? null),
          triggers: triggers.instructorPresentation(),
          runtimeDirector: runtimeDirector.instructorPresentation(),
          emergentEligibility: emergentEligibility.instructorPresentation(),
          trajectory: trajectory.instructorPresentation(),
          clinicalConsequences: consequences.instructorPresentation(),
          patientPosition: patientPosition.instructorPresentation(),
          log: debriefLog.instructorTimeline(),
          debrief: debriefLog.summary()
        };
      },
      learnerDebrief() {
        const endpoint = trajectory.presentation().endpoint;
        if (!endpoint) return null;
        const timeline = debriefLog.learnerTimeline();
        const outcomeLabels = {
          preferred: 'Effective / preferred',
          acceptable: 'Reasonable',
          temporizing: 'Temporizing',
          ineffective: 'Ineffective',
          harmful: 'Potentially harmful',
          'critical-error': 'Critical error'
        };
        // After the endpoint, expose a deliberately narrow review of the
        // learner's own interventions. We do NOT expose eventId, hidden
        // complication state, trigger metadata, or instructor-only rationale.
        const actionReview = debriefLog.instructorTimeline()
          .filter((entry) => entry.kind === 'clinical-action-outcome' || entry.category === 'action' || entry.category === 'resuscitation')
          .map((entry) => ({
            atSec: entry.atSec,
            action: entry.actionLabel ?? entry.actionId ?? entry.kind,
            feedback: entry.feedback ?? entry.finding ?? '',
            classification: entry.outcomeClass ? (outcomeLabels[entry.outcomeClass] ?? entry.outcomeClass) : null
          }));
        return clone({
          outcome: endpoint.type,
          outcomeReason: endpoint.reason ?? null,
          durationSec: state.timeSec,
          objectives: scenario.learnerObjectives ?? [],
          actionReview,
          timeline,
          summary: debriefLog.summary(),
          analysis: buildLearnerDebriefAnalysis({ scenario, timeline: debriefLog.instructorTimeline(), endpoint })
        });
      },
      snapshot() {
        return clone({ ...state, labOrders: labQueue.all(), clinicalEventState: clinicalEvents.snapshot(), triggerState: triggers.snapshot(), runtimeDirectorState: runtimeDirector.snapshot(), emergentEligibilityState: emergentEligibility.snapshot(), trajectoryState: trajectory.snapshot(), clinicalConsequenceState: consequences.snapshot(), patientPositionState: patientPosition.snapshot(), informationState: information.snapshot(), debriefLog: debriefLog.snapshot() });
      },
      presentation,
      advance(seconds) {
        if (!state.started) return { ok: true, timeSec: state.timeSec, status: 'not-started', complete: false, engineData: clone(state) };
        const ended = trajectory.presentation().endpoint;
        if (ended) return { ok: true, timeSec: state.timeSec, status: ended.type, complete: true, engineData: clone(state) };
        const elapsed = Math.max(0, Number(seconds) || 0);
        state.timeSec += elapsed;

        // Event state and support consequences are evaluated before monitored
        // physiology advances so the bedside monitor responds to the patient's
        // actual support state rather than drifting independently.
        evaluateTriggers();
        const eventTransitions = clinicalEvents.advance(elapsed, { timeSec: state.timeSec, internal: state.internal, settings: state.settings });
        for (const transition of eventTransitions) pushLog({ kind: 'clinical-event-transition', ...transition });
        evaluateConsequences();
        state.internal = advanceInternal(state.internal, state.settings, elapsed, coeffs);
        // Re-evaluate after the physiology tick so trajectory and monitor agree.
        evaluateConsequences();
        evaluateTrajectory();
        evaluateEmergentEligibility();
        evaluateConsequences();
        evaluateTrajectory();
        labQueue.tick(state.timeSec);
        maybeSpawnCheckpoint();
        information.tick(state.timeSec, state.clinicalContext);

        // Rhythm escalation — driven by physiology, never by a player action.
        const monitoredNow = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
        const circuitNow = deriveCircuitMechanics(monitoredNow.flowLpm, state.bubbleDetector === 'alarm', state.timeSec, coeffs);
        state.hypoxiaSeconds = monitoredNow.spo2 < rhythmThresholds.hypoxiaSpo2Ceiling ? state.hypoxiaSeconds + elapsed : 0;
        state.noFlowSeconds = circuitNow.measuredFlowLpm < rhythmThresholds.noFlowFloorLpm ? state.noFlowSeconds + elapsed : 0;
        const trajectoryNow = trajectory.instructorPresentation().last;
        const endpointNow = trajectory.presentation().endpoint;
        const criticalTrajectoryLabels = new Set(['critical', 'collapse', 'arrest', 'terminal']);
        state.criticalTrajectorySeconds = criticalTrajectoryLabels.has(trajectoryNow.label) ? state.criticalTrajectorySeconds + elapsed : 0;
        const escalation = resolveRhythmEscalation({
          rhythm: state.rhythm, hypoxiaSeconds: state.hypoxiaSeconds, noFlowSeconds: state.noFlowSeconds,
          criticalTrajectorySeconds: state.criticalTrajectorySeconds, arrestActive: trajectoryNow.arrest === true,
          endpointType: endpointNow?.type ?? null, thresholds: rhythmThresholds
        });
        if (escalation) {
          state.rhythm = escalation.rhythm;
          state.rhythmAnnouncement = `${escalation.rhythm} — ${escalation.reason}`;
          pushLog({ kind: 'rhythm-change', rhythm: escalation.rhythm, reason: escalation.reason });
        }

        const endpoint = trajectory.presentation().endpoint;
        return { ok: true, timeSec: state.timeSec, complete: endpoint != null, status: endpoint?.type ?? 'running', engineData: clone({ ...state, labOrders: labQueue.all() }) };
      },
      submit(action) {
        const type = action?.type;
        if (type === 'start-scenario') {
          if (state.started) return { ok: true, accepted: true, complete: false, status: 'already-started', feedback: '' };
          state.started = true;
          pushLog({ kind: 'scenario-started' });
          // Capture the patient's pre-complication support baseline before any
          // at-start event changes flow.
          evaluateConsequences();
          evaluateTriggers();
          evaluateConsequences();
          evaluateTrajectory();
          return { ok: true, accepted: true, complete: false, status: 'started', feedback: 'Scenario started.' };
        }
        if (scenario.requiresManualStart && !state.started) {
          return { ok: false, accepted: false, complete: false, status: 'not-started', feedback: 'Press Start Scenario before interacting with the patient.' };
        }
        if (type === 'end-scenario') {
          const endpoint = evaluateTrajectory({ type: 'instructor-terminated', reason: action.reason ?? 'instructor-ended-session' });
          return { ok: true, accepted: true, complete: true, status: endpoint.type, feedback: 'Scenario ended.' };
        }
        const existingEndpoint = trajectory.presentation().endpoint;
        if (existingEndpoint) {
          return { ok: false, accepted: false, complete: true, status: existingEndpoint.type, feedback: 'The scenario has ended.' };
        }
        if (type === 'set-clinical-context') {
          state.clinicalContext[action.key] = Boolean(action.value);
          information.tick(state.timeSec, state.clinicalContext);
          pushLog({ kind: 'clinical-context', key: action.key, value: Boolean(action.value) });
          return { ok: true, accepted: true, complete: false, status: 'applied', feedback: '' };
        }
        if (type === 'order-study') {
          const rec = information.request(action.studyType, { timeSec: state.timeSec, label: action.label, payload: action.payload ?? {}, blockers: action.blockers ?? [] });
          information.tick(state.timeSec, state.clinicalContext);
          pushLog({ kind: 'study-ordered', studyType: action.studyType, requestId: rec.id });
          return { ok: true, accepted: true, complete: false, status: 'ordered', feedback: `${rec.label} requested.`, requestId: rec.id };
        }
        if (type === 'acquire-study') {
          const result = information.acquire(action.requestId, { timeSec: state.timeSec, context: state.clinicalContext, rawResult: action.rawResult, interpretation: action.interpretation });
          pushLog({ kind: 'study-acquisition', requestId: action.requestId, status: result.status });
          return { ok: result.ok, accepted: result.ok, complete: false, status: result.status, feedback: result.reason ?? '' };
        }
        if (type === 'set-flow-target') {
          const target = Math.max(0, Number(action.flowIndexMlKgMin ?? 0));
          let lo=0,hi=6000,best=state.settings.pumpRpm ?? 0;
          for(let i=0;i<24;i++){
            const mid=(lo+hi)/2;
            const m=deriveMonitoredVitals({settings:{...state.settings,pumpRpm:mid},internal:state.internal,coeffs});
            if(m.flowIndexMlKgMin<target)lo=mid;else hi=mid;
            best=mid;
          }
          const previous=Number(state.settings.pumpRpm ?? 0);
          state.settings.pumpRpm=Math.round(best/10)*10;
          let clinicalOutcome=null;
          if(state.settings.pumpRpm>previous)clinicalOutcome=evaluateClinicalAction('increase-rpm');
          evaluateConsequences();
          const after=deriveMonitoredVitals({settings:state.settings,internal:state.internal,coeffs});
          return sanitizeLearnerActionResult({ok:true,accepted:true,complete:false,status:'applied',
            feedback:clinicalOutcome?.feedback ?? `Flow target adjusted to ${Math.round(target)} mL/kg/min by changing pump RPM. Measured flow is now ${Math.round(after.flowIndexMlKgMin)} mL/kg/min at ${Math.round(state.settings.pumpRpm)} RPM. Reassess pressures, drainage, and patient response.`});
        }
        if (type === 'set-bubble-detector-state') {
          const status = action.status === 'alarm' ? 'alarm' : 'clear';
          state.bubbleDetector = status;
          if (status === 'alarm') {
            state.residualAirUpstream = action.residualAirUpstream !== false;
            state.bubbleAlarmResetArmed = false;
          }
          pushLog({kind:'bubble-detector-state',status,source:action.source ?? 'simulation'});
          evaluateConsequences();
          return {
            ok:true,accepted:true,complete:false,status:'applied',
            feedback: status === 'alarm'
              ? 'Air has reached the return-limb bubble detector downstream of the final pigtail. The detector alarms and the safety interlock stops pump flow.'
              : 'Bubble detector clear. No air is currently detected at the return-limb sensor location.'
          };
        }
        if (type === 'reset-bubble-detector-alarm') {
          if (state.bubbleDetector !== 'alarm') return {ok:true,accepted:true,complete:false,status:'applied',feedback:'Bubble detector is already clear; no alarm reset is required.'};
          state.bubbleDetector='clear';
          state.bubbleAlarmResetArmed=true;
          pushLog({kind:'bubble-detector-reset',residualAirUpstream:state.residualAirUpstream});
          return {ok:true,accepted:true,complete:false,status:'applied',
            feedback:state.residualAirUpstream
              ? 'Bubble detector alarm reset and re-armed, but residual air has not been cleared from the circuit. Restoring pump flow may carry that air back to the detector and retrigger the alarm.'
              : 'Bubble detector alarm reset and re-armed. No residual upstream air is currently modeled.'};
        }
        if (type === 'clear-circuit-air') {
          state.residualAirUpstream=false;
          pushLog({kind:'circuit-air-cleared'});
          return {ok:true,accepted:true,complete:false,status:'applied',feedback:'Circuit air has been explicitly cleared/de-aired upstream of the return-limb bubble detector.'};
        }
        if (type === 'set-circuit-clamp') {
          const nextClamped=Boolean(action.clamped);
          if(nextClamped&&!state.circuitClamped){
            state.internal.preClampSupportFlowMultiplier=Number(state.internal.supportFlowMultiplier ?? 1);
            state.internal.supportFlowMultiplier=0;
          } else if(!nextClamped&&state.circuitClamped){
            state.internal.supportFlowMultiplier=Number(state.internal.preClampSupportFlowMultiplier ?? 1);
            delete state.internal.preClampSupportFlowMultiplier;
          }
          state.circuitClamped=nextClamped;
          if(!nextClamped && Number(state.settings.pumpRpm ?? 0)>0 && state.bubbleAlarmResetArmed && state.residualAirUpstream){
            state.bubbleDetector='alarm';
            state.bubbleAlarmResetArmed=false;
            pushLog({kind:'bubble-detector-retrip',reason:'residual-air-reached-sensor-after-unclamp'});
          }
          pushLog({kind:'circuit-clamp',clamped:state.circuitClamped});
          evaluateConsequences();
          return {ok:true,accepted:true,complete:false,status:'applied',
            feedback:state.circuitClamped?'Circuit clamped. ECMO circuit flow is interrupted immediately; reassess patient perfusion and circuit status.':'Circuit unclamped. ECMO flow resumes according to pump RPM, preload, resistance, and circuit conditions.'};
        }
        if (type === 'set-param') {
          if (!SETTABLE_PARAMS.has(action.param)) {
            return { ok: false, accepted: false, complete: false, status: 'invalid', feedback: `Unknown parameter "${action.param}".`, engineData: clone(state) };
          }
          const previous = Number(state.settings[action.param] ?? 0);
          const nextValue = Number(action.value);
          state.settings[action.param] = nextValue;
          if (action.param === 'pumpRpm' && nextValue > 0 && state.bubbleAlarmResetArmed && state.residualAirUpstream) {
            state.bubbleDetector='alarm';
            state.bubbleAlarmResetArmed=false;
            pushLog({kind:'bubble-detector-retrip',reason:'residual-air-reached-sensor-after-flow-restored'});
          }
          pushLog({ kind: 'set-param', param: action.param, value: nextValue });
          let clinicalOutcome = null;
          if (action.param === 'pumpRpm' && nextValue > previous) clinicalOutcome = evaluateClinicalAction('increase-rpm');
          if (action.param === 'sweepGasLpm' && nextValue > previous) clinicalOutcome = evaluateClinicalAction('increase-sweep');
          evaluateConsequences();
          const afterMonitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
          let fallbackFeedback = '';
          if (action.param === 'pumpRpm') fallbackFeedback = `RPM adjusted from ${Math.round(previous)} to ${Math.round(nextValue)}. Current ECMO flow is ${Math.round(afterMonitored.flowIndexMlKgMin)} mL/kg/min; reassess drainage, pressures, and patient response.`;
          else if (action.param === 'sweepGasLpm') fallbackFeedback = `Sweep adjusted from ${previous} to ${nextValue} L/min. Reassess the appropriate gas-exchange monitor or obtain a blood gas; an immediate visible bedside change is not guaranteed.`;
          else fallbackFeedback = `${action.param} adjusted from ${previous} to ${nextValue}. Reassess the patient for a clinically meaningful response.`;
          return sanitizeLearnerActionResult({ ok: true, accepted: true, complete: false, status: 'applied', feedback: clinicalOutcome?.feedback ?? fallbackFeedback });
        }
        if (type === 'bolus-volume') {
          const mlKg = Number(action.mlPerKg ?? 0);
          state.internal.volumeBolusMapBump += mlKg * coeffs.mapPerMlKgVolumeBolus;
          state.internal.volumeBolusCvpBump += mlKg * coeffs.cvpPerMlKgVolumeBolus;
          pushLog({ kind: 'bolus-volume', mlPerKg: mlKg });
          const clinicalOutcome = evaluateClinicalAction('volume-bolus');
          evaluateConsequences();
          const afterMonitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
          const fallbackFeedback = `Volume bolus administered. Current MAP is ${Math.round(afterMonitored.map)} mmHg and ECMO flow is ${Math.round(afterMonitored.flowIndexMlKgMin)} mL/kg/min. Reassess whether the response is meaningful and sustained.`;
          return sanitizeLearnerActionResult({ ok: true, accepted: true, complete: false, status: 'applied', feedback: clinicalOutcome?.feedback ?? fallbackFeedback });
        }
        if (type === 'order-lab') {
          const trueLatent = deriveTrueLatent({ settings: state.settings, internal: state.internal, coeffs });
          const record = labQueue.order(action.labType, { orderedAtSec: state.timeSec, trueLatent, turnaround });
          pushLog({ kind: 'order-lab', labType: action.labType, resultAtSec: record.resultAtSec });
          return { ok: true, accepted: true, complete: false, status: 'ordered', feedback: `${action.labType.toUpperCase()} sent — result in ~${Math.round((record.resultAtSec - state.timeSec) / 60)} min.`, engineData: clone(state) };
        }
        if (type === 'answer-checkpoint') {
          if (!state.checkpoint) {
            return { ok: false, accepted: false, complete: false, status: 'invalid', feedback: 'No checkpoint is currently open.', engineData: clone(state) };
          }
          const session = liveCheckpointSession();
          const result = session.submit(action.optionId);
          state.checkpoint.engineSnapshot = session.snapshot();
          if (result.complete) {
            pushLog({ kind: 'checkpoint-answered', dtt: state.checkpoint.dtt, optionId: action.optionId, status: result.status });
            state.checkpoint = null; // resolved — a later dtt result can open the next one
          }
          return { ok: result.ok, accepted: result.accepted, complete: false, status: result.status, feedback: result.feedback, rationale: result.rationale, engineData: clone(state) };
        }
        if (type === 'trigger-bubble-alarm') {
          state.bubbleDetector = 'alarm';
          pushLog({ kind: 'bubble-alarm', status: 'triggered' });
          return { ok: true, accepted: true, complete: false, status: 'alarm', feedback: 'Air detected — pump stopped.', engineData: clone(state) };
        }
        if (type === 'clear-bubble-alarm') {
          state.bubbleDetector = 'clear';
          pushLog({ kind: 'bubble-alarm', status: 'cleared' });
          return { ok: true, accepted: true, complete: false, status: 'cleared', feedback: 'Bubble detector cleared — pump resumed.', engineData: clone(state) };
        }
        if (type === 'dismiss-rhythm-announcement') {
          state.rhythmAnnouncement = null;
          return { ok: true, accepted: true, complete: false, status: 'dismissed', feedback: '', engineData: clone(state) };
        }
        if (type === 'set-patient-position') {
          if (!action.position) return { ok:false, accepted:false, complete:false, status:'invalid', feedback:'Select a patient position.' };
          const result = applyPatientPosition(action.position, 'learner');
          return { ok:true, accepted:true, complete:false, status:'applied', feedback:result.feedback, patientPosition:result.position };
        }
        if (type === 'restore-previous-position') {
          const result = restorePreviousPatientPosition();
          return { ok:true, accepted:true, complete:false, status:'applied', feedback:result.feedback, patientPosition:result.position };
        }
        // Backward-compatible natural-language actions now route through the
        // position-state system rather than carrying their own medical effects.
        if (type === 'clinical-action' && action.actionId === 'restore-prior-position') {
          const result = restorePreviousPatientPosition();
          return { ok:true, accepted:true, complete:false, status:'applied', feedback:result.feedback, patientPosition:result.position };
        }
        if (type === 'clinical-action' && action.actionId === 'turn-patient') {
          return {
            ok:true, accepted:true, complete:false, status:'position-selection-required',
            feedback:`Current position: ${patientPosition.learnerPresentation().current.replaceAll('-',' ')}. Select the specific new patient position; a generic "turn" does not imply returning to the documented pre-event position (${patientPosition.learnerPresentation().previousDocumented.replaceAll('-',' ')}).`,
            positionOptions:patientPosition.learnerPresentation().available
          };
        }
        if (type === 'clinical-action' && action.actionId in RHYTHM_RESCUE_ACTIONS) {
          const monitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
          const circuit = deriveCircuitMechanics(monitored.flowLpm, state.bubbleDetector === 'alarm' || state.circuitClamped, state.timeSec, coeffs, state.internal);
          const circuitFlowAdequate = circuit.measuredFlowLpm >= rhythmThresholds.noFlowFloorLpm;
          const result = resolveRhythmRescueAction(action.actionId, state.rhythm, { circuitFlowAdequate });
          const rhythmChanged = result.nextRhythm !== state.rhythm;
          if (rhythmChanged) {
            state.rhythm = result.nextRhythm;
            state.rhythmAnnouncement = `${result.nextRhythm} — ${action.actionId}`;
          }
          pushLog({
            kind: 'rhythm-rescue-action', actionId: action.actionId, outcomeClass: result.outcome,
            scoreDelta: result.scoreDelta, rhythmChanged, feedback: result.feedback
          });
          return sanitizeLearnerActionResult({ ok: true, accepted: true, complete: false, status: 'applied', feedback: result.feedback });
        }
        if (type === 'clinical-action') {
          if (!action.actionId) return { ok: false, accepted: false, complete: false, status: 'invalid', feedback: 'clinical-action requires actionId.', engineData: clone(state) };
          const clinicalOutcome = evaluateClinicalAction(action.actionId);
          if (!clinicalOutcome) {
            const monitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
            const circuit = deriveCircuitMechanics(monitored.flowLpm, state.bubbleDetector === 'alarm' || state.circuitClamped, state.timeSec, coeffs, state.internal);
            const finding = resolveObservation(action.actionId, {
              eventSnapshot: clinicalEvents.snapshot(),
              circuit: { ...circuit, flowIndexMlKgMin: monitored.flowIndexMlKgMin, chatter: monitored.chatter },
              monitored,
              internal: state.internal,
              scenario
            });
            const actionLabel = defaultClinicalKnowledgeRegistry.resolveLearnerActionButtons([action.actionId], { hiddenComplicationIds:[] })[0]?.label ?? action.actionId.replaceAll('-',' ');
            const feedback = finding ?? `${actionLabel} performed. No specific clinically meaningful response is observed from this action in the current state; reassess the patient and circuit.`;
            pushLog({ kind: 'clinical-action', actionId: action.actionId, outcome: 'assessment-or-no-specific-effect', feedback });
            return { ok: true, accepted: true, complete: false, status: 'no-specific-effect', feedback, clinicalOutcome: null, engineData: clone(state) };
          }
          const postMonitored = deriveMonitoredVitals({ settings: state.settings, internal: state.internal, coeffs });
          const postCircuit = deriveCircuitMechanics(postMonitored.flowLpm, state.bubbleDetector === 'alarm' || state.circuitClamped, state.timeSec, coeffs, state.internal);
          const observationFeedback = resolveObservation(action.actionId, {
            eventSnapshot: clinicalEvents.snapshot(),
            circuit: { ...postCircuit, flowIndexMlKgMin: postMonitored.flowIndexMlKgMin, chatter: postMonitored.chatter },
            monitored: postMonitored,
            internal: state.internal,
            scenario
          });
          const richObservationActions = new Set(['assess-oxygenator','assess-differential-hypoxemia','assess-lv-distension','assess-limb-perfusion','assess-thrombosis','assess-recirculation','assess-gas-exchange','assess-thorax','assess-airway-ventilator','neuro-assessment','assess-shock','assess-renal-fluid','assess-electrolytes','assess-pulmonary-hypertension']);
          const feedback = richObservationActions.has(action.actionId) && observationFeedback
            ? observationFeedback : clinicalOutcome.feedback;
          return sanitizeLearnerActionResult({ ok: true, accepted: true, complete: false, status: 'applied', feedback });
        }
        return { ok: false, accepted: false, complete: false, status: 'invalid', feedback: 'Unrecognized action.', engineData: clone(state) };
      }
    };
  }
});

export default circuitSandboxEngine;
