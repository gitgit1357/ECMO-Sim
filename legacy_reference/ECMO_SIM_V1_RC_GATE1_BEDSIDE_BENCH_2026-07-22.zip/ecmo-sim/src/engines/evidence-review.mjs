// Forked verbatim from the Academy Suite (src/engines/evidence-review.mjs).
// A single-decision, multiple-choice checkpoint: present a prompt +
// options, score the selected option against a correct answer. This is
// what the dTT titration checkpoint (see core/titration-lookup.mjs) is
// built on — no changes needed here, the mission data does the work.
import { defineActivityEngine } from './contract.mjs';

function cloneState(value) {
  return JSON.parse(JSON.stringify(value));
}

function normalizeOption(input) {
  if (input && typeof input === 'object') return String(input.id ?? input.value ?? '').trim();
  return String(input ?? '').trim();
}

export const evidenceReviewEngine = defineActivityEngine({
  id: 'evidence-review',
  label: 'Evidence Review',
  apiVersion: 1,
  capabilities: ['session'],
  createSession({ mission, snapshot } = {}) {
    if (!mission?.id || !Array.isArray(mission.options) || !mission.options.length) {
      throw new Error('Evidence Review requires a mission with options.');
    }
    const state = {
      version: 1,
      missionId: mission.id,
      attempts: Number(snapshot?.attempts ?? 0),
      complete: Boolean(snapshot?.complete),
      selected: snapshot?.selected ?? null
    };
    return {
      snapshot() { return cloneState(state); },
      presentation() {
        return {
          kind: 'evidence-review',
          missionId: mission.id,
          eyebrow: mission.eyebrow ?? 'EVIDENCE REVIEW',
          title: mission.title,
          prompt: mission.prompt,
          evidence: cloneState(mission.evidence ?? []),
          options: cloneState(mission.options),
          complete: state.complete,
          selected: state.selected
        };
      },
      submit(input) {
        if (state.complete) {
          return { ok: true, accepted: true, complete: true, status: 'complete', feedback: mission.rationale, rationale: mission.rationale, engineData: cloneState(state) };
        }
        const selected = normalizeOption(input);
        const option = mission.options.find((item) => item.id === selected);
        state.attempts += 1;
        state.selected = selected || null;
        if (!option) {
          return { ok: false, accepted: false, complete: false, status: 'invalid', feedback: 'Choose one of the available findings.', engineData: cloneState(state) };
        }
        if (selected !== mission.correctOption) {
          return {
            ok: false,
            accepted: false,
            complete: false,
            status: 'rejected',
            feedback: option.feedback || mission.missFeedback || 'That conclusion does not account for the strongest evidence.',
            engineData: cloneState(state)
          };
        }
        state.complete = true;
        return {
          ok: true,
          accepted: true,
          complete: true,
          status: 'accepted',
          feedback: mission.successFeedback || 'Finding confirmed.',
          rationale: mission.rationale,
          scoreSignals: { firstTry: state.attempts === 1, attempts: state.attempts },
          engineData: cloneState(state)
        };
      }
    };
  }
});

export default evidenceReviewEngine;
