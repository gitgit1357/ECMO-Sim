import { buildScenarioFromSetup } from './scenario-builder.mjs';

function clone(v){return JSON.parse(JSON.stringify(v));}
const BASE_SETUP=Object.freeze({
 patient:{population:'adult',age:'48 years',weightKg:80,diagnosis:'Cardiogenic shock requiring VA ECMO',procedure:'Peripheral VA ECMO',postOpDay:1},
 ecmo:{mode:'VA',cannulation:'peripheral',cannulaFr:17,pumpRpm:3200,sweepGasLpm:3,fdo2Percent:100,circuitAgeHours:36},
 startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'none',renalFunction:'normal',neurologicStatus:'sedated'},
 education:{primaryObjective:'va-support',concepts:[],mode:'guided',difficulty:'intermediate'}
});

export const VA_ECMO_PRESETS=Object.freeze([
 {id:'va-01-differential-hypoxemia',learnerLabel:'VA ECMO 01',educatorLabel:'Differential hypoxemia / North-South syndrome',complicationId:'va-differential-hypoxemia',
 briefing:'You are assuming care of a patient supported with peripheral VA ECMO. Native cardiac function has begun to change. Review site-specific oxygenation and support data and respond to any clinically important mismatch.',
 recentEvents:[
  {minutesBeforeStart:120,text:'Peripheral VA ECMO support and systemic perfusion were documented as adequate.'},
  {minutesBeforeStart:35,text:'Native pulsatility and cardiac ejection appeared to be increasing.'},
  {minutesBeforeStart:10,text:'A discrepancy was noted between upper-body oxygenation and other available oxygenation measurements; the cause has not been established.'},
  {minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'va-02-lv-distension',learnerLabel:'VA ECMO 02',educatorLabel:'LV distension / inadequate unloading',complicationId:'va-lv-distension',
 briefing:'You are assuming care of a patient on VA ECMO with evolving cardiac and pulmonary findings. Assess ventricular ejection, pulmonary congestion, and adequacy of unloading.',
 recentEvents:[{minutesBeforeStart:90,text:'VA ECMO flow remained near the established support target.'},{minutesBeforeStart:25,text:'Pulmonary congestion and reduced effective ventricular ejection became a concern.'},{minutesBeforeStart:0,text:'You assume care before a definitive management decision has been made.'}]},
 {id:'va-03-limb-ischemia',learnerLabel:'VA ECMO 03',educatorLabel:'Peripheral cannulation limb ischemia',complicationId:'limb-ischemia',
 briefing:'You are assuming care of a patient on peripheral VA ECMO. Review distal perfusion and cannulation-related vascular findings and respond to any threatened limb perfusion.',
 recentEvents:[{minutesBeforeStart:60,text:'Peripheral VA ECMO support remained stable.'},{minutesBeforeStart:15,text:'A change in the cannulated extremity prompted repeat distal perfusion assessment.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'va-04-thrombosis',learnerLabel:'VA ECMO 04',educatorLabel:'Circuit / cannula / intracardiac thrombosis',complicationId:'circuit-systemic-thrombosis',
 briefing:'You are assuming care of a patient on VA ECMO with a new concern involving effective support and possible thrombotic burden. Use circuit and patient evidence to localize the problem and manage the immediate threat.',
 recentEvents:[{minutesBeforeStart:180,text:'Circuit support was previously near the established baseline.'},{minutesBeforeStart:30,text:'A new support abnormality and concern for thrombotic burden were reported.'},{minutesBeforeStart:0,text:'You assume care while localization remains incomplete.'}]}
]);

const OBJECTIVES=Object.freeze([
 'Recognize VA-specific complications using patient, circuit, and site-specific evidence.',
 'Distinguish native heart/lung interaction problems from primary circuit-support problems.',
 'Choose cause-directed interventions rather than treating a single monitor value in isolation.',
 'Reassess patient and ECMO response after intervention and escalate when definitive correction is required.'
]);

function merge(base,patch={}){return {...clone(base),...clone(patch),patient:{...clone(base.patient),...clone(patch.patient??{})},ecmo:{...clone(base.ecmo),...clone(patch.ecmo??{})},startingCondition:{...clone(base.startingCondition),...clone(patch.startingCondition??{})},education:{...clone(base.education),...clone(patch.education??{})}};}

export function listVaEcmoScenarios({audience='learner'}={}){return VA_ECMO_PRESETS.map(p=>({id:p.id,label:audience==='educator'?p.educatorLabel:p.learnerLabel}));}
export function buildVaEcmoScenario(id,{setup={}}={}){
 const p=VA_ECMO_PRESETS.find(x=>x.id===id);if(!p)throw new Error(`Unknown VA ECMO scenario: ${id}`);
 const s=buildScenarioFromSetup(merge(BASE_SETUP,setup),{id:`va-ecmo-${p.id}`});
 s.learningPlan.concepts=['va-support'];
 s.clinicalKnowledgePlan.requiredComplicationIds=[p.complicationId];
 s.clinicalKnowledgePlan.allowedComplicationIds=[p.complicationId];
 s.clinicalKnowledgePlan.triggerPolicies=[{id:`preset-${p.id}`,complicationId:p.complicationId,type:'at-start',source:'va-ecmo-scenario-library'}];
 s.learnerBriefing={caseLabel:p.learnerLabel,text:p.briefing};
 s.handoff={summary:'The patient is supported with VA ECMO. Review recent events, native heart/lung interaction, site-specific patient data, and circuit support before acting.',currentConcern:'A clinically significant VA-specific complication may be developing. The cause has not been established.'};
 s.recentEvents=clone(p.recentEvents);s.learnerObjectives=clone(OBJECTIVES);
 s.lifecycle={version:1,completionRule:'clinical-endpoint',successEndpointTypes:['stabilized'],failureEndpointTypes:['death'],allowInstructorTermination:true};
 s.educatorScenarioMetadata={presetId:p.id,intendedComplicationId:p.complicationId,educatorLabel:p.educatorLabel,milestone:'M4'};
 return s;
}
