import { listLowFlowTroubleshootingScenarios, buildLowFlowTroubleshootingScenario } from './troubleshooting-scenario-library.mjs';
import { listCircuitEmergencyScenarios, buildCircuitEmergencyScenario } from './circuit-emergency-scenario-library.mjs';
import { listVaEcmoScenarios, buildVaEcmoScenario } from './va-ecmo-scenario-library.mjs';
import { listVvEcmoScenarios, buildVvEcmoScenario } from './vv-ecmo-scenario-library.mjs';
import { listPatientEmergencyScenarios, buildPatientEmergencyScenario } from './patient-emergency-scenario-library.mjs';

function clone(v){return JSON.parse(JSON.stringify(v));}
const PACKS=[
 {id:'low-flow',label:'Low-Flow Troubleshooting',list:()=>listLowFlowTroubleshootingScenarios({audience:'educator'}),build:(id,o)=>buildLowFlowTroubleshootingScenario(id,o)},
 {id:'circuit',label:'Circuit Emergencies',list:()=>listCircuitEmergencyScenarios({audience:'educator'}),build:(id,o)=>buildCircuitEmergencyScenario(id,o)},
 {id:'va',label:'VA ECMO',list:()=>listVaEcmoScenarios({audience:'educator'}),build:(id,o)=>buildVaEcmoScenario(id,o)},
 {id:'vv',label:'VV ECMO',list:()=>listVvEcmoScenarios({audience:'educator'}),build:(id,o)=>buildVvEcmoScenario(id,o)},
 {id:'patient',label:'Patient Emergencies',list:()=>listPatientEmergencyScenarios({audience:'educator'}),build:(id,o)=>buildPatientEmergencyScenario(id,o)}
];

export function educatorScenarioCatalog(){
 return PACKS.map(pack=>({id:pack.id,label:pack.label,templates:pack.list().map(x=>({id:x.id,label:x.label}))}));
}

function findTemplate(templateId){
 for(const pack of PACKS){const item=pack.list().find(x=>x.id===templateId);if(item)return {pack,item};}
 return null;
}

export function createEducatorScenario({
 templateId,
 difficulty='intermediate',
 mode='guided',
 patient={},
 ecmo={},
 recentEventNote=''
}={}){
 const found=findTemplate(templateId);if(!found)throw new Error(`Unsupported educator scenario template "${templateId}".`);
 if(!['beginner','intermediate','advanced'].includes(difficulty))throw new Error(`Unsupported difficulty "${difficulty}".`);
 if(!['guided','adaptive','dynamic'].includes(mode))throw new Error(`Unsupported education mode "${mode}".`);

 const setup={patient:clone(patient),ecmo:clone(ecmo),education:{difficulty,mode}};
 const scenario=found.pack.build(templateId,{setup,difficulty,mode});
 scenario.learningPlan={...(scenario.learningPlan??{}),difficulty,mode};
 scenario.educatorSetup={...(scenario.educatorSetup??{}),patient:{...(scenario.educatorSetup?.patient??{}),...clone(patient)},ecmo:{...(scenario.educatorSetup?.ecmo??{}),...clone(ecmo)},education:{...(scenario.educatorSetup?.education??{}),difficulty,mode}};
 if(String(recentEventNote??'').trim()){
   scenario.recentEvents=[...(scenario.recentEvents??[]),{minutesBeforeStart:0,text:String(recentEventNote).trim(),source:'educator-added-context'}];
 }
 scenario.educatorCreatorMetadata={packId:found.pack.id,templateId,difficulty,mode,createdFromSupportedTemplate:true};
 return scenario;
}
