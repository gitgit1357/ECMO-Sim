function clone(value) { return JSON.parse(JSON.stringify(value)); }

export const TRAJECTORY_LEVELS = Object.freeze({ stable: 0, impaired: 1, critical: 2, absent: 3 });

export const DEFAULT_ENDPOINT_PROFILE = Object.freeze({
  // These are simulation-policy placeholders, not claims about real-world timing.
  stabilizationWindowSec: 120,
  arrestRescueWindowSec: 180,
  cumulativeCriticalExposureSec: 600,
  requireEncounteredInstabilityForAutoStabilization: true
});

const DIMENSIONS = ['perfusion', 'oxygenation', 'ventilation', 'hemodynamics', 'neurologicRisk', 'bleeding', 'circuitSupport'];

function normalizeLevel(value) {
  if (typeof value === 'number') return Math.max(0, Math.min(3, Math.round(value)));
  if (value == null) return 0;
  if (!(value in TRAJECTORY_LEVELS)) throw new Error(`Unsupported trajectory level "${value}".`);
  return TRAJECTORY_LEVELS[value];
}

function maxSignals(signals = []) {
  const dimensions = Object.fromEntries(DIMENSIONS.map((key) => [key, 0]));
  let arrest = false;
  let catastrophicTerminal = false;
  for (const signal of signals) {
    for (const key of DIMENSIONS) dimensions[key] = Math.max(dimensions[key], normalizeLevel(signal?.dimensions?.[key]));
    arrest ||= Boolean(signal?.arrest);
    catastrophicTerminal ||= Boolean(signal?.catastrophicTerminal);
  }
  return { dimensions, arrest, catastrophicTerminal };
}

function overallLabel(dimensions, arrest, endpoint) {
  if (endpoint?.type === 'death') return 'terminal';
  if (arrest) return 'arrest';
  const max = Math.max(...Object.values(dimensions));
  if (max >= 3) return 'collapse';
  if (max >= 2) return 'critical';
  if (max >= 1) return 'deteriorating';
  return 'stable';
}

export function createClinicalTrajectoryEngine({ profile = {}, snapshot = null } = {}) {
  const config = { ...DEFAULT_ENDPOINT_PROFILE, ...profile };
  const state = snapshot ? clone(snapshot) : {
    lastAtSec: 0,
    criticalExposureSec: 0,
    arrestExposureSec: 0,
    stableSinceSec: null,
    encounteredInstability: false,
    endpoint: null,
    last: { dimensions: Object.fromEntries(DIMENSIONS.map((key) => [key, 0])), label: 'stable', arrest: false }
  };

  function evaluate({ timeSec = 0, signals = [], unresolvedEventCount = 0, started = false, forceEndpoint = null } = {}) {
    const now = Number(timeSec);
    const elapsed = Math.max(0, now - Number(state.lastAtSec ?? now));
    state.lastAtSec = now;
    if (state.endpoint) return clone(state.endpoint);

    if (forceEndpoint) {
      state.endpoint = { type: forceEndpoint.type, reason: forceEndpoint.reason ?? 'manual', atSec: now };
      return clone(state.endpoint);
    }

    const aggregate = maxSignals(signals);
    const maxSeverity = Math.max(...Object.values(aggregate.dimensions));
    if (maxSeverity > 0 || aggregate.arrest || Number(unresolvedEventCount) > 0) state.encounteredInstability = true;
    if (maxSeverity >= 2) state.criticalExposureSec += elapsed;
    if (aggregate.arrest) state.arrestExposureSec += elapsed;
    else state.arrestExposureSec = 0;

    const stableNow = started && Number(unresolvedEventCount) === 0 && maxSeverity === 0 && !aggregate.arrest;
    if (stableNow) {
      if (state.stableSinceSec == null) state.stableSinceSec = now;
    } else {
      state.stableSinceSec = null;
    }

    if (aggregate.catastrophicTerminal) {
      state.endpoint = { type: 'death', reason: 'catastrophic-terminal-condition', atSec: now };
    } else if (aggregate.arrest && state.arrestExposureSec >= Number(config.arrestRescueWindowSec)) {
      state.endpoint = { type: 'death', reason: 'unresolved-arrest-beyond-rescue-window', atSec: now };
    } else if (state.criticalExposureSec >= Number(config.cumulativeCriticalExposureSec)) {
      state.endpoint = { type: 'death', reason: 'cumulative-critical-deterioration', atSec: now };
    } else if (stableNow && state.stableSinceSec != null && now - state.stableSinceSec >= Number(config.stabilizationWindowSec)) {
      const permitted = !config.requireEncounteredInstabilityForAutoStabilization || state.encounteredInstability;
      if (permitted) state.endpoint = { type: 'stabilized', reason: 'sustained-clinical-stability', atSec: now };
    }

    state.last = {
      dimensions: clone(aggregate.dimensions),
      arrest: aggregate.arrest,
      label: overallLabel(aggregate.dimensions, aggregate.arrest, state.endpoint)
    };
    return clone(state.endpoint);
  }

  function instructorPresentation() {
    return { config: clone(config), ...clone(state) };
  }

  return {
    evaluate,
    presentation: () => ({ label: state.last.label, endpoint: clone(state.endpoint) }),
    instructorPresentation,
    snapshot: () => clone(state)
  };
}
