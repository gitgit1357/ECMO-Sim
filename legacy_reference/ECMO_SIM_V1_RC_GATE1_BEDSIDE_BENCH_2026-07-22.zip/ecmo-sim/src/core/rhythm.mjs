// Rhythm is scenario/physiology-driven, never player-driven — there is
// deliberately no "set rhythm" action anywhere in circuit-sandbox.mjs.
// This module is the answer to "what should change it, and to what."
//
// The monitor is the only information a learner has once a scenario
// starts, and rhythm is one of the biggest signals on it — so rhythm
// escalation is driven by TWO independent pathways, and either can push
// it forward:
//   1. The original hypoxia/no-flow timers below (direct circuit signals).
//   2. The overall clinical trajectory (clinical-trajectory.mjs) — the
//      same system that decides whether the patient is stabilizing or
//      dying. Any case heading toward "critical"/"arrest"/"death" must
//      show that on the monitor, regardless of which complication is
//      actually driving it. Before this, only hypoxia/no-flow triggered
//      rhythm changes, so a patient could reach a "death" trajectory
//      endpoint while the ECG still calmly read sinus. That's fixed here.
//
// This is still a placeholder rule set standing in for real
// scenario-authored triggers. Escalation never auto-reverts on its own —
// that's the job of the rescue actions (resolveRhythmRescueAction).

export const RHYTHM_ORDER = Object.freeze(['sinus', 'junctional', 'vtach', 'vfib', 'asystole']);

export const RHYTHM_LABELS = Object.freeze({
  sinus: 'Sinus',
  junctional: 'Junctional (JET)',
  vtach: 'V-Tach',
  vfib: 'V-Fib',
  asystole: 'Asystole'
});

export const DEFAULT_RHYTHM_THRESHOLDS = Object.freeze({
  hypoxiaSpo2Ceiling: 60,        // SpO2 below this counts as "hypoxic" for the timer
  hypoxiaToJunctionalSec: 60,
  hypoxiaToVtachSec: 150,
  hypoxiaToVfibSec: 300,
  noFlowFloorLpm: 0.05,          // measured flow below this counts as "no flow" for the timer
  noFlowToVtachSec: 20,
  noFlowToVfibSec: 45,
  // Trajectory-driven thresholds — same shape as the hypoxia ones, but
  // keyed off clinical-trajectory.mjs's own severity label rather than a
  // single circuit signal, so ANY cause of sustained critical instability
  // (not just hypoxia or lost flow) eventually shows up on the monitor.
  criticalTrajectoryToJunctionalSec: 60,
  criticalTrajectoryToVtachSec: 150,
  criticalTrajectoryToVfibSec: 300
});

/**
 * Given the current rhythm and how long the tracked conditions have been
 * running, decide whether the scenario should escalate the rhythm.
 * Returns { rhythm, reason } if it should change, or null if not —
 * never de-escalates.
 *
 * New params beyond the original hypoxia/no-flow ones:
 *   criticalTrajectorySeconds — how long clinical-trajectory.mjs's own
 *     severity label has read 'critical' or worse, regardless of cause.
 *   arrestActive — clinical-trajectory's arrest flag (true during its own
 *     tracked arrest-exposure window). Forces at least vfib immediately.
 *   endpointType — clinical-trajectory's endpoint.type once the scenario
 *     has ended. 'death' forces asystole — a dying patient must show a
 *     terminal rhythm, not a calm one.
 */
export function resolveRhythmEscalation({
  rhythm, hypoxiaSeconds, noFlowSeconds, criticalTrajectorySeconds = 0, arrestActive = false, endpointType = null,
  thresholds = DEFAULT_RHYTHM_THRESHOLDS
}) {
  const currentIndex = RHYTHM_ORDER.indexOf(rhythm);
  let targetIndex = currentIndex;
  let reason = null;

  if (hypoxiaSeconds >= thresholds.hypoxiaToJunctionalSec && RHYTHM_ORDER.indexOf('junctional') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('junctional');
    reason = 'sustained hypoxia';
  }
  if (hypoxiaSeconds >= thresholds.hypoxiaToVtachSec && RHYTHM_ORDER.indexOf('vtach') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vtach');
    reason = 'sustained hypoxia';
  }
  if (hypoxiaSeconds >= thresholds.hypoxiaToVfibSec && RHYTHM_ORDER.indexOf('vfib') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vfib');
    reason = 'prolonged critical hypoxia';
  }
  if (noFlowSeconds >= thresholds.noFlowToVtachSec && RHYTHM_ORDER.indexOf('vtach') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vtach');
    reason = 'loss of circuit flow';
  }
  if (noFlowSeconds >= thresholds.noFlowToVfibSec && RHYTHM_ORDER.indexOf('vfib') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vfib');
    reason = 'loss of circuit flow';
  }
  if (criticalTrajectorySeconds >= thresholds.criticalTrajectoryToJunctionalSec && RHYTHM_ORDER.indexOf('junctional') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('junctional');
    reason = 'sustained critical instability';
  }
  if (criticalTrajectorySeconds >= thresholds.criticalTrajectoryToVtachSec && RHYTHM_ORDER.indexOf('vtach') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vtach');
    reason = 'sustained critical instability';
  }
  if (criticalTrajectorySeconds >= thresholds.criticalTrajectoryToVfibSec && RHYTHM_ORDER.indexOf('vfib') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vfib');
    reason = 'prolonged critical instability';
  }
  if (arrestActive && RHYTHM_ORDER.indexOf('vfib') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('vfib');
    reason = 'cardiac arrest';
  }
  if (endpointType === 'death' && RHYTHM_ORDER.indexOf('asystole') > targetIndex) {
    targetIndex = RHYTHM_ORDER.indexOf('asystole');
    reason = 'irreversible deterioration';
  }

  if (targetIndex <= currentIndex) return null;
  return { rhythm: RHYTHM_ORDER[targetIndex], reason };
}

// --- Rescue actions -----------------------------------------------------
//
// PLACEHOLDER CLINICAL LOGIC — same caveat as every coefficient in
// physiology.mjs. Which action is "preferred" vs "harmful" for a given
// rhythm, and the chest-compressions-vs-ECMO-flow branching below, are my
// best understanding, not something you've validated against your own
// practice. Correct before trusting this for training.
//
// One deliberate simplification: every "successful conversion" targets
// 'sinus' directly, never an intermediate rhythm. Real conversions can
// land somewhere else depending on the underlying pathology; this keeps
// the mechanic simple for a first pass.
//
// One deliberate NON-bug: converting a rhythm does not reset
// hypoxiaSeconds/noFlowSeconds. If the underlying driver (hypoxia, lost
// flow) is still present on the next tick, resolveRhythmEscalation will
// re-escalate from scratch — possibly immediately back to the same
// rhythm. That's intentional: shocking a rhythm without addressing the
// reversible cause is a real and important way for a rescue to "fail."
// The feedback strings below say so explicitly, so it doesn't just look
// like a broken revert.
export const RHYTHM_RESCUE_ACTIONS = Object.freeze({
  'assess-rhythm': {
    label: 'Assess cardiac rhythm',
    resolve: (rhythm) => ({
      outcome: 'acceptable', nextRhythm: rhythm, scoreDelta: 2,
      feedback: `Rhythm assessed: ${RHYTHM_LABELS[rhythm] ?? rhythm}.`
    })
  },
  defibrillate: {
    label: 'Defibrillate (unsynchronized shock)',
    resolve: (rhythm) => {
      if (rhythm === 'vfib') {
        return {
          outcome: 'preferred', nextRhythm: 'sinus', scoreDelta: 20,
          feedback: 'Defibrillation terminates ventricular fibrillation; an organized rhythm returns. If the underlying cause (hypoxia, lost circuit flow) is not corrected, it may recur.'
        };
      }
      if (rhythm === 'vtach') {
        return {
          outcome: 'acceptable', nextRhythm: 'sinus', scoreDelta: 10,
          feedback: 'Unsynchronized defibrillation terminates the ventricular tachycardia. Synchronized cardioversion would have been the more refined choice for an organized wide-complex rhythm.'
        };
      }
      return {
        outcome: 'harmful', nextRhythm: rhythm, scoreDelta: -15,
        feedback: `Defibrillation is not indicated for ${RHYTHM_LABELS[rhythm] ?? rhythm} and risks provoking a dangerous rhythm in an organized, perfusing heart.`
      };
    }
  },
  'synchronized-cardioversion': {
    label: 'Synchronized cardioversion',
    resolve: (rhythm) => {
      if (rhythm === 'vtach') {
        return {
          outcome: 'preferred', nextRhythm: 'sinus', scoreDelta: 20,
          feedback: 'Synchronized cardioversion terminates the ventricular tachycardia. If the underlying cause is not corrected, it may recur.'
        };
      }
      if (rhythm === 'vfib') {
        return {
          outcome: 'ineffective', nextRhythm: rhythm, scoreDelta: -5,
          feedback: 'Synchronized cardioversion needs an organized QRS to synchronize to and will not deliver a shock in ventricular fibrillation.'
        };
      }
      return {
        outcome: 'harmful', nextRhythm: rhythm, scoreDelta: -15,
        feedback: `Cardioversion is not indicated for ${RHYTHM_LABELS[rhythm] ?? rhythm}.`
      };
    }
  },
  'administer-arrest-epinephrine': {
    label: 'Administer arrest-dose epinephrine',
    resolve: (rhythm) => {
      if (rhythm === 'asystole') {
        return {
          outcome: 'preferred', nextRhythm: 'junctional', scoreDelta: 18,
          feedback: 'Epinephrine is the primary treatment for asystole (a non-shockable rhythm) — organized electrical activity returns. Continued reassessment and support are still needed.'
        };
      }
      if (rhythm === 'vtach' || rhythm === 'vfib') {
        return {
          outcome: 'acceptable', nextRhythm: rhythm, scoreDelta: 6,
          feedback: 'Arrest-dose epinephrine is given per resuscitation algorithm. It does not by itself terminate the arrhythmia — pair it with defibrillation/cardioversion.'
        };
      }
      return {
        outcome: 'ineffective', nextRhythm: rhythm, scoreDelta: -5,
        feedback: 'Arrest-dose epinephrine is not indicated outside of arrest / shockable-rhythm management.'
      };
    }
  },
  'begin-chest-compressions': {
    label: 'Begin chest compressions',
    resolve: (rhythm, context = {}) => {
      const flowAdequate = context.circuitFlowAdequate !== false;
      if (!flowAdequate) {
        return {
          outcome: 'preferred', nextRhythm: rhythm, scoreDelta: 15,
          feedback: 'ECMO flow is inadequate or absent, so the circuit is not currently providing circulatory support — chest compressions are indicated until flow is restored.'
        };
      }
      if (rhythm === 'vtach' || rhythm === 'vfib') {
        return {
          outcome: 'ineffective', nextRhythm: rhythm, scoreDelta: -5,
          feedback: 'ECMO flow is currently adequate — the circuit is already providing circulatory support, so chest compressions are not required for perfusion here.'
        };
      }
      return {
        outcome: 'harmful', nextRhythm: rhythm, scoreDelta: -10,
        feedback: 'Chest compressions are not indicated for a perfusing rhythm with adequate ECMO support.'
      };
    }
  }
});

/**
 * Resolve a rhythm-rescue action against the current rhythm. Returns null
 * if actionId isn't a recognized rescue action at all (so a caller can
 * fall through to other action handling), or
 * { outcome, nextRhythm, scoreDelta, feedback } if it is.
 * context.circuitFlowAdequate lets the caller pass in whether the ECMO
 * circuit is currently delivering adequate flow — chest compressions is
 * the one action whose correctness depends on that, not on rhythm alone.
 */
export function resolveRhythmRescueAction(actionId, rhythm, context = {}) {
  const action = RHYTHM_RESCUE_ACTIONS[actionId];
  if (!action) return null;
  return action.resolve(rhythm, context);
}

