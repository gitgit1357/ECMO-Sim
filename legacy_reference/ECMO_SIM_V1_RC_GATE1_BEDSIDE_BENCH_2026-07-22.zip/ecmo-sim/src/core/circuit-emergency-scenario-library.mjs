import { buildScenarioFromSetup } from './scenario-builder.mjs';

function clone(v){ return JSON.parse(JSON.stringify(v)); }

const BASE_SETUP = Object.freeze({
  patient:{population:'pediatric',age:'2 years',weightKg:12,diagnosis:'Severe cardiopulmonary failure requiring ECMO',procedure:'ECMO support',postOpDay:0},
  ecmo:{mode:'VA',cannulation:'peripheral',cannulaFr:15,pumpRpm:2800,sweepGasLpm:2.5,fdo2Percent:100,circuitAgeHours:72},
  startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'none',renalFunction:'normal',neurologicStatus:'sedated'},
  education:{primaryObjective:'circuit-emergency-pack',concepts:[],mode:'guided',difficulty:'intermediate'}
});

export const CIRCUIT_EMERGENCY_PRESETS = Object.freeze([
  {
    id:'ce-01-air-emergency', learnerLabel:'Circuit Emergency 01', educatorLabel:'Air entrainment / circuit air emergency', complicationId:'air-emergency',
    briefing:'You are assuming care of a patient on ECMO with previously stable support. Review the handoff, start the scenario, and respond to any acute circuit emergency.',
    recentEvents:[
      {minutesBeforeStart:20,text:'ECMO support was documented near the established baseline.'},
      {minutesBeforeStart:4,text:'The bedside team noted a sudden circuit/support abnormality requiring immediate reassessment.'},
      {minutesBeforeStart:0,text:'You assume care.'}
    ]
  },
  {
    id:'ce-02-circuit-breach', learnerLabel:'Circuit Emergency 02', educatorLabel:'Circuit breach / disconnection with major blood loss', complicationId:'circuit-breach-hemorrhage',
    briefing:'You are assuming care of a patient on ECMO with previously stable support. Review the handoff, start the scenario, and respond to any acute circuit emergency.',
    recentEvents:[
      {minutesBeforeStart:10,text:'Circuit flows and hemodynamics were documented near the established bedside baseline.'},
      {minutesBeforeStart:1,text:'An abrupt loss of effective support with visible blood loss from the extracorporeal circuit was reported.'},
      {minutesBeforeStart:0,text:'You assume care during the emergency response.'}
    ]
  },
  {
    id:'ce-03-oxygenator', learnerLabel:'Circuit Emergency 03', educatorLabel:'Oxygenator thrombosis / membrane-lung failure', complicationId:'oxygenator-thrombosis-failure',
    briefing:'You are assuming care of a patient on ECMO with a circuit that has been in service for several days. Review the bedside data and respond to clinically significant changes in circuit performance or gas exchange.',
    recentEvents:[
      {minutesBeforeStart:180,text:'ECMO support documented as clinically adequate on the prior shift.'},
      {minutesBeforeStart:90,text:'Bedside team noted increasing concern for circuit performance; no definitive diagnosis was established.'},
      {minutesBeforeStart:20,text:'Gas exchange became less satisfactory despite unchanged overall support goals.'},
      {minutesBeforeStart:0,text:'You assume care.'}
    ]
  },
  {
    id:'ce-04-sweep-gas', learnerLabel:'Circuit Emergency 04', educatorLabel:'Sweep gas / gas-source failure', complicationId:'sweep-gas-failure',
    briefing:'You are assuming care of a patient on ECMO with previously stable extracorporeal gas exchange. Review the bedside data and troubleshoot any acute deterioration.',
    recentEvents:[
      {minutesBeforeStart:60,text:'Ventilation and extracorporeal gas exchange were documented as adequate.'},
      {minutesBeforeStart:10,text:'A rising CO2 trend developed without a major change in pump flow.'},
      {minutesBeforeStart:0,text:'You assume care before the cause has been established.'}
    ]
  },
  {
    id:'ce-05-hemolysis', learnerLabel:'Circuit Emergency 05', educatorLabel:'Clinically significant hemolysis', complicationId:'hemolysis',
    briefing:'You are assuming care of a patient on ECMO. Review the available patient and circuit information and investigate any clinically significant evidence of circuit-related blood trauma.',
    recentEvents:[
      {minutesBeforeStart:180,text:'Hemoglobin and circuit support were previously near the established bedside baseline.'},
      {minutesBeforeStart:45,text:'Darkening urine and a new laboratory concern for blood-cell injury were reported.'},
      {minutesBeforeStart:0,text:'You assume care while the source remains undetermined.'}
    ]
  },
  {
    id:'ce-06-major-bleeding', learnerLabel:'Circuit Emergency 06', educatorLabel:'Major bleeding / coagulopathic hemorrhage', complicationId:'major-bleeding',
    briefing:'You are assuming care of a patient on ECMO. Review the handoff and respond to any major bleeding emergency while maintaining safe extracorporeal support.',
    recentEvents:[
      {minutesBeforeStart:30,text:'Hemodynamics were near the established bedside baseline.'},
      {minutesBeforeStart:6,text:'New clinically significant bleeding with worsening hemodynamics was reported.'},
      {minutesBeforeStart:0,text:'You assume care during active reassessment and resuscitation.'}
    ]
  }
]);

function mergeSetup(base, patch={}){
  return {
    ...clone(base), ...clone(patch),
    patient:{...clone(base.patient),...clone(patch.patient ?? {})},
    ecmo:{...clone(base.ecmo),...clone(patch.ecmo ?? {})},
    startingCondition:{...clone(base.startingCondition),...clone(patch.startingCondition ?? {})},
    education:{...clone(base.education),...clone(patch.education ?? {})}
  };
}

function applyPlan(scenario,preset){
  scenario.learningPlan.primaryObjective='circuit-emergency-pack';scenario.learningPlan.concepts=['circuit-emergency-pack'];
  scenario.clinicalKnowledgePlan.requiredComplicationIds=[preset.complicationId];
  scenario.clinicalKnowledgePlan.allowedComplicationIds=[preset.complicationId];
  scenario.clinicalKnowledgePlan.triggerPolicies=[{
    id:`preset-${preset.id}`, complicationId:preset.complicationId, type:'at-start', source:'circuit-emergency-scenario-library'
  }];
  scenario.learnerBriefing={caseLabel:preset.learnerLabel,text:preset.briefing};
  scenario.handoff={
    summary:'The patient has been receiving ECMO support with a previously established bedside baseline. Review recent events and the live patient/circuit data before acting.',
    currentConcern:'A new clinically significant change may be developing. The cause has not been established.'
  };
  scenario.recentEvents=clone(preset.recentEvents ?? []);
  scenario.learnerObjectives=[
    'Recognize a clinically significant ECMO circuit emergency promptly.',
    'Use patient, circuit, pressure, gas-exchange, and recent-event evidence to distinguish the likely failure mechanism.',
    'Choose immediate stabilizing actions when required, then perform cause-directed definitive management.',
    'Reassess patient and circuit response to verify that effective ECMO support has been restored or preserved.'
  ];
  scenario.lifecycle={version:1,completionRule:'clinical-endpoint',successEndpointTypes:['stabilized'],failureEndpointTypes:['death'],allowInstructorTermination:true};
  scenario.educatorScenarioMetadata={presetId:preset.id,educatorLabel:preset.educatorLabel,intendedComplicationId:preset.complicationId,milestone:'M3'};
  return scenario;
}

export function listCircuitEmergencyScenarios({audience='educator'}={}){
  return CIRCUIT_EMERGENCY_PRESETS.map((p,index)=>audience==='learner'
    ? {caseKey:`circuit-${String(index+1).padStart(2,'0')}`,label:p.learnerLabel,briefing:p.briefing}
    : {id:p.id,label:p.educatorLabel,learnerLabel:p.learnerLabel,complicationId:p.complicationId});
}

export function buildCircuitEmergencyScenario(presetId,overrides={}){
  const preset=CIRCUIT_EMERGENCY_PRESETS.find(x=>x.id===presetId);
  if(!preset) throw new Error(`Unknown circuit-emergency preset "${presetId}".`);
  const setup=mergeSetup(BASE_SETUP,overrides.setup ?? {});
  setup.education.mode=overrides.mode ?? setup.education.mode;
  setup.education.difficulty=overrides.difficulty ?? setup.education.difficulty;
  const scenario=buildScenarioFromSetup(setup,{id:overrides.id ?? `circuit-emergency-${preset.id}`});
  return applyPlan(scenario,preset);
}
