// Physiology core for the ECMO circuit sandbox.
//
// GOVERNING RULE (Frank's spec): the model is split into two channels.
//
//   MONITORED  — has a bedside sensor/waveform. Recalculated every tick,
//                visible the instant settings/meds change. HR, arterial
//                line MAP, pulse-ox SpO2, CVP, pump flow/RPM, circuit
//                pressures, temp.
//
//   LATENT     — true in the model at all times, but only *revealed* to
//                the trainee through an ordered lab, after a turnaround
//                delay, UNLESS a continuous surrogate monitor is present
//                (transcutaneous CO2, continuous SvO2 catheter, NIRS),
//                in which case that one variable moves into the
//                monitored channel for that scenario.
//
// This file only computes numbers. It has no idea what a "session",
// "lab order", or "scenario" is — that's circuit-sandbox.mjs and
// lab-queue.mjs. Keeping this pure makes it independently testable and
// makes it the single place to correct coefficients against real
// ELSO/institutional behavior.
//
// EVERY COEFFICIENT BELOW IS AN ILLUSTRATIVE PLACEHOLDER, not a
// validated clinical model. Tune DEFAULT_COEFFICIENTS before trusting
// this for training.

export const DEFAULT_COEFFICIENTS = Object.freeze({
  // Hemodynamics — flow is WEIGHT-INDEXED (mL/kg/min), not raw L/min,
  // since this is a pediatric/neonatal shop and that's how flow is
  // actually dosed and thought about at the bedside.
  mapPerMlKgMinFlowIndex: 0.4,  // mmHg of MAP gained per mL/kg/min of indexed ECMO flow, above baseline
  mapPerMcgKgMinEpi: 6,         // mmHg of MAP gained per mcg/kg/min epinephrine steady-state
  hrPerMcgKgMinEpi: 18,         // bpm gained per mcg/kg/min epinephrine steady-state
  mapPerMcgKgMinNorepi: 5,
  mapPerMlKgVolumeBolus: 0.4,   // mmHg per mL/kg crystalloid/blood bolus (transient, decays)
  cvpPerMlKgVolumeBolus: 0.06,

  // Gas exchange (VA/VV agnostic simplification)
  paco2BaselineMmHg: 40,
  paco2DropPerLpmSweepAboveBaseline: 6, // mmHg PaCO2 drop per L/min sweep above the baseline sweep
  baselineSweepLpm: 2,
  pao2BaselineMmHg: 90,
  pao2GainPerFdo2Percent: 3.2, // mmHg PaO2 gained per % FdO2 above 21
  spo2SaturationKneeMmHg: 90,  // above this PaO2, SpO2 plateaus near 100 (oxyhemoglobin curve shape)

  // Drift / decay
  epiEffectRiseHalfLifeSec: 60,   // time constant for drip effect to reach steady state
  bolusDecayHalfLifeSec: 300,     // volume bolus hemodynamic bump decays over ~5 min

  // Anticoagulation — bivalirudin, dosed mg/kg/hr, monitored by DTT
  // (dilute thrombin time, reported mcg/mL free bivalirudin). Goal
  // 0.5-1 mcg/mL routinely, 0.2-0.5 mcg/mL if bleeding — that's scenario/
  // case data, not a model coefficient, so it isn't baked in here.
  dttBaselineMcgMl: 0,               // undetectable off drug
  dttPerMgKgHrBivalirudin: 1.74,      // calibrated from a real neonatal data point: 0.31 mg/kg/hr -> DTT 0.54 mcg/mL (0.54/0.31). One data point only — get a second at a different dose to confirm this is linear across your working range, not just anchored at this one.

  // Circuit flow — the player sets RPM, not flow. Flow is a saturating
  // function of RPM toward a cannula-limited ceiling (diminishing
  // returns), plus a preload penalty when CVP runs low (venous line
  // "chatter"/suck-down). This is a simplified stand-in for the real
  // pump-curve-vs-resistance-line intersection — see deriveFlow() docs.
  maxFlowPerCannulaFr: 0.09,     // L/min of ceiling flow per Fr of cannula size — ILLUSTRATIVE
  flowRpmScale: 1300,            // how quickly flow approaches its ceiling as RPM rises
  preloadPenaltyFloorCvp: 6,     // below this CVP, achievable flow starts getting clipped
  preloadPenaltyPerCvpDeficit: 0.05, // fractional flow loss per mmHg of CVP below the floor
  chatterCvpThreshold: 3,        // below this CVP, flag venous-line chatter

  // Circuit pressures — all ILLUSTRATIVE, not calibrated.
  venousPressureBaselineMmHg: 20,
  venousPressurePerLpmFlow: 25,
  preOxyPressurePerLpmFlow: 60,
  deltaPBaselineMmHg: 15,
  deltaPPerLpmFlow: 10
});

// Two starting points for the population-dependent numbers you flagged —
// mainly flow indexing and baseline hemodynamics. Merge one of these into
// DEFAULT_COEFFICIENTS (or a scenario's coefficientOverrides) rather than
// hand-editing DEFAULT_COEFFICIENTS itself.
export const POPULATION_PRESETS = Object.freeze({
  neonatal: Object.freeze({
    fullSupportFlowIndexMlKgMin: 125,  // ~100-150 mL/kg/min per your range
    mapPerMlKgMinFlowIndex: 0.32       // tuned so ~125 mL/kg/min indexed flow reaches full-support MAP from a cannulated-but-off baseline
  }),
  pediatric: Object.freeze({
    fullSupportFlowIndexMlKgMin: 100,  // ~80-120 mL/kg/min per your range
    mapPerMlKgMinFlowIndex: 0.4
  })
});

function clamp(value, min, max) {
  return Math.max(min, Math.min(max, value));
}

// First-order approach toward a steady-state target — used so drips
// don't snap instantly to their final effect, but do move fast enough
// that "immediate" monitored changes still read as immediate within a
// tick or two (consistent with real pressor kinetics being seconds-
// to-low-minutes, not the multi-minute-to-hour lab turnaround delay).
function approachSteadyState(current, target, elapsedSec, halfLifeSec) {
  if (halfLifeSec <= 0) return target;
  const factor = 1 - Math.pow(0.5, elapsedSec / halfLifeSec);
  return current + (target - current) * factor;
}

/**
 * Compute the instantaneous MONITORED vitals from current settings and
 * running internal drug/volume state. Called every tick — this is the
 * "immediate" channel.
 */
/**
 * The player dials in RPM, not flow. Flow is what actually results — a
 * centrifugal pump's real behavior is a pump curve (pressure ~ RPM^2)
 * intersected with a resistance line dominated by cannula size. This is
 * a simplified stand-in for that: flow rises with RPM but saturates
 * toward a cannula-limited ceiling — diminishing returns, same shape as
 * the real relationship, without solving the full two-curve system.
 */
export function deriveFlow(rpm, cannulaFr, cvp, coeffs = DEFAULT_COEFFICIENTS) {
  const maxFlowForCannula = cannulaFr * coeffs.maxFlowPerCannulaFr;
  const base = maxFlowForCannula * (1 - Math.exp(-rpm / coeffs.flowRpmScale));
  const preloadPenalty = cvp < coeffs.preloadPenaltyFloorCvp
    ? (coeffs.preloadPenaltyFloorCvp - cvp) * coeffs.preloadPenaltyPerCvpDeficit
    : 0;
  const chatter = cvp < coeffs.chatterCvpThreshold;
  const flowLpm = Math.max(0, base * (1 - preloadPenalty));
  return { flowLpm, maxFlowForCannula, chatter };
}

export function deriveMonitoredVitals({ settings, internal, coeffs = DEFAULT_COEFFICIENTS }) {
  const epi = settings.epiMcgKgMin ?? 0;
  const norepi = settings.norepiMcgKgMin ?? 0;
  const cvpNow = clamp(internal.cvpBaseline + internal.volumeBolusCvpBump, 0, 30);
  const derivedFlow = deriveFlow(settings.pumpRpm ?? 0, internal.cannulaFr, cvpNow, coeffs);
  // Contextual support-flow multiplier is a discrete clinical-state modifier
  // (e.g. severe position-dependent drainage compromise), not a physiology equation.
  // Defaults to 1 so legacy scenarios are unchanged.
  const supportFlowMultiplier = Math.max(0, Math.min(1, Number(internal.supportFlowMultiplier ?? 1)));
  const flowLpm = derivedFlow.flowLpm * supportFlowMultiplier;
  const maxFlowForCannula = derivedFlow.maxFlowForCannula;
  const chatter = derivedFlow.chatter || supportFlowMultiplier < 0.5;
  const flowIndexMlKgMin = (flowLpm * 1000) / internal.weightKg;

  // `hrBaseline` and `mapBaseline` are actual bedside baselines, not a
  // cannulated-but-off theoretical baseline. Clinical support consequences
  // are applied as contextual modifiers by the consequence engine.
  const hrTarget = internal.hrBaseline
    + Number(internal.supportHrModifier ?? 0)
    + epi * coeffs.hrPerMcgKgMinEpi;
  const mapTarget = internal.mapBaseline
    + Number(internal.supportMapModifier ?? 0)
    + epi * coeffs.mapPerMcgKgMinEpi
    + norepi * coeffs.mapPerMcgKgMinNorepi
    + internal.volumeBolusMapBump;

  return {
    hr: Math.round(clamp(internal.hrCurrent ?? hrTarget, 30, 220)),
    map: Math.round(clamp(internal.mapCurrent ?? mapTarget, 20, 160)),
    cvp: Math.round(cvpNow),
    spo2: Math.round(clamp(spo2FromPaO2(internal.trueLatent.pao2, coeffs), 40, 100)),
    pumpRpm: settings.pumpRpm ?? 0,
    flowLpm,
    flowIndexMlKgMin: Math.round(flowIndexMlKgMin),
    maxFlowForCannula,
    chatter,
    tempC: settings.heaterTempC ?? 37,
    _hrTarget: hrTarget,
    _mapTarget: mapTarget
  };
}

function spo2FromPaO2(pao2, coeffs) {
  if (pao2 >= coeffs.spo2SaturationKneeMmHg) return 100 - Math.max(0, (100 - 97) * Math.exp(-(pao2 - coeffs.spo2SaturationKneeMmHg) / 40));
  // Steep part of the oxyhemoglobin dissociation curve below the knee.
  return 40 + (pao2 / coeffs.spo2SaturationKneeMmHg) * 55;
}

/**
 * Compute the TRUE latent values (what a lab drawn right now would
 * show), independent of whether anything is monitoring them. This is
 * called both when a lab is ordered (to snapshot the value at draw
 * time) and, if a surrogate monitor is equipped, every tick.
 */
export function deriveTrueLatent({ settings, internal, coeffs = DEFAULT_COEFFICIENTS }) {
  const sweepLpm = settings.sweepGasLpm ?? coeffs.baselineSweepLpm;
  const fdo2Percent = settings.fdo2Percent ?? 21;

  const genericPaco2 = clamp(
    coeffs.paco2BaselineMmHg - (sweepLpm - coeffs.baselineSweepLpm) * coeffs.paco2DropPerLpmSweepAboveBaseline,
    15, 100
  );
  const genericPao2 = clamp(
    coeffs.pao2BaselineMmHg + (fdo2Percent - 21) * coeffs.pao2GainPerFdo2Percent,
    30, 550
  );
  // A clinical consequence, or an active clinical-events complication, may
  // make gas exchange abnormal independent of settings (e.g. oxygenator
  // failure, sweep-gas failure). These targets are categorical/contextual
  // overrides, not gas-exchange equations — and they are the ONLY way a
  // complication's effect on PaO2/PaCO2 persists past the first tick;
  // writing directly to internal.trueLatent.pao2/paco2 does nothing; both
  // are recomputed fresh from settings every tick unless overridden here.
  // Two independent systems can each have a reason for PaO2 to be
  // abnormal: a clinical-events complication (clinicalPao2Target, e.g.
  // oxygenator failure) and the support-consequence engine
  // (consequencePao2Target, flow/MAP-driven hypoxemia). Neither should
  // silently overwrite the other — take whichever is worse (lower).
  const pao2Overrides = [internal.clinicalPao2Target, internal.consequencePao2Target].filter((v) => v != null);
  const pao2 = pao2Overrides.length
    ? clamp(Math.min(...pao2Overrides.map(Number)), 30, 550)
    : genericPao2;
  const paco2 = internal.clinicalPaco2Target != null
    ? clamp(Number(internal.clinicalPaco2Target), 15, 150)
    : genericPaco2;
  const dttMcgMl = clamp(
    coeffs.dttBaselineMcgMl + (settings.bivalirudinMgKgHr ?? 0) * coeffs.dttPerMgKgHrBivalirudin,
    0, 3
  );

  return {
    pao2,
    paco2,
    ph: clamp(7.4 - (paco2 - 40) * 0.008, 6.9, 7.7),
    lactateMmolL: internal.trueLatent.lactateMmolL,   // slow-moving; adjusted by dedicated events, not derived per tick
    hgbGdl: internal.trueLatent.hgbGdl,
    dttMcgMl,
    // Pass-through, not derived: no dose-response data yet linking anything
    // settable to HepPTT/TEG r-time/ATIII. These only change via scripted
    // scenario events until that data exists — see anticoagulation-protocol.json
    // for the goal bands they get checked against.
    hepPttSec: internal.trueLatent.hepPttSec,
    tegRTimeMin: internal.trueLatent.tegRTimeMin,
    atiiiPercent: internal.trueLatent.atiiiPercent
  };
}

/**
 * Circuit pressures at the three points clinicians actually watch
 * (venous/pre-pump, pre-oxygenator, post-oxygenator/arterial) plus the
 * oxygenator's ΔP. ILLUSTRATIVE magnitudes — right clinical ballpark,
 * not calibrated. When the bubble detector alarms, flow and all three
 * pressures collapse toward zero, same as a real console's safety
 * interlock.
 */
export function deriveCircuitMechanics(flowLpm, bubbleAlarm, timeSec, coeffs = DEFAULT_COEFFICIENTS, internal = {}) {
  if (bubbleAlarm) {
    return { measuredFlowLpm: 0, venousPressure: 0, preOxyPressure: 0, postOxyPressure: 0, deltaP: 0 };
  }
  const wiggle = 0.015 * Math.sin(timeSec * 0.7); // small deterministic jitter, stands in for flow-probe noise
  const measuredFlowLpm = Math.max(0, flowLpm + wiggle);
  const venousPressure = Math.round(-(coeffs.venousPressureBaselineMmHg + measuredFlowLpm * coeffs.venousPressurePerLpmFlow));
  const preOxyPressure = Math.round(-venousPressure + measuredFlowLpm * coeffs.preOxyPressurePerLpmFlow);
  const oxygenatorDeltaPAddMmHg = Number(internal?.oxygenatorDeltaPAddMmHg ?? 0);
  const deltaP = Math.round(coeffs.deltaPBaselineMmHg + measuredFlowLpm * coeffs.deltaPPerLpmFlow + oxygenatorDeltaPAddMmHg);
  const postOxyPressure = preOxyPressure - deltaP;
  return { measuredFlowLpm: Math.round(measuredFlowLpm * 100) / 100, venousPressure, preOxyPressure, postOxyPressure, deltaP };
}

/**
 * Advance the internal (hidden) state by elapsedSec of simulated time.
 * Handles first-order approach of monitored vitals toward their targets
 * and decay of transient volume-bolus effects. Mutates and returns a
 * new internal object (caller owns immutability/cloning).
 */
export function advanceInternal(internal, settings, elapsedSec, coeffs = DEFAULT_COEFFICIENTS) {
  const monitored = deriveMonitoredVitals({ settings, internal: { ...internal, hrCurrent: undefined, mapCurrent: undefined }, coeffs });
  const hrCurrent = approachSteadyState(internal.hrCurrent ?? monitored._hrTarget, monitored._hrTarget, elapsedSec, coeffs.epiEffectRiseHalfLifeSec);
  const mapCurrent = approachSteadyState(internal.mapCurrent ?? monitored._mapTarget, monitored._mapTarget, elapsedSec, coeffs.epiEffectRiseHalfLifeSec);
  const decayFactor = Math.pow(0.5, elapsedSec / coeffs.bolusDecayHalfLifeSec);

  return {
    ...internal,
    hrCurrent,
    mapCurrent,
    volumeBolusMapBump: internal.volumeBolusMapBump * decayFactor,
    volumeBolusCvpBump: internal.volumeBolusCvpBump * decayFactor,
    trueLatent: deriveTrueLatent({ settings, internal, coeffs })
  };
}
