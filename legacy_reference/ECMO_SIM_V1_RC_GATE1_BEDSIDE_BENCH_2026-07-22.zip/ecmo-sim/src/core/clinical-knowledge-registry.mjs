function clone(v) { return JSON.parse(JSON.stringify(v)); }

const VALID_KINDS = new Set(['complication', 'action', 'observation', 'objective']);

export function createClinicalKnowledgeRegistry(entries = []) {
  const byKind = new Map([...VALID_KINDS].map((kind) => [kind, new Map()]));

  for (const entry of entries) {
    if (!entry?.id || !entry?.kind) throw new Error('Knowledge entries require id and kind.');
    if (!VALID_KINDS.has(entry.kind)) throw new Error(`Unsupported knowledge kind "${entry.kind}".`);
    const bucket = byKind.get(entry.kind);
    if (bucket.has(entry.id)) throw new Error(`Duplicate ${entry.kind} id "${entry.id}".`);
    bucket.set(entry.id, clone(entry));
  }

  function get(kind, id) {
    return clone(byKind.get(kind)?.get(id) ?? null);
  }

  function list(kind) {
    if (!VALID_KINDS.has(kind)) throw new Error(`Unsupported knowledge kind "${kind}".`);
    return [...byKind.get(kind).values()].map(clone);
  }

  function resolveObjective(objectiveId, selectedConceptIds = []) {
    const objective = byKind.get('objective').get(objectiveId);
    if (!objective) return { objective: null, concepts: [], complicationIds: [], actionIds: [], observationIds: [], unresolvedConceptIds: [...selectedConceptIds] };

    const conceptMap = objective.concepts ?? {};
    const requested = selectedConceptIds.length ? selectedConceptIds : Object.keys(conceptMap);
    const resolved = requested.flatMap((conceptId) => conceptMap[conceptId] ? [{ id: conceptId, ...conceptMap[conceptId] }] : []);
    const uniq = (values) => [...new Set(values.filter(Boolean))];
    return {
      objective: clone(objective),
      concepts: clone(resolved),
      complicationIds: uniq(resolved.flatMap((c) => c.complicationIds ?? [])),
      actionIds: uniq(resolved.flatMap((c) => c.actionIds ?? [])),
      observationIds: uniq(resolved.flatMap((c) => c.observationIds ?? [])),
      unresolvedConceptIds: requested.filter((id) => !conceptMap[id])
    };
  }

  function compileComplications(complicationIds, { activateIds = [], ecmoMode = null } = {}) {
    const active = new Set(activateIds);
    return complicationIds.map((id) => {
      const entry = byKind.get('complication').get(id);
      if (!entry) throw new Error(`Unknown complication knowledge id "${id}".`);
      const definition = clone(entry.definition);
      const applicability = definition.applicability ?? null;
      if (ecmoMode && Array.isArray(applicability) && applicability.length && !applicability.includes(ecmoMode)) {
        throw new Error(`Complication "${id}" is not applicable to ECMO mode "${ecmoMode}".`);
      }
      if (active.has(id)) definition.activeAtStart = true;
      return definition;
    });
  }

  // Turns a list of actionIds (e.g. scenario.clinicalKnowledgePlan.actionIds,
  // already resolved by resolveObjective) into learner-safe button
  // descriptors: id + label + category only, no complication ids, no
  // rationale, no scoring. Actions whose category is 'ecmo-control' are
  // excluded by default — those (increase-rpm, increase-sweep) are already
  // triggered implicitly by the cockpit's own RPM/sweep controls, not by a
  // separate button, so listing them again would be a duplicate/dead
  // affordance. Unknown ids are skipped rather than throwing, since a
  // scenario built against a future registry version shouldn't crash an
  // older UI.
  function resolveLearnerActionButtons(actionIds = [], { excludeCategories = ['ecmo-control'], hiddenComplicationIds = [] } = {}) {
    const excluded = new Set(excludeCategories);
    const hiddenNeedles = hiddenComplicationIds.map((id) => String(id).toLowerCase()).filter(Boolean);
    const seen = new Set();
    const buttons = [];
    for (const id of actionIds) {
      if (seen.has(id)) continue;
      seen.add(id);
      const entry = byKind.get('action').get(id);
      if (!entry) continue;
      if (excluded.has(entry.category)) continue;
      // Defense in depth: even when a wider differential's action list is
      // passed in (the normal way this stays hidden-safe), never show a
      // button whose own id literally names a hidden complication. This
      // also covers scenarios with no differential to hide within at all.
      if (hiddenNeedles.some((needle) => entry.id.toLowerCase().includes(needle))) continue;
      buttons.push({ id: entry.id, label: entry.label, category: entry.category ?? null });
    }
    return buttons;
  }

  function publicCatalog() {
    return {
      objectives: list('objective').map(({ definition, ...entry }) => entry),
      actions: list('action').map(({ implementation, ...entry }) => entry),
      observations: list('observation'),
      complications: list('complication').map(({ definition, ...entry }) => entry)
    };
  }

  return { get, list, resolveObjective, compileComplications, resolveLearnerActionButtons, publicCatalog };
}

const entries = [
  {
    kind: 'action', id: 'volume-bolus', label: 'Administer volume bolus', category: 'intervention',
    description: 'A reusable learner action whose consequence is determined by active clinical context.'
  },
  {
    kind: 'action', id: 'increase-rpm', label: 'Increase pump RPM', category: 'ecmo-control',
    description: 'Increase pump speed using the ECMO cockpit control.'
  },
  {
    kind: 'action', id: 'increase-sweep', label: 'Increase sweep gas', category: 'ecmo-control',
    description: 'Increase sweep gas using the ECMO cockpit control.'
  },
  { kind: 'action', id: 'assess-hemodynamics', label: 'Assess hemodynamic pattern', category: 'assessment' },
  { kind: 'action', id: 'order-echo', label: 'Order bedside echocardiography', category: 'diagnostic' },
  { kind: 'action', id: 'pericardial-decompression', label: 'Initiate pericardial decompression', category: 'procedure' },
  { kind: 'action', id: 'turn-patient', label: 'Turn / reposition patient for care', category: 'patient-care' },
  { kind: 'action', id: 'restore-prior-position', label: 'Return patient to documented pre-event position and reassess circuit', category: 'patient-care' },
  { kind: 'action', id: 'inspect-drainage-cannula', label: 'Inspect drainage cannula and tubing path', category: 'assessment' },
  { kind: 'action', id: 'relieve-cannula-kink', label: 'Relieve external cannula / tubing kink', category: 'procedure' },
  { kind: 'action', id: 'inspect-circuit-path', label: 'Inspect circuit for mechanical obstruction', category: 'assessment' },
  { kind: 'action', id: 'relieve-circuit-obstruction', label: 'Correct accessible circuit obstruction', category: 'procedure' },
  { kind: 'action', id: 'prepare-component-exchange', label: 'Prepare / initiate indicated circuit component exchange', category: 'procedure' },
  { kind: 'action', id: 'assess-pump-function', label: 'Assess pump power, speed, alarms, and actual output', category: 'assessment' },
  { kind: 'action', id: 'restore-pump-support', label: 'Restore pump function / transition to backup support', category: 'emergency-procedure' },

  // Rhythm-rescue actions. Logic lives in rhythm.mjs (resolveRhythmRescueAction),
  // not here — this is just the catalog entry so these get labels/categories
  // and show up via resolveLearnerActionButtons like every other action.
  { kind: 'action', id: 'assess-rhythm', label: 'Assess cardiac rhythm', category: 'assessment' },
  { kind: 'action', id: 'defibrillate', label: 'Defibrillate (unsynchronized shock)', category: 'emergency-procedure' },
  { kind: 'action', id: 'synchronized-cardioversion', label: 'Synchronized cardioversion', category: 'emergency-procedure' },
  { kind: 'action', id: 'administer-arrest-epinephrine', label: 'Administer arrest-dose epinephrine', category: 'emergency-procedure' },
  { kind: 'action', id: 'begin-chest-compressions', label: 'Begin chest compressions', category: 'emergency-procedure' },

  { kind:'action', id:'inspect-for-air', label:"Inspect circuit for air source / entrainment", category:'assessment' },
  { kind:'action', id:'isolate-air-source', label:"Stop air entrainment / secure source", category:'emergency-procedure' },
  { kind:'action', id:'manage-air-emergency', label:"Initiate circuit air-emergency response", category:'emergency-procedure' },
  { kind:'action', id:'control-circuit-breach', label:"Clamp / control circuit breach and blood loss", category:'emergency-procedure' },
  { kind:'action', id:'restore-circuit-integrity', label:"Restore circuit integrity / exchange damaged segment", category:'emergency-procedure' },
  { kind:'action', id:'assess-oxygenator', label:"Assess oxygenator performance and pressure gradient", category:'assessment' },
  { kind:'action', id:'exchange-oxygenator', label:"Initiate oxygenator / circuit component exchange", category:'emergency-procedure' },
  { kind:'action', id:'verify-sweep-gas', label:"Verify sweep gas connection, source, flow, and blender", category:'assessment' },
  { kind:'action', id:'restore-sweep-gas', label:"Restore sweep / gas source", category:'emergency-procedure' },
  { kind:'action', id:'assess-hemolysis', label:"Evaluate for clinically significant hemolysis", category:'assessment' },
  { kind:'action', id:'correct-hemolysis-source', label:"Correct mechanical / circuit cause of hemolysis", category:'procedure' },
  { kind:'action', id:'control-major-bleeding', label:"Initiate major hemorrhage control / resuscitation pathway", category:'emergency-procedure' },
  { kind:'action', id:'reduce-anticoagulation', label:"Hold / reduce anticoagulation when clinically indicated", category:'intervention' },
  { kind:'action', id:'neuro-assessment', label:"Perform focused neurologic assessment", category:'assessment' },
  { kind:'action', id:'urgent-neuro-imaging', label:"Obtain urgent neurologic imaging", category:'diagnostic' },
  { kind:'action', id:'stroke-escalation', label:"Initiate stroke / neurologic emergency escalation", category:'emergency-procedure' },
  { kind:'action', id:'assess-thrombosis', label:"Assess for circuit / cannula / intracardiac thrombosis", category:'assessment' },
  { kind:'action', id:'manage-thrombosis', label:"Initiate thrombosis-directed management / exchange pathway", category:'procedure' },
  { kind:'action', id:'assess-anticoagulation', label:"Review anticoagulation, bleeding, and thrombosis data", category:'assessment' },
  { kind:'action', id:'adjust-anticoagulation', label:"Adjust anticoagulation per protocol / clinical context", category:'intervention' },
  { kind:'action', id:'assess-recirculation', label:"Assess for VV recirculation and cannula relationship", category:'assessment' },
  { kind:'action', id:'correct-recirculation', label:"Correct VV cannula / flow configuration causing recirculation", category:'procedure' },
  { kind:'action', id:'assess-differential-hypoxemia', label:"Assess upper/lower body oxygenation and mixing", category:'assessment' },
  { kind:'action', id:'correct-differential-hypoxemia', label:"Initiate strategy to correct differential hypoxemia", category:'procedure' },
  { kind:'action', id:'assess-lv-distension', label:"Assess LV distension / aortic valve opening / pulmonary edema", category:'assessment' },
  { kind:'action', id:'initiate-lv-unloading', label:"Initiate indicated LV unloading strategy", category:'procedure' },
  { kind:'action', id:'assess-limb-perfusion', label:"Assess distal limb perfusion", category:'assessment' },
  { kind:'action', id:'restore-limb-perfusion', label:"Restore distal perfusion / correct cannulation-related ischemia", category:'procedure' },
  { kind:'action', id:'assess-thorax', label:"Assess for pneumothorax / tension physiology", category:'assessment' },
  { kind:'action', id:'decompress-chest', label:"Emergency pleural decompression", category:'emergency-procedure' },
  { kind:'action', id:'assess-airway-ventilator', label:"Assess airway, ETT, and ventilator circuit", category:'assessment' },
  { kind:'action', id:'restore-airway-ventilation', label:"Correct airway / ETT / ventilator failure", category:'procedure' },
  { kind:'action', id:'manage-pulmonary-hemorrhage', label:"Initiate pulmonary hemorrhage management", category:'emergency-procedure' },
  { kind:'action', id:'assess-gas-exchange', label:"Assess gas exchange using appropriate monitor/lab data", category:'assessment' },
  { kind:'action', id:'correct-gas-exchange', label:"Correct clinically significant gas-exchange support problem", category:'intervention' },
  { kind:'action', id:'manage-arrhythmia', label:"Treat clinically significant rhythm disturbance", category:'emergency-procedure' },
  { kind:'action', id:'resuscitate-arrest', label:"Initiate arrest / ECPR rescue pathway", category:'emergency-procedure' },
  { kind:'action', id:'assess-shock', label:"Assess distributive / vasoplegic shock pattern", category:'assessment' },
  { kind:'action', id:'treat-vasoplegia', label:"Initiate appropriate shock / vasoplegia treatment", category:'intervention' },
  { kind:'action', id:'obtain-cultures', label:"Obtain appropriate cultures / infectious evaluation", category:'diagnostic' },
  { kind:'action', id:'treat-sepsis', label:"Initiate sepsis treatment and source-control pathway", category:'intervention' },
  { kind:'action', id:'assess-renal-fluid', label:"Assess renal function, urine output, and fluid balance", category:'assessment' },
  { kind:'action', id:'manage-fluid-overload', label:"Initiate fluid / renal support strategy", category:'intervention' },
  { kind:'action', id:'assess-ckrt', label:"Assess CKRT/CRRT circuit and ECMO interaction", category:'assessment' },
  { kind:'action', id:'restore-ckrt', label:"Correct CKRT/ECMO interaction or restore renal-replacement support", category:'procedure' },
  { kind:'action', id:'assess-electrolytes', label:"Review urgent metabolic / electrolyte data", category:'assessment' },
  { kind:'action', id:'correct-electrolyte-emergency', label:"Treat clinically significant metabolic / electrolyte emergency", category:'intervention' },
  { kind:'action', id:'assess-neurologic-deterioration', label:"Assess acute neurologic deterioration / seizure", category:'assessment' },
  { kind:'action', id:'treat-neurologic-emergency', label:"Initiate neurologic emergency treatment", category:'intervention' },
  { kind:'action', id:'assess-abdomen', label:"Assess abdominal perfusion / pressure / ischemia", category:'assessment' },
  { kind:'action', id:'treat-abdominal-emergency', label:"Initiate abdominal compartment / ischemia escalation", category:'procedure' },
  { kind:'action', id:'assess-pulmonary-hypertension', label:"Assess pulmonary hypertensive / RV crisis pattern", category:'assessment' },
  { kind:'action', id:'treat-pulmonary-hypertension', label:"Initiate pulmonary hypertensive crisis treatment", category:'intervention' },
  { kind:'action', id:'assess-congenital-circulation', label:"Assess shunt / single-ventricle / residual lesion physiology", category:'assessment' },
  { kind:'action', id:'escalate-congenital-lesion', label:"Escalate for lesion-specific intervention", category:'procedure' },
  { kind:'action', id:'assess-treatment-reaction', label:"Assess for medication / transfusion adverse effect", category:'assessment' },
  { kind:'action', id:'stop-offending-treatment', label:"Stop or reverse offending treatment when indicated", category:'intervention' },
  { kind:'action', id:'stabilize-transport-position', label:"Stop movement / restore safe position and support", category:'emergency-procedure' },
  { kind:'action', id:'verify-monitor-sensor', label:"Verify questionable monitor / sensor data against independent source", category:'assessment' },

  { kind: 'observation', id: 'low-flow-pattern', label: 'Low ECMO flow pattern', channel: 'continuous-monitoring' },
  { kind: 'observation', id: 'filling-pressure-trend', label: 'Filling pressure trend', channel: 'continuous-monitoring' },
  { kind: 'observation', id: 'drainage-instability', label: 'Drainage instability / chatter', channel: 'circuit-inspection' },
  { kind: 'observation', id: 'bedside-echo', label: 'Bedside echocardiography', channel: 'ordered-study' },
  { kind: 'observation', id: 'position-flow-response', label: 'Position-dependent ECMO flow response', channel: 'continuous-monitoring' },
  { kind: 'observation', id: 'visible-cannula-tubing-kink', label: 'Visible cannula / tubing path abnormality', channel: 'circuit-inspection' },
  { kind: 'observation', id: 'pressure-pattern-obstruction', label: 'Pressure pattern suggesting circuit resistance / obstruction', channel: 'continuous-monitoring' },
  { kind: 'observation', id: 'pump-power-alarm-status', label: 'Pump power, speed, alarm, and output status', channel: 'continuous-monitoring' },

  { kind:'observation', id:'air-circuit-clues', label:"Air / bubble detector / circuit entrainment clues", channel:'continuous-monitoring' },
  { kind:'observation', id:'circuit-breach-clues', label:"Visible circuit breach / blood loss / pressure loss", channel:'circuit-inspection' },
  { kind:'observation', id:'oxygenator-performance', label:"Oxygenator gas-transfer and pressure-gradient pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'sweep-gas-status', label:"Sweep flow / gas source / blender status", channel:'circuit-inspection' },
  { kind:'observation', id:'hemolysis-pattern', label:"Hemolysis laboratory / urine / circuit pattern", channel:'ordered-study' },
  { kind:'observation', id:'major-bleeding-pattern', label:"Clinically significant bleeding and blood-loss pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'acute-neuro-change', label:"Acute neurologic examination change", channel:'assessment' },
  { kind:'observation', id:'thrombotic-pattern', label:"Circuit / vascular / intracardiac thrombosis clues", channel:'ordered-study' },
  { kind:'observation', id:'recirculation-pattern', label:"VV recirculation pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'upper-lower-oxygenation', label:"Upper/lower body oxygenation differential", channel:'continuous-monitoring' },
  { kind:'observation', id:'lv-distension-pattern', label:"LV distension / pulmonary edema / aortic valve opening pattern", channel:'ordered-study' },
  { kind:'observation', id:'distal-limb-perfusion', label:"Distal limb perfusion findings", channel:'assessment' },
  { kind:'observation', id:'tension-thorax-pattern', label:"Pneumothorax / tension physiology findings", channel:'assessment' },
  { kind:'observation', id:'airway-ventilator-pattern', label:"Airway / ETT / ventilator failure clues", channel:'assessment' },
  { kind:'observation', id:'pulmonary-bleeding-pattern', label:"Pulmonary hemorrhage findings", channel:'continuous-monitoring' },
  { kind:'observation', id:'gas-exchange-pattern', label:"Clinically significant oxygenation / ventilation trend", channel:'continuous-monitoring' },
  { kind:'observation', id:'rhythm-instability', label:"Clinically significant rhythm / arrest pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'shock-pattern', label:"Perfusion / vasoplegia / shock pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'infection-pattern', label:"Infection / sepsis clinical and laboratory pattern", channel:'ordered-study' },
  { kind:'observation', id:'renal-fluid-pattern', label:"Urine output / renal function / fluid balance trend", channel:'continuous-monitoring' },
  { kind:'observation', id:'ckrt-interaction-pattern', label:"CKRT/ECMO interaction or renal-support failure pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'metabolic-emergency-pattern', label:"Clinically significant electrolyte / metabolic result", channel:'ordered-study' },
  { kind:'observation', id:'neurologic-deterioration-pattern', label:"Seizure / consciousness / cerebral perfusion pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'abdominal-emergency-pattern', label:"Abdominal pressure / perfusion / ischemia pattern", channel:'assessment' },
  { kind:'observation', id:'pulmonary-hypertension-pattern', label:"Pulmonary hypertensive / RV crisis pattern", channel:'continuous-monitoring' },
  { kind:'observation', id:'congenital-circulation-pattern', label:"Shunt / single-ventricle / residual lesion failure pattern", channel:'ordered-study' },
  { kind:'observation', id:'treatment-adverse-pattern', label:"Temporal pattern consistent with treatment / transfusion harm", channel:'continuous-monitoring' },
  { kind:'observation', id:'operational-hazard-pattern', label:"Support change associated with movement / transport / equipment data", channel:'continuous-monitoring' },

  {
    kind: 'objective', id: 'low-flow-troubleshooting', label: 'ECMO Low-Flow Troubleshooting',
    concepts: {
      'preload-limitation': {
        label: 'Preload limitation',
        complicationIds: ['hypovolemia'],
        actionIds: ['volume-bolus', 'increase-rpm', 'increase-sweep'],
        observationIds: ['low-flow-pattern', 'drainage-instability']
      },
      'tamponade-recognition': {
        label: 'Tamponade recognition',
        complicationIds: ['postoperative-tamponade'],
        actionIds: ['volume-bolus', 'increase-rpm', 'assess-hemodynamics', 'order-echo', 'pericardial-decompression'],
        observationIds: ['low-flow-pattern', 'filling-pressure-trend', 'bedside-echo']
      },
      'cannula-malposition': {
        label: 'Cannula malposition / drainage compromise',
        complicationIds: ['position-sensitive-cannula','drainage-cannula-kink'],
        actionIds: ['turn-patient','restore-prior-position','increase-rpm','inspect-drainage-cannula','relieve-cannula-kink'],
        observationIds: ['low-flow-pattern','drainage-instability','position-flow-response','visible-cannula-tubing-kink']
      },
      'circuit-obstruction': {
        label: 'Circuit obstruction',
        complicationIds: ['mechanical-circuit-obstruction'],
        actionIds: ['inspect-circuit-path','increase-rpm','relieve-circuit-obstruction','prepare-component-exchange'],
        observationIds: ['low-flow-pattern','pressure-pattern-obstruction']
      },
      'pump-failure': {
        label: 'Pump failure / loss of pump support',
        complicationIds: ['pump-support-failure'],
        actionIds: ['assess-pump-function','restore-pump-support'],
        observationIds: ['low-flow-pattern','pump-power-alarm-status']
      }
    }
  },
  {
    kind: 'objective', id: 'gas-exchange', label: 'Gas Exchange',
    concepts: {
      hypoxemia: { label:'Hypoxemia', complicationIds:['gas-exchange-failure'], actionIds:['assess-gas-exchange','correct-gas-exchange'], observationIds:['gas-exchange-pattern'] },
      hypercarbia: { label:'Hypercarbia', complicationIds:['gas-exchange-failure','sweep-gas-failure'], actionIds:['assess-gas-exchange','verify-sweep-gas','restore-sweep-gas'], observationIds:['gas-exchange-pattern','sweep-gas-status'] },
      'oxygenator-dysfunction': { label:'Oxygenator dysfunction', complicationIds:['oxygenator-thrombosis-failure'], actionIds:['assess-oxygenator','exchange-oxygenator'], observationIds:['oxygenator-performance'] },
      recirculation: { label:'Recirculation', complicationIds:['vv-recirculation'], actionIds:['assess-recirculation','correct-recirculation'], observationIds:['recirculation-pattern'] }
    }
  },
  {
    kind: 'objective', id: 'circuit-emergencies', label: 'Circuit Emergencies',
    concepts: {
      'air-emergency': { label:'Air emergency', complicationIds:['air-emergency'], actionIds:['inspect-for-air','isolate-air-source','manage-air-emergency'], observationIds:['air-circuit-clues'] },
      'oxygenator-failure': { label:'Oxygenator failure', complicationIds:['oxygenator-thrombosis-failure'], actionIds:['assess-oxygenator','exchange-oxygenator'], observationIds:['oxygenator-performance'] },
      'pump-failure': { label:'Pump failure', complicationIds:['pump-support-failure'], actionIds:['assess-pump-function','restore-pump-support'], observationIds:['pump-power-alarm-status'] },
      'circuit-clot': { label:'Circuit clot', complicationIds:['circuit-systemic-thrombosis'], actionIds:['assess-thrombosis','manage-thrombosis'], observationIds:['thrombotic-pattern'] },
      'circuit-breach': { label:'Circuit breach / disconnection', complicationIds:['circuit-breach-hemorrhage'], actionIds:['control-circuit-breach','restore-circuit-integrity'], observationIds:['circuit-breach-clues'] },
      'sweep-gas-failure': { label:'Sweep / gas failure', complicationIds:['sweep-gas-failure'], actionIds:['verify-sweep-gas','restore-sweep-gas'], observationIds:['sweep-gas-status'] }
    }
  },
  {
    kind:'objective', id:'circuit-emergency-pack', label:'Circuit Emergencies — V1 Pack',
    concepts:{
      air:{label:'Air emergency',complicationIds:['air-emergency'],actionIds:['inspect-for-air','isolate-air-source','manage-air-emergency'],observationIds:['air-circuit-clues']},
      breach:{label:'Circuit breach',complicationIds:['circuit-breach-hemorrhage'],actionIds:['control-circuit-breach','restore-circuit-integrity'],observationIds:['circuit-breach-clues']},
      oxygenator:{label:'Oxygenator failure',complicationIds:['oxygenator-thrombosis-failure'],actionIds:['assess-oxygenator','increase-sweep','exchange-oxygenator'],observationIds:['oxygenator-performance']},
      gas:{label:'Sweep gas failure',complicationIds:['sweep-gas-failure'],actionIds:['verify-sweep-gas','restore-sweep-gas','increase-sweep'],observationIds:['sweep-gas-status']},
      hemolysis:{label:'Hemolysis',complicationIds:['hemolysis'],actionIds:['assess-hemolysis','correct-hemolysis-source','increase-rpm'],observationIds:['hemolysis-pattern']},
      bleeding:{label:'Major bleeding',complicationIds:['major-bleeding'],actionIds:['control-major-bleeding','reduce-anticoagulation'],observationIds:['major-bleeding-pattern']}
    }
  },
  {
    kind: 'objective', id: 'anticoagulation', label: 'Anticoagulation',
    concepts: {
      titration: { label:'Titration', complicationIds:['anticoagulation-management'], actionIds:['assess-anticoagulation','adjust-anticoagulation'], observationIds:[] },
      bleeding: { label:'Bleeding', complicationIds:['major-bleeding'], actionIds:['control-major-bleeding','reduce-anticoagulation'], observationIds:['major-bleeding-pattern'] },
      thrombosis: { label:'Thrombosis', complicationIds:['circuit-systemic-thrombosis'], actionIds:['assess-thrombosis','manage-thrombosis'], observationIds:['thrombotic-pattern'] },
      hemolysis: { label:'Hemolysis', complicationIds:['hemolysis'], actionIds:['assess-hemolysis','correct-hemolysis-source'], observationIds:['hemolysis-pattern'] }
    }
  },


  {
    kind:'objective', id:'vv-support-pack', label:'VV ECMO Support — V1 Pack',
    concepts:{
      recirculation:{label:'Recirculation',complicationIds:['vv-recirculation'],actionIds:['assess-recirculation','correct-recirculation','increase-rpm'],observationIds:['recirculation-pattern']},
      oxygenator:{label:'Oxygenator dysfunction',complicationIds:['oxygenator-thrombosis-failure'],actionIds:['assess-oxygenator','increase-sweep','exchange-oxygenator'],observationIds:['oxygenator-performance']},
      gas:{label:'Gas-exchange failure',complicationIds:['gas-exchange-failure'],actionIds:['assess-gas-exchange','correct-gas-exchange'],observationIds:['gas-exchange-pattern']},
      thorax:{label:'Tension pneumothorax',complicationIds:['pneumothorax-intrathoracic-pressure'],actionIds:['assess-thorax','decompress-chest','increase-rpm'],observationIds:['tension-thorax-pattern']},
      airway:{label:'Airway/ventilator failure',complicationIds:['airway-ventilator-failure'],actionIds:['assess-airway-ventilator','restore-airway-ventilation'],observationIds:['airway-ventilator-pattern']}
    }
  },
  {
    kind:'objective', id:'va-support', label:'VA ECMO Support Complications',
    concepts:{
      'differential-hypoxemia':{label:'Differential hypoxemia',complicationIds:['va-differential-hypoxemia'],actionIds:['assess-differential-hypoxemia','correct-differential-hypoxemia'],observationIds:['upper-lower-oxygenation']},
      'lv-distension':{label:'LV distension / unloading',complicationIds:['va-lv-distension'],actionIds:['assess-lv-distension','initiate-lv-unloading'],observationIds:['lv-distension-pattern']},
      'limb-ischemia':{label:'Limb ischemia',complicationIds:['limb-ischemia'],actionIds:['assess-limb-perfusion','restore-limb-perfusion'],observationIds:['distal-limb-perfusion']}
    }
  },
  {
    kind:'objective', id:'patient-emergencies', label:'Patient Emergencies on ECMO',
    concepts:{
      'tension-pneumothorax':{label:'Tension pneumothorax',complicationIds:['pneumothorax-intrathoracic-pressure'],actionIds:['assess-thorax','decompress-chest'],observationIds:['tension-thorax-pattern']},
      'airway-ventilator':{label:'Airway / ventilator failure',complicationIds:['airway-ventilator-failure'],actionIds:['assess-airway-ventilator','restore-airway-ventilation'],observationIds:['airway-ventilator-pattern']},
      'pulmonary-hemorrhage':{label:'Pulmonary hemorrhage',complicationIds:['pulmonary-hemorrhage'],actionIds:['manage-pulmonary-hemorrhage'],observationIds:['pulmonary-bleeding-pattern']},
      'arrhythmia-arrest':{label:'Arrhythmia / arrest',complicationIds:['arrhythmia-arrest'],actionIds:['manage-arrhythmia','resuscitate-arrest'],observationIds:['rhythm-instability']},
      'vasoplegia':{label:'Vasoplegia / shock',complicationIds:['vasoplegia-shock'],actionIds:['assess-shock','treat-vasoplegia'],observationIds:['shock-pattern']}
    }
  },
  {
    kind:'objective', id:'neurologic', label:'Neurologic Complications',
    concepts:{
      'intracranial-hemorrhage':{label:'Intracranial hemorrhage',complicationIds:['intracranial-hemorrhage'],actionIds:['neuro-assessment','urgent-neuro-imaging'],observationIds:['acute-neuro-change']},
      'ischemic-stroke':{label:'Ischemic stroke / thromboembolism',complicationIds:['thromboembolism-stroke'],actionIds:['neuro-assessment','urgent-neuro-imaging','stroke-escalation'],observationIds:['acute-neuro-change']},
      'neurologic-deterioration':{label:'Seizure / acute neurologic deterioration',complicationIds:['neurologic-deterioration'],actionIds:['assess-neurologic-deterioration','treat-neurologic-emergency'],observationIds:['neurologic-deterioration-pattern']}
    }
  },
  {
    kind:'objective', id:'organ-support', label:'Organ Dysfunction & Systemic Complications',
    concepts:{
      'sepsis':{label:'Infection / sepsis',complicationIds:['infection-sepsis'],actionIds:['obtain-cultures','treat-sepsis'],observationIds:['infection-pattern']},
      'aki-fluid-overload':{label:'AKI / fluid overload',complicationIds:['aki-fluid-overload'],actionIds:['assess-renal-fluid','manage-fluid-overload'],observationIds:['renal-fluid-pattern']},
      'ckrt-interaction':{label:'CKRT / ECMO interaction',complicationIds:['ckrt-ecmo-interaction'],actionIds:['assess-ckrt','restore-ckrt'],observationIds:['ckrt-interaction-pattern']},
      'metabolic-emergency':{label:'Metabolic / electrolyte emergency',complicationIds:['metabolic-electrolyte-emergency'],actionIds:['assess-electrolytes','correct-electrolyte-emergency'],observationIds:['metabolic-emergency-pattern']},
      'abdominal-emergency':{label:'Abdominal compartment / ischemia',complicationIds:['abdominal-ischemic-compartment'],actionIds:['assess-abdomen','treat-abdominal-emergency'],observationIds:['abdominal-emergency-pattern']}
    }
  },
  {
    kind:'objective', id:'patient-emergency-pack', label:'Patient Emergencies on ECMO — V1 Pack',
    concepts:{
      'arrhythmia-arrest':{label:'Arrhythmia / arrest',complicationIds:['arrhythmia-arrest'],actionIds:['assess-rhythm','defibrillate','synchronized-cardioversion','administer-arrest-epinephrine','begin-chest-compressions','manage-arrhythmia','resuscitate-arrest'],observationIds:['rhythm-instability']},
      'acute-neurologic':{label:'Acute neurologic emergency',complicationIds:['intracranial-hemorrhage'],actionIds:['neuro-assessment','urgent-neuro-imaging','reduce-anticoagulation','treat-neurologic-emergency'],observationIds:['acute-neuro-change']},
      'distributive-shock':{label:'Vasoplegia / sepsis',complicationIds:['vasoplegia-shock','infection-sepsis'],actionIds:['assess-shock','treat-vasoplegia','obtain-cultures','treat-sepsis'],observationIds:['shock-pattern','infection-pattern']},
      'renal-fluid':{label:'AKI / fluid overload',complicationIds:['aki-fluid-overload'],actionIds:['assess-renal-fluid','manage-fluid-overload'],observationIds:['renal-fluid-pattern']},
      'metabolic':{label:'Metabolic / electrolyte emergency',complicationIds:['metabolic-electrolyte-emergency'],actionIds:['assess-electrolytes','correct-electrolyte-emergency'],observationIds:['metabolic-emergency-pattern']},
      'pulmonary-hypertension':{label:'Pulmonary hypertensive / RV crisis',complicationIds:['pulmonary-hypertensive-crisis'],actionIds:['assess-pulmonary-hypertension','treat-pulmonary-hypertension'],observationIds:['pulmonary-hypertension-pattern']}
    }
  },
  {
    kind:'objective', id:'special-populations', label:'Special Population / Context Complications',
    concepts:{
      'pulmonary-hypertension':{label:'Pulmonary hypertensive crisis',complicationIds:['pulmonary-hypertensive-crisis'],actionIds:['assess-pulmonary-hypertension','treat-pulmonary-hypertension'],observationIds:['pulmonary-hypertension-pattern']},
      'congenital-circulation':{label:'Congenital circulation / shunt problem',complicationIds:['congenital-circulation-specific'],actionIds:['assess-congenital-circulation','escalate-congenital-lesion'],observationIds:['congenital-circulation-pattern']},
      'treatment-adverse':{label:'Treatment / transfusion adverse event',complicationIds:['treatment-transfusion-adverse'],actionIds:['assess-treatment-reaction','stop-offending-treatment'],observationIds:['treatment-adverse-pattern']},
      'transport-operational':{label:'Transport / operational hazard',complicationIds:['transport-procedural-operational'],actionIds:['stabilize-transport-position','verify-monitor-sensor'],observationIds:['operational-hazard-pattern']}
    }
  },


  {
    kind: 'complication', id: 'hypovolemia', label: 'Preload limitation / hypovolemia',
    tags: ['preload', 'low-flow'],
    definition: {
      id: 'hypovolemia', label: 'Preload limitation / hypovolemia', initialState: 'decompensating', hidden: true,
      trajectoryByState: {
        decompensating: { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        worsened: { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        critical: { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        arrest: { dimensions: { perfusion:'absent', hemodynamics:'absent', circuitSupport:'critical' }, arrest:true },
        resolved: { dimensions: {} }
      },
      actionRules: [
        { actionId:'volume-bolus', whenStates:['decompensating','worsened','critical'], outcome:'preferred', score:15,
          feedback:'Volume is administered. Venous-line chatter resolves, circuit flow improves, and perfusion stabilizes.',
          rationale:'The intervention addresses inadequate preload rather than forcing higher RPM against a preload-limited circuit.',
          effects:{ internal:{ cvpBaseline:{add:5}, mapBaseline:{add:8}, 'trueLatent.lactateMmolL':{add:-0.8} }, eventState:'resolved', resolve:true } },
        { actionId:'increase-rpm', whenStates:['decompensating'], outcome:'harmful', score:-10,
          feedback:'RPM increases, but flow improves only briefly. Venous drainage worsens and chatter becomes more pronounced.',
          rationale:'The circuit is preload-limited; increasing RPM does not correct the cause and can worsen venous collapse.',
          effects:{ internal:{ cvpBaseline:{add:-1}, mapBaseline:{add:-3}, 'trueLatent.lactateMmolL':{add:0.5} }, eventState:'worsened' } },
        { actionId:'increase-sweep', outcome:'ineffective', score:-1,
          feedback:'Sweep is increased. The low-flow pattern and hemodynamic instability do not meaningfully improve.',
          rationale:'Sweep controls CO2 removal and does not correct inadequate venous return to the circuit.' }
      ],
      timeRules:[
        { fromState:'decompensating', afterSec:240, toState:'worsened', effects:{ internal:{cvpBaseline:{add:-2}, mapBaseline:{add:-4}, 'trueLatent.lactateMmolL':{add:0.6}} }, feedback:'Preload limitation goes uncorrected and hemodynamic compromise progresses.' },
        { fromState:'worsened', afterSec:60, toState:'critical', effects:{ internal:{mapBaseline:{add:-6}, 'trueLatent.lactateMmolL':{add:1}} }, feedback:'Hemodynamic compromise progresses to critical instability.' },
        { fromState:'critical', afterSec:90, toState:'arrest', effects:{ internal:{mapBaseline:{set:10}, hrCurrent:{set:40}} }, feedback:'The patient progresses to cardiovascular arrest.' }
      ]
    }
  },
  {
    kind: 'complication', id: 'postoperative-tamponade', label: 'Postoperative cardiac tamponade',
    tags: ['mechanical', 'low-flow', 'postoperative'],
    definition: {
      id:'postoperative-tamponade', label:'Postoperative cardiac tamponade', initialState:'decompensating', hidden:true,
      trajectoryByState: {
        decompensating: { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        temporized: { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        suspected: { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        diagnosed: { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        worsened: { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        critical: { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        arrest: { dimensions: { perfusion:'absent', hemodynamics:'absent', circuitSupport:'critical' }, arrest:true },
        resolved: { dimensions: {} }
      },
      actionRules:[
        { actionId:'volume-bolus', whenStates:['decompensating'], outcome:'temporizing', score:4,
          feedback:'Volume produces a modest, temporary improvement in pressure, but venous congestion remains and ECMO flow does not normalize. The underlying obstruction persists.',
          rationale:'Additional preload may briefly support filling pressure, but it cannot relieve external cardiac compression.',
          effects:{ internal:{ mapBaseline:{add:2}, cvpBaseline:{add:2} }, eventState:'temporized' } },
        { actionId:'volume-bolus', whenStates:['temporized','diagnosed'], outcome:'ineffective', score:-2,
          feedback:'Additional volume raises filling pressure without producing meaningful sustained improvement in circuit flow or perfusion.',
          rationale:'The limiting problem is mechanical compression, not simple volume depletion.',
          effects:{ internal:{ cvpBaseline:{add:2}, 'trueLatent.lactateMmolL':{add:0.2} } } },
        { actionId:'increase-rpm', whenStates:['decompensating','temporized','diagnosed'], outcome:'harmful', score:-10,
          feedback:'RPM increases, but effective flow fails to improve. Venous drainage becomes more negative while systemic perfusion continues to deteriorate.',
          rationale:'Higher pump speed cannot overcome impaired venous return caused by tamponade and may worsen drainage instability.',
          effects:{ internal:{ mapBaseline:{add:-3}, 'trueLatent.lactateMmolL':{add:0.5} }, eventState:'worsened' } },
        { actionId:'assess-hemodynamics', whenStates:['decompensating','temporized','worsened'], outcome:'acceptable', score:5,
          feedback:'Assessment confirms a concerning pattern: elevated filling pressure, falling effective ECMO support, and worsening perfusion without a clear circuit obstruction.',
          rationale:'Recognizing that this is not behaving like simple hypovolemia appropriately narrows the differential.', effects:{eventState:'suspected'} },
        { actionId:'order-echo', whenStates:['decompensating','temporized','worsened','suspected'], outcome:'preferred', score:12,
          feedback:'Bedside echocardiography demonstrates a compressive pericardial collection with impaired cardiac filling, confirming tamponade physiology.',
          rationale:'Urgent echocardiographic assessment directly evaluates a reversible mechanical cause of low flow with elevated filling pressure.', effects:{eventState:'diagnosed'} },
        { actionId:'pericardial-decompression', whenStates:['diagnosed'], outcome:'preferred', score:20,
          feedback:'The pericardial collection is urgently decompressed. Filling improves, ECMO flow recovers, arterial pressure rises, and perfusion stabilizes.',
          rationale:'Definitive relief of the mechanical compression treats the cause of the deterioration.',
          effects:{ internal:{ cvpBaseline:{add:-6}, mapBaseline:{add:10}, 'trueLatent.lactateMmolL':{add:-1} }, eventState:'resolved', resolve:true } },
        { actionId:'pericardial-decompression', whenStates:['decompensating','temporized','worsened','suspected','critical'], outcome:'acceptable', score:8,
          feedback:'The team proceeds with emergency decompression based on the rapidly deteriorating clinical pattern. Hemodynamics improve as cardiac compression is relieved.',
          rationale:'In an unstable postoperative patient, emergent treatment may be justified before formal imaging confirmation when clinical suspicion is sufficiently high.',
          effects:{ internal:{ cvpBaseline:{add:-6}, mapBaseline:{add:9}, 'trueLatent.lactateMmolL':{add:-0.8} }, eventState:'resolved', resolve:true } },
        { actionId:'increase-sweep', whenStates:['decompensating','temporized','worsened','suspected','diagnosed'], outcome:'ineffective', score:-1,
          feedback:'Sweep is increased. The hemodynamic low-flow pattern does not meaningfully improve.',
          rationale:'Gas exchange adjustment does not relieve external cardiac compression.' }
      ],
      timeRules:[
        { fromState:'decompensating', afterSec:240, toState:'worsened', effects:{ internal:{mapBaseline:{add:-4}, cvpBaseline:{add:2}, 'trueLatent.lactateMmolL':{add:0.6}} }, feedback:'Unrecognized tamponade physiology goes uncorrected and hemodynamic compromise progresses.' },
        { fromState:'temporized', afterSec:120, toState:'decompensating', effects:{ internal:{mapBaseline:{add:-2}} }, feedback:'The brief hemodynamic benefit fades and low-flow deterioration returns.' },
        { fromState:'suspected', afterSec:180, toState:'worsened', effects:{ internal:{mapBaseline:{add:-4}, cvpBaseline:{add:2}, 'trueLatent.lactateMmolL':{add:0.6}} }, feedback:'Concern is recognized but definitive treatment has not occurred, and hemodynamic compromise progresses.' },
        { fromState:'diagnosed', afterSec:120, toState:'worsened', effects:{ internal:{mapBaseline:{add:-4}, cvpBaseline:{add:2}, 'trueLatent.lactateMmolL':{add:0.6}} }, feedback:'Tamponade is confirmed but remains undrained, and hemodynamic compromise progresses.' },
        { fromState:'worsened', afterSec:60, toState:'critical', effects:{ internal:{mapBaseline:{add:-6}, 'trueLatent.lactateMmolL':{add:1}} }, feedback:'Hemodynamic compromise progresses to critical instability.' },
        { fromState:'critical', afterSec:90, toState:'arrest', effects:{ internal:{mapBaseline:{set:10}, hrCurrent:{set:40}} }, feedback:'The patient progresses to cardiovascular arrest.' }
      ]
    }
  },
  {
    kind: 'complication', id: 'position-sensitive-cannula', label: 'Position-sensitive cannula drainage compromise',
    tags: ['cannula', 'low-flow', 'position-dependent'],
    definition: {
      id:'position-sensitive-cannula', label:'Position-sensitive cannula drainage compromise', initialState:'latent-position-sensitive', hidden:true,
      trajectoryByState: {
        'latent-position-sensitive': { dimensions: {} },
        'partial-flow-compromise': { dimensions: { perfusion:'impaired', hemodynamics:'impaired', circuitSupport:'impaired' } },
        'severe-flow-compromise': { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        'worsened': { dimensions: { perfusion:'critical', hemodynamics:'critical', circuitSupport:'critical' } },
        resolved: { dimensions: {} }
      },
      contextRules:[
        {
          contextKey:'patient-position-effect', value:'adverse',
          whenStates:['latent-position-sensitive','partial-flow-compromise','severe-flow-compromise','worsened'],
          outcome:'harmful', score:-2,
          feedback:'In this position, venous drainage becomes markedly unstable and ECMO flow falls to a critically inadequate level.',
          rationale:'The patient position is interacting adversely with cannula drainage.',
          effects:{ internal:{ supportFlowMultiplier:{set:0.27} }, eventState:'severe-flow-compromise' }
        },
        {
          contextKey:'patient-position-effect', value:'partial',
          whenStates:['latent-position-sensitive','partial-flow-compromise','severe-flow-compromise','worsened'],
          outcome:'acceptable', score:4,
          feedback:'This position improves drainage and ECMO flow, but support remains below the previous baseline and intermittent drainage limitation persists.',
          rationale:'The new position partially improves the cannula-drainage relationship without fully correcting it.',
          effects:{ internal:{ supportFlowMultiplier:{set:0.60} }, eventState:'partial-flow-compromise' }
        },
        {
          contextKey:'patient-position-effect', value:'favorable',
          whenStates:['latent-position-sensitive','partial-flow-compromise','severe-flow-compromise','worsened'],
          outcome:'preferred', score:15,
          feedback:'In this position, drainage stabilizes and ECMO flow returns toward the previous support level.',
          rationale:'The favorable position restores an effective cannula-drainage relationship.',
          effects:{ internal:{ supportFlowMultiplier:{set:1} }, eventState:'resolved', resolve:true }
        },
        {
          contextKey:'patient-position-effect', value:'neutral',
          whenStates:['latent-position-sensitive','partial-flow-compromise','severe-flow-compromise','worsened'],
          outcome:'ineffective', score:0,
          feedback:'The new position does not produce a meaningful improvement in drainage or ECMO support.',
          rationale:'This position does not correct the clinically important drainage limitation.'
        }
      ],
      actionRules:[
        {
          actionId:'increase-rpm', whenStates:['severe-flow-compromise','partial-flow-compromise'], outcome:'harmful', score:-10,
          feedback:'Increasing RPM does not restore adequate flow. Drainage instability persists while effective support remains inadequate.',
          rationale:'Pump speed does not correct a position-dependent drainage limitation.',
          effects:{ eventState:'worsened' }
        }
      ]
    }
  },
  {
    kind:'complication', id:'drainage-cannula-kink', label:'Drainage cannula / tubing kink',
    tags:['cannula','mechanical','low-flow'],
    definition:{
      id:'drainage-cannula-kink', label:'Drainage cannula / tubing kink', initialState:'active-obstruction', hidden:true,
      activationEffects:{internal:{supportFlowMultiplier:{set:0.35},mapBaseline:{add:-6}}},
      trajectoryByState:{
        'active-obstruction':{dimensions:{perfusion:'critical',hemodynamics:'critical',circuitSupport:'critical'}},
        'worsened':{dimensions:{perfusion:'critical',hemodynamics:'critical',circuitSupport:'critical'}},
        resolved:{dimensions:{}}
      },
      actionRules:[
        {
          actionId:'inspect-drainage-cannula', whenStates:['active-obstruction','worsened'], outcome:'preferred', score:8,
          feedback:'Inspection identifies a mechanical abnormality along the drainage cannula / tubing path that can account for the abrupt loss of support.',
          rationale:'Direct inspection of the drainage cannula and tubing is a rapid way to identify an externally correctable restriction. Drainage limitation should be interpreted with venous-line pressure/flow behavior and patient preload rather than flow alone.'
        },
        {
          actionId:'relieve-cannula-kink', whenStates:['active-obstruction','worsened'], outcome:'preferred', score:18,
          feedback:'The mechanical kink is relieved. Venous drainage improves promptly and ECMO flow returns toward the prior support level.',
          rationale:'Removing an external mechanical restriction can restore venous drainage; persistent limitation after external correction requires evaluation for cannula position, intravascular obstruction, or inadequate preload.',
          effects:{internal:{supportFlowMultiplier:{set:1},mapBaseline:{add:8}},eventState:'resolved',resolve:true}
        },
        {
          actionId:'increase-rpm', whenStates:['active-obstruction','worsened'], outcome:'harmful', score:-10,
          feedback:'Increasing RPM does not restore adequate support. Drainage instability persists and the low-flow state remains clinically significant.',
          rationale:'Increasing pump speed does not correct a fixed drainage restriction and can worsen excessive negative inlet pressure or drainage instability.',
          effects:{internal:{mapBaseline:{add:-3}},eventState:'worsened'}
        }
      ]
    }
  },
  {
    kind:'complication', id:'mechanical-circuit-obstruction', label:'Mechanical circuit obstruction',
    tags:['circuit','mechanical','low-flow'],
    definition:{
      id:'mechanical-circuit-obstruction', label:'Mechanical circuit obstruction', initialState:'flow-limited', hidden:true,
      activationEffects:{internal:{supportFlowMultiplier:{set:0.50},mapBaseline:{add:-5}}},
      trajectoryByState:{
        'flow-limited':{dimensions:{perfusion:'critical',hemodynamics:'critical',circuitSupport:'critical'}},
        'worsened':{dimensions:{perfusion:'critical',hemodynamics:'critical',circuitSupport:'critical'}},
        resolved:{dimensions:{}}
      },
      actionRules:[
        {
          actionId:'inspect-circuit-path', whenStates:['flow-limited','worsened'], outcome:'preferred', score:10,
          feedback:'Circuit inspection reveals a clinically important resistance / obstruction pattern requiring immediate mechanical troubleshooting.',
          rationale:'A low-flow state with evidence of abnormal circuit resistance should prompt inspection of the entire circuit path and interpretation of pressure gradients in relation to flow, device, and trend.'
        },
        {
          actionId:'increase-rpm', whenStates:['flow-limited','worsened'], outcome:'harmful', score:-10,
          feedback:'RPM rises, but adequate flow is not restored. The obstruction remains and circuit stress increases.',
          rationale:'Increasing pump speed does not remove a fixed circuit-path obstruction and may increase circuit stress; identify and correct the restriction.',
          effects:{internal:{mapBaseline:{add:-3}},eventState:'worsened'}
        },
        {
          actionId:'relieve-circuit-obstruction', whenStates:['flow-limited','worsened'], outcome:'preferred', score:18,
          feedback:'The accessible mechanical obstruction is corrected. Circuit flow and effective support recover.',
          rationale:'Correcting the actual mechanical restriction restores the circuit pathway; verify recovery of flow and pressure behavior after correction.',
          effects:{internal:{supportFlowMultiplier:{set:1},mapBaseline:{add:7}},eventState:'resolved',resolve:true}
        },
        {
          actionId:'prepare-component-exchange', whenStates:['flow-limited','worsened'], outcome:'acceptable', score:10,
          feedback:'The team prepares for definitive circuit-component intervention while maintaining support as safely as possible.',
          rationale:'When the obstruction cannot be safely corrected in place, component exchange may be required.'
        }
      ]
    }
  },
  {
    kind:'complication', id:'pump-support-failure', label:'Pump failure / loss of pump support',
    tags:['pump','circuit','emergency','low-flow'],
    definition:{
      id:'pump-support-failure', label:'Pump failure / loss of pump support', initialState:'support-lost', hidden:true,
      activationEffects:{internal:{supportFlowMultiplier:{set:0},mapBaseline:{add:-10}}},
      trajectoryByState:{
        'support-lost':{dimensions:{perfusion:'absent',hemodynamics:'critical',circuitSupport:'absent'}},
        'worsened':{dimensions:{perfusion:'absent',hemodynamics:'absent',circuitSupport:'absent'},arrest:true},
        resolved:{dimensions:{}}
      },
      actionRules:[
        {
          actionId:'assess-pump-function', whenStates:['support-lost'], outcome:'preferred', score:10,
          feedback:'Assessment confirms loss of effective pump support and identifies the need for immediate restoration of circuit flow.',
          rationale:'The priority is rapid confirmation of pump function, power/drive status, and circuit flow, followed by restoration of effective support rather than treatment of secondary monitor changes alone.'
        },
        {
          actionId:'restore-pump-support', whenStates:['support-lost','worsened'], outcome:'preferred', score:25,
          feedback:'Pump support is restored using the available backup / emergency pathway. Circuit flow returns and systemic support begins to recover.',
          rationale:'Restore effective pump support using the device-appropriate backup/emergency pathway. Pump-specific emergency behavior matters; a hand-crank is not a universal solution for all pump types or failure modes.',
          effects:{internal:{supportFlowMultiplier:{set:1},mapBaseline:{add:10}},eventState:'resolved',resolve:true}
        },
        {
          actionId:'increase-rpm', whenStates:['support-lost','worsened'], outcome:'ineffective', score:-4,
          feedback:'Changing the RPM command does not restore effective pump output.',
          rationale:'A failed or nonfunctional pump requires restoration of effective pump function/support; increasing a commanded RPM setpoint alone cannot correct loss of actual pump output.'
        }
      ],
      timeRules:[
        {
          fromState:'support-lost', afterSec:60, toState:'worsened',
          effects:{internal:{mapBaseline:{add:-10}}},
          feedback:'Loss of effective extracorporeal support progresses to profound cardiovascular deterioration.'
        }
      ]
    }
  },
  {
    kind:'complication', id:'air-emergency', label:"Air entrainment / circuit air emergency",
    tags:["circuit","air","emergency"],
    definition:{
      id:'air-emergency', label:"Air entrainment / circuit air emergency", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.55}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}}, managed:{dimensions:{"perfusion":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"perfusion":"absent","circuitSupport":"absent"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"inspect-for-air","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":8,"feedback":"Circuit inspection confirms clinically significant air / entrainment clues requiring immediate source control.","rationale":"Rapidly identify where air entered and whether gross air is present. ELSO circuit guidance emphasizes immediate control of massive air, source correction, and safe de-airing rather than continuing contaminated flow."},
        {"actionId":"isolate-air-source","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The source of air entrainment is isolated and further air entry stops.","rationale":"Stop ongoing air entry immediately. With massive/gross circuit air, immediate circuit isolation/clamping may be required while the source is addressed; do not propel contaminated circuit contents forward.","effects":{"eventState":"contained"}},
        {"actionId":"manage-air-emergency","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"The circuit air-emergency response is completed and effective extracorporeal support is safely restored.","rationale":"Definitive management addresses the air source, removes/de-airs the circuit hazard, and exchanges affected pump/circuit components when needed before safe support is restored. A contaminated pump should not be hand-cranked in a massive-air event.","effects":{"internal":{"supportFlowMultiplier":{"set":1},"thrombusBurdenGrade":{"set":"controlled"},"thrombusLocationPattern":{"set":"managed"}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":90,"toState":"critical","feedback":"The unresolved air emergency progresses to severe loss of safe extracorporeal support."}
      ]
    }
  },
  {
    kind:'complication', id:'circuit-breach-hemorrhage', label:"Circuit breach / disconnection with major blood loss",
    tags:["circuit","hemorrhage","emergency"],
    definition:{
      id:'circuit-breach-hemorrhage', label:"Circuit breach / disconnection with major blood loss", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.35},"mapBaseline":{"add":-10},"cvpBaseline":{"add":-3}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"absent","bleeding":"critical","circuitSupport":"absent"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"control-circuit-breach","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"The circuit breach is immediately controlled, limiting further blood loss and loss of support.","rationale":"Rapid mechanical control is the first priority in a circuit breach.","effects":{"eventState":"controlled"}},
        {"actionId":"restore-circuit-integrity","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained","controlled"],"outcome":"preferred","score":25,"feedback":"Circuit integrity is restored and extracorporeal support recovers while hemorrhage resuscitation continues.","rationale":"Definitive restoration of the circuit treats the mechanical cause of support loss.","effects":{"internal":{"supportFlowMultiplier":{"set":1},"mapBaseline":{"add":8},"cvpBaseline":{"add":2}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-10,"feedback":"Increasing RPM does not correct the circuit breach and may worsen blood loss or loss of effective support.","rationale":"A mechanical breach requires immediate control, not higher pump speed."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":60,"toState":"critical","feedback":"Ongoing circuit blood loss and support failure progress rapidly."}
      ]
    }
  },
  {
    kind:'complication', id:'oxygenator-thrombosis-failure', label:"Oxygenator thrombosis / membrane-lung failure",
    tags:["oxygenator","thrombosis","gas-exchange"],
    definition:{
      id:'oxygenator-thrombosis-failure', label:"Oxygenator thrombosis / membrane-lung failure", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":55},"clinicalPaco2Target":{"set":58},"oxygenatorDeltaPAddMmHg":{"set":35},"postOxyPao2Target":{"set":135}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","ventilation":"impaired","circuitSupport":"impaired"}},
        recognized:{dimensions:{"oxygenation":"critical","ventilation":"impaired","circuitSupport":"impaired"}}, controlled:{dimensions:{"oxygenation":"impaired","ventilation":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","ventilation":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","ventilation":"impaired","circuitSupport":"impaired"}}, evaluated:{dimensions:{"oxygenation":"critical","ventilation":"impaired","circuitSupport":"impaired"}}, managed:{dimensions:{"oxygenation":"impaired","ventilation":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","ventilation":"impaired","circuitSupport":"impaired"}},
        worsened:{dimensions:{"oxygenation":"critical","ventilation":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"oxygenation":"critical","ventilation":"critical","circuitSupport":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-oxygenator","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment shows a clinically significant oxygenator performance / resistance pattern requiring definitive planning.","rationale":"Evaluating gas transfer and circuit pressure behavior distinguishes membrane-lung failure from patient-only causes.","effects":{"eventState":"recognized"}},
        {"actionId":"exchange-oxygenator","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":25,"feedback":"The failing oxygenator / affected circuit component is exchanged and gas transfer returns toward effective support.","rationale":"When the oxygenator no longer provides adequate blood passage or gas transfer, or creates clinically important burden, component exchange is definitive management; unnecessary change-outs should still be avoided.","effects":{"internal":{"clinicalPao2Target":{"set":null},"clinicalPaco2Target":{"set":null},"oxygenatorDeltaPAddMmHg":{"set":0},"postOxyPao2Target":{"set":450}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-sweep","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"temporizing","score":3,"feedback":"Increasing sweep produces limited or incomplete improvement while the underlying oxygenator problem persists.","rationale":"A brief sweep increase can help clear condensation or a gas-path obstruction and may transiently improve CO2 transfer; it does not reverse persistent structural membrane-lung failure or clot burden."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":40},"clinicalPaco2Target":{"set":68},"oxygenatorDeltaPAddMmHg":{"set":60},"postOxyPao2Target":{"set":90}}},"feedback":"Oxygenator dysfunction progresses with worsening effective gas exchange and circuit performance."},
        {"fromState":"worsened","afterSec":150,"toState":"critical","effects":{"internal":{"clinicalPao2Target":{"set":30},"mapBaseline":{"add":-6},"oxygenatorDeltaPAddMmHg":{"set":85},"postOxyPao2Target":{"set":60}}},"feedback":"Severe oxygenator failure produces critical gas-exchange and hemodynamic compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'sweep-gas-failure', label:"Sweep gas / gas-source failure",
    tags:["gas","oxygenator","ventilation"],
    definition:{
      id:'sweep-gas-failure', label:"Sweep gas / gas-source failure", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPaco2Target":{"set":75}}},
      trajectoryByState:{
        active:{dimensions:{"ventilation":"critical"}},
        recognized:{dimensions:{"ventilation":"critical"}}, controlled:{dimensions:{"ventilation":"impaired"}}, contained:{dimensions:{"ventilation":"impaired"}}, identified:{dimensions:{"ventilation":"critical"}}, evaluated:{dimensions:{"ventilation":"critical"}}, managed:{dimensions:{"ventilation":"impaired"}}, verified:{dimensions:{"ventilation":"critical"}},
        worsened:{dimensions:{"ventilation":"critical"}}, critical:{dimensions:{"ventilation":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"verify-sweep-gas","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Inspection identifies loss or interruption of effective sweep-gas delivery.","rationale":"Verify the complete gas-delivery path—source, blender/flowmeter, tubing, connections, and oxygenator gas inlet—because effective sweep delivery is required for extracorporeal CO2 removal.","effects":{"eventState":"identified"}},
        {"actionId":"restore-sweep-gas","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"Sweep-gas delivery is restored and CO2 removal recovers.","rationale":"Restoring effective gas flow to the oxygenator restores the mechanism that controls extracorporeal CO2 removal; sweep changes must remain within the oxygenator manufacturer’s stated limits.","effects":{"internal":{"clinicalPaco2Target":{"set":null}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-sweep","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"ineffective","score":-2,"feedback":"Changing the sweep setting does not help while effective gas delivery remains interrupted.","rationale":"Increasing a commanded sweep setting cannot improve CO2 clearance if gas is not actually reaching the oxygenator. First restore effective gas delivery; do not exceed the oxygenator manufacturer’s sweep-gas limits."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":150,"toState":"worsened","effects":{"internal":{"clinicalPaco2Target":{"set":95}}},"feedback":"Unaddressed sweep-gas failure produces worsening hypercarbia."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"clinicalPaco2Target":{"set":110},"mapBaseline":{"add":-6}}},"feedback":"Severe unaddressed hypercarbia produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'hemolysis', label:"Clinically significant hemolysis",
    tags:["blood","hemolysis","circuit"],
    definition:{
      id:'hemolysis', label:"Clinically significant hemolysis", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"trueLatent.hgbGdl":{"add":-1.5},"hrCurrent":{"add":10}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}},
        recognized:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, controlled:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, identified:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, evaluated:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, managed:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, verified:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}},
        worsened:{dimensions:{"perfusion":"critical","neurologicRisk":"critical"}}, critical:{dimensions:{"perfusion":"critical","neurologicRisk":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-hemolysis","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"The available laboratory, urine, and circuit findings support clinically significant hemolysis and prompt a search for the mechanical cause.","rationale":"Hemolysis is a consequence pattern. Assess plasma-free hemoglobin/hemolysis trend together with circuit resistance, cannula pressure-drop/flow behavior, visible clot burden, drainage conditions, and pump mechanics to localize ongoing blood trauma.","effects":{"eventState":"recognized"}},
        {"actionId":"correct-hemolysis-source","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"The clinically significant source of mechanical blood trauma is corrected and ongoing hemolysis begins to abate.","rationale":"Definitive management requires correction of the underlying mechanical/circuit cause; component change should be considered when clot burden or device dysfunction is accompanied by hemolysis, impaired flow, coagulopathy burden, or inadequate support.","effects":{"internal":{"trueLatent.hgbGdl":{"add":1},"hrCurrent":{"add":-10}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-6,"feedback":"Higher pump speed does not treat hemolysis and may worsen mechanical blood trauma when adverse drainage or resistance is present.","rationale":"Escalating pump speed without correcting adverse drainage, excessive resistance, obstruction, or device dysfunction can increase mechanical blood trauma; flow/RPM decisions must be interpreted with the full circuit-pressure and drainage context."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"trueLatent.hgbGdl":{"add":-1.5},"mapBaseline":{"add":-3},"hrCurrent":{"add":10}}},"feedback":"Ongoing unaddressed hemolysis worsens anemia and hemodynamic strain."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"trueLatent.hgbGdl":{"add":-1.5},"mapBaseline":{"add":-4},"trueLatent.lactateMmolL":{"add":1}}},"feedback":"Severe ongoing hemolysis produces critical anemia and hemodynamic compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'major-bleeding', label:"Major bleeding / coagulopathic hemorrhage",
    tags:["bleeding","hemorrhage"],
    definition:{
      id:'major-bleeding', label:"Major bleeding / coagulopathic hemorrhage", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-8},"cvpBaseline":{"add":-2},"trueLatent.hgbGdl":{"add":-2}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","bleeding":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical","bleeding":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"absent","bleeding":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"control-major-bleeding","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Major hemorrhage management is initiated with source control and clinically appropriate resuscitation.","rationale":"Control the bleeding source and maintain perfusion while correcting clinically important hemostatic deficits. Anticoagulation reduction/cessation may be necessary in significant bleeding, but requires repeated reassessment of circuit thrombus burden and the need to restart anticoagulation.","effects":{"eventState":"controlled"}},
        {"actionId":"reduce-anticoagulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained","controlled"],"outcome":"acceptable","score":8,"feedback":"Anticoagulation is reassessed and adjusted in the context of active major bleeding.","rationale":"Anticoagulation reduction or temporary cessation may be appropriate for excessive bleeding, but it does not replace source control and must be balanced against circuit/patient thrombosis risk with frequent reassessment."},
        {"actionId":"control-major-bleeding","whenStates":["controlled"],"outcome":"preferred","score":20,"feedback":"Bleeding is brought under control and hemodynamic support begins to recover.","rationale":"Definitive hemorrhage control resolves the active bleeding state.","effects":{"internal":{"mapBaseline":{"add":7},"cvpBaseline":{"add":2}},"eventState":"resolved","resolve":true}}
      ]
    }
  },
  {
    kind:'complication', id:'intracranial-hemorrhage', label:"Intracranial hemorrhage",
    tags:["neurologic","bleeding"],
    definition:{
      id:'intracranial-hemorrhage', label:"Intracranial hemorrhage", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"hrCurrent":{"add":10}}},
      trajectoryByState:{
        active:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}},
        recognized:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}}, controlled:{dimensions:{"neurologicRisk":"impaired","bleeding":"impaired"}}, contained:{dimensions:{"neurologicRisk":"impaired","bleeding":"impaired"}}, identified:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}}, evaluated:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}}, managed:{dimensions:{"neurologicRisk":"impaired","bleeding":"impaired"}}, verified:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}},
        worsened:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}}, critical:{dimensions:{"neurologicRisk":"critical","bleeding":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"neuro-assessment","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Focused neurologic assessment identifies an acute concerning change requiring urgent evaluation.","rationale":"An acute neurologic change on ECMO requires urgent neurologic consultation and focused examination while avoiding premature prognostication from confounded findings alone.","effects":{"eventState":"suspected"}},
        {"actionId":"urgent-neuro-imaging","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"Urgent imaging confirms an acute intracranial bleeding process.","rationale":"Urgent non-contrast head CT is recommended when acute intracranial hemorrhage is suspected; imaging establishes the diagnosis and guides multidisciplinary neurocritical-care and anticoagulation decisions.","effects":{"eventState":"diagnosed"}},
        {"actionId":"reduce-anticoagulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained","controlled"],"outcome":"acceptable","score":8,"feedback":"Anticoagulation is urgently reassessed in the context of intracranial bleeding, and the trajectory toward worsening mass effect slows.","rationale":"Acute intracranial hemorrhage generally requires early cessation/reassessment of systemic anticoagulation and careful resumption with repeated neuroimaging. VA ECMO carries higher thromboembolic/circuit risk during anticoagulation interruption than VV ECMO.","effects":{"internal":{"mapBaseline":{"add":-3}},"eventState":"controlled"}},
        {"actionId":"treat-neurologic-emergency","whenStates":["diagnosed","controlled"],"outcome":"preferred","score":22,"feedback":"The acute intracranial hemorrhage response is escalated with neurocritical care, bleeding-risk management, and definitive multidisciplinary stabilization measures. The immediate deterioration threat is controlled.","rationale":"The simulator endpoint represents control of the acute threat, not disappearance of the hemorrhage.","effects":{"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":240,"toState":"worsened","effects":{"internal":{"mapBaseline":{"add":6},"hrCurrent":{"add":-15},"trueLatent.hgbGdl":{"add":-0.5}}},"feedback":"Rising intracranial pressure produces early Cushing-reflex physiology (rising pressure, falling heart rate) as bleeding continues."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-20},"hrCurrent":{"add":-30}}},"feedback":"Decompensation and herniation physiology produce hemodynamic collapse."}
      ]
    }
  },
  {
    kind:'complication', id:'thromboembolism-stroke', label:"Thromboembolism / ischemic stroke",
    tags:["neurologic","thrombosis"],
    definition:{
      id:'thromboembolism-stroke', label:"Thromboembolism / ischemic stroke", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"hrCurrent":{"add":8},"mapBaseline":{"add":5}}},
      trajectoryByState:{
        active:{dimensions:{"neurologicRisk":"critical"}},
        recognized:{dimensions:{"neurologicRisk":"critical"}}, controlled:{dimensions:{"neurologicRisk":"impaired"}}, contained:{dimensions:{"neurologicRisk":"impaired"}}, identified:{dimensions:{"neurologicRisk":"critical"}}, evaluated:{dimensions:{"neurologicRisk":"critical"}}, managed:{dimensions:{"neurologicRisk":"impaired"}}, verified:{dimensions:{"neurologicRisk":"critical"}},
        worsened:{dimensions:{"neurologicRisk":"critical"}}, critical:{dimensions:{"neurologicRisk":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"neuro-assessment","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Focused neurologic assessment confirms an acute focal or global change requiring urgent stroke evaluation.","rationale":"Rapid recognition and focused neurologic examination are essential because ischemic stroke, hemorrhage, seizure, and global hypoperfusion require different emergency pathways.","effects":{"eventState":"suspected"}},
        {"actionId":"urgent-neuro-imaging","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"Urgent imaging identifies an acute ischemic / thromboembolic neurologic event.","rationale":"Urgent brain imaging distinguishes ischemic injury from hemorrhage and guides stroke, anticoagulation, and neurocritical-care decisions. ECMO does not remove the need for time-sensitive stroke evaluation.","effects":{"eventState":"diagnosed"}},
        {"actionId":"stroke-escalation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":15,"feedback":"The multidisciplinary stroke / neurologic emergency pathway is activated and further evolution is limited.","rationale":"Definitive stroke management depends on event type, timing, vessel status, anticoagulation, bleeding risk, ECMO mode, and candidacy for reperfusion or neurointerventional therapy; no single ECMO-specific stroke treatment fits every case.","effects":{"internal":{"hrCurrent":{"add":-8}},"eventState":"managed"}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"hrCurrent":{"add":10},"mapBaseline":{"add":-6}}},"feedback":"Ongoing untreated cerebral ischemia produces worsening autonomic instability."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-10},"trueLatent.lactateMmolL":{"add":0.8}}},"feedback":"Extending or unrecognized infarction produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'circuit-systemic-thrombosis', label:"Circuit / cannula / intracardiac thrombosis",
    tags:["thrombosis","circuit"],
    definition:{
      id:'circuit-systemic-thrombosis', label:"Circuit / cannula / intracardiac thrombosis", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.7},"thrombusLocationPattern":{"set":"circuit-or-cannula-burden"},"thrombusBurdenGrade":{"set":"clinically-significant"}}},
      trajectoryByState:{
        active:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}},
        recognized:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, controlled:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, contained:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, identified:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, evaluated:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, managed:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, verified:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}},
        worsened:{dimensions:{"circuitSupport":"critical","perfusion":"critical"}}, critical:{dimensions:{"circuitSupport":"critical","perfusion":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-thrombosis","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment identifies clinically important thrombotic burden requiring definitive management planning.","rationale":"Define thrombus location, growth, pressure/flow consequences, hemolysis, patient embolic risk, and circuit performance before choosing anticoagulation adjustment, component exchange, or other intervention.","effects":{"eventState":"recognized"}},
        {"actionId":"manage-thrombosis","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"A definitive thrombosis-management pathway is initiated and the immediate threat is controlled.","rationale":"Management targets the actual thrombus burden and its circuit/patient consequences. Anticoagulation escalation alone does not substitute for component exchange when thrombus causes clinically important obstruction, hemolysis, or device dysfunction.","effects":{"internal":{"supportFlowMultiplier":{"set":1}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-5,"feedback":"Increasing pump speed does not remove thrombotic obstruction and may increase circuit stress.","rationale":"Mechanical or thrombotic obstruction requires targeted management."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":210,"toState":"worsened","effects":{"internal":{"supportFlowMultiplier":{"set":0.45}}},"feedback":"Growing thrombus burden progressively reduces effective circuit support."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"supportFlowMultiplier":{"set":0.2}}},"feedback":"Critical thrombotic obstruction severely limits effective ECMO support."}
      ]
    }
  },
  {
    kind:'complication', id:'anticoagulation-management', label:"Clinically significant anticoagulation imbalance",
    tags:["anticoagulation"],
    definition:{
      id:'anticoagulation-management', label:"Clinically significant anticoagulation imbalance", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"trueLatent.hgbGdl":{"add":-0.5}}},
      trajectoryByState:{
        active:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}},
        recognized:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, controlled:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, evaluated:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, managed:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"bleeding":"impaired","circuitSupport":"impaired"}},
        worsened:{dimensions:{"bleeding":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"bleeding":"critical","circuitSupport":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-anticoagulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Anticoagulation, bleeding, thrombosis, laboratory trends, and clinical context are reviewed together.","rationale":"Anticoagulation monitoring must be individualized using drug-specific/plasma testing, whole-blood/hemostatic assessment where appropriate, bleeding and thrombosis risk, organ dysfunction, inflammation, and circuit findings rather than a single isolated number.","effects":{"eventState":"recognized"}},
        {"actionId":"adjust-anticoagulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"Anticoagulation is adjusted according to the applicable protocol and clinical risk context.","rationale":"Adjust anticoagulation using the governing protocol and the patient/circuit risk context. A single ACT, aPTT, anti-Xa, or viscoelastic result should not be interpreted in isolation from the full clinical picture.","effects":{"internal":{"trueLatent.hgbGdl":{"add":0.5}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"trueLatent.hgbGdl":{"add":-1},"mapBaseline":{"add":-4}}},"feedback":"An unmanaged anticoagulation imbalance produces worsening bleeding and hemodynamic strain."},
        {"fromState":"worsened","afterSec":150,"toState":"critical","effects":{"internal":{"trueLatent.hgbGdl":{"add":-1},"mapBaseline":{"add":-6}}},"feedback":"Ongoing imbalance produces critical bleeding-related compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'vv-recirculation', label:"VV ECMO recirculation / ineffective support",
    tags:["VV","recirculation","gas-exchange"],
    definition:{
      id:'vv-recirculation', label:"VV ECMO recirculation / ineffective support", initialState:'active', hidden:true,
      applicability:["VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":65},"recirculationFractionTarget":{"set":0.48},"drainageSatTarget":{"set":86},"returnSatTarget":{"set":98},"systemicSpo2Target":{"set":84}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","circuitSupport":"impaired"}},
        recognized:{dimensions:{"oxygenation":"critical","circuitSupport":"impaired"}}, controlled:{dimensions:{"oxygenation":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","circuitSupport":"impaired"}}, evaluated:{dimensions:{"oxygenation":"critical","circuitSupport":"impaired"}}, managed:{dimensions:{"oxygenation":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","circuitSupport":"impaired"}},
        worsened:{dimensions:{"oxygenation":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"oxygenation":"critical","circuitSupport":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-recirculation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment identifies a pattern consistent with significant recirculation / ineffective VV support.","rationale":"Evaluate cannula relationship, drainage/pre-oxygenator saturation or blood color, systemic oxygen delivery, and the response to flow changes. Recirculation is suggested by unusually oxygenated drainage blood and can paradoxically worsen systemic saturation as VV flow is increased.","effects":{"eventState":"recognized"}},
        {"actionId":"correct-recirculation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"Cannula / flow configuration is corrected and effective systemic oxygen delivery improves.","rationale":"Correct cannula position/configuration and flow conditions to reduce re-drainage of oxygenated return blood and increase effective flow delivered to the patient.","effects":{"internal":{"clinicalPao2Target":{"set":null},"recirculationFractionTarget":{"set":0.18},"drainageSatTarget":{"set":72},"returnSatTarget":{"set":98},"systemicSpo2Target":{"set":94}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-5,"feedback":"More pump speed does not reliably improve systemic oxygenation and may worsen recirculation.","rationale":"More commanded flow is not automatically more effective flow. When cannula geometry promotes recirculation, increasing flow can increase the recirculated fraction and may paradoxically reduce systemic oxygenation."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":240,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":50},"hrCurrent":{"add":10}}},"feedback":"Unaddressed recirculation produces worsening systemic hypoxemia."},
        {"fromState":"worsened","afterSec":120,"toState":"critical","effects":{"internal":{"clinicalPao2Target":{"set":40},"mapBaseline":{"add":-5}}},"feedback":"Severe unaddressed hypoxemia produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'va-differential-hypoxemia', label:"VA differential hypoxemia / North-South syndrome",
    tags:["VA","oxygenation"],
    definition:{
      id:'va-differential-hypoxemia', label:"VA differential hypoxemia / North-South syndrome", initialState:'active', hidden:true,
      applicability:["VA"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":60},"rightRadialSpo2Target":{"set":82},"lowerBodySpo2Target":{"set":98},"rightRadialPao2Target":{"set":48},"lowerBodyPao2Target":{"set":180},"mixingZonePattern":{"set":"mixing-point-below-upper-body"}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}},
        recognized:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}}, controlled:{dimensions:{"oxygenation":"impaired","neurologicRisk":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","neurologicRisk":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}}, evaluated:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}}, managed:{dimensions:{"oxygenation":"impaired","neurologicRisk":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}},
        worsened:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}}, critical:{dimensions:{"oxygenation":"critical","neurologicRisk":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-differential-hypoxemia","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Upper- and lower-body oxygenation assessment identifies clinically important differential oxygenation.","rationale":"Monitor oxygenation from the right arm/right radial arterial circulation to detect proximal aortic-arch hypoxemia that lower-body measurements may miss. Differential oxygenation reflects competition between native LV output and retrograde ECMO flow.","effects":{"eventState":"recognized"}},
        {"actionId":"correct-differential-hypoxemia","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"A strategy is initiated to improve oxygen delivery to the threatened upper-body circulation.","rationale":"Optimize native lung oxygenation/ventilation and reassess the mixing pattern. If clinically important upper-body hypoxemia persists, an alternate return/support configuration such as VAV may be required; avoid relying on a lower-body saturation alone.","effects":{"internal":{"clinicalPao2Target":{"set":null},"rightRadialSpo2Target":{"set":96},"lowerBodySpo2Target":{"set":97},"rightRadialPao2Target":{"set":95},"lowerBodyPao2Target":{"set":110},"mixingZonePattern":{"set":"adequate-upper-body-oxygen-delivery"}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":240,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":45},"rightRadialSpo2Target":{"set":75},"rightRadialPao2Target":{"set":38},"lowerBodySpo2Target":{"set":98},"lowerBodyPao2Target":{"set":175},"hrCurrent":{"add":10}}},"feedback":"Unaddressed upper-body hypoxemia worsens, threatening coronary and cerebral oxygen delivery."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"clinicalPao2Target":{"set":35},"rightRadialSpo2Target":{"set":68},"rightRadialPao2Target":{"set":30},"lowerBodySpo2Target":{"set":97},"lowerBodyPao2Target":{"set":165},"mapBaseline":{"add":-8}}},"feedback":"Severe unaddressed differential hypoxemia produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'va-lv-distension', label:"VA ECMO LV distension / inadequate unloading",
    tags:["VA","cardiac","unloading"],
    definition:{
      id:'va-lv-distension', label:"VA ECMO LV distension / inadequate unloading", initialState:'active', hidden:true,
      applicability:["VA"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"cvpBaseline":{"add":4},"clinicalPao2Target":{"set":80},"lvDistensionGrade":{"set":"moderate"},"aorticValveOpening":{"set":"minimal"},"pulmonaryCongestionGrade":{"set":"moderate"}}},
      trajectoryByState:{
        active:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired","circuitSupport":"impaired"}},
        recognized:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired","circuitSupport":"impaired"}}, controlled:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired","circuitSupport":"impaired"}}, evaluated:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired","circuitSupport":"impaired"}}, managed:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired","circuitSupport":"impaired"}},
        worsened:{dimensions:{"hemodynamics":"critical","oxygenation":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"hemodynamics":"absent","oxygenation":"critical","circuitSupport":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-lv-distension","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment identifies clinically important LV distension / inadequate ejection with risk of pulmonary congestion and stasis.","rationale":"Assess arterial pulsatility/pulse pressure, aortic-valve opening, LV/LA distension, spontaneous-echo-contrast or stasis, filling pressures, and pulmonary edema. These findings collectively determine the need and urgency for LV unloading.","effects":{"eventState":"recognized"}},
        {"actionId":"initiate-lv-unloading","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"An appropriate LV unloading strategy is initiated and the consequences of distension begin to improve.","rationale":"Reduce LV pressure/volume burden while preserving systemic perfusion. ELSO describes stepwise options ranging from less-invasive measures (flow optimization, inotropy/vasodilation, PEEP/diuresis where appropriate) to catheter-based or surgical venting when inadequate unloading persists.","effects":{"internal":{"cvpBaseline":{"add":-4},"clinicalPao2Target":{"set":null},"lvDistensionGrade":{"set":"improved"},"aorticValveOpening":{"set":"improved"},"pulmonaryCongestionGrade":{"set":"improving"}},"eventState":"resolved","resolve":true}},
        {"actionId":"volume-bolus","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-8,"feedback":"Additional volume worsens congestion without correcting inadequate LV unloading.","rationale":"Volume loading may aggravate ventricular distension and pulmonary edema in this context."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":180,"toState":"worsened","effects":{"internal":{"cvpBaseline":{"add":5},"clinicalPao2Target":{"set":65},"mapBaseline":{"add":-6},"lvDistensionGrade":{"set":"severe"},"aorticValveOpening":{"set":"absent-or-intermittent"},"pulmonaryCongestionGrade":{"set":"severe"}}},"feedback":"Unrelieved LV distension worsens pulmonary congestion and hemodynamic strain."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-15},"clinicalPao2Target":{"set":50}}},"feedback":"Severe unrelieved distension produces critical cardiopulmonary compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'limb-ischemia', label:"Peripheral cannulation limb ischemia",
    tags:["VA","vascular"],
    definition:{
      id:'limb-ischemia', label:"Peripheral cannulation limb ischemia", initialState:'active', hidden:true,
      applicability:["VA"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"hrCurrent":{"add":8},"distalPulseStatus":{"set":"absent-doppler"},"limbTemperatureStatus":{"set":"cool"},"limbColorStatus":{"set":"pale-mottled"},"distalPerfusionConcern":{"set":"high"}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","neurologicRisk":"impaired"}},
        recognized:{dimensions:{"perfusion":"critical","neurologicRisk":"impaired"}}, controlled:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, identified:{dimensions:{"perfusion":"critical","neurologicRisk":"impaired"}}, evaluated:{dimensions:{"perfusion":"critical","neurologicRisk":"impaired"}}, managed:{dimensions:{"perfusion":"impaired","neurologicRisk":"impaired"}}, verified:{dimensions:{"perfusion":"critical","neurologicRisk":"impaired"}},
        worsened:{dimensions:{"perfusion":"critical","neurologicRisk":"critical"}}, critical:{dimensions:{"perfusion":"absent","neurologicRisk":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-limb-perfusion","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Distal perfusion assessment identifies clinically significant limb ischemia requiring urgent correction.","rationale":"Use close distal-perfusion monitoring—clinical limb comparison, Doppler/flow assessment, and NIRS where available—to identify threatened perfusion early. Peripheral femoral VA ECMO requires active surveillance of the cannulated limb.","effects":{"eventState":"recognized"}},
        {"actionId":"restore-limb-perfusion","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"Distal perfusion is restored or the cannulation-related cause is corrected.","rationale":"Restore distal limb blood flow promptly by correcting the cannulation/perfusion problem. Distal perfusion catheter function, arterial obstruction, thrombosis, compartment syndrome, and need for revascularization/fasciotomy should be considered according to the cause and severity.","effects":{"internal":{"hrCurrent":{"add":-8},"distalPulseStatus":{"set":"doppler-restored"},"limbTemperatureStatus":{"set":"warming"},"limbColorStatus":{"set":"improving"},"distalPerfusionConcern":{"set":"resolved"}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"trueLatent.lactateMmolL":{"add":0.8},"hrCurrent":{"add":10},"limbColorStatus":{"set":"dusky-mottled"},"limbTemperatureStatus":{"set":"cold"},"distalPerfusionConcern":{"set":"worsening"}}},"feedback":"Prolonged unaddressed limb ischemia produces worsening tissue injury and systemic effects."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"trueLatent.lactateMmolL":{"add":1.5},"mapBaseline":{"add":-8}}},"feedback":"Severe ischemia-reperfusion effects produce systemic hemodynamic compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'pneumothorax-intrathoracic-pressure', label:"Pneumothorax / tension physiology impairing support",
    tags:["respiratory","mechanical","low-flow"],
    definition:{
      id:'pneumothorax-intrathoracic-pressure', label:"Pneumothorax / tension physiology impairing support", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.55},"mapBaseline":{"add":-8}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}},
        recognized:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}}, controlled:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}}, evaluated:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}}, managed:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}},
        worsened:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"oxygenation":"critical","hemodynamics":"absent","circuitSupport":"absent"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-thorax","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment identifies a thoracic pressure / pneumothorax pattern that explains acute respiratory and support deterioration.","rationale":"A tension process can impair ventilation, venous return, and ECMO drainage simultaneously.","effects":{"eventState":"recognized"}},
        {"actionId":"decompress-chest","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":25,"feedback":"Emergency pleural decompression relieves the pressure problem and effective ventilation / venous return improve.","rationale":"Immediate decompression treats tension physiology.","effects":{"internal":{"supportFlowMultiplier":{"set":1},"mapBaseline":{"add":8}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-8,"feedback":"Increasing RPM does not correct the thoracic mechanical problem and drainage remains compromised.","rationale":"The limiting issue is impaired venous return from intrathoracic pressure, not insufficient pump speed."}
      ]
    }
  },
  {
    kind:'complication', id:'airway-ventilator-failure', label:"Airway / ETT / ventilator failure",
    tags:["respiratory","airway"],
    definition:{
      id:'airway-ventilator-failure', label:"Airway / ETT / ventilator failure", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":50},"clinicalPaco2Target":{"set":65}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","ventilation":"critical"}},
        recognized:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, controlled:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, evaluated:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, managed:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","ventilation":"critical"}},
        worsened:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, critical:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-airway-ventilator","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Airway and ventilator assessment identifies a clinically significant mechanical ventilation problem.","rationale":"Rapidly assess the airway, endotracheal tube, ventilator circuit, pressures, and lung mechanics to identify a correctable mechanical failure. VV ECMO should permit lung-protective ventilation, but an acute airway/ventilator failure still requires direct correction.","effects":{"eventState":"recognized"}},
        {"actionId":"restore-airway-ventilation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":22,"feedback":"The airway / ventilator problem is corrected and native pulmonary gas exchange improves.","rationale":"Correct the airway/ventilator mechanical failure while maintaining lung-protective ventilation. Do not compensate for inadequate ECMO gas exchange by simply escalating ventilator intensity beyond the chosen protective strategy.","effects":{"internal":{"clinicalPao2Target":{"set":null},"clinicalPaco2Target":{"set":null}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":150,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":38},"clinicalPaco2Target":{"set":80},"hrCurrent":{"add":15}}},"feedback":"Unaddressed airway/ventilator failure produces worsening hypoxemia and hypercarbia."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-10}}},"feedback":"Severe unaddressed respiratory failure produces critical hemodynamic compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'pulmonary-hemorrhage', label:"Pulmonary hemorrhage",
    tags:["respiratory","bleeding"],
    definition:{
      id:'pulmonary-hemorrhage', label:"Pulmonary hemorrhage", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":55},"trueLatent.hgbGdl":{"add":-1}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","bleeding":"critical"}},
        recognized:{dimensions:{"oxygenation":"critical","bleeding":"critical"}}, controlled:{dimensions:{"oxygenation":"impaired","bleeding":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","bleeding":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","bleeding":"critical"}}, evaluated:{dimensions:{"oxygenation":"critical","bleeding":"critical"}}, managed:{dimensions:{"oxygenation":"impaired","bleeding":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","bleeding":"critical"}},
        worsened:{dimensions:{"oxygenation":"critical","bleeding":"critical"}}, critical:{dimensions:{"oxygenation":"critical","bleeding":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"manage-pulmonary-hemorrhage","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Pulmonary hemorrhage management is initiated with airway protection, bleeding control, and support optimization.","rationale":"The immediate priorities are oxygenation, airway safety, hemorrhage control, and anticoagulation reassessment.","effects":{"eventState":"controlled"}},
        {"actionId":"reduce-anticoagulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained","controlled"],"outcome":"acceptable","score":8,"feedback":"Anticoagulation is urgently reassessed in the setting of active pulmonary bleeding.","rationale":"Adjustment may be required but must be balanced against circuit thrombosis risk."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":150,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":40},"trueLatent.hgbGdl":{"add":-1.5},"mapBaseline":{"add":-6}}},"feedback":"Ongoing pulmonary hemorrhage worsens oxygenation, anemia, and hemodynamic stability."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"trueLatent.hgbGdl":{"add":-1.5},"mapBaseline":{"add":-8}}},"feedback":"Massive ongoing pulmonary hemorrhage produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'gas-exchange-failure', label:"Clinically significant gas-exchange failure",
    tags:["gas-exchange"],
    definition:{
      id:'gas-exchange-failure', label:"Clinically significant gas-exchange failure", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"clinicalPao2Target":{"set":55},"clinicalPaco2Target":{"set":60}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","ventilation":"impaired"}},
        recognized:{dimensions:{"oxygenation":"critical","ventilation":"impaired"}}, controlled:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","ventilation":"impaired"}}, evaluated:{dimensions:{"oxygenation":"critical","ventilation":"impaired"}}, managed:{dimensions:{"oxygenation":"impaired","ventilation":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","ventilation":"impaired"}},
        worsened:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, critical:{dimensions:{"oxygenation":"critical","ventilation":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-gas-exchange","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Gas-exchange assessment confirms a clinically significant oxygenation / ventilation problem and narrows whether the cause is patient, circuit, or settings related.","rationale":"Localize inadequate oxygen delivery or CO2 clearance by assessing effective ECMO flow relative to cardiac output, recirculation, hemoglobin/oxygen content, metabolic demand, sweep gas, membrane-lung function, and native lung contribution rather than reacting to saturation alone.","effects":{"eventState":"recognized"}},
        {"actionId":"correct-gas-exchange","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The identified gas-exchange support problem is corrected and effective oxygenation / ventilation improve.","rationale":"Target the identified limiting mechanism. On VV ECMO, inadequate oxygenation/ventilation should primarily be corrected through effective extracorporeal support and cause-directed management rather than indiscriminately increasing injurious ventilator settings.","effects":{"internal":{"clinicalPao2Target":{"set":null},"clinicalPaco2Target":{"set":null}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":210,"toState":"worsened","effects":{"internal":{"clinicalPao2Target":{"set":40},"clinicalPaco2Target":{"set":75},"hrCurrent":{"add":10}}},"feedback":"Unaddressed gas-exchange failure worsens hypoxemia and hypercarbia."},
        {"fromState":"worsened","afterSec":120,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-8}}},"feedback":"Severe unaddressed gas-exchange failure produces critical instability."}
      ]
    }
  },
  {
    kind:'complication', id:'arrhythmia-arrest', label:"Clinically significant arrhythmia / arrest",
    tags:["cardiac","rhythm","arrest"],
    definition:{
      id:'arrhythmia-arrest', label:"Clinically significant arrhythmia / arrest", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-8},"hrCurrent":{"add":-20}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"absent"}, arrest:true}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"manage-arrhythmia","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The clinically significant rhythm disturbance is treated using the appropriate resuscitation / rhythm-management pathway.","rationale":"Treat the identified rhythm using the current resuscitation/rhythm algorithm and address reversible causes. ECMO support does not eliminate the need for rhythm-specific treatment such as defibrillation for VF/pVT when indicated.","effects":{"internal":{"mapBaseline":{"add":6},"hrCurrent":{"add":15}},"eventState":"managed"}},
        {"actionId":"resuscitate-arrest","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":25,"feedback":"The arrest rescue pathway is initiated while reversible causes and adequacy of extracorporeal support are addressed.","rationale":"Verify whether effective systemic circulation is actually being provided by ECMO while treating the arrest rhythm and reversible cause. Standard arrest interventions remain rhythm- and perfusion-dependent rather than being replaced by the ECMO circuit.","effects":{"internal":{"mapBaseline":{"add":10},"hrCurrent":{"add":25}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":90,"toState":"worsened","effects":{"internal":{"mapBaseline":{"add":-10},"hrCurrent":{"add":-15}}},"feedback":"An unmanaged clinically significant arrhythmia progresses toward hemodynamic collapse."},
        {"fromState":"worsened","afterSec":60,"toState":"critical","effects":{"internal":{"mapBaseline":{"set":10},"hrCurrent":{"set":30}}},"feedback":"The rhythm disturbance progresses to cardiovascular arrest."}
      ]
    }
  },
  {
    kind:'complication', id:'vasoplegia-shock', label:"Vasoplegia / distributive shock",
    tags:["hemodynamics","shock"],
    definition:{
      id:'vasoplegia-shock', label:"Vasoplegia / distributive shock", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-12},"shockPattern":{"set":"low-svr-warm-distributive"},"capillaryRefillPattern":{"set":"variable"},"lactateTrendPattern":{"set":"rising"}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"absent"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-shock","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Assessment identifies a distributive / vasoplegic perfusion pattern rather than isolated circuit-flow failure.","rationale":"Adequate displayed ECMO flow does not guarantee adequate vascular tone or tissue perfusion. Assess distributive physiology using perfusion markers, vascular tone, lactate trend, capillary refill, cardiac function, and the possible cause.","effects":{"eventState":"recognized"}},
        {"actionId":"treat-vasoplegia","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Appropriate shock treatment is initiated and perfusion pressure improves.","rationale":"Management targets distributive physiology and its cause with appropriate vasopressor support and resuscitation while avoiding reflexive fluid loading when the patient is not fluid responsive.","effects":{"internal":{"mapBaseline":{"add":10}},"eventState":"resolved","resolve":true}}
      ]
    }
  },
  {
    kind:'complication', id:'infection-sepsis', label:"Infection / sepsis with clinically significant deterioration",
    tags:["infection","sepsis"],
    definition:{
      id:'infection-sepsis', label:"Infection / sepsis with clinically significant deterioration", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-6},"trueLatent.lactateMmolL":{"add":1.5},"infectionPattern":{"set":"suspected-systemic-infection"},"temperaturePattern":{"set":"abnormal"},"perfusionTrendPattern":{"set":"worsening"}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"impaired"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"impaired"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"impaired"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"impaired"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"impaired"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"obtain-cultures","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"acceptable","score":8,"feedback":"Appropriate infectious evaluation and cultures are obtained without delaying necessary stabilization.","rationale":"Obtain appropriate cultures and diagnostic samples promptly when feasible, but do not delay time-sensitive antimicrobial therapy, hemodynamic stabilization, or source-control actions in sepsis or septic shock.","effects":{"eventState":"evaluated"}},
        {"actionId":"treat-sepsis","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Sepsis treatment and source-control evaluation are initiated and systemic instability begins to improve.","rationale":"Treat sepsis with timely antimicrobials, source-control evaluation, and individualized hemodynamic support. Current sepsis guidance favors norepinephrine as first-line vasopressor for septic shock and repeated reassessment rather than indiscriminate fluid administration.","effects":{"internal":{"mapBaseline":{"add":6},"trueLatent.lactateMmolL":{"add":-1}},"eventState":"resolved","resolve":true}}
      ]
    }
  },
  {
    kind:'complication', id:'aki-fluid-overload', label:"Acute kidney injury / fluid overload",
    tags:["renal","fluid"],
    definition:{
      id:'aki-fluid-overload', label:"Acute kidney injury / fluid overload", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"cvpBaseline":{"add":3},"urineOutputMlKgHr":{"set":0.3},"cumulativeFluidBalancePct":{"set":12},"renalTrendPattern":{"set":"worsening"}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}},
        recognized:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, controlled:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, identified:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, evaluated:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, managed:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}}, verified:{dimensions:{"perfusion":"impaired","oxygenation":"impaired"}},
        worsened:{dimensions:{"perfusion":"critical","oxygenation":"critical"}}, critical:{dimensions:{"perfusion":"critical","oxygenation":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-renal-fluid","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Renal function, urine output, cumulative balance, and perfusion are reviewed as a single clinical problem.","rationale":"Assess urine output, renal-function trajectory, cumulative fluid balance, perfusion, electrolyte/acid-base consequences, and organ congestion together. Fluid overload and AKI on ECMO are dynamic syndromes, not single-number diagnoses.","effects":{"eventState":"recognized"}},
        {"actionId":"manage-fluid-overload","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"A renal / fluid-management strategy is initiated and clinically important fluid burden is addressed.","rationale":"Optimize perfusion and fluid balance, avoid unnecessary positive balance, and escalate to renal replacement support when clinically indicated by fluid, electrolyte, acid-base, or renal-support needs rather than one isolated value.","effects":{"internal":{"cvpBaseline":{"add":-3}},"eventState":"resolved","resolve":true}},
        {"actionId":"volume-bolus","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-6,"feedback":"Additional volume does not improve the underlying renal/fluid problem and worsens clinically important fluid burden.","rationale":"Repeated empiric volume can worsen fluid overload when preload is not the limiting issue."}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"cvpBaseline":{"add":4},"clinicalPao2Target":{"set":78}}},"feedback":"Unaddressed fluid overload worsens pulmonary congestion and oxygenation."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"cvpBaseline":{"add":5},"mapBaseline":{"add":-6}}},"feedback":"Severe unaddressed fluid overload produces critical cardiopulmonary compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'ckrt-ecmo-interaction', label:"CKRT / CRRT failure or ECMO interaction",
    tags:["renal","CKRT","circuit"],
    definition:{
      id:'ckrt-ecmo-interaction', label:"CKRT / CRRT failure or ECMO interaction", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.85}}},
      trajectoryByState:{
        active:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}},
        recognized:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, controlled:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, contained:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, identified:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, evaluated:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, managed:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, verified:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}},
        worsened:{dimensions:{"circuitSupport":"critical","perfusion":"critical"}}, critical:{dimensions:{"circuitSupport":"critical","perfusion":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-ckrt","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Assessment identifies a clinically significant renal-replacement support or ECMO/CKRT interaction problem.","rationale":"Troubleshoot whether the problem is CKRT access/return configuration, pressure interaction with the ECMO circuit, filter clotting, inadequate delivered therapy, or a patient-level renal/fluid indication. Connection strategy and pressures must be interpreted together.","effects":{"eventState":"recognized"}},
        {"actionId":"restore-ckrt","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The CKRT/ECMO interaction is corrected and effective renal-replacement support is restored.","rationale":"Restore effective CKRT while preserving ECMO support and circuit safety. Correct connection/pressure problems, clotting, or access issues rather than accepting loss of renal-replacement therapy as an unavoidable ECMO consequence.","effects":{"internal":{"supportFlowMultiplier":{"set":1}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"supportFlowMultiplier":{"set":0.6},"cvpBaseline":{"add":3}}},"feedback":"Unaddressed CKRT/ECMO interaction worsens circuit performance and fluid balance."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"supportFlowMultiplier":{"set":0.35}}},"feedback":"Severe unaddressed interaction produces critical loss of effective support."}
      ]
    }
  },
  {
    kind:'complication', id:'metabolic-electrolyte-emergency', label:"Major metabolic / electrolyte emergency",
    tags:["metabolic","electrolyte"],
    definition:{
      id:'metabolic-electrolyte-emergency', label:"Major metabolic / electrolyte emergency", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"hrCurrent":{"add":-10},"mapBaseline":{"add":-5},"criticalElectrolytePattern":{"set":"severe-potassium-abnormality"},"potassiumTarget":{"set":7.1}}},
      trajectoryByState:{
        active:{dimensions:{"hemodynamics":"critical","neurologicRisk":"impaired"}},
        recognized:{dimensions:{"hemodynamics":"critical","neurologicRisk":"impaired"}}, controlled:{dimensions:{"hemodynamics":"impaired","neurologicRisk":"impaired"}}, contained:{dimensions:{"hemodynamics":"impaired","neurologicRisk":"impaired"}}, identified:{dimensions:{"hemodynamics":"critical","neurologicRisk":"impaired"}}, evaluated:{dimensions:{"hemodynamics":"critical","neurologicRisk":"impaired"}}, managed:{dimensions:{"hemodynamics":"impaired","neurologicRisk":"impaired"}}, verified:{dimensions:{"hemodynamics":"critical","neurologicRisk":"impaired"}},
        worsened:{dimensions:{"hemodynamics":"critical","neurologicRisk":"critical"}}, critical:{dimensions:{"hemodynamics":"absent","neurologicRisk":"critical"}, arrest:true}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-electrolytes","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Urgent laboratory review identifies a clinically significant metabolic / electrolyte abnormality that requires treatment.","rationale":"Confirm the specific electrolyte/metabolic abnormality, severity, ECG/hemodynamic effects, renal context, and rate of change. Acute treatment depends on the actual abnormality.","effects":{"eventState":"recognized"}},
        {"actionId":"correct-electrolyte-emergency","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"The clinically significant metabolic / electrolyte abnormality is treated and immediate risk decreases.","rationale":"Use abnormality-specific emergency treatment and address the cause. Severe potassium disturbances or arrest-associated electrolyte abnormalities require the current specialty resuscitation/electrolyte pathway rather than a generic one-step correction.","effects":{"internal":{"hrCurrent":{"add":15},"mapBaseline":{"add":8}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":120,"toState":"worsened","effects":{"internal":{"hrCurrent":{"add":-15},"mapBaseline":{"add":-8}}},"feedback":"An unmanaged metabolic/electrolyte emergency progresses toward cardiovascular instability."},
        {"fromState":"worsened","afterSec":60,"toState":"critical","effects":{"internal":{"mapBaseline":{"set":10},"hrCurrent":{"set":25}}},"feedback":"The unmanaged emergency progresses to cardiovascular arrest."}
      ]
    }
  },
  {
    kind:'complication', id:'neurologic-deterioration', label:"Acute neurologic deterioration / seizure",
    tags:["neurologic"],
    definition:{
      id:'neurologic-deterioration', label:"Acute neurologic deterioration / seizure", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      // NOTE: a seizure/acute neuro change's real signal is a neuro exam
      // finding, not a vitals number — this engine has no dedicated
      // neuro-status channel yet, so this uses a modest autonomic/stress
      // proxy (HR) purely so the complication isn't silently invisible.
      // A dedicated observable would be more accurate than this stand-in.
      activationEffects:{internal:{"hrCurrent":{"add":15}}},
      trajectoryByState:{
        active:{dimensions:{"neurologicRisk":"critical"}},
        recognized:{dimensions:{"neurologicRisk":"critical"}}, controlled:{dimensions:{"neurologicRisk":"impaired"}}, contained:{dimensions:{"neurologicRisk":"impaired"}}, identified:{dimensions:{"neurologicRisk":"critical"}}, evaluated:{dimensions:{"neurologicRisk":"critical"}}, managed:{dimensions:{"neurologicRisk":"impaired"}}, verified:{dimensions:{"neurologicRisk":"critical"}},
        worsened:{dimensions:{"neurologicRisk":"critical"}}, critical:{dimensions:{"neurologicRisk":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-neurologic-deterioration","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Focused neurologic assessment confirms a clinically important acute neurologic change.","rationale":"Rapid recognition should trigger focused neurologic examination and syndrome-specific escalation. Acute neurologic changes on ECMO require differentiation among hemorrhage, ischemia, seizure, metabolic causes, sedation effects, and perfusion problems.","effects":{"eventState":"recognized"}},
        {"actionId":"treat-neurologic-emergency","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The neurologic emergency pathway is initiated and immediate secondary injury risk is addressed.","rationale":"Management depends on the identified neurologic syndrome and cause; treatment may require urgent imaging, EEG/seizure management, perfusion correction, anticoagulation decisions, or neurocritical-care intervention.","effects":{"internal":{"hrCurrent":{"add":-15}},"eventState":"managed"}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":300,"toState":"worsened","effects":{"internal":{"hrCurrent":{"add":15}}},"feedback":"An unaddressed acute neurologic change progresses, with worsening secondary physiologic stress."},
        {"fromState":"worsened","afterSec":180,"toState":"critical","effects":{"internal":{"mapBaseline":{"add":-8}}},"feedback":"Ongoing untreated neurologic deterioration produces secondary hemodynamic compromise."}
      ]
    }
  },
  {
    kind:'complication', id:'abdominal-ischemic-compartment', label:"Abdominal compartment / bowel ischemia / abdominal perfusion emergency",
    tags:["abdominal","perfusion"],
    definition:{
      id:'abdominal-ischemic-compartment', label:"Abdominal compartment / bowel ischemia / abdominal perfusion emergency", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.7},"mapBaseline":{"add":-5}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"impaired"}},
        recognized:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"impaired"}}, controlled:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, identified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"impaired"}}, evaluated:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"impaired"}}, managed:{dimensions:{"perfusion":"impaired","hemodynamics":"impaired","circuitSupport":"impaired"}}, verified:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"impaired"}},
        worsened:{dimensions:{"perfusion":"critical","hemodynamics":"critical","circuitSupport":"critical"}}, critical:{dimensions:{"perfusion":"absent","hemodynamics":"absent","circuitSupport":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-abdomen","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Assessment identifies an abdominal pressure / perfusion pattern capable of impairing venous return and organ perfusion.","rationale":"An abdominal compartment or ischemic process can impair venous return, organ perfusion, ventilation, and ECMO drainage. Evaluate abdominal pressure/perfusion together with lactate, organ function, hemodynamics, and mechanical findings.","effects":{"eventState":"recognized"}},
        {"actionId":"treat-abdominal-emergency","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Urgent abdominal intervention / escalation is initiated and the mechanical-perfusion threat is addressed.","rationale":"Definitive management treats the abdominal cause through urgent surgical/critical-care evaluation and cause-specific intervention rather than escalating ECMO settings alone.","effects":{"internal":{"supportFlowMultiplier":{"set":1},"mapBaseline":{"add":5}},"eventState":"resolved","resolve":true}},
        {"actionId":"increase-rpm","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"harmful","score":-6,"feedback":"Higher RPM does not correct the abdominal mechanical limitation and effective drainage remains impaired.","rationale":"The underlying venous-return problem must be corrected."}
      ]
    }
  },
  {
    kind:'complication', id:'pulmonary-hypertensive-crisis', label:"Pulmonary hypertensive / RV crisis",
    tags:["cardiopulmonary","pediatric"],
    definition:{
      id:'pulmonary-hypertensive-crisis', label:"Pulmonary hypertensive / RV crisis", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-8},"clinicalPao2Target":{"set":60},"rvCrisisPattern":{"set":"acute-rv-pressure-overload"},"pulmonaryPressurePattern":{"set":"severely-elevated"}}},
      trajectoryByState:{
        active:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}},
        recognized:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}}, controlled:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","perfusion":"impaired"}}, contained:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","perfusion":"impaired"}}, identified:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}}, evaluated:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}}, managed:{dimensions:{"oxygenation":"impaired","hemodynamics":"impaired","perfusion":"impaired"}}, verified:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}},
        worsened:{dimensions:{"oxygenation":"critical","hemodynamics":"critical","perfusion":"critical"}}, critical:{dimensions:{"oxygenation":"critical","hemodynamics":"absent","perfusion":"absent"}, arrest:true}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-pulmonary-hypertension","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"Assessment identifies a pulmonary hypertensive / RV crisis pattern requiring targeted cardiopulmonary management.","rationale":"Recognition distinguishes pulmonary vascular/RV failure from isolated circuit malfunction. Assess RV pressure-load physiology, oxygenation/ventilation, acid-base status, preload, systemic pressure, and precipitating causes together.","effects":{"eventState":"recognized"}},
        {"actionId":"treat-pulmonary-hypertension","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"Targeted pulmonary hypertensive crisis treatment is initiated and cardiopulmonary stability improves.","rationale":"Management addresses pulmonary vascular load, oxygenation/ventilation and acid-base triggers, RV perfusion/support, and the precipitating cause. Exact vasodilator/inotrope strategy remains specialty- and context-specific.","effects":{"internal":{"mapBaseline":{"add":7},"clinicalPao2Target":{"set":null}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":150,"toState":"worsened","effects":{"internal":{"mapBaseline":{"add":-8},"clinicalPao2Target":{"set":42}}},"feedback":"An unmanaged pulmonary hypertensive crisis progresses toward RV failure."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"set":10},"hrCurrent":{"set":30}}},"feedback":"Unrelieved RV crisis progresses to cardiovascular arrest."}
      ]
    }
  },
  {
    kind:'complication', id:'congenital-circulation-specific', label:"Congenital circulation / shunt / residual lesion failure",
    tags:["congenital","pediatric"],
    definition:{
      id:'congenital-circulation-specific', label:"Congenital circulation / shunt / residual lesion failure", initialState:'active', hidden:true,
      applicability:["VA"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-6},"clinicalPao2Target":{"set":80}}},
      trajectoryByState:{
        active:{dimensions:{"perfusion":"critical","oxygenation":"impaired","hemodynamics":"critical"}},
        recognized:{dimensions:{"perfusion":"critical","oxygenation":"impaired","hemodynamics":"critical"}}, controlled:{dimensions:{"perfusion":"impaired","oxygenation":"impaired","hemodynamics":"impaired"}}, contained:{dimensions:{"perfusion":"impaired","oxygenation":"impaired","hemodynamics":"impaired"}}, identified:{dimensions:{"perfusion":"critical","oxygenation":"impaired","hemodynamics":"critical"}}, evaluated:{dimensions:{"perfusion":"critical","oxygenation":"impaired","hemodynamics":"critical"}}, managed:{dimensions:{"perfusion":"impaired","oxygenation":"impaired","hemodynamics":"impaired"}}, verified:{dimensions:{"perfusion":"critical","oxygenation":"impaired","hemodynamics":"critical"}},
        worsened:{dimensions:{"perfusion":"critical","oxygenation":"critical","hemodynamics":"critical"}}, critical:{dimensions:{"perfusion":"absent","oxygenation":"critical","hemodynamics":"absent"}, arrest:true}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-congenital-circulation","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":12,"feedback":"Assessment identifies a circulation-specific imbalance or residual lesion pattern that cannot be explained by generic ECMO troubleshooting alone.","rationale":"Congenital anatomy, shunts, surgical palliation, residual lesions, and parallel/series circulations can create support problems that generic VA ECMO troubleshooting will miss. Interpretation must be anatomy- and operation-specific.","effects":{"eventState":"recognized"}},
        {"actionId":"escalate-congenital-lesion","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":20,"feedback":"The lesion-specific cardiac/surgical escalation pathway is activated and definitive evaluation or intervention is initiated.","rationale":"Residual lesions, shunt problems, coronary/perfusion issues, or surgically created circulations require urgent congenital-cardiology/cardiac-surgery evaluation and anatomy-specific intervention rather than generic ECMO setting changes alone.","effects":{"internal":{"mapBaseline":{"add":8},"clinicalPao2Target":{"set":90}},"eventState":"managed"}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":150,"toState":"worsened","effects":{"internal":{"mapBaseline":{"add":-10},"clinicalPao2Target":{"set":65}}},"feedback":"An unaddressed congenital circulation problem progresses toward critical instability."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"set":10},"hrCurrent":{"set":30}}},"feedback":"The unresolved lesion-specific problem progresses to cardiovascular arrest."}
      ]
    }
  },
  {
    kind:'complication', id:'treatment-transfusion-adverse', label:"Clinically significant medication / transfusion adverse event",
    tags:["treatment","transfusion"],
    definition:{
      id:'treatment-transfusion-adverse', label:"Clinically significant medication / transfusion adverse event", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"mapBaseline":{"add":-10},"hrCurrent":{"add":20},"clinicalPao2Target":{"set":80}}},
      trajectoryByState:{
        active:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired"}},
        recognized:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired"}}, controlled:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired"}}, contained:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired"}}, identified:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired"}}, evaluated:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired"}}, managed:{dimensions:{"hemodynamics":"impaired","oxygenation":"impaired"}}, verified:{dimensions:{"hemodynamics":"critical","oxygenation":"impaired"}},
        worsened:{dimensions:{"hemodynamics":"critical","oxygenation":"critical"}}, critical:{dimensions:{"hemodynamics":"absent","oxygenation":"critical"}, arrest:true}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"assess-treatment-reaction","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":10,"feedback":"The temporal relationship and clinical pattern raise concern for a clinically significant treatment / transfusion adverse event.","rationale":"Confirm the temporal relationship and reaction phenotype before attributing deterioration to a medication or transfusion. Distinguish allergic/anaphylactic, hemolytic, febrile, volume, pulmonary, and medication-related mechanisms because management differs.","effects":{"eventState":"recognized"}},
        {"actionId":"stop-offending-treatment","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"The suspected offending treatment is stopped or reversed when appropriate and the adverse trajectory is interrupted.","rationale":"Stop the suspected causal exposure when appropriate and initiate reaction-specific emergency management. Transfusion or medication reactions are not interchangeable, and reversal is appropriate only when a specific reversible exposure and indication exist.","effects":{"internal":{"mapBaseline":{"add":8},"hrCurrent":{"add":-10},"clinicalPao2Target":{"set":null}},"eventState":"resolved","resolve":true}}
      ],
      timeRules:[
        {"fromState":"active","afterSec":120,"toState":"worsened","effects":{"internal":{"mapBaseline":{"add":-10},"clinicalPao2Target":{"set":70}}},"feedback":"An unrecognized adverse reaction progresses toward critical instability."},
        {"fromState":"worsened","afterSec":90,"toState":"critical","effects":{"internal":{"mapBaseline":{"set":10},"hrCurrent":{"set":30}}},"feedback":"The unaddressed reaction progresses to cardiovascular arrest."}
      ]
    }
  },
  {
    kind:'complication', id:'transport-procedural-operational', label:"Transport / positioning / operational support hazard",
    tags:["operations","transport","position"],
    definition:{
      id:'transport-procedural-operational', label:"Transport / positioning / operational support hazard", initialState:'active', hidden:true,
      applicability:["VA","VV"],
      timingPolicyStatus:'placeholder-until-validated',
      activationEffects:{internal:{"supportFlowMultiplier":{"set":0.65}}},
      trajectoryByState:{
        active:{dimensions:{"circuitSupport":"critical","perfusion":"impaired"}},
        recognized:{dimensions:{"circuitSupport":"critical","perfusion":"impaired"}}, controlled:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, contained:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, identified:{dimensions:{"circuitSupport":"critical","perfusion":"impaired"}}, evaluated:{dimensions:{"circuitSupport":"critical","perfusion":"impaired"}}, managed:{dimensions:{"circuitSupport":"impaired","perfusion":"impaired"}}, verified:{dimensions:{"circuitSupport":"critical","perfusion":"impaired"}},
        worsened:{dimensions:{"circuitSupport":"critical","perfusion":"critical"}}, critical:{dimensions:{"circuitSupport":"absent","perfusion":"critical"}}, resolved:{dimensions:{}}
      },
      actionRules:[
        {"actionId":"stabilize-transport-position","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"preferred","score":18,"feedback":"Movement is stopped, the patient/circuit are returned to a safe configuration, and effective support improves.","rationale":"Stop the unsafe movement or procedure, stabilize the patient and circuit, verify cannula/tubing position and securement, restore adequate support, and use a transport/procedure-specific contingency plan before proceeding.","effects":{"internal":{"supportFlowMultiplier":{"set":1}},"eventState":"resolved","resolve":true}},
        {"actionId":"verify-monitor-sensor","whenStates":["active","recognized","worsened","critical","identified","evaluated","managed","verified","suspected","diagnosed","contained"],"outcome":"acceptable","score":8,"feedback":"Questionable data are checked against an independent source before treatment is escalated.","rationale":"Confirm suspect monitor data against an independent source before escalating treatment, while simultaneously checking circuit integrity and patient condition so a true deterioration is not dismissed as artifact.","effects":{"eventState":"verified"}}
      ]
    }
  }
];

export const defaultClinicalKnowledgeRegistry = createClinicalKnowledgeRegistry(entries);
