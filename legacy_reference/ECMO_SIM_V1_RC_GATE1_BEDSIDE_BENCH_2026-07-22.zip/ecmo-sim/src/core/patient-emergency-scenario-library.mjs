import { buildScenarioFromSetup } from './scenario-builder.mjs';
function clone(v){return JSON.parse(JSON.stringify(v));}
const BASE=Object.freeze({
 patient:{population:'adult',age:'36 years',weightKg:70,diagnosis:'Critical illness requiring ECMO support',procedure:'ECMO support',postOpDay:2},
 ecmo:{mode:'VA',cannulation:'peripheral',cannulaFr:17,pumpRpm:3000,sweepGasLpm:3,fdo2Percent:100,circuitAgeHours:48},
 startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'none',renalFunction:'normal',neurologicStatus:'sedated'},
 education:{primaryObjective:'patient-emergency-pack',concepts:[],mode:'guided',difficulty:'intermediate'}
});
export const PATIENT_EMERGENCY_PRESETS=Object.freeze([
 {id:'pe-01-arrhythmia-arrest',learnerLabel:'Patient Emergency 01',educatorLabel:'Arrhythmia / ventricular fibrillation arrest on ECMO',complicationId:'arrhythmia-arrest',initialRhythm:'vfib',
  briefing:'You are assuming care during an acute rhythm and perfusion emergency in a patient receiving ECMO support. Identify the rhythm, treat the immediate arrest state, and verify that both rhythm and systemic support recover.',
  recentEvents:[{minutesBeforeStart:5,text:'The patient had a sudden hemodynamic deterioration with a new malignant rhythm.'},{minutesBeforeStart:0,text:'You assume care during active emergency response.'}]},
 {id:'pe-02-ich',learnerLabel:'Patient Emergency 02',educatorLabel:'Intracranial hemorrhage / acute neurologic emergency',complicationId:'intracranial-hemorrhage',
  briefing:'You are assuming care of an ECMO patient with an acute neurologic change. Perform focused assessment, obtain definitive evaluation, and control the immediate neurologic/bleeding threat.',
  recentEvents:[{minutesBeforeStart:20,text:'Neurologic examination had previously been stable for the patient’s sedation level.'},{minutesBeforeStart:4,text:'A new acute neurologic change was reported.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'pe-03-vasoplegia',learnerLabel:'Patient Emergency 03A',educatorLabel:'Vasoplegia / distributive shock',complicationId:'vasoplegia-shock',
  briefing:'You are assuming care of an ECMO patient with worsening perfusion pressure despite apparently adequate extracorporeal flow. Distinguish vascular-tone failure from isolated circuit-flow failure.',
  recentEvents:[{minutesBeforeStart:30,text:'ECMO flow remained near target.'},{minutesBeforeStart:8,text:'MAP and tissue-perfusion indicators worsened despite maintained displayed flow.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'pe-03-sepsis',learnerLabel:'Patient Emergency 03B',educatorLabel:'Sepsis / infectious deterioration',complicationId:'infection-sepsis',
  briefing:'You are assuming care of an ECMO patient with new systemic instability and concern for infection. Evaluate the infectious driver while treating time-sensitive perfusion consequences.',
  recentEvents:[{minutesBeforeStart:120,text:'The patient had no major new instability.'},{minutesBeforeStart:25,text:'New systemic inflammatory/infectious concern developed with worsening perfusion markers.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'pe-04-aki-fluid',learnerLabel:'Patient Emergency 04',educatorLabel:'AKI / clinically significant fluid overload',complicationId:'aki-fluid-overload',
  briefing:'You are assuming care of an ECMO patient with worsening urine output and fluid accumulation. Integrate renal function, cumulative balance, perfusion, and organ consequences.',
  recentEvents:[{minutesBeforeStart:360,text:'Urine output had been declining over the prior shift.'},{minutesBeforeStart:60,text:'Cumulative fluid balance and congestion became clinically significant.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'pe-05-metabolic',learnerLabel:'Patient Emergency 05',educatorLabel:'Major metabolic / electrolyte emergency',complicationId:'metabolic-electrolyte-emergency',
  briefing:'You are assuming care of an ECMO patient with new hemodynamic/rhythm risk and an urgent metabolic concern. Identify the actionable abnormality and correct it promptly.',
  recentEvents:[{minutesBeforeStart:30,text:'A new laboratory abnormality was flagged as potentially clinically significant.'},{minutesBeforeStart:5,text:'Heart rate and hemodynamics began to change.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'pe-06-ph-crisis',learnerLabel:'Patient Emergency 06',educatorLabel:'Pulmonary hypertensive / RV crisis',complicationId:'pulmonary-hypertensive-crisis',
  briefing:'You are assuming care of an ECMO patient with acute cardiopulmonary instability. Assess for pulmonary vascular/RV crisis physiology and initiate targeted management.',
  recentEvents:[{minutesBeforeStart:20,text:'Cardiopulmonary status was previously near the established support baseline.'},{minutesBeforeStart:5,text:'Abrupt oxygenation/hemodynamic deterioration with concern for RV strain developed.'},{minutesBeforeStart:0,text:'You assume care.'}]}
]);
const OBJECTIVES=Object.freeze([
 'Recognize a clinically important patient emergency even when ECMO circuit support appears technically adequate.',
 'Use patient examination, rhythm, laboratory, imaging, and perfusion evidence to identify the dominant mechanism.',
 'Apply immediate stabilizing and cause-directed treatment appropriate to the emergency.',
 'Verify that the acute threat, rhythm/perfusion state, and overall trajectory are genuinely stabilized before declaring success.'
]);
function merge(base,patch={}){return {...clone(base),...clone(patch),patient:{...clone(base.patient),...clone(patch.patient??{})},ecmo:{...clone(base.ecmo),...clone(patch.ecmo??{})},startingCondition:{...clone(base.startingCondition),...clone(patch.startingCondition??{})},education:{...clone(base.education),...clone(patch.education??{})}};}
export function listPatientEmergencyScenarios({audience='learner'}={}){return PATIENT_EMERGENCY_PRESETS.map(p=>({id:p.id,label:audience==='educator'?p.educatorLabel:p.learnerLabel}));}
export function buildPatientEmergencyScenario(id,{setup={}}={}){
 const p=PATIENT_EMERGENCY_PRESETS.find(x=>x.id===id);if(!p)throw new Error(`Unknown patient emergency scenario: ${id}`);
 const s=buildScenarioFromSetup(merge(BASE,setup),{id:`patient-emergency-${p.id}`});
 s.learningPlan.primaryObjective='patient-emergency-pack';s.learningPlan.concepts=['patient-emergency-pack'];s.clinicalKnowledgePlan.requiredComplicationIds=[p.complicationId];s.clinicalKnowledgePlan.allowedComplicationIds=[p.complicationId];
 s.clinicalKnowledgePlan.triggerPolicies=[{id:`preset-${p.id}`,complicationId:p.complicationId,type:'at-start',source:'patient-emergency-scenario-library'}];
 s.learnerBriefing={caseLabel:p.learnerLabel,text:p.briefing};s.handoff={summary:'The patient is receiving ECMO support but has developed a clinically significant patient-side emergency. Review patient, rhythm, laboratory, imaging, and perfusion evidence rather than assuming the circuit is the primary problem.',currentConcern:'The immediate cause has not been established.'};
 s.recentEvents=clone(p.recentEvents);s.learnerObjectives=clone(OBJECTIVES);s.initialRhythm=p.initialRhythm??'sinus';
 s.lifecycle={version:1,completionRule:'clinical-endpoint',successEndpointTypes:['stabilized'],failureEndpointTypes:['death'],allowInstructorTermination:true};
 s.educatorScenarioMetadata={presetId:p.id,intendedComplicationId:p.complicationId,educatorLabel:p.educatorLabel,milestone:'M6'};
 return s;
}
