function clone(value) { return JSON.parse(JSON.stringify(value)); }

export const OUTCOME_CLASSES = Object.freeze([
  'preferred',
  'acceptable',
  'temporizing',
  'ineffective',
  'harmful',
  'critical-error'
]);

const VALID_OUTCOMES = new Set(OUTCOME_CLASSES);

function applyPatch(target, patch = {}) {
  for (const [path, rawValue] of Object.entries(patch)) {
    const parts = path.split('.');
    let cursor = target;
    for (let i = 0; i < parts.length - 1; i += 1) {
      const key = parts[i];
      if (!cursor[key] || typeof cursor[key] !== 'object') cursor[key] = {};
      cursor = cursor[key];
    }
    const leaf = parts[parts.length - 1];
    if (rawValue && typeof rawValue === 'object' && !Array.isArray(rawValue) && ('add' in rawValue || 'set' in rawValue)) {
      if ('set' in rawValue) cursor[leaf] = rawValue.set;
      if ('add' in rawValue) cursor[leaf] = Number(cursor[leaf] ?? 0) + Number(rawValue.add);
    } else {
      cursor[leaf] = rawValue;
    }
  }
}

function validateDefinition(definition) {
  if (!definition?.id) throw new Error('Clinical event definition requires id.');
  if (!definition?.initialState) throw new Error(`Clinical event "${definition.id}" requires initialState.`);
  for (const rule of definition.actionRules ?? []) {
    if (!rule.actionId) throw new Error(`Clinical event "${definition.id}" has an action rule without actionId.`);
    if (!VALID_OUTCOMES.has(rule.outcome)) throw new Error(`Clinical event "${definition.id}" rule "${rule.actionId}" has invalid outcome "${rule.outcome}".`);
  }
  for (const rule of definition.contextRules ?? []) {
    if (!rule.contextKey) throw new Error(`Clinical event "${definition.id}" has a context rule without contextKey.`);
    if (!VALID_OUTCOMES.has(rule.outcome)) throw new Error(`Clinical event "${definition.id}" context rule "${rule.contextKey}" has invalid outcome "${rule.outcome}".`);
  }
}

export function createClinicalEventSystem(definitions = [], snapshot = null) {
  definitions.forEach(validateDefinition);
  const defs = new Map(definitions.map((d) => [d.id, clone(d)]));
  const state = snapshot ? clone(snapshot) : {
    active: Object.fromEntries(definitions.filter((d) => d.activeAtStart).map((d) => [d.id, {
      state: d.initialState,
      activatedAtSec: 0,
      stateEnteredAtSec: 0,
      resolvedAtSec: null,
      history: []
    }])),
    score: 0,
    lastOutcome: null,
    sequence: 0
  };

  // Backward-compatible snapshot migration for v0.1 saves, which did not
  // track when the current event state was entered. Falling back to the
  // activation time preserves old behavior while enabling state-relative
  // timers for new complications.
  for (const eventState of Object.values(state.active ?? {})) {
    if (eventState.stateEnteredAtSec == null) eventState.stateEnteredAtSec = Number(eventState.activatedAtSec ?? 0);
  }

  function activate(eventId, timeSec = 0, initialState = null, context = {}) {
    const def = defs.get(eventId);
    if (!def) throw new Error(`Unknown clinical event "${eventId}".`);
    if (!state.active[eventId]) {
      state.active[eventId] = {
        state: initialState ?? def.initialState,
        activatedAtSec: timeSec,
        stateEnteredAtSec: timeSec,
        resolvedAtSec: null,
        history: []
      };
      // Optional activation effects let reusable clinical knowledge establish
      // a meaningful initial condition when an event enters the live case.
      // These remain part of the complication definition, never scenario code.
      if (def.activationEffects?.internal) applyPatch(context.internal, def.activationEffects.internal);
      if (def.activationEffects?.settings) applyPatch(context.settings, def.activationEffects.settings);
    }
    return clone(state.active[eventId]);
  }


  function applyRule(eventId, eventState, rule, context = {}, actionId = null) {
    const timeSec = Number(context.timeSec ?? 0);
    if (rule.effects?.internal) applyPatch(context.internal, rule.effects.internal);
    if (rule.effects?.settings) applyPatch(context.settings, rule.effects.settings);
    if (rule.effects?.eventState && rule.effects.eventState !== eventState.state) {
      eventState.state = rule.effects.eventState;
      eventState.stateEnteredAtSec = timeSec;
    }
    if (rule.effects?.resolve) eventState.resolvedAtSec = timeSec;

    const scoreDelta = Number(rule.score ?? 0);
    state.score += scoreDelta;
    state.sequence += 1;
    const outcome = {
      id: `clinical-outcome-${state.sequence}`,
      eventId,
      actionId,
      outcome: rule.outcome,
      feedback: rule.feedback ?? '',
      rationale: rule.rationale ?? '',
      scoreDelta,
      atSec: timeSec,
      eventState: eventState.state,
      resolved: eventState.resolvedAtSec != null
    };
    eventState.history.push(clone(outcome));
    state.lastOutcome = clone(outcome);
    return outcome;
  }

  function evaluateContextChange(contextKey, value, context = {}) {
    const matches = [];
    for (const [eventId, eventState] of Object.entries(state.active)) {
      if (eventState.resolvedAtSec != null) continue;
      const def = defs.get(eventId);
      if (!def) continue;
      for (const rule of def.contextRules ?? []) {
        if (rule.contextKey !== contextKey) continue;
        if (rule.value !== value) continue;
        const allowedStates = rule.whenStates ?? null;
        if (allowedStates && !allowedStates.includes(eventState.state)) continue;
        matches.push({ eventId, eventState, rule });
      }
    }
    const priority = { 'critical-error': 6, harmful: 5, preferred: 4, acceptable: 3, temporizing: 2, ineffective: 1 };
    matches.sort((a,b)=>priority[b.rule.outcome]-priority[a.rule.outcome]);
    const match=matches[0];
    if(!match) return null;
    return applyRule(match.eventId, match.eventState, match.rule, context, `context:${contextKey}:${value}`);
  }

  function evaluateAction(actionId, context = {}) {
    const matches = [];
    for (const [eventId, eventState] of Object.entries(state.active)) {
      if (eventState.resolvedAtSec != null) continue;
      const def = defs.get(eventId);
      if (!def) continue;
      for (const rule of def.actionRules ?? []) {
        if (rule.actionId !== actionId) continue;
        const allowedStates = rule.whenStates ?? null;
        if (allowedStates && !allowedStates.includes(eventState.state)) continue;
        matches.push({ eventId, eventState, def, rule });
      }
    }

    // More severe/specific consequence wins if multiple active events react.
    const priority = { 'critical-error': 6, harmful: 5, preferred: 4, acceptable: 3, temporizing: 2, ineffective: 1 };
    matches.sort((a, b) => priority[b.rule.outcome] - priority[a.rule.outcome]);
    const match = matches[0];
    if (!match) return null;

    const { eventId, eventState, rule } = match;
    return applyRule(eventId, eventState, rule, context, actionId);
  }

  function advance(elapsedSec, context = {}) {
    const transitions = [];
    const timeSec = Number(context.timeSec ?? 0);
    for (const [eventId, eventState] of Object.entries(state.active)) {
      if (eventState.resolvedAtSec != null) continue;
      const def = defs.get(eventId);
      // Cascade through every transition this much elapsed time actually
      // earns, not just the first one — otherwise a single large time
      // jump (e.g. advance(900) instead of many advance(1) calls) only
      // ever applies one stage of a multi-stage decline, regardless of
      // how much simulated time has actually passed. Guard against a
      // pathological rule cycle with a hard iteration cap.
      for (let guard = 0; guard < 20; guard += 1) {
        const rule = (def.timeRules ?? []).find((r) => r.fromState === eventState.state);
        if (!rule) break;
        const enteredAt = Number(eventState.stateEnteredAtSec ?? eventState.activatedAtSec ?? 0);
        const stateAgeSec = timeSec - enteredAt;
        if (stateAgeSec < Number(rule.afterSec ?? Infinity)) break;
        eventState.state = rule.toState;
        // The moment this transition actually occurred, not "now" — so any
        // leftover time within the same advance() call still counts toward
        // the NEXT threshold instead of resetting to zero and starving it.
        eventState.stateEnteredAtSec = enteredAt + Number(rule.afterSec ?? 0);
        if (rule.effects?.internal) applyPatch(context.internal, rule.effects.internal);
        if (rule.effects?.settings) applyPatch(context.settings, rule.effects.settings);
        if (rule.resolve) eventState.resolvedAtSec = timeSec;
        transitions.push({ eventId, fromState: rule.fromState, toState: rule.toState, atSec: eventState.stateEnteredAtSec, feedback: rule.feedback ?? '' });
        if (eventState.resolvedAtSec != null) break;
      }
    }
    return transitions;
  }

  function trajectorySignals() {
    const signals = [];
    for (const [eventId, eventState] of Object.entries(state.active)) {
      if (eventState.resolvedAtSec != null) continue;
      const def = defs.get(eventId);
      const spec = def?.trajectoryByState?.[eventState.state] ?? def?.trajectory ?? null;
      if (!spec) continue;
      signals.push({ eventId, state: eventState.state, ...clone(spec) });
    }
    return signals;
  }

  function presentation() {
    const lastOutcome = clone(state.lastOutcome);
    if (lastOutcome) {
      const lastDef = defs.get(lastOutcome.eventId);
      if (lastDef?.hidden) delete lastOutcome.eventId;
    }
    return {
      score: state.score,
      lastOutcome,
      active: Object.entries(state.active).flatMap(([eventId, eventState]) => {
        const def = defs.get(eventId);
        if (def?.hidden) return [];
        return [{
          id: eventId,
          label: def?.label ?? eventId,
          state: eventState.state,
          resolved: eventState.resolvedAtSec != null
        }];
      })
    };
  }

  return { activate, evaluateAction, evaluateContextChange, advance, trajectorySignals, presentation, snapshot: () => clone(state) };
}
