// Enforces the governing rule for the LATENT channel: ordering a lab
// snapshots the true value at that instant, but the trainee doesn't see
// the result until simulated time has advanced past its turnaround.
//
// Point-of-care tests (ABG, ACT) turn around fast; send-out labs (CBC,
// coags, chemistry) take longer. These defaults are placeholders — set
// them to match your unit's real turnaround times.

export const DEFAULT_TURNAROUND_SEC = Object.freeze({
  abg: 4 * 60,          // point-of-care blood gas
  dtt: 25 * 60,         // dilute thrombin time — sent to lab, not point-of-care at most shops
  hepptt: 20 * 60,      // Hepzyme PTT
  teg: 35 * 60,         // Rapid TEG — assay itself takes time to run
  atiii: 45 * 60,       // send-out
  cbc: 30 * 60,
  bmp: 30 * 60,
  coags: 40 * 60,
  mixedVenousGas: 6 * 60
});

const LAB_FIELDS = Object.freeze({
  abg: ['pao2', 'paco2', 'ph'],
  dtt: ['dttMcgMl'],
  hepptt: ['hepPttSec'],
  teg: ['tegRTimeMin'],
  atiii: ['atiiiPercent'],
  cbc: ['hgbGdl'],
  bmp: ['lactateMmolL'],
  coags: ['dttMcgMl'],
  mixedVenousGas: ['pao2']
});

function pickFields(trueLatent, fields) {
  const out = {};
  for (const field of fields) out[field] = trueLatent[field];
  return out;
}

export function createLabQueue(snapshot = []) {
  let orders = snapshot.map((order) => ({ ...order }));

  function order(type, { orderedAtSec, trueLatent, turnaround = DEFAULT_TURNAROUND_SEC }) {
    if (!LAB_FIELDS[type]) throw new Error(`Unknown lab type "${type}".`);
    const record = {
      id: `${type}-${orderedAtSec}-${Math.random().toString(36).slice(2, 7)}`,
      type,
      orderedAtSec,
      resultAtSec: orderedAtSec + (turnaround[type] ?? 20 * 60),
      values: pickFields(trueLatent, LAB_FIELDS[type]),
      revealed: false
    };
    orders.push(record);
    return record;
  }

  // Call after every time advance so newly-due results flip to revealed.
  function tick(nowSec) {
    orders = orders.map((o) => (!o.revealed && nowSec >= o.resultAtSec ? { ...o, revealed: true } : o));
  }

  function pending(nowSec) {
    return orders.filter((o) => !o.revealed);
  }

  function resulted() {
    return orders.filter((o) => o.revealed);
  }

  function all() {
    return orders.map((o) => ({ ...o }));
  }

  return { order, tick, pending, resulted, all };
}
