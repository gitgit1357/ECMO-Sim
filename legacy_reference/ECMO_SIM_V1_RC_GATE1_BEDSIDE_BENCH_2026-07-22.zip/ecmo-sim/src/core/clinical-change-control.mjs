export function authorizeClinicalChange(record={}){
 const evidence=record.sourceContentReviewed===true;
 const applicable=record.sourceApplicabilityConfirmed===true;
 const comparison=['aligned','revise'].includes(record.comparisonDisposition);
 const approved=record.changeApproved===true;
 const traceable=Boolean(record.sourceTitle&&record.sourceLocator);
 return {authorized:evidence&&applicable&&comparison&&approved&&traceable,
  reasons:[
   !evidence&&'source-content-not-reviewed',
   !applicable&&'source-applicability-not-confirmed',
   !comparison&&'comparison-not-disposed',
   !approved&&'change-not-approved',
   !traceable&&'source-not-traceable'
  ].filter(Boolean)};
}
export function evidenceHash(text=''){
 let h=2166136261;
 for(let i=0;i<text.length;i++){h^=text.charCodeAt(i);h=Math.imul(h,16777619);}
 return (h>>>0).toString(16).padStart(8,'0');
}
