// Clinical consequence bridge.
//
// PURPOSE:
// Convert loss of effective ECMO support into clinically coherent patient consequences
// without pretending to be a high-fidelity mathematical human model.
//
// This is intentionally categorical and policy-driven. Thresholds/timings are placeholders
// for validation. It connects support state -> patient reserve -> monitor/labs/trajectory.

function clone(v){ return JSON.parse(JSON.stringify(v)); }
function clamp(v,min,max){ return Math.max(min,Math.min(max,v)); }

export const DEFAULT_SUPPORT_PROFILE = Object.freeze({
  ecmoDependency: 'high',          // low | moderate | high
  nativeCardiacContribution: 'low',
  nativeLungContribution: 'moderate',
  compensationReserve: 'moderate',
  oxygenationSensitivity: 'moderate', // low | moderate | high
  // A hemodynamically adequate MAP for this population/case — NOT
  // self-calibrated from the scenario's own starting value, unlike flow
  // below. Self-calibrating MAP the same way flow does would hide exactly
  // the defect this constant exists to catch: a case that starts already
  // hypotensive (as every low-flow troubleshooting preset does) would
  // otherwise never register a deficit no matter how low MAP went.
  // Set to 50 to match this codebase's own "stable" baseline MAP convention
  // (see scenario-builder.mjs / troubleshooting-scenario-library.mjs) —
  // still a PLACEHOLDER, pick a real target for your population before
  // trusting this.
  adequateMapTarget: 50
});

const SEVERITY_RANK = { adequate: 0, impaired: 1, severe: 2, critical: 3 };

function worseClass(a, b) {
  return SEVERITY_RANK[b] > SEVERITY_RANK[a] ? b : a;
}

const DEP_FACTOR = { low:0.35, moderate:0.65, high:1.0 };
const NATIVE_FACTOR = { low:0.2, moderate:0.5, high:0.8 };
const OXY_SENSITIVITY = { low:0.35, moderate:0.7, high:1.0 };

export function createClinicalConsequenceEngine({ profile = {}, snapshot = null } = {}) {
  const config = { ...DEFAULT_SUPPORT_PROFILE, ...profile };
  const state = snapshot ? clone(snapshot) : {
    baselineFlowIndexMlKgMin: profile.baselineFlowIndexMlKgMin != null ? Number(profile.baselineFlowIndexMlKgMin) : null,
    inadequateSupportExposureSec: 0,
    severeSupportExposureSec: 0,
    lastAtSec: 0,
    last: {
      supportRatio: 1,
      supportClass:'adequate',
      mapModifier:0,
      hrModifier:0,
      pao2Target:null,
      lactateDeltaPerMin:0,
      trajectorySignal:null
    }
  };

  function classify(ratio){
    if (ratio >= 0.75) return 'adequate';
    if (ratio >= 0.50) return 'impaired';
    if (ratio >= 0.25) return 'severe';
    return 'critical';
  }

  function evaluate({ timeSec=0, flowIndexMlKgMin=0, map=null, started=false, internal=null } = {}) {
    const now=Number(timeSec);
    const elapsed=Math.max(0, now-Number(state.lastAtSec ?? now));
    state.lastAtSec=now;

    if (state.baselineFlowIndexMlKgMin == null && started && flowIndexMlKgMin > 0) {
      state.baselineFlowIndexMlKgMin=Number(flowIndexMlKgMin);
    }
    const baseline=Math.max(1, Number(state.baselineFlowIndexMlKgMin ?? flowIndexMlKgMin ?? 1));
    const ratio=clamp(Number(flowIndexMlKgMin)/baseline,0,1.5);
    const flowCls=classify(ratio);

    // MAP deficit against a fixed, non-self-calibrating target (see the
    // comment on adequateMapTarget above for why it must not calibrate to
    // the scenario's own starting value).
    const mapRatio = map != null ? clamp(Number(map)/Number(config.adequateMapTarget), 0, 1.5) : 1;
    const mapCls = map != null ? classify(mapRatio) : 'adequate';
    const cls = worseClass(flowCls, mapCls);

    if (cls === 'adequate') {
      state.inadequateSupportExposureSec=Math.max(0,state.inadequateSupportExposureSec-elapsed*2);
      state.severeSupportExposureSec=Math.max(0,state.severeSupportExposureSec-elapsed*2);
    } else {
      state.inadequateSupportExposureSec += elapsed;
      if (cls==='severe' || cls==='critical') state.severeSupportExposureSec += elapsed;
      else state.severeSupportExposureSec=Math.max(0,state.severeSupportExposureSec-elapsed);
    }

    const dependency=DEP_FACTOR[config.ecmoDependency] ?? 1;
    const nativeCardiac=NATIVE_FACTOR[config.nativeCardiacContribution] ?? 0.5;
    const nativeLung=NATIVE_FACTOR[config.nativeLungContribution] ?? 0.5;
    const combinedRatio = Math.min(ratio, mapRatio);
    const deficit=clamp(1-combinedRatio,0,1);
    const effectiveHemodynamicDeficit=deficit*dependency*(1-nativeCardiac*0.55);

    // Time-stage response: early compensation, then progressive decompensation.
    const severeAge=state.severeSupportExposureSec;
    const inadequateAge=state.inadequateSupportExposureSec;
    let mapModifier=0, hrModifier=0, pao2Target=null, lactateDeltaPerMin=0;

    if (cls!=='adequate') {
      const timeFactor = inadequateAge < 15 ? 0.15 : inadequateAge < 60 ? 0.45 : inadequateAge < 120 ? 0.75 : 1.0;
      mapModifier = -Math.round(18 * effectiveHemodynamicDeficit * timeFactor);

      // Compensation first; prolonged severe support loss can become bradycardic.
      if (severeAge < 150) {
        hrModifier = Math.round(28 * effectiveHemodynamicDeficit * (severeAge < 20 ? 0.25 : severeAge < 60 ? 0.6 : 1));
      } else if (severeAge < 240) {
        hrModifier = Math.round(8 * effectiveHemodynamicDeficit);
      } else {
        hrModifier = -Math.round(45 * effectiveHemodynamicDeficit);
      }

      // Oxygenation effect is contextual, not automatic. Native lungs blunt the effect in VA.
      const oxygenDependence = dependency*(1-nativeLung*0.75)*(OXY_SENSITIVITY[config.oxygenationSensitivity] ?? 0.7);
      if (inadequateAge >= 30 && oxygenDependence > 0.25) {
        const floor = 48 + 32*nativeLung;
        pao2Target = Math.round(clamp(95 - 55*deficit*oxygenDependence*(inadequateAge<90?0.55:1), floor, 100));
      }
      lactateDeltaPerMin = 0.15 + 0.8*effectiveHemodynamicDeficit;
    }

    let trajectorySignal=null;
    if (cls==='impaired') {
      trajectorySignal={source:'support-consequence',dimensions:{perfusion:'impaired',circuitSupport:'impaired'}};
    } else if (cls==='severe') {
      trajectorySignal={source:'support-consequence',dimensions:{
        perfusion: severeAge >= 60 ? 'critical':'impaired',
        hemodynamics: severeAge >= 90 ? 'critical':'impaired',
        circuitSupport:'critical'
      }};
    } else if (cls==='critical') {
      trajectorySignal={source:'support-consequence',dimensions:{
        perfusion: severeAge >= 30 ? 'critical':'impaired',
        hemodynamics: severeAge >= 60 ? 'critical':'impaired',
        circuitSupport:'critical',
        oxygenation: (pao2Target != null && pao2Target < 70) ? 'critical':'impaired'
      }, arrest: severeAge >= 300};
    }

    if (internal) {
      internal.supportMapModifier = mapModifier;
      internal.supportHrModifier = hrModifier;
      // Own field, not shared with clinical-events' clinicalPao2Target — a
      // complication (e.g. oxygenator failure) may have its own reason for
      // PaO2 to be abnormal that has nothing to do with support/flow
      // deficit. Combining the two happens in physiology.mjs (worse wins),
      // not by one engine overwriting the other's field.
      internal.consequencePao2Target = pao2Target;
      if (elapsed > 0 && lactateDeltaPerMin > 0 && internal.trueLatent) {
        internal.trueLatent.lactateMmolL = clamp(
          Number(internal.trueLatent.lactateMmolL ?? 2) + lactateDeltaPerMin*(elapsed/60),
          0.5, 20
        );
      }
    }

    state.last={supportRatio:ratio,mapRatio,flowClass:flowCls,mapClass:mapCls,supportClass:cls,mapModifier,hrModifier,pao2Target,lactateDeltaPerMin,trajectorySignal};
    return clone(state.last);
  }

  return {
    evaluate,
    presentation:()=>clone(state.last),
    instructorPresentation:()=>({config:clone(config),...clone(state)}),
    snapshot:()=>clone(state)
  };
}
