// Clinical source-governance for post-feature-freeze validation.
//
// Governing hierarchy:
// 1) institution-specific protocol/policy when available and applicable
// 2) applicable ELSO standards/guidelines are the governing default for institutional gaps
// 3) unresolved/unvalidated only if neither source provides applicable guidance
//
// A simulation rule is never promoted to "validated" merely because the
// software passes tests or because a value appears clinically plausible.

export const SOURCE_AUTHORITY = Object.freeze({
  INSTITUTION: 'institution',
  ELSO: 'elso',
  UNVALIDATED: 'unvalidated'
});

export function resolveClinicalAuthority({
  institutionalSource = null,
  elsoSource = null
} = {}) {
  if (institutionalSource?.available === true) {
    return {
      authority: SOURCE_AUTHORITY.INSTITUTION,
      source: institutionalSource,
      fallbackUsed: false,
      validationEligible: true
    };
  }
  if (elsoSource?.available === true) {
    return {
      authority: SOURCE_AUTHORITY.ELSO,
      source: elsoSource,
      fallbackUsed: true,
      validationEligible: true
    };
  }
  return {
    authority: SOURCE_AUTHORITY.UNVALIDATED,
    source: null,
    fallbackUsed: false,
    validationEligible: false
  };
}

export function clinicalRuleRecord({
  ruleId,
  description,
  institutionalSource = null,
  elsoSource = null,
  currentSimulationValue = null,
  evidenceType = 'guideline-or-protocol',
  reviewerStatus = 'pending'
} = {}) {
  if (!ruleId) throw new Error('clinicalRuleRecord requires ruleId.');
  const authority = resolveClinicalAuthority({ institutionalSource, elsoSource });
  return {
    ruleId,
    description: description ?? '',
    governingAuthority: authority.authority,
    governingSource: authority.source,
    fallbackUsed: authority.fallbackUsed,
    validationEligible: authority.validationEligible,
    evidenceType,
    currentSimulationValue,
    reviewerStatus,
    clinicallyValidated: reviewerStatus === 'validated' && authority.validationEligible === true
  };
}
