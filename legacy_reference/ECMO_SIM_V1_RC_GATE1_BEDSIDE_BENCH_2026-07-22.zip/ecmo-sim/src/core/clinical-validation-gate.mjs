export function ruleValidationState(record={}){
 const sourceAssigned=record.sourceAssigned===true;
 const ruleExtracted=record.ruleExtracted===true;
 const expertReviewed=record.expertReviewed===true;
 const regressionVerified=record.regressionVerified===true;
 return {
  sourceAssigned,ruleExtracted,expertReviewed,regressionVerified,
  clinicallyValidated:sourceAssigned&&ruleExtracted&&expertReviewed&&regressionVerified
 };
}
export function canClaimElsoNumericStandard({exactSourceSupport=false}={}){
 return exactSourceSupport===true;
}

export function sourceVerificationState(record={}){
 return {
  sourceIdentityVerified:record?.sourceVerification?.officialCatalogVerified===true,
  exactRuleValidated:record?.gates?.exactSourceTextReviewed===true
    && record?.gates?.simulationCompared===true
    && record?.gates?.expertReviewed===true
 };
}
