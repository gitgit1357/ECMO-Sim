import { defaultClinicalKnowledgeRegistry } from './clinical-knowledge-registry.mjs';

function uniq(values){return [...new Set(values.filter(Boolean))];}

export function buildLearnerDebriefAnalysis({scenario,timeline=[],endpoint=null}={}){
  if(!endpoint) return null;
  const intendedId=scenario?.educatorScenarioMetadata?.intendedComplicationId
    ?? scenario?.clinicalKnowledgePlan?.requiredComplicationIds?.[0]
    ?? null;
  const comp=intendedId?defaultClinicalKnowledgeRegistry.get('complication',intendedId):null;
  const rules=comp?.definition?.actionRules ?? [];
  const preferred=uniq(rules.filter(r=>r.outcome==='preferred').map(r=>r.actionId));
  const acceptable=uniq(rules.filter(r=>r.outcome==='acceptable'||r.outcome==='temporizing').map(r=>r.actionId));
  const harmfulKnown=uniq(rules.filter(r=>r.outcome==='harmful'||r.outcome==='critical-error').map(r=>r.actionId));
  const ineffectiveKnown=uniq(rules.filter(r=>r.outcome==='ineffective').map(r=>r.actionId));

  const actionEntries=timeline.filter(e=>e.actionId && (
    e.kind==='clinical-action-outcome' || e.category==='action' || e.category==='resuscitation' || e.kind==='clinical-action'
  ));
  const performed=actionEntries.map(e=>e.actionId);
  const performedSet=new Set(performed);
  const firstById={};
  for(const e of actionEntries) if(firstById[e.actionId]==null) firstById[e.actionId]=e.atSec;

  const actionRows=actionEntries.map(e=>{
    const action=defaultClinicalKnowledgeRegistry.get('action',e.actionId);
    return {
      atSec:e.atSec,
      actionId:e.actionId,
      label:action?.label ?? e.actionLabel ?? e.actionId,
      category:action?.category ?? e.category ?? null,
      classification:e.outcomeClass ?? e.outcome ?? null,
      feedback:e.feedback ?? e.finding ?? ''
    };
  });

  const assessmentIds=actionRows.filter(r=>r.category==='assessment'||r.category==='diagnostic').map(r=>r.actionId);
  const firstAssessment=actionRows.find(r=>r.category==='assessment'||r.category==='diagnostic');
  const firstPreferred=actionRows.find(r=>preferred.includes(r.actionId));
  const harmfulPerformed=uniq(actionRows.filter(r=>r.classification==='harmful'||r.classification==='critical-error'||harmfulKnown.includes(r.actionId)).map(r=>r.actionId));
  const temporizingPerformed=uniq(actionRows.filter(r=>r.classification==='temporizing').map(r=>r.actionId));
  const ineffectivePerformed=uniq(actionRows.filter(r=>r.classification==='ineffective'||ineffectiveKnown.includes(r.actionId)).map(r=>r.actionId));
  const missedPreferred=preferred.filter(id=>!performedSet.has(id));

  const expectedPathway=preferred.map(id=>{
    const action=defaultClinicalKnowledgeRegistry.get('action',id);
    return {actionId:id,label:action?.label??id,performed:performedSet.has(id),atSec:firstById[id]??null};
  });

  const strengths=[];
  if(firstAssessment) strengths.push(`Assessment/evidence gathering began at ${firstAssessment.atSec}s.`);
  if(firstPreferred) strengths.push(`A preferred/cause-directed action was reached at ${firstPreferred.atSec}s.`);
  if(endpoint.type==='stabilized') strengths.push('The patient reached sustained stabilization after intervention.');
  if(!harmfulPerformed.length) strengths.push('No clearly harmful/critical-error action was recorded.');

  const improvementOpportunities=[];
  if(!firstAssessment) improvementOpportunities.push('No clear assessment/diagnostic action was recorded before the endpoint.');
  if(missedPreferred.length) improvementOpportunities.push(`Preferred pathway elements not recorded: ${missedPreferred.map(id=>defaultClinicalKnowledgeRegistry.get('action',id)?.label??id).join('; ')}.`);
  if(harmfulPerformed.length) improvementOpportunities.push(`Potentially harmful actions occurred: ${harmfulPerformed.map(id=>defaultClinicalKnowledgeRegistry.get('action',id)?.label??id).join('; ')}.`);
  if(temporizingPerformed.length) improvementOpportunities.push(`Temporizing actions helped without definitively correcting the cause: ${temporizingPerformed.map(id=>defaultClinicalKnowledgeRegistry.get('action',id)?.label??id).join('; ')}.`);
  if(ineffectivePerformed.length) improvementOpportunities.push(`Ineffective actions occurred: ${ineffectivePerformed.map(id=>defaultClinicalKnowledgeRegistry.get('action',id)?.label??id).join('; ')}.`);
  if(endpoint.type!=='stabilized') improvementOpportunities.push('The scenario ended without sustained stabilization; review recognition, timing, and definitive management.');

  return {
    clinicalProblem: comp?.label ?? null,
    endpoint: endpoint.type,
    expectedPathway,
    performedActions: actionRows,
    evidenceActionsUsed: uniq(assessmentIds),
    missedPreferredActions: missedPreferred,
    harmfulActionsPerformed: harmfulPerformed,
    temporizingActionsPerformed: temporizingPerformed,
    ineffectiveActionsPerformed: ineffectivePerformed,
    timeToFirstAssessmentSec:firstAssessment?.atSec??null,
    timeToFirstPreferredActionSec:firstPreferred?.atSec??null,
    strengths,
    improvementOpportunities
  };
}
