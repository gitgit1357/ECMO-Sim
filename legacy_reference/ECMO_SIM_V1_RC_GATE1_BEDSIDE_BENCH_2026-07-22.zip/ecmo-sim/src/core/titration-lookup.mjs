// Turns Frank's real bivalirudin titration protocol into a scored
// decision point. Only encodes what the protocol document actually gave
// us: neonate "standard" and neonate "hemorrhagic or operative" tables.
// Pediatric titration steps and the neonate "high thrombosis risk"
// titration steps were NOT in the uploaded protocol (only their goal
// bands were, in anticoagulation-protocol.json) — this file deliberately
// does not guess at them. Calling buildTitrationMission for an
// unsupported population/context throws rather than fabricating a table.

// bands are checked in order; `max` is exclusive (matches "0.3-0.4" style
// ranges in the source document), `min` with no `max` means "greater than".
const NEONATE_STANDARD_BANDS = [
  { max: 0.3, action: 'increase20-recheck', label: 'Increase dose 20% (x1.2), recheck dTT in 2h' },
  { min: 0.3, max: 0.4, action: 'increase15', label: 'Increase dose 15% (x1.15)' },
  { min: 0.4, max: 0.5, action: 'increase10', label: 'Increase dose 10% (x1.1)' },
  { min: 0.5, max: 1.0, action: 'no-change', label: 'No change' },
  { min: 1.0, max: 1.2, action: 'decrease10', label: 'Decrease dose 10% (x0.9)' },
  { min: 1.2, max: 1.5, action: 'decrease15', label: 'Decrease dose 15% (x0.85)' },
  { min: 1.5, action: 'decrease-renal-adjusted', label: 'Decrease dose 20-30% depending on renal function' }
];

const NEONATE_HEMORRHAGIC_BANDS = [
  { max: 0.1, action: 'increase20-recheck', label: 'Increase dose 20% (x1.2), recheck dTT in 2h' },
  { min: 0.1, max: 0.15, action: 'increase15', label: 'Increase dose 15% (x1.15)' },
  { min: 0.15, max: 0.2, action: 'increase10', label: 'Increase dose 10% (x1.1)' },
  { min: 0.2, max: 0.5, action: 'no-change', label: 'No change' },
  { min: 0.5, max: 0.7, action: 'decrease10', label: 'Decrease dose 10% (x0.9)' },
  { min: 0.7, max: 1.0, action: 'decrease15', label: 'Decrease dose 15% (x0.85)' },
  { min: 1.0, action: 'decrease-renal-adjusted', label: 'Decrease dose 20-30% depending on renal function' }
];

const RENAL_ADJUSTMENT = {
  normal: { action: 'decrease20', label: 'Decrease dose 20% (x0.8) — normal renal function' },
  mildModerate: { action: 'decrease25', label: 'Decrease dose 25% (x0.75) — mild-moderate impairment' },
  severe: { action: 'decrease30', label: 'Recheck dTT, contact provider, decrease dose 30% (x0.7) — severe impairment' }
};

const SUPPORTED_TABLES = {
  neonate: { standard: NEONATE_STANDARD_BANDS, hemorrhagicOrOperative: NEONATE_HEMORRHAGIC_BANDS }
};

function findBand(dtt, bands) {
  return bands.find((b) => (b.min === undefined || dtt >= b.min) && (b.max === undefined || dtt < b.max));
}

/**
 * Resolve the protocol-correct action for a given dTT result.
 *
 * `attemptNumber` handles the below-goal-floor bands, which the protocol
 * treats as a short sequence rather than a single lookup: 1st low reading
 * -> increase + recheck in 2h; 2nd consecutive low reading -> increase
 * again; 3rd -> consult the Peds Surgery attending/fellow. Anything else
 * in the table is a single lookup regardless of attempt number.
 *
 * `renalFunction` ('normal' | 'mildModerate' | 'severe') is required only
 * when the resolved band is the top, renal-adjusted one — passing none
 * there throws rather than guessing which percent applies.
 */
function baseBand({ population, riskContext, dtt }) {
  const table = SUPPORTED_TABLES[population]?.[riskContext];
  if (!table) {
    throw new Error(
      `No titration table for population "${population}" / riskContext "${riskContext}" — ` +
      'only neonate standard and neonate hemorrhagicOrOperative are in the protocol as uploaded.'
    );
  }
  const band = findBand(dtt, table);
  if (!band) throw new Error(`dTT ${dtt} did not match any band in the ${population}/${riskContext} table.`);
  return band;
}

/**
 * True if this dTT sits in the below-goal-floor band that triggers the
 * increase/increase-again/consult-attending sequence. Callers that need
 * to track attemptNumber across a session (e.g. circuit-sandbox) use this
 * to decide whether to keep incrementing their streak counter or reset it.
 */
export function isBelowGoalFloor({ population, riskContext, dtt }) {
  return baseBand({ population, riskContext, dtt }).action === 'increase20-recheck';
}

export function resolveTitrationAction({ population, riskContext, dtt, attemptNumber = 1, renalFunction } = {}) {
  const band = baseBand({ population, riskContext, dtt });

  if (band.action === 'increase20-recheck') {
    if (attemptNumber >= 3) return { action: 'consult-attending', label: 'Consult Pedi Surgery attending/fellow — still below goal after two dose increases' };
    if (attemptNumber === 2) return { action: 'increase20-second', label: 'Increase dose another 20% (x1.2)' };
    return band;
  }

  if (band.action === 'decrease-renal-adjusted') {
    if (!renalFunction || !RENAL_ADJUSTMENT[renalFunction]) {
      throw new Error(`dTT ${dtt} is in the renal-adjusted band — pass a renalFunction ('normal' | 'mildModerate' | 'severe') to resolve it.`);
    }
    return RENAL_ADJUSTMENT[renalFunction];
  }

  return band;
}

// The full set of action codes a distractor pool can draw from, labeled
// for display. Kept here (not scattered in the mission builder) so a UI
// can render a legend/glossary if useful.
export const ACTION_LABELS = Object.freeze({
  'increase20-recheck': 'Increase dose 20%, recheck dTT in 2h',
  'increase20-second': 'Increase dose another 20%',
  'consult-attending': 'Consult Pedi Surgery attending/fellow',
  increase15: 'Increase dose 15%',
  increase10: 'Increase dose 10%',
  'no-change': 'No change',
  decrease10: 'Decrease dose 10%',
  decrease15: 'Decrease dose 15%',
  decrease20: 'Decrease dose 20% (normal renal function)',
  decrease25: 'Decrease dose 25% (mild-moderate renal impairment)',
  decrease30: 'Decrease dose 30% (severe renal impairment)'
});

function shuffledDistractors(correctAction, count = 3) {
  const pool = Object.keys(ACTION_LABELS).filter((code) => code !== correctAction);
  const picked = [];
  while (picked.length < count && pool.length) {
    const index = Math.floor(Math.random() * pool.length);
    picked.push(pool.splice(index, 1)[0]);
  }
  return picked;
}

/**
 * Build a mission object in the shape the (forked) evidence-review engine
 * expects: { id, title, prompt, evidence, options, correctOption,
 * rationale, successFeedback, missFeedback }. Feed this straight into
 * evidenceReviewEngine.createSession({ mission }).
 */
export function buildTitrationMission({ id, population, riskContext, dtt, attemptNumber = 1, renalFunction }) {
  const correct = resolveTitrationAction({ population, riskContext, dtt, attemptNumber, renalFunction });
  const distractorCodes = shuffledDistractors(correct.action);
  const options = [
    { id: correct.action, label: correct.label },
    ...distractorCodes.map((code) => ({ id: code, label: ACTION_LABELS[code] }))
  ].sort(() => Math.random() - 0.5);

  return {
    id: id ?? `titration-${population}-${riskContext}-${dtt}`,
    eyebrow: 'ANTICOAGULATION TITRATION',
    title: `dTT resulted at ${dtt} mcg/mL`,
    prompt: `${population === 'neonate' ? 'Neonate' : population}, ${riskContext} goal context. Per protocol, what's the correct next step?`,
    evidence: [{ label: 'Resulted dTT', value: `${dtt} mcg/mL` }],
    options,
    correctOption: correct.action,
    rationale: correct.label,
    successFeedback: 'Correct per protocol.',
    missFeedback: 'Not the protocol-correct step for this dTT — check the goal band again.'
  };
}
