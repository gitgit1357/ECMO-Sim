export const RELEASE_LEVELS=Object.freeze({
 FEATURE_COMPLETE_PRECLINICAL:'feature-complete-preclinical',
 VALIDATION_IN_PROGRESS:'validation-in-progress',
 CLINICALLY_VALIDATED:'clinically-validated',
 COMPETENCY_READY:'competency-ready'
});

export function computeReleaseReadiness({rules=[],scenarioCount=0}={}){
 const total=rules.length;
 const validated=rules.filter(r=>r.clinicallyValidated===true).length;
 const allValidated=total>0&&validated===total;
 const competency=allValidated&&rules.every(r=>r.competencyReady===true);
 return {
  totalRules:total,validatedRules:validated,scenarioCount,
  level:competency?RELEASE_LEVELS.COMPETENCY_READY:
        allValidated?RELEASE_LEVELS.CLINICALLY_VALIDATED:
        RELEASE_LEVELS.VALIDATION_IN_PROGRESS,
  mayClaimClinicallyValidated:allValidated,
  mayClaimCompetencyReady:competency
 };
}

export function releaseClaimGuard(readiness,claim){
 if(claim==='clinically-validated'&&!readiness.mayClaimClinicallyValidated)return {allowed:false,reason:'clinical-validation-incomplete'};
 if(claim==='competency-ready'&&!readiness.mayClaimCompetencyReady)return {allowed:false,reason:'competency-validation-incomplete'};
 return {allowed:true,reason:null};
}
