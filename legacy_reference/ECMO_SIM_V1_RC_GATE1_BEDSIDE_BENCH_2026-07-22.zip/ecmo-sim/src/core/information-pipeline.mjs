function clone(v){ return JSON.parse(JSON.stringify(v)); }

export const TIMING_PLACEHOLDERS = Object.freeze({
  abg: { requestToAcquisitionSec: null, acquisitionToRawResultSec: null, rawResultToInterpretationSec: 0 },
  xray: { requestToAcquisitionSec: null, acquisitionToRawResultSec: 0, rawResultToInterpretationSec: null, acquisitionBlockers: ['active-code'] },
  echo: { requestToAcquisitionSec: null, acquisitionToRawResultSec: 0, rawResultToInterpretationSec: null },
  ct: { requestToAcquisitionSec: null, acquisitionToRawResultSec: null, rawResultToInterpretationSec: null }
});

function resolvedTiming(kind, timingProfile = {}) {
  return { ...(TIMING_PLACEHOLDERS[kind] ?? {}), ...(timingProfile[kind] ?? {}) };
}

export function createInformationPipeline({ timingProfile = {}, snapshot = null } = {}) {
  const state = snapshot ? clone(snapshot) : { sequence: 0, requests: [], feed: [] };

  function feed(kind, atSec, title, detail = '', requestId = null) {
    state.feed.push({ id: `info-${++state.sequence}`, kind, atSec, title, detail, requestId });
  }

  function request(kind, { timeSec = 0, label = kind.toUpperCase(), payload = {}, blockers = [] } = {}) {
    const timing = resolvedTiming(kind, timingProfile);
    const id = `request-${++state.sequence}`;
    const rec = {
      id, kind, label, requestedAtSec: timeSec, payload: clone(payload),
      status: 'requested', acquiredAtSec: null, rawAvailableAtSec: null, interpretedAtSec: null,
      acquisitionReadyAtSec: timing.requestToAcquisitionSec == null ? null : timeSec + Number(timing.requestToAcquisitionSec),
      timing, blockers: [...new Set([...(timing.acquisitionBlockers ?? []), ...blockers])]
    };
    state.requests.push(rec);
    feed('request', timeSec, `${label} requested`, '', id);
    return clone(rec);
  }

  function blockersActive(rec, context = {}) {
    return rec.blockers.some((b) => Boolean(context[b]));
  }

  function tick(timeSec, context = {}) {
    for (const rec of state.requests) {
      if (rec.status === 'requested') {
        const ready = rec.acquisitionReadyAtSec != null && timeSec >= rec.acquisitionReadyAtSec;
        if (ready) {
          if (blockersActive(rec, context)) {
            if (rec.status !== 'blocked') rec.status = 'blocked';
          } else {
            rec.status = 'ready-for-acquisition';
            feed('ready', timeSec, `${rec.label} ready`, 'Bedside/service is available to perform the study.', rec.id);
          }
        }
      } else if (rec.status === 'ready-for-acquisition' && blockersActive(rec, context)) {
        rec.status = 'blocked';
      } else if (rec.status === 'blocked' && !blockersActive(rec, context)) {
        rec.status = 'ready-for-acquisition';
        feed('ready', timeSec, `${rec.label} ready`, 'Previously delayed by clinical activity; may now be performed.', rec.id);
      }
      if (rec.status === 'acquired' && rec.rawAvailableAtSec != null && timeSec >= rec.rawAvailableAtSec) {
        rec.status = 'raw-available';
        feed('result', timeSec, `${rec.label} available`, 'Raw result/image is now available to review.', rec.id);
      }
      if (rec.status === 'raw-available' && rec.interpretedAtSec != null && timeSec >= rec.interpretedAtSec) {
        rec.status = 'interpreted';
        feed('interpretation', timeSec, `${rec.label} interpretation available`, 'Formal interpretation is now available.', rec.id);
      }
    }
  }

  function acquire(requestId, { timeSec = 0, context = {}, rawResult = null, interpretation = null } = {}) {
    const rec = state.requests.find((r) => r.id === requestId);
    if (!rec) throw new Error(`Unknown information request ${requestId}`);
    if (blockersActive(rec, context)) return { ok:false, status:'blocked', reason:'Clinical activity is preventing acquisition right now.' };
    if (!['ready-for-acquisition','requested','blocked'].includes(rec.status)) return { ok:false, status:rec.status };
    rec.acquiredAtSec = timeSec;
    rec.payload.rawResult = rawResult ?? rec.payload.rawResult ?? null;
    rec.payload.interpretation = interpretation ?? rec.payload.interpretation ?? null;
    const rawDelay = rec.timing.acquisitionToRawResultSec;
    const interpDelay = rec.timing.rawResultToInterpretationSec;
    rec.rawAvailableAtSec = rawDelay == null ? null : timeSec + Number(rawDelay);
    rec.interpretedAtSec = (rawDelay == null || interpDelay == null) ? null : rec.rawAvailableAtSec + Number(interpDelay);
    rec.status = 'acquired';
    feed('acquired', timeSec, `${rec.label} acquired`, '', rec.id);
    tick(timeSec, context);
    return { ok:true, status:rec.status, request:clone(rec) };
  }

  function presentation() {
    return {
      requests: clone(state.requests),
      feed: clone(state.feed).sort((a,b)=>a.atSec-b.atSec || a.id.localeCompare(b.id))
    };
  }
  return { request, acquire, tick, presentation, snapshot:()=>clone(state) };
}
