export function verifyReleaseManifest(manifest={}){
  const errors=[];
  if(manifest.releaseClass!=='preclinical-release-candidate') errors.push('unexpected release class');
  if(manifest.clinicalStatus!=='validation-in-progress') errors.push('clinical status must remain validation-in-progress');
  if(manifest.competencyReady!==false) errors.push('preclinical package cannot be competency ready');
  const required=['START_HERE.md','M12_V1_FEATURE_FREEZE_2026-07-22.md','clinical-source-registry.json','clinical-validation-manifest.json','prevalidation-clinical-baseline.json','standalone-v3.3/index.html'];
  for(const key of required){
    const f=manifest.criticalFiles?.[key];
    if(!f?.exists) errors.push(`missing critical file: ${key}`);
    if(f?.exists&&!/^[a-f0-9]{64}$/.test(f.sha256??'')) errors.push(`invalid sha256: ${key}`);
  }
  return {valid:errors.length===0,errors};
}
