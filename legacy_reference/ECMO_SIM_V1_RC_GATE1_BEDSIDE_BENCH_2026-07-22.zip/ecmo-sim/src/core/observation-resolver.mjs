// Learner-facing assessment resolver.
// Assessments should return findings even when they do not treat the active problem.
// Hidden diagnosis IDs never appear in returned text.

function unresolved(active, id){
  const s=active?.[id];
  return s && s.resolvedAtSec == null ? s : null;
}

export function resolveObservation(actionId, { eventSnapshot = {}, circuit = {}, monitored = {}, internal = {}, scenario = {} } = {}) {
  const active=eventSnapshot.active ?? {};







  if(actionId==='neuro-assessment'){
    if(unresolved(active,'intracranial-hemorrhage')) return 'Focused neurologic assessment shows a new asymmetric/acute examination change inconsistent with the prior sedation baseline, requiring urgent neuroimaging and bleeding-risk escalation.';
  }
  if(actionId==='assess-shock'){
    if(unresolved(active,'vasoplegia-shock')) return `Perfusion assessment shows a distributive/vasoplegic pattern with inadequate MAP despite maintained ECMO flow, consistent with vascular-tone failure rather than isolated pump-flow loss.`;
  }
  if(actionId==='assess-renal-fluid'){
    if(unresolved(active,'aki-fluid-overload')) return `Renal/fluid assessment shows urine output about ${Number(internal?.urineOutputMlKgHr??0.3).toFixed(1)} mL/kg/hr with cumulative fluid balance about +${Math.round(Number(internal?.cumulativeFluidBalancePct??12))}% and clinically important congestion.`;
  }
  if(actionId==='assess-electrolytes'){
    if(unresolved(active,'metabolic-electrolyte-emergency')) return `Urgent metabolic review identifies a severe actionable potassium abnormality (K about ${Number(internal?.potassiumTarget??7.1).toFixed(1)} mmol/L) with hemodynamic/rhythm risk requiring immediate targeted correction.`;
  }
  if(actionId==='assess-pulmonary-hypertension'){
    if(unresolved(active,'pulmonary-hypertensive-crisis')) return `Cardiopulmonary assessment shows an acute RV pressure-overload/pulmonary hypertensive crisis pattern with worsening oxygenation and perfusion despite technically functioning ECMO support.`;
  }

  if(actionId==='assess-gas-exchange'){
    const event=unresolved(active,'gas-exchange-failure');
    const pao2=Math.round(Number(internal?.clinicalPao2Target ?? internal?.trueLatent?.pao2 ?? 90));
    const paco2=Math.round(Number(internal?.clinicalPaco2Target ?? internal?.trueLatent?.paco2 ?? 40));
    if(event){
      return `Gas-exchange assessment confirms a clinically significant support mismatch: systemic PaO2 about ${pao2} mmHg and PaCO2 about ${paco2} mmHg. Circuit flow, membrane-lung function, sweep/FdO2, native lung condition, and cannula effectiveness must be localized before indiscriminate escalation.`;
    }
    return `Gas-exchange reassessment shows effective support restored with oxygenation and ventilation trending back toward target.`;
  }

  if(actionId==='assess-thorax'){
    const event=unresolved(active,'pneumothorax-intrathoracic-pressure');
    if(event){
      return `Thoracic assessment shows an acute unilateral pressure/ventilation pattern with impaired venous return and ECMO drainage, consistent with a tension-type mechanical process requiring immediate decompression.`;
    }
    return `Thoracic reassessment shows restored mechanics and no ongoing tension-type impairment of ventilation or venous return.`;
  }

  if(actionId==='assess-airway-ventilator'){
    const event=unresolved(active,'airway-ventilator-failure');
    const pao2=Math.round(Number(internal?.clinicalPao2Target ?? internal?.trueLatent?.pao2 ?? 90));
    const paco2=Math.round(Number(internal?.clinicalPaco2Target ?? internal?.trueLatent?.paco2 ?? 40));
    if(event){
      return `Airway/ventilator assessment identifies a correctable mechanical ventilation failure with impaired native gas exchange (PaO2 about ${pao2} mmHg; PaCO2 about ${paco2} mmHg). The ECMO circuit itself does not explain the full deterioration.`;
    }
    return `Airway/ventilator reassessment shows the mechanical problem corrected with native ventilation and gas exchange improving.`;
  }

  if(actionId==='assess-recirculation'){
    const event=unresolved(active,'vv-recirculation');
    const frac=Math.round(Number(internal?.recirculationFractionTarget ?? 0.18)*100);
    const drainage=Math.round(Number(internal?.drainageSatTarget ?? 72));
    const ret=Math.round(Number(internal?.returnSatTarget ?? 98));
    const systemic=Math.round(Number(internal?.systemicSpo2Target ?? monitored?.spo2 ?? 94));
    if(event){
      return `VV support assessment shows a recirculation pattern: estimated recirculated fraction about ${frac}%, drainage/pre-oxygenator saturation about ${drainage}%, return saturation about ${ret}%, while systemic SpO2 is only about ${systemic}%. High drainage saturation despite poor systemic oxygenation suggests oxygenated return blood is being re-drained rather than delivered effectively to the patient.`;
    }
    return `VV reassessment shows improved effective support: estimated recirculation about ${frac}% with lower drainage saturation and systemic SpO2 about ${systemic}%.`;
  }

  if(actionId==='assess-lv-distension'){
    const event=unresolved(active,'va-lv-distension');
    if(event){
      const grade=internal?.lvDistensionGrade ?? 'moderate';
      const av=internal?.aorticValveOpening ?? 'minimal';
      const congestion=internal?.pulmonaryCongestionGrade ?? 'moderate';
      return `Focused VA assessment shows ${grade} LV distension with ${av} aortic-valve opening and ${congestion} pulmonary congestion. The pattern indicates inadequate left-heart unloading with stasis/congestion risk.`;
    }
    return 'Focused VA assessment shows no clinically important LV distension pattern; ventricular ejection and pulmonary congestion are acceptably controlled.';
  }

  if(actionId==='assess-limb-perfusion'){
    const event=unresolved(active,'limb-ischemia');
    if(event){
      const pulse=internal?.distalPulseStatus ?? 'absent-doppler';
      const temp=internal?.limbTemperatureStatus ?? 'cool';
      const color=internal?.limbColorStatus ?? 'pale-mottled';
      return `Cannulated-extremity assessment shows distal pulse status: ${pulse}; limb temperature: ${temp}; color/perfusion: ${color}. The findings indicate clinically significant threatened distal perfusion requiring urgent correction.`;
    }
    return 'Distal perfusion assessment shows restored flow with improving temperature/color and no ongoing critical limb-ischemia pattern.';
  }

  if(actionId==='assess-thrombosis'){
    const event=unresolved(active,'circuit-systemic-thrombosis');
    if(event){
      const flow=Math.round(Number(circuit.flowIndexMlKgMin ?? 0));
      const location=internal?.thrombusLocationPattern ?? 'circuit-or-cannula-burden';
      const burden=internal?.thrombusBurdenGrade ?? 'clinically-significant';
      return `Thrombosis assessment identifies a ${burden} ${location} pattern with reduced effective ECMO support (flow index about ${flow} mL/kg/min). Localization and consequence require definitive thrombosis-directed management rather than simple RPM escalation.`;
    }
    return 'Thrombosis reassessment shows the immediate thrombotic threat is controlled and effective ECMO support has recovered.';
  }

  if(actionId==='assess-differential-hypoxemia'){
    const event=unresolved(active,'va-differential-hypoxemia');
    const rSpo2=Math.round(Number(internal?.rightRadialSpo2Target ?? monitored?.spo2 ?? 96));
    const lSpo2=Math.round(Number(internal?.lowerBodySpo2Target ?? monitored?.spo2 ?? 96));
    const rPao2=Math.round(Number(internal?.rightRadialPao2Target ?? internal?.trueLatent?.pao2 ?? 90));
    const lPao2=Math.round(Number(internal?.lowerBodyPao2Target ?? internal?.trueLatent?.pao2 ?? 90));
    if(event){
      return `Site-specific oxygenation assessment shows a clinically important differential: right radial/upper-body SpO2 about ${rSpo2}% with PaO2 about ${rPao2} mmHg, while lower-body/postductal SpO2 is about ${lSpo2}% with PaO2 about ${lPao2} mmHg. The pattern is consistent with poorly oxygenated native cardiac output preferentially reaching the upper-body circulation while better-oxygenated retrograde VA ECMO flow supplies the lower body.`;
    }
    return `Site-specific oxygenation is acceptably matched: right radial/upper-body SpO2 about ${rSpo2}% and lower-body SpO2 about ${lSpo2}%, without a clinically important upper/lower-body differential.`;
  }

  if(actionId==='assess-oxygenator'){
    const event=unresolved(active,'oxygenator-thrombosis-failure');
    const deltaP=Math.round(Number(circuit.deltaP ?? 0));
    const prePao2=Math.round(Number(internal?.trueLatent?.pao2 ?? internal?.clinicalPao2Target ?? 55));
    const postTarget=Number(internal?.postOxyPao2Target ?? (event ? 135 : 450));
    const postPao2=Math.round(postTarget);
    if(event){
      const severity=event.state==='critical' ? 'severely abnormal' : event.state==='worsened' ? 'markedly abnormal' : 'abnormal';
      return `Oxygenator assessment shows an ${severity} pattern: the trans-oxygenator pressure gradient is approximately ${deltaP} mmHg at the current flow and is abnormal relative to the established device/flow trend, with limited post-oxygenator oxygen transfer (pre-oxygenator PaO2 about ${prePao2} mmHg; post-oxygenator PaO2 about ${postPao2} mmHg). Interpret ΔP as a trend in relation to flow and oxygenator characteristics rather than as a universal absolute cutoff. The pattern is not explained by patient-only lung dysfunction.`;
    }
    return `Oxygenator assessment shows no major membrane-lung failure pattern: the pressure-gradient trend is acceptable for the current flow/device context (approximately ${deltaP} mmHg at this moment) with strong post-oxygenator oxygen transfer.`;
  }

  if(actionId==='assess-pump-function'){
    if(unresolved(active,'pump-support-failure')){
      return 'Pump assessment shows loss of effective pump output despite the commanded setting. This is not behaving like a simple preload problem.';
    }
    return `Pump is powered and running. Displayed RPM matches the commanded setting. No pump-fault pattern is identified.`;
  }

  if(actionId==='inspect-circuit-path'){
    if(unresolved(active,'mechanical-circuit-obstruction')){
      return 'Circuit inspection identifies an abnormal resistance / obstruction pattern that requires immediate mechanical troubleshooting.';
    }
    return 'The visible circuit path is intact. No external tubing kink, disconnection, or obvious accessible circuit obstruction is identified.';
  }

  if(actionId==='inspect-drainage-cannula'){
    if(unresolved(active,'drainage-cannula-kink')){
      return 'Inspection identifies a mechanical abnormality along the drainage cannula / tubing path that can account for the flow loss.';
    }
    if(unresolved(active,'position-sensitive-cannula')){
      return `No external cannula/tubing kink is seen. Drainage is unstable in the current position${circuit.chatter ? ' with visible/console evidence of drainage limitation' : ''}.`;
    }
    return 'No visible external drainage cannula kink or tubing obstruction is identified.';
  }

  if(actionId==='assess-hemodynamics'){
    const flow=Math.round(Number(circuit.flowIndexMlKgMin ?? 0));
    return `Current assessment: ECMO flow ${flow} mL/kg/min, MAP ${monitored.map ?? '--'} mmHg, CVP ${monitored.cvp ?? '--'} mmHg. Review the trend and circuit findings for the cause of inadequate support.`;
  }

  if(actionId==='turn-patient'){
    return 'The patient is repositioned. No meaningful clinical change is observed. Continue to observe ECMO flow, drainage behavior, and hemodynamics.';
  }

  if(actionId==='restore-prior-position'){
    return 'The patient is returned toward the documented prior position. Observe for a reproducible change in drainage and ECMO flow.';
  }

  if(actionId==='relieve-cannula-kink'){
    return 'No previously identified external cannula/tubing kink is available to correct.';
  }

  if(actionId==='relieve-circuit-obstruction'){
    return 'No previously identified accessible circuit obstruction is available to correct.';
  }

  if(actionId==='order-echo'){
    return 'Bedside echocardiography is requested. Findings will be available through the diagnostic-results workflow when the study is completed.';
  }

  return 'No meaningful clinical change is observed. No additional specific finding is produced by that action in the current state.';
}
