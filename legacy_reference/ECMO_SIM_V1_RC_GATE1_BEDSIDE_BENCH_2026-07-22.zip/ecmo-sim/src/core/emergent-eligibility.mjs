function clone(value) { return JSON.parse(JSON.stringify(value)); }

function getPath(obj, path) {
  return String(path ?? '').split('.').filter(Boolean).reduce((cur, key) => cur == null ? undefined : cur[key], obj);
}

function compare(actual, op, expected) {
  switch (op ?? 'eq') {
    case 'eq': return actual === expected;
    case 'neq': return actual !== expected;
    case 'gte': return Number(actual) >= Number(expected);
    case 'gt': return Number(actual) > Number(expected);
    case 'lte': return Number(actual) <= Number(expected);
    case 'lt': return Number(actual) < Number(expected);
    case 'includes': return Array.isArray(actual) ? actual.includes(expected) : String(actual ?? '').includes(String(expected));
    default: throw new Error(`Unsupported emergent eligibility comparator "${op}".`);
  }
}

function conditionMatches(condition, context) {
  if (!condition?.source || !condition?.path) throw new Error('Emergent eligibility conditions require source and path.');
  const source = context[condition.source] ?? {};
  return compare(getPath(source, condition.path), condition.op, condition.value);
}

export function createEmergentEligibilityEngine(rules = [], snapshot = null) {
  const ruleMap = new Map(rules.map((rule) => {
    if (!rule?.id || !rule?.complicationId) throw new Error('Emergent eligibility rules require id and complicationId.');
    return [rule.id, clone(rule)];
  }));
  const state = snapshot ? clone(snapshot) : {
    firedRuleIds: [],
    sustainedSinceSec: {},
    actionCounts: {},
    sequence: 0
  };
  const fired = new Set(state.firedRuleIds ?? []);

  function recordAction(actionId) {
    if (!actionId) return;
    state.actionCounts[actionId] = Number(state.actionCounts[actionId] ?? 0) + 1;
  }

  function ruleMatches(rule, context) {
    const all = rule.all ?? [];
    const any = rule.any ?? [];
    const augmented = { ...context, actionCounts: state.actionCounts };
    const allMatch = all.every((condition) => conditionMatches(condition, augmented));
    const anyMatch = !any.length || any.some((condition) => conditionMatches(condition, augmented));
    return allMatch && anyMatch;
  }

  function evaluate(context = {}) {
    const timeSec = Number(context.timeSec ?? 0);
    const eligible = [];
    for (const rule of ruleMap.values()) {
      if (fired.has(rule.id)) continue;
      const matches = ruleMatches(rule, context);
      if (!matches) {
        delete state.sustainedSinceSec[rule.id];
        continue;
      }
      if (state.sustainedSinceSec[rule.id] == null) state.sustainedSinceSec[rule.id] = timeSec;
      const sustainedForSec = timeSec - Number(state.sustainedSinceSec[rule.id]);
      if (sustainedForSec < Number(rule.sustainForSec ?? 0)) continue;
      fired.add(rule.id);
      state.firedRuleIds = [...fired];
      state.sequence += 1;
      eligible.push({
        id: `emergent-${state.sequence}`,
        ruleId: rule.id,
        complicationId: rule.complicationId,
        source: rule.source ?? 'emergent-eligibility',
        priority: Number(rule.priority ?? 0),
        atSec: timeSec,
        metadata: clone(rule.metadata ?? {})
      });
    }
    return eligible;
  }

  function instructorPresentation() {
    return {
      rules: [...ruleMap.values()].map(clone),
      firedRuleIds: [...fired],
      sustainedSinceSec: clone(state.sustainedSinceSec),
      actionCounts: clone(state.actionCounts)
    };
  }

  return {
    recordAction,
    evaluate,
    instructorPresentation,
    snapshot: () => clone({ ...state, firedRuleIds: [...fired] })
  };
}
