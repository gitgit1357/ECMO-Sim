import { educatorScenarioCatalog } from './educator-scenario-creator.mjs';

export const VALIDATION_STATES=Object.freeze({
 technical:['not-tested','automated-passed','failed'],
 bench:['not-tested','accepted','failed'],
 clinical:['pending','in-review','validated','rejected'],
 timing:['placeholder','reviewed','validated']
});

function templates(){return educatorScenarioCatalog().flatMap(p=>p.templates.map(t=>({packId:p.id,packLabel:p.label,...t})));}

export function validationCatalog(){
 return templates().map(t=>({
   templateId:t.id,
   packId:t.packId,
   label:t.label,
   version:'v1-preclinical',
   technicalStatus:'automated-passed',
   benchStatus:'accepted',
   clinicalReviewStatus:'pending',
   timingValidationStatus:'placeholder',
   competencyReady:false,
   notes:['Technical/bench acceptance does not equal clinical validation.']
 }));
}

export function validationSummary(){
 const rows=validationCatalog();
 return {
   totalTemplates:rows.length,
   technicalPassed:rows.filter(x=>x.technicalStatus==='automated-passed').length,
   benchAccepted:rows.filter(x=>x.benchStatus==='accepted').length,
   clinicalValidated:rows.filter(x=>x.clinicalReviewStatus==='validated').length,
   competencyReady:rows.filter(x=>x.competencyReady).length,
   clinicalReviewPending:rows.filter(x=>x.clinicalReviewStatus==='pending').length
 };
}

export function evaluateCompetencyReadiness(record){
 return record?.technicalStatus==='automated-passed'
   && record?.benchStatus==='accepted'
   && record?.clinicalReviewStatus==='validated'
   && record?.timingValidationStatus==='validated';
}

export function applyValidationUpdate(record,patch={}){
 const next={...record,...patch};
 next.competencyReady=evaluateCompetencyReadiness(next);
 return next;
}

export function clinicalReviewChecklist(){
 return [
  'Confirm case premise and expected differential are clinically appropriate.',
  'Review action classifications: preferred, acceptable, temporizing, ineffective, harmful.',
  'Review deterioration timing and physiologic thresholds.',
  'Review monitor/lab/observation realism and absence of diagnosis leakage.',
  'Review success/failure endpoint criteria.',
  'Document reviewer identity, date, version, required changes, and disposition.',
  'Mark clinical/timing status validated only after required changes are incorporated and re-tested.'
 ];
}
