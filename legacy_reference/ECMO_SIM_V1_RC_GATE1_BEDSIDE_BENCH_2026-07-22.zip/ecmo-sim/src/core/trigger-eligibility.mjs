function clone(value) { return JSON.parse(JSON.stringify(value)); }

export function createTriggerEligibilityEngine(policies = [], snapshot = null) {
  const policyMap = new Map(policies.map((policy) => {
    if (!policy?.id || !policy?.complicationId) throw new Error('Trigger policies require id and complicationId.');
    return [policy.id, clone(policy)];
  }));

  const state = snapshot ? clone(snapshot) : {
    firedPolicyIds: [],
    actionCounts: {},
    sequence: 0
  };

  const fired = new Set(state.firedPolicyIds ?? []);

  function recordAction(actionId) {
    if (!actionId) return;
    state.actionCounts[actionId] = Number(state.actionCounts[actionId] ?? 0) + 1;
  }

  function contextMatches(required = {}, actual = {}) {
    return Object.entries(required).every(([key, expected]) => actual[key] === expected);
  }

  function isEligible(policy, { timeSec = 0, clinicalContext = {}, started = false } = {}) {
    if (fired.has(policy.id)) return false;
    switch (policy.type ?? 'at-start') {
      case 'at-start':
        return started;
      case 'time-window':
        return started && Number(timeSec) >= Number(policy.eligibleAfterSec ?? 0);
      case 'context':
        return started && contextMatches(policy.requiresContext ?? {}, clinicalContext);
      case 'action-count':
        return started && Number(state.actionCounts[policy.actionId] ?? 0) >= Number(policy.count ?? 1);
      case 'manual':
        return false;
      default:
        throw new Error(`Unsupported trigger policy type "${policy.type}".`);
    }
  }

  function evaluate(context = {}) {
    const activations = [];
    for (const policy of policyMap.values()) {
      if (!isEligible(policy, context)) continue;
      fired.add(policy.id);
      state.firedPolicyIds = [...fired];
      state.sequence += 1;
      activations.push({
        id: `trigger-${state.sequence}`,
        policyId: policy.id,
        complicationId: policy.complicationId,
        source: policy.source ?? 'scenario-policy',
        atSec: Number(context.timeSec ?? 0),
        metadata: clone(policy.metadata ?? {})
      });
    }
    return activations;
  }

  function instructorPresentation() {
    return {
      policies: [...policyMap.values()].map(clone),
      firedPolicyIds: [...fired],
      actionCounts: clone(state.actionCounts)
    };
  }

  return {
    recordAction,
    evaluate,
    instructorPresentation,
    snapshot: () => clone({ ...state, firedPolicyIds: [...fired] })
  };
}
