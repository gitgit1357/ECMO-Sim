function clone(value) { return JSON.parse(JSON.stringify(value)); }

const HIDDEN_LOG_KINDS = new Set([
  'clinical-action-outcome',
  'clinical-event-transition',
  'checkpoint-skipped',
  'trigger-activation'
]);

const FORBIDDEN_LEARNER_KEYS = new Set([
  'eventId', 'complicationId', 'hiddenState', 'eventState',
  'score', 'scoreDelta', 'rationale', 'learningPlan',
  'clinicalKnowledgePlan', 'educatorSetup', 'requiredComplicationIds',
  'allowedComplicationIds', 'activateAtStartIds', 'triggerPolicies'
]);

export function sanitizeLearnerLog(entries = []) {
  return entries
    .filter((entry) => !HIDDEN_LOG_KINDS.has(entry?.kind))
    .map((entry) => stripForbiddenFields(entry));
}

export function stripForbiddenFields(value) {
  if (Array.isArray(value)) return value.map(stripForbiddenFields);
  if (!value || typeof value !== 'object') return value;
  const out = {};
  for (const [key, child] of Object.entries(value)) {
    if (FORBIDDEN_LEARNER_KEYS.has(key)) continue;
    out[key] = stripForbiddenFields(child);
  }
  return out;
}

export function learnerActionResult({ ok = true, accepted = true, complete = false, status = 'applied', feedback = '' } = {}) {
  return { ok, accepted, complete, status, feedback };
}

export function sanitizeLearnerActionResult(result = {}) {
  const publicStatus = [
    'invalid', 'not-started', 'already-started', 'started', 'blocked',
    'pending', 'raw-available', 'interpreted', 'no-specific-effect'
  ].includes(result.status) ? result.status : 'applied';

  return learnerActionResult({
    ok: result.ok,
    accepted: result.accepted,
    complete: result.complete,
    status: publicStatus,
    feedback: result.feedback ?? ''
  });
}

export function assertNoDiagnosticLeakage(value, forbiddenTerms = []) {
  const text = JSON.stringify(value).toLowerCase();
  const hits = forbiddenTerms.filter((term) => term && text.includes(String(term).toLowerCase()));
  return { ok: hits.length === 0, hits };
}

export function cloneInstructorPayload(value) { return clone(value); }
