const AUTHORITIES=new Set(['institution','elso','specialty-supplement']);
export function validateSourceIngestion(doc={}){
 const errors=[];
 for(const k of ['sourceId','authority','title','version','documentLocator'])if(!doc[k])errors.push(`missing ${k}`);
 if(doc.authority&&!AUTHORITIES.has(doc.authority))errors.push('invalid authority');
 if(!Array.isArray(doc.rulesSupported)||doc.rulesSupported.length===0)errors.push('rulesSupported must contain at least one rule');
 if(!Array.isArray(doc.extractions)||doc.extractions.length===0)errors.push('at least one extraction required');
 for(const [i,x] of (doc.extractions||[]).entries()){
  if(!x.ruleId)errors.push(`extractions[${i}] missing ruleId`);
  if(!x.section&&!x.page)errors.push(`extractions[${i}] missing source locator`);
  if(!x.statementParaphrase)errors.push(`extractions[${i}] missing statementParaphrase`);
  if(x.supportsExactNumericValue===true&&(x.exactNumericValue===null||x.exactNumericValue===undefined||!x.units))
   errors.push(`extractions[${i}] exact numeric support requires value and units`);
 }
 return {valid:errors.length===0,errors};
}
export function authorityRank(a){return a==='institution'?3:a==='elso'?2:a==='specialty-supplement'?1:0;}
export function selectGoverningExtraction(extractions=[]){
 return [...extractions].sort((a,b)=>authorityRank(b.authority)-authorityRank(a.authority))[0]??null;
}
