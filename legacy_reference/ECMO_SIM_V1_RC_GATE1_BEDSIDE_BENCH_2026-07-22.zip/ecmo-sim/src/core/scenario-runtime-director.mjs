function clone(value) { return JSON.parse(JSON.stringify(value)); }

export const DEFAULT_DIRECTOR_PROFILES = Object.freeze({
  guided: Object.freeze({ maxConcurrentEvents: 1, minEventSpacingSec: 0 }),
  adaptive: Object.freeze({ maxConcurrentEvents: 1, minEventSpacingSec: 60 }),
  dynamic: Object.freeze({ maxConcurrentEvents: 2, minEventSpacingSec: 30 })
});

function normalizeCandidate(candidate, sequence) {
  if (!candidate?.complicationId) throw new Error('Runtime director candidate requires complicationId.');
  return {
    id: candidate.id ?? `candidate-${sequence}`,
    eligibilityId: candidate.id ?? `candidate-${sequence}`,
    complicationId: candidate.complicationId,
    source: candidate.source ?? 'eligibility-engine',
    eligibleAtSec: Number(candidate.atSec ?? 0),
    priority: Number(candidate.priority ?? 0),
    metadata: clone(candidate.metadata ?? {})
  };
}

export function createScenarioRuntimeDirector({ mode = 'adaptive', profile = {}, snapshot = null } = {}) {
  if (!DEFAULT_DIRECTOR_PROFILES[mode]) throw new Error(`Unsupported runtime director mode "${mode}".`);
  const config = { ...DEFAULT_DIRECTOR_PROFILES[mode], ...profile };
  const state = snapshot ? clone(snapshot) : {
    sequence: 0,
    queue: [],
    released: [],
    lastReleaseAtSec: null
  };
  const releasedComplications = new Set((state.released ?? []).map((r) => r.complicationId));
  const queuedComplications = new Set((state.queue ?? []).map((r) => r.complicationId));

  function enqueue(candidates = []) {
    const accepted = [];
    for (const raw of candidates) {
      if (!raw?.complicationId) continue;
      if (releasedComplications.has(raw.complicationId) || queuedComplications.has(raw.complicationId)) continue;
      state.sequence += 1;
      const candidate = normalizeCandidate(raw, state.sequence);
      state.queue.push(candidate);
      queuedComplications.add(candidate.complicationId);
      accepted.push(clone(candidate));
    }
    state.queue.sort((a, b) => (b.priority - a.priority) || (a.eligibleAtSec - b.eligibleAtSec));
    return accepted;
  }

  function canRelease({ timeSec = 0, activeUnresolvedCount = 0 } = {}) {
    if (!state.queue.length) return false;
    if (Number(activeUnresolvedCount) >= Number(config.maxConcurrentEvents)) return false;
    if (state.lastReleaseAtSec != null && Number(timeSec) - Number(state.lastReleaseAtSec) < Number(config.minEventSpacingSec)) return false;
    return state.queue.some((candidate) => Number(timeSec) >= Number(candidate.eligibleAtSec));
  }

  function evaluate(context = {}) {
    const releases = [];
    let activeCount = Number(context.activeUnresolvedCount ?? 0);
    const timeSec = Number(context.timeSec ?? 0);
    while (canRelease({ timeSec, activeUnresolvedCount: activeCount })) {
      const index = state.queue.findIndex((candidate) => timeSec >= Number(candidate.eligibleAtSec));
      if (index < 0) break;
      const candidate = state.queue.splice(index, 1)[0];
      queuedComplications.delete(candidate.complicationId);
      const release = {
        id: `runtime-release-${state.released.length + 1}`,
        complicationId: candidate.complicationId,
        eligibilityId: candidate.eligibilityId,
        source: candidate.source,
        eligibleAtSec: candidate.eligibleAtSec,
        releasedAtSec: timeSec,
        mode,
        metadata: clone(candidate.metadata ?? {})
      };
      state.released.push(release);
      releasedComplications.add(candidate.complicationId);
      state.lastReleaseAtSec = timeSec;
      releases.push(clone(release));
      activeCount += 1;
      if (Number(config.minEventSpacingSec) > 0) break;
    }
    return releases;
  }

  function instructorPresentation() {
    return { mode, config: clone(config), queue: clone(state.queue), released: clone(state.released), lastReleaseAtSec: state.lastReleaseAtSec };
  }

  return {
    enqueue,
    evaluate,
    instructorPresentation,
    snapshot: () => clone(state)
  };
}
