export function validationProgress(records=[]){
 const total=records.length;
 const gateNames=['sourceAssigned','exactSourceTextReviewed','simulationCompared','changesApproved','expertReviewed','regressionVerified'];
 const gateCounts=Object.fromEntries(gateNames.map(g=>[g,records.filter(r=>r.gates?.[g]===true).length]));
 const fullyValidated=records.filter(r=>gateNames.every(g=>r.gates?.[g]===true)).length;
 return {total,gateCounts,fullyValidated,remaining:total-fullyValidated,percentComplete:total?Math.round((fullyValidated/total)*100):0};
}
export function promoteValidationRecord(record){
 const required=['sourceAssigned','exactSourceTextReviewed','simulationCompared','changesApproved','expertReviewed','regressionVerified'];
 const ok=required.every(g=>record?.gates?.[g]===true);
 return {...record,releaseStatus:ok?'clinically-validated':'preclinical-not-competency-ready',clinicallyValidated:ok};
}
