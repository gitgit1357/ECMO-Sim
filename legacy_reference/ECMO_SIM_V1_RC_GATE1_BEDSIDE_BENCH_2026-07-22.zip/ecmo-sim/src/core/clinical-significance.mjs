// Clinical significance filter.
//
// GOVERNING RULE:
// Simulate and surface changes that should alter recognition, urgency,
// management, or outcome. Suppress trivial biological noise.
//
// Thresholds are simulation-policy placeholders. They are intentionally
// configurable and must be validated/tuned before training deployment.

function clone(v) { return JSON.parse(JSON.stringify(v)); }

export const DEFAULT_SIGNIFICANCE_PROFILE = Object.freeze({
  hr: { noticeableAbs: 10, significantAbs: 25, criticalAbs: 50 },
  map: { noticeableAbs: 5, significantAbs: 10, criticalAbs: 20 },
  spo2: { noticeableAbs: 3, significantAbs: 8, criticalAbs: 15 },
  cvp: { noticeableAbs: 3, significantAbs: 6, criticalAbs: 10 },
  flowIndexMlKgMin: {
    noticeableAbs: 20,
    significantAbs: 40,
    criticalAbs: 70,
    significantRelativeFraction: 0.30,
    criticalRelativeFraction: 0.55
  }
});

const RANK = Object.freeze({ background:0, noticeable:1, significant:2, critical:3 });

function absDelta(before, after) {
  return Math.abs(Number(after ?? 0) - Number(before ?? 0));
}

export function classifyClinicalChange(metric, before, after, profile = DEFAULT_SIGNIFICANCE_PROFILE) {
  const cfg = profile?.[metric];
  if (!cfg) return { metric, before, after, delta: Number(after ?? 0) - Number(before ?? 0), significance:'background' };
  const delta = Number(after ?? 0) - Number(before ?? 0);
  const magnitude = Math.abs(delta);
  const baseline = Math.max(Math.abs(Number(before ?? 0)), 1);
  const relative = magnitude / baseline;

  let significance = 'background';
  if (magnitude >= Number(cfg.noticeableAbs ?? Infinity)) significance = 'noticeable';
  if (magnitude >= Number(cfg.significantAbs ?? Infinity) || relative >= Number(cfg.significantRelativeFraction ?? Infinity)) significance = 'significant';
  if (magnitude >= Number(cfg.criticalAbs ?? Infinity) || relative >= Number(cfg.criticalRelativeFraction ?? Infinity)) significance = 'critical';

  return { metric, before:Number(before), after:Number(after), delta, relativeFraction:relative, significance };
}

export function evaluateClinicalSignificance(before = {}, after = {}, profile = DEFAULT_SIGNIFICANCE_PROFILE) {
  const changes = Object.keys(profile).map((metric) => classifyClinicalChange(metric, before?.[metric], after?.[metric], profile));
  const meaningful = changes.filter((change) => RANK[change.significance] >= RANK.noticeable);
  const highest = meaningful.reduce((best, change) => RANK[change.significance] > RANK[best] ? change.significance : best, 'background');
  return { significance: highest, meaningfulChanges: clone(meaningful), allChanges: clone(changes) };
}

export function shouldSurfaceClinicalChange(result, minimum = 'noticeable') {
  return RANK[result?.significance ?? 'background'] >= RANK[minimum];
}
