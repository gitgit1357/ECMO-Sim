export function auditStatusText(text=''){
 const issues=[];
 const lower=text.toLowerCase();
 const prohibited=[
  ['clinically validated',/clinically validated/],
  ['competency ready',/\bcompetency[- ]ready\b/],
  ['elso certified',/\belso[- ]certified\b/],
  ['institutionally certified',/\binstitutionally certified\b/]
 ];
 for(const [label,re] of prohibited){
  if(re.test(lower)&&!/not (?:yet )?competency[- ]ready|not clinically validated|not elso[- ]certified|not institutionally certified/.test(lower)){
   issues.push(`potential unsupported claim: ${label}`);
  }
 }
 return issues;
}
