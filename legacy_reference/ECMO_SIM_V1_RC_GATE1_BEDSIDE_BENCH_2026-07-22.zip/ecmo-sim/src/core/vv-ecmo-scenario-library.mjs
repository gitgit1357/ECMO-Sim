import { buildScenarioFromSetup } from './scenario-builder.mjs';

function clone(v){return JSON.parse(JSON.stringify(v));}
const BASE_SETUP=Object.freeze({
 patient:{population:'adult',age:'42 years',weightKg:75,diagnosis:'Severe respiratory failure requiring VV ECMO',procedure:'VV ECMO support',postOpDay:2},
 ecmo:{mode:'VV',cannulation:'dual-site',cannulaFr:23,pumpRpm:3200,sweepGasLpm:4,fdo2Percent:100,circuitAgeHours:48},
 startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'none',renalFunction:'normal',neurologicStatus:'sedated'},
 education:{primaryObjective:'vv-support-pack',concepts:[],mode:'guided',difficulty:'intermediate'}
});

export const VV_ECMO_PRESETS=Object.freeze([
 {id:'vv-01-recirculation',learnerLabel:'VV ECMO 01',educatorLabel:'VV recirculation / ineffective support',complicationId:'vv-recirculation',
  briefing:'You are assuming care of a patient on VV ECMO with worsening systemic oxygenation despite apparently substantial extracorporeal flow. Assess whether delivered flow is translating into effective systemic support.',
  recentEvents:[{minutesBeforeStart:90,text:'VV ECMO flow and oxygenator function were documented near baseline.'},{minutesBeforeStart:25,text:'Systemic oxygenation became less satisfactory despite maintained pump flow.'},{minutesBeforeStart:5,text:'Cannula relationship and recirculation were raised as possible contributors, but no diagnosis was established.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'vv-02-oxygenator',learnerLabel:'VV ECMO 02',educatorLabel:'VV oxygenator dysfunction',complicationId:'oxygenator-thrombosis-failure',
  briefing:'You are assuming care of a VV ECMO patient with worsening extracorporeal gas-exchange performance. Distinguish membrane-lung dysfunction from patient-only or cannula-related causes.',
  recentEvents:[{minutesBeforeStart:120,text:'Extracorporeal gas exchange was previously adequate.'},{minutesBeforeStart:30,text:'Gas-transfer performance and circuit pressure behavior became concerning.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'vv-03-gas-exchange',learnerLabel:'VV ECMO 03',educatorLabel:'VV gas-exchange failure / support mismatch',complicationId:'gas-exchange-failure',
  briefing:'You are assuming care of a VV ECMO patient with worsening oxygenation and ventilation. Localize whether the problem is patient, circuit, or support-setting related before correcting it.',
  recentEvents:[{minutesBeforeStart:60,text:'Gas exchange was near the established target.'},{minutesBeforeStart:15,text:'Oxygenation and CO2 control worsened without a definitive cause.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'vv-04-pneumothorax',learnerLabel:'VV ECMO 04A',educatorLabel:'Tension pneumothorax / intrathoracic pressure emergency on VV ECMO',complicationId:'pneumothorax-intrathoracic-pressure',
  briefing:'You are assuming care during an acute respiratory and ECMO-support deterioration. Assess for a patient-side mechanical problem that may impair both ventilation and venous return.',
  recentEvents:[{minutesBeforeStart:10,text:'VV ECMO flow and ventilation were previously stable.'},{minutesBeforeStart:2,text:'An abrupt respiratory/hemodynamic change with worsening ECMO drainage was noted.'},{minutesBeforeStart:0,text:'You assume care.'}]},
 {id:'vv-04-airway',learnerLabel:'VV ECMO 04B',educatorLabel:'Airway / ETT / ventilator failure on VV ECMO',complicationId:'airway-ventilator-failure',
  briefing:'You are assuming care during an acute gas-exchange deterioration on VV ECMO. Assess the airway and ventilator system as well as extracorporeal support.',
  recentEvents:[{minutesBeforeStart:15,text:'Ventilation and VV ECMO support were stable.'},{minutesBeforeStart:3,text:'A sudden deterioration in native ventilation and gas exchange was reported.'},{minutesBeforeStart:0,text:'You assume care.'}]}
]);

const OBJECTIVES=Object.freeze([
 'Recognize whether ineffective VV support reflects recirculation, membrane-lung dysfunction, patient gas-exchange failure, or an acute patient/airway mechanical problem.',
 'Use cannula, circuit, oxygenator, gas, and patient evidence to localize the limiting mechanism.',
 'Choose cause-directed management rather than escalating flow or sweep indiscriminately.',
 'Reassess systemic oxygenation/ventilation and effective extracorporeal support after intervention.'
]);

function merge(base,patch={}){return {...clone(base),...clone(patch),patient:{...clone(base.patient),...clone(patch.patient??{})},ecmo:{...clone(base.ecmo),...clone(patch.ecmo??{})},startingCondition:{...clone(base.startingCondition),...clone(patch.startingCondition??{})},education:{...clone(base.education),...clone(patch.education??{})}};}
export function listVvEcmoScenarios({audience='learner'}={}){return VV_ECMO_PRESETS.map(p=>({id:p.id,label:audience==='educator'?p.educatorLabel:p.learnerLabel}));}
export function buildVvEcmoScenario(id,{setup={}}={}){
 const p=VV_ECMO_PRESETS.find(x=>x.id===id);if(!p)throw new Error(`Unknown VV ECMO scenario: ${id}`);
 const s=buildScenarioFromSetup(merge(BASE_SETUP,setup),{id:`vv-ecmo-${p.id}`});
 s.learningPlan.primaryObjective='vv-support-pack';s.learningPlan.concepts=['vv-support-pack'];s.clinicalKnowledgePlan.requiredComplicationIds=[p.complicationId];s.clinicalKnowledgePlan.allowedComplicationIds=[p.complicationId];
 s.clinicalKnowledgePlan.triggerPolicies=[{id:`preset-${p.id}`,complicationId:p.complicationId,type:'at-start',source:'vv-ecmo-scenario-library'}];
 s.learnerBriefing={caseLabel:p.learnerLabel,text:p.briefing};
 s.handoff={summary:'The patient is supported with VV ECMO. Review native lung/airway status, cannula relationship, circuit mechanics, membrane-lung performance, and systemic gas exchange before acting.',currentConcern:'A clinically significant loss of effective gas-exchange support may be developing. The cause has not been established.'};
 s.recentEvents=clone(p.recentEvents);s.learnerObjectives=clone(OBJECTIVES);
 s.lifecycle={version:1,completionRule:'clinical-endpoint',successEndpointTypes:['stabilized'],failureEndpointTypes:['death'],allowInstructorTermination:true};
 s.educatorScenarioMetadata={presetId:p.id,intendedComplicationId:p.complicationId,educatorLabel:p.educatorLabel,milestone:'M5'};
 return s;
}
