function clone(v){ return JSON.parse(JSON.stringify(v)); }
import { defaultClinicalKnowledgeRegistry } from './clinical-knowledge-registry.mjs';

export const LEARNING_OBJECTIVES = Object.freeze(
  Object.fromEntries(defaultClinicalKnowledgeRegistry.list('objective').map((objective) => [objective.id, {
    label: objective.label,
    concepts: Object.keys(objective.concepts ?? {})
  }]))
);

export const SCENARIO_FORM_SCHEMA = Object.freeze({
  patient: ['population','age','weightKg','diagnosis','procedure','postOpDay'],
  ecmo: ['mode','cannulation','cannulaFr','pumpRpm','sweepGasLpm','fdo2Percent','circuitAgeHours'],
  startingCondition: ['hemodynamics','oxygenation','volumeStatus','bleeding','renalFunction','neurologicStatus'],
  education: ['primaryObjective','concepts','mode','difficulty']
});

export function buildScenarioFromSetup(setup, { id = `educator-${Date.now()}`, knowledgeRegistry = defaultClinicalKnowledgeRegistry } = {}) {
  const selectedConcepts = setup.education?.concepts ?? [];
  const primaryObjective = setup.education?.primaryObjective ?? null;
  const resolved = primaryObjective ? knowledgeRegistry.resolveObjective(primaryObjective, selectedConcepts) : {
    complicationIds: [], actionIds: [], observationIds: [], unresolvedConceptIds: [...selectedConcepts]
  };

  // Scenarios reference reusable clinical knowledge by ID. They do not copy
  // action/complication behavior into the scenario definition.
  const requiredComplicationIds = [...resolved.complicationIds];
  return {
    id,
    generatedBy: 'educator-scenario-builder',
    requiresManualStart: true,
    population: setup.patient?.population ?? 'pediatric',
    renalFunction: setup.startingCondition?.renalFunction ?? 'normal',
    educatorSetup: clone(setup),
    learningPlan: {
      primaryObjective,
      concepts: clone(selectedConcepts),
      mode: setup.education?.mode ?? 'adaptive',
      difficulty: setup.education?.difficulty ?? 'intermediate',
      unresolvedConceptIds: clone(resolved.unresolvedConceptIds ?? [])
    },
    runtimeDirector: {
      mode: setup.education?.mode ?? 'adaptive',
      // Pacing values are orchestration placeholders, not clinical facts.
      // Educators/configuration can override them without changing complication knowledge.
      profile: clone(setup.runtimeDirectorProfile ?? {})
    },
    clinicalKnowledgePlan: {
      objectiveId: primaryObjective,
      requiredComplicationIds,
      allowedComplicationIds: [...requiredComplicationIds],
      actionIds: [...resolved.actionIds],
      observationIds: [...resolved.observationIds],
      // Generic consequence rules live outside scenario scripts. The default
      // registry currently supplies none until each medical relationship is
      // deliberately defined and validated.
      emergentEligibilityRules: clone(setup.emergentEligibilityRules ?? []),
      // Activation belongs to a separate trigger/eligibility layer. Current
      // implemented teaching complications use an explicit at-start policy so
      // existing cases remain playable; future timing/context/emergent policies
      // can replace this without touching complication definitions.
      triggerPolicies: requiredComplicationIds.map((complicationId) => ({
        id: `required-${complicationId}`,
        complicationId,
        type: 'at-start',
        source: 'educator-learning-objective'
      }))
    },
    initialSettings: {
      pumpRpm: Number(setup.ecmo?.pumpRpm ?? 1400),
      sweepGasLpm: Number(setup.ecmo?.sweepGasLpm ?? 0.5),
      fdo2Percent: Number(setup.ecmo?.fdo2Percent ?? 100),
      heaterTempC: 36.5,
      epiMcgKgMin: 0,
      norepiMcgKgMin: 0,
      bivalirudinMgKgHr: 0
    },
    initialInternal: {
      weightKg: Number(setup.patient?.weightKg ?? 4),
      cannulaFr: Number(setup.ecmo?.cannulaFr ?? 10),
      cvpBaseline: setup.startingCondition?.volumeStatus === 'low' ? 3 : 8,
      hrBaseline: 120,
      mapBaseline: setup.startingCondition?.hemodynamics === 'unstable' ? 35 : 50,
      hrCurrent: 120,
      mapCurrent: setup.startingCondition?.hemodynamics === 'unstable' ? 35 : 50,
      pulsePressureMmHg: Number(setup.startingCondition?.pulsePressureMmHg ?? (String(setup.ecmo?.mode).toUpperCase()==='VA' ? 10 : 28)),
      arterialFlowLpm: setup.ecmo?.arterialFlowLpm == null ? null : Number(setup.ecmo.arterialFlowLpm),
      shuntFlowLpm: setup.ecmo?.shuntFlowLpm == null ? null : Number(setup.ecmo.shuntFlowLpm),
      preDuctalSpo2Offset: Number(setup.startingCondition?.preDuctalSpo2Offset ?? 0),
      postDuctalSpo2Offset: Number(setup.startingCondition?.postDuctalSpo2Offset ?? 0),
      volumeBolusMapBump: 0,
      volumeBolusCvpBump: 0,
      trueLatent: { pao2: 100, paco2: 40, ph: 7.4, lactateMmolL: 2, hgbGdl: 12, dtt: 0.5 }
    },
    equipment: clone(setup.equipment ?? {}),
    informationTimingProfile: clone(setup.informationTimingProfile ?? {}),
    // Endpoint timings are configurable simulation-policy placeholders.
    endpointProfile: clone(setup.endpointProfile ?? {})
  };
}
