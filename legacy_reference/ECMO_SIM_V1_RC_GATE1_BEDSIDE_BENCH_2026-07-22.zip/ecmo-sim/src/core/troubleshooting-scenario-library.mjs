import { buildScenarioFromSetup } from './scenario-builder.mjs';

function clone(v){ return JSON.parse(JSON.stringify(v)); }

const BASE_SETUP = Object.freeze({
  patient:{population:'neonatal',age:'4 days',weightKg:4,diagnosis:'Post-cardiotomy congenital heart disease',procedure:'Recent cardiac surgery',postOpDay:1},
  ecmo:{mode:'VA',cannulation:'central',cannulaFr:10,pumpRpm:1800,sweepGasLpm:2,fdo2Percent:100,circuitAgeHours:18,shuntFlowLpm:0.35},
  startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'mild-postoperative',renalFunction:'normal',neurologicStatus:'sedated'},
  education:{primaryObjective:'low-flow-troubleshooting',concepts:[],mode:'guided',difficulty:'intermediate'}
});

export const LOW_FLOW_TROUBLESHOOTING_PRESETS = Object.freeze([
  {
    id:'lf-01-preload',
    learnerLabel:'Low-Flow Troubleshooting 01',
    educatorLabel:'Preload loss / hypovolemia',
    complicationId:'hypovolemia',
    conceptId:'preload-limitation',
    learnerBriefing:'You are assuming care of a postoperative neonatal VA ECMO patient. Review the bedside data, start the scenario, and manage clinically significant changes as they occur.',
    setupPatch:{ startingCondition:{volumeStatus:'low'} }
  },
  {
    id:'lf-02-tamponade',
    learnerLabel:'Low-Flow Troubleshooting 02',
    educatorLabel:'Postoperative tamponade',
    complicationId:'postoperative-tamponade',
    conceptId:'tamponade-recognition',
    learnerBriefing:'You are assuming care of a postoperative neonatal VA ECMO patient. Review the bedside data, start the scenario, and manage clinically significant changes as they occur.'
  },
  {
    id:'lf-03-position',
    learnerLabel:'Low-Flow Troubleshooting 03',
    educatorLabel:'Position-sensitive cannula drainage compromise',
    complicationId:'position-sensitive-cannula',
    conceptId:'cannula-malposition',
    learnerBriefing:'You are caring for a neonatal VA ECMO patient during routine bedside care. Manage any clinically significant changes that develop.'
  },
  {
    id:'lf-04-kink',
    learnerLabel:'Low-Flow Troubleshooting 04',
    educatorLabel:'Drainage cannula / tubing kink',
    complicationId:'drainage-cannula-kink',
    conceptId:'cannula-malposition',
    learnerBriefing:'You are assuming care of a neonatal VA ECMO patient with previously adequate support. Start the scenario and troubleshoot any clinically significant deterioration.'
  },
  {
    id:'lf-05-circuit-obstruction',
    learnerLabel:'Low-Flow Troubleshooting 05',
    educatorLabel:'Mechanical circuit obstruction',
    complicationId:'mechanical-circuit-obstruction',
    conceptId:'circuit-obstruction',
    learnerBriefing:'You are assuming care of a neonatal VA ECMO patient with previously adequate support. Start the scenario and troubleshoot any clinically significant deterioration.'
  },
  {
    id:'lf-06-pump-failure',
    learnerLabel:'Low-Flow Troubleshooting 06',
    educatorLabel:'Pump failure / loss of pump support',
    complicationId:'pump-support-failure',
    conceptId:'pump-failure',
    learnerBriefing:'You are assuming care of a neonatal VA ECMO patient. Start the scenario and respond to any clinically significant change in extracorporeal support.'
  }
]);

function mergeSetup(base, patch = {}) {
  return {
    ...clone(base),
    ...clone(patch),
    patient:{...clone(base.patient),...clone(patch.patient ?? {})},
    ecmo:{...clone(base.ecmo),...clone(patch.ecmo ?? {})},
    startingCondition:{...clone(base.startingCondition),...clone(patch.startingCondition ?? {})},
    education:{...clone(base.education),...clone(patch.education ?? {})}
  };
}

function applySingleComplicationPlan(scenario, preset) {
  scenario.learningPlan.concepts = [preset.conceptId];
  scenario.clinicalKnowledgePlan.requiredComplicationIds = [preset.complicationId];
  scenario.clinicalKnowledgePlan.allowedComplicationIds = [preset.complicationId];
  scenario.clinicalKnowledgePlan.triggerPolicies = [{
    id:`preset-${preset.id}`,
    complicationId:preset.complicationId,
    type:'at-start',
    source:'troubleshooting-scenario-library'
  }];
  scenario.learnerBriefing = {
    caseLabel:preset.learnerLabel,
    text:preset.learnerBriefing
  };

  // Structured learner-known context. This is history/evidence, not hidden diagnosis.
  scenario.handoff = preset.handoff ?? {
    summary:'You are assuming care of an ECMO patient. Review the known baseline and recent events before starting the live scenario.'
  };
  scenario.recentEvents = clone(preset.recentEvents ?? []);

  // M2 universal learner-facing objectives. These describe the reasoning
  // task without exposing the hidden etiology selected for this case.
  scenario.learnerObjectives = [
    'Recognize clinically significant ECMO low-flow or drainage instability promptly.',
    'Use bedside, circuit, and recent-event evidence to differentiate patient, cannula, circuit, and pump causes.',
    'Choose a cause-directed intervention while avoiding actions that can worsen the underlying problem.',
    'Reassess flow, hemodynamics, and circuit response to verify that the intervention was effective.'
  ];
  scenario.lifecycle = {
    version: 1,
    completionRule: 'clinical-endpoint',
    successEndpointTypes: ['stabilized'],
    failureEndpointTypes: ['death'],
    allowInstructorTermination: true
  };

  // Low-flow acceptance case: the learner arrives after a documented recent
  // turn with new drainage/flow instability. The hidden cause remains unknown,
  // but "restore prior position" is now a reasoned action rather than a guess.
  if (preset.id === 'lf-03-position') {
    scenario.handoff = {
      summary:'Postoperative neonatal patient on central VA ECMO. Earlier flows were stable around 145–155 mL/kg/min with MAP in the high 40s to low 50s. No major change in oxygenation was reported.',
      currentConcern:'The bedside team reports that flow became substantially lower after a recent turn for routine care. No definitive cause has been identified and no corrective intervention has yet been documented.'
    };
    scenario.recentEvents = [
      { minutesBeforeStart:12, text:'ECMO flow documented near prior baseline before routine care.' },
      { minutesBeforeStart:8, text:'Patient turned to a right-side tilt for linen change and routine bedside care.' },
      { minutesBeforeStart:6, text:'Lower ECMO flow and intermittent drainage instability noted after repositioning.' },
      { minutesBeforeStart:0, text:'You assume care.' }
    ];
    scenario.patientSupportProfile = {
      ecmoDependency:'high',
      nativeCardiacContribution:'low',
      nativeLungContribution:'high',
      compensationReserve:'moderate',
      oxygenationSensitivity:'low',
      baselineFlowIndexMlKgMin:150
    };
    scenario.patientPositionProfile = {
      current:'right-tilt',
      previousDocumented:'supine-midline',
      positionEffectMap:{
        'supine-midline':'favorable',
        'left-tilt':'partial',
        'right-tilt':'adverse',
        'head-neck-adjusted':'neutral'
      }
    };
    scenario.initialInternal.mapBaseline = 50;
    scenario.initialInternal.mapCurrent = 50;
    scenario.initialInternal.hrBaseline = 120;
    scenario.initialInternal.hrCurrent = 120;
    scenario.initialInternal.supportFlowMultiplier = 0.27;
    scenario.clinicalKnowledgePlan.triggerPolicies[0].metadata = { initialState:'severe-flow-compromise' };
  }

  // Educator-only metadata must never be copied into learner presentation.
  scenario.educatorScenarioMetadata = {
    presetId:preset.id,
    educatorLabel:preset.educatorLabel,
    intendedComplicationId:preset.complicationId,
    conceptId:preset.conceptId
  };
  return scenario;
}

export function listLowFlowTroubleshootingScenarios({audience='educator'} = {}) {
  return LOW_FLOW_TROUBLESHOOTING_PRESETS.map((preset, index) => audience === 'learner'
    ? {caseKey:`case-${String(index + 1).padStart(2,'0')}`,label:preset.learnerLabel,briefing:preset.learnerBriefing}
    : {id:preset.id,label:preset.educatorLabel,learnerLabel:preset.learnerLabel,complicationId:preset.complicationId,conceptId:preset.conceptId}
  );
}

export function buildLowFlowTroubleshootingScenario(presetId, overrides = {}) {
  const preset = LOW_FLOW_TROUBLESHOOTING_PRESETS.find((x) => x.id === presetId);
  if (!preset) throw new Error(`Unknown low-flow troubleshooting preset "${presetId}".`);
  const setup = mergeSetup(mergeSetup(BASE_SETUP, preset.setupPatch ?? {}), overrides.setup ?? {});
  setup.education.concepts = [preset.conceptId];
  setup.education.mode = overrides.mode ?? setup.education.mode;
  setup.education.difficulty = overrides.difficulty ?? setup.education.difficulty;
  const scenario = buildScenarioFromSetup(setup, {id:overrides.id ?? `troubleshooting-${preset.id}`});
  return applySingleComplicationPlan(scenario, preset);
}

function seededIndex(seed, length) {
  const text=String(seed ?? 'default');
  let h=2166136261;
  for (let i=0;i<text.length;i++){ h ^= text.charCodeAt(i); h = Math.imul(h,16777619); }
  return Math.abs(h) % length;
}

export function buildBlindLowFlowTroubleshootingScenario({seed='default',id=null,mode='guided',difficulty='intermediate'} = {}) {
  const preset = LOW_FLOW_TROUBLESHOOTING_PRESETS[seededIndex(seed, LOW_FLOW_TROUBLESHOOTING_PRESETS.length)];
  const scenario = buildLowFlowTroubleshootingScenario(preset.id,{id:id ?? `blind-low-flow-${seed}`,mode,difficulty});
  scenario.learnerBriefing.caseLabel='Blind Low-Flow Troubleshooting';
  scenario.educatorScenarioMetadata.blindSelection=true;
  scenario.educatorScenarioMetadata.selectionSeed=String(seed);
  return scenario;
}
