// Generic debrief event-log — captures every clinically relevant decision
// and state transition during a session, in one canonical shape, so a
// future debrief/comparative-analysis engine (Phase 10 in the project
// handoff) has structured data to work from without re-deriving meaning
// from a grab-bag of ad hoc log entries.
//
// This module deliberately does NOT attempt "expected vs actual pathway"
// comparison — that's a real, separate, harder feature (needs a notion of
// an ideal pathway per scenario) and stays out of scope here. This module
// only does the two things asked for: (1) a consistent schema for every
// entry, (2) a lightweight aggregate summary over what already happened.
//
// Reuses the existing learner-disclosure boundary (sanitizeLearnerLog)
// rather than re-implementing hidden-kind/forbidden-field logic — this
// module only adds structure on top, it doesn't own the disclosure rule.

import { sanitizeLearnerLog } from './learner-disclosure.mjs';

function clone(value) { return JSON.parse(JSON.stringify(value)); }

// Maps existing `kind` strings (already used throughout circuit-sandbox.mjs)
// to a small set of stable categories, so a debrief UI can filter/group
// without hardcoding every kind string that exists today or gets added
// later. Unmapped kinds fall back to 'other' rather than throwing — new
// log kinds should still get recorded even before this table is updated.
const CATEGORY_BY_KIND = Object.freeze({
  'scenario-started': 'system',
  'clinical-context': 'system',
  'runtime-event-eligible': 'trigger',
  'runtime-event-released': 'trigger',
  'scenario-endpoint': 'endpoint',
  'checkpoint-opened': 'checkpoint',
  'checkpoint-answered': 'checkpoint',
  'checkpoint-skipped': 'checkpoint',
  'clinical-action-outcome': 'clinical-outcome',
  'clinically-significant-change': 'clinical-observation',
  'clinical-event-transition': 'clinical-transition',
  'patient-position-change': 'clinical-outcome',
  'rhythm-change': 'physiology',
  'rhythm-rescue-action': 'resuscitation',
  'study-ordered': 'study',
  'study-acquisition': 'study',
  'order-lab': 'lab',
  'set-param': 'action',
  'bolus-volume': 'action',
  'clinical-action': 'action',
  'bubble-alarm': 'safety-event'
});

const VALID_OUTCOME_CLASSES = new Set([
  'preferred', 'acceptable', 'temporizing', 'ineffective', 'harmful', 'critical-error'
]);

function inferCategory(entry) {
  return CATEGORY_BY_KIND[entry.kind] ?? 'other';
}

function inferOutcomeClass(entry) {
  if (VALID_OUTCOME_CLASSES.has(entry.outcomeClass)) return entry.outcomeClass;
  if (VALID_OUTCOME_CLASSES.has(entry.outcome)) return entry.outcome;
  return null;
}

export function createDebriefLog(snapshot = null) {
  const state = snapshot ? clone(snapshot) : { entries: [], sequence: 0 };

  /**
   * Record one entry. Accepts whatever shape a call site already builds
   * (e.g. `{ kind: 'clinical-action-outcome', ...outcome }`) and layers
   * canonical fields on top without renaming or dropping anything the
   * caller passed — existing kind-based learner-disclosure filtering
   * keeps working unchanged because `kind` is never altered.
   */
  function record(rawEntry) {
    state.sequence += 1;
    const entry = {
      ...rawEntry,
      id: `debrief-${state.sequence}`,
      sequence: state.sequence,
      atSec: Number(rawEntry.atSec ?? 0),
      category: rawEntry.category ?? inferCategory(rawEntry),
      outcomeClass: inferOutcomeClass(rawEntry)
    };
    state.entries.push(entry);
    return clone(entry);
  }

  function instructorTimeline() {
    return clone(state.entries);
  }

  function learnerTimeline(limit = null) {
    const source = limit != null ? state.entries.slice(-limit) : state.entries;
    return sanitizeLearnerLog(clone(source));
  }

  /**
   * Lightweight aggregate over what has happened so far — total score,
   * a histogram of outcome classes, one row per complication encountered
   * (first-seen/resolved timestamps, how many scored outcomes it produced),
   * and endpoint info if the scenario has ended. This is the "capture the
   * data" half of Phase 10, not the "compare to an ideal pathway" half —
   * that needs a per-scenario notion of an ideal pathway that doesn't
   * exist yet, and is deliberately not invented here.
   */
  function summary() {
    const outcomeClassCounts = {};
    const complicationsById = {};
    let totalScore = 0;
    let scenarioStartedAtSec = null;
    let endpoint = null;

    for (const entry of state.entries) {
      if (entry.outcomeClass) outcomeClassCounts[entry.outcomeClass] = (outcomeClassCounts[entry.outcomeClass] ?? 0) + 1;
      if (typeof entry.scoreDelta === 'number') totalScore += entry.scoreDelta;
      if (entry.kind === 'scenario-started') scenarioStartedAtSec = entry.atSec;
      if (entry.kind === 'scenario-endpoint') endpoint = clone(entry.endpoint ?? null);

      const eventId = entry.eventId ?? null;
      if (!eventId) continue;
      const row = complicationsById[eventId] ?? {
        eventId, firstSeenAtSec: entry.atSec, resolvedAtSec: null, scoredOutcomeCount: 0
      };
      row.firstSeenAtSec = Math.min(row.firstSeenAtSec, entry.atSec);
      if (entry.outcomeClass) row.scoredOutcomeCount += 1;
      if (entry.resolved || entry.resolve) row.resolvedAtSec = entry.atSec;
      complicationsById[eventId] = row;
    }

    return {
      entryCount: state.entries.length,
      totalScore,
      outcomeClassCounts,
      complications: Object.values(complicationsById),
      actionCount: state.entries.filter((e) => e.category === 'action').length,
      scenarioStartedAtSec,
      endpoint
    };
  }

  return {
    record,
    instructorTimeline,
    learnerTimeline,
    summary,
    snapshot: () => clone(state)
  };
}
