import { buildScenarioFromSetup } from './scenario-builder.mjs';
import { defaultClinicalKnowledgeRegistry } from './clinical-knowledge-registry.mjs';

function clone(v){ return JSON.parse(JSON.stringify(v)); }

const BASE_SETUP = Object.freeze({
  patient:{population:'neonatal',age:'4 days',weightKg:4,diagnosis:'Critical illness requiring ECMO',procedure:'ECMO support',postOpDay:1},
  ecmo:{mode:'VA',cannulation:'central',cannulaFr:10,pumpRpm:1800,sweepGasLpm:2,fdo2Percent:100,circuitAgeHours:18},
  startingCondition:{hemodynamics:'stable',oxygenation:'stable',volumeStatus:'appropriate',bleeding:'none',renalFunction:'normal',neurologicStatus:'sedated'},
  education:{primaryObjective:null,concepts:[],mode:'guided',difficulty:'intermediate'}
});

function unique(values){ return [...new Set(values.filter(Boolean))]; }

function modeFor(definition){
  const modes=definition?.applicability ?? [];
  if(modes.length===1) return modes[0];
  return 'VA';
}

export function listAllClinicalModuleScenarios({audience='educator'} = {}) {
  const entries=defaultClinicalKnowledgeRegistry.list('complication');
  return entries.map((entry,index)=>{
    const neutral=`Clinical Troubleshooting ${String(index+1).padStart(2,'0')}`;
    return audience==='learner'
      ? {caseKey:`module-${String(index+1).padStart(2,'0')}`,label:neutral}
      : {id:entry.id,label:entry.label,learnerLabel:neutral,applicability:clone(entry.definition?.applicability ?? [])};
  });
}

export function buildClinicalModuleScenario(complicationId,{id=null,mode=null,difficulty='intermediate',setupPatch={}} = {}){
  const entry=defaultClinicalKnowledgeRegistry.get('complication',complicationId);
  if(!entry) throw new Error(`Unknown complication "${complicationId}".`);
  const ecmoMode=mode ?? modeFor(entry.definition);
  const setup={
    ...clone(BASE_SETUP),
    ...clone(setupPatch),
    patient:{...clone(BASE_SETUP.patient),...clone(setupPatch.patient ?? {})},
    ecmo:{...clone(BASE_SETUP.ecmo),mode:ecmoMode,...clone(setupPatch.ecmo ?? {})},
    startingCondition:{...clone(BASE_SETUP.startingCondition),...clone(setupPatch.startingCondition ?? {})},
    education:{...clone(BASE_SETUP.education),mode:'guided',difficulty,...clone(setupPatch.education ?? {})}
  };
  const scenario=buildScenarioFromSetup(setup,{id:id ?? `module-${complicationId}`});
  const actionIds=unique((entry.definition?.actionRules ?? []).map(rule=>rule.actionId));
  scenario.clinicalKnowledgePlan={
    objectiveId:null,
    requiredComplicationIds:[complicationId],
    allowedComplicationIds:[complicationId],
    actionIds,
    observationIds:[],
    emergentEligibilityRules:[],
    triggerPolicies:[{id:`module-${complicationId}`,complicationId,type:'at-start',source:'clinical-module-library'}]
  };
  scenario.learnerBriefing={
    caseLabel:'Clinical Troubleshooting',
    text:'Review the patient and ECMO support, start the scenario, and respond to clinically significant changes using the available assessment and intervention tools.'
  };
  scenario.educatorScenarioMetadata={
    intendedComplicationId:complicationId,
    educatorLabel:entry.label,
    applicability:clone(entry.definition?.applicability ?? []),
    validationStatus:'knowledge-ready; dedicated visual/threshold bench validation may still be pending'
  };
  return scenario;
}
