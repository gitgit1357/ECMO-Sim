export function compareNumericRule({sourceValue,sourceUnits,simulatorValue,simulatorUnits}={}){
 if(sourceValue===null||sourceValue===undefined)return {comparable:false,disposition:'source-silent'};
 if(simulatorValue===null||simulatorValue===undefined)return {comparable:false,disposition:'simulator-value-absent'};
 if(!sourceUnits||!simulatorUnits||sourceUnits!==simulatorUnits)return {comparable:false,disposition:'unit-mismatch'};
 const delta=Number(simulatorValue)-Number(sourceValue);
 return {comparable:true,delta,disposition:delta===0?'aligned':'revise'};
}
export function compareClassification({sourceClassification,simulatorClassification}={}){
 if(!sourceClassification)return {comparable:false,disposition:'source-silent'};
 if(!simulatorClassification)return {comparable:false,disposition:'simulator-value-absent'};
 return {comparable:true,disposition:sourceClassification===simulatorClassification?'aligned':'revise'};
}
