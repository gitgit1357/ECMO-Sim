// Generic patient-position state.
//
// This module knows positions and history, but no medical consequences.
// A scenario may classify positions as favorable/partial/adverse for a hidden
// condition; the clinical event knowledge decides what those classes mean.

function clone(v){ return JSON.parse(JSON.stringify(v)); }

export const PATIENT_POSITIONS = Object.freeze([
  'supine-midline',
  'left-tilt',
  'right-tilt',
  'head-neck-adjusted'
]);

export function createPatientPositionState({ profile = {}, snapshot = null } = {}) {
  const state = snapshot ? clone(snapshot) : {
    current: profile.current ?? 'supine-midline',
    previousDocumented: profile.previousDocumented ?? 'supine-midline',
    positionEffectMap: clone(profile.positionEffectMap ?? {}),
    history: []
  };

  function setPosition(position, { timeSec = 0, source = 'learner' } = {}) {
    if (!PATIENT_POSITIONS.includes(position)) throw new Error(`Unknown patient position "${position}".`);
    const from = state.current;
    state.current = position;
    state.history.push({ atSec:Number(timeSec), from, to:position, source });
    return {
      from,
      to:position,
      effectClass:state.positionEffectMap[position] ?? 'neutral'
    };
  }

  function restorePrevious(opts = {}) {
    return setPosition(state.previousDocumented, { ...opts, source:opts.source ?? 'restore-previous' });
  }

  function learnerPresentation(){
    return {
      current:state.current,
      previousDocumented:state.previousDocumented,
      available:[...PATIENT_POSITIONS]
    };
  }

  return {
    setPosition,
    restorePrevious,
    learnerPresentation,
    instructorPresentation:()=>clone(state),
    snapshot:()=>clone(state)
  };
}
