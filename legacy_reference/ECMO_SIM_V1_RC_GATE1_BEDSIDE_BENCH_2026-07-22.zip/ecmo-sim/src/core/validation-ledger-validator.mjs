export function validateEvidenceLedger(rows=[]){
 const errors=[];
 for(const r of rows){
  if(!r.ruleId)errors.push('missing ruleId');
  if(!r.governingAuthority)errors.push(`${r.ruleId}: missing governingAuthority`);
  if(r.governingAuthority==='elso'&&!r.primaryGuideline)errors.push(`${r.ruleId}: ELSO authority without primaryGuideline`);
  if(r.numericStandardClaimAllowed===true&&r.exactRuleTextExtracted!==true)errors.push(`${r.ruleId}: numeric standard claim without exact extraction`);
  if(r.simulationChangeAuthorized===true&&r.exactRuleTextExtracted!==true)errors.push(`${r.ruleId}: change authorized without exact extraction`);
 }
 return {valid:errors.length===0,errors};
}
