# CORE ECMO COCKPIT CONTRACT
Date: 2026-07-22

## Governing design decision
ECMO bedside monitoring and routine circuit controls are global simulator capabilities, not scenario-specific actions.

Every scenario inherits:
- continuous HR;
- arterial BP with systolic/diastolic and MAP;
- systemic SpO2;
- pre-/post-ductal SpO2 when appropriate;
- temperature;
- CVP;
- RPM;
- measured circuit flow in L/min and indexed mL/kg/min;
- arterial return flow when applicable;
- shunt flow when modeled/applicable;
- venous/pre-oxygenator/post-oxygenator pressures and delta-P;
- CDI Hgb, Hct, and SvO2.

Always-available immediate controls:
- RPM;
- flow target (implemented through pump RPM/flow mechanics rather than a fictitious independent flow knob);
- sweep gas;
- FdO2;
- clamp/unclamp circuit.

Clinical scenario logic may determine whether an adjustment is helpful, ineffective, or harmful, but it may not hide or delay access to these routine controls.

Pressures are continuously monitored but are not directly set as independent controls; they respond to pump setting, flow, preload, resistance, obstruction, clamp state, and patient/circuit condition.

Applicability:
- non-applicable site-specific/shunt channels display N/A rather than fabricated values;
- congenital neonatal VA base scenarios expose modeled shunt flow;
- pre/post ductal oxygenation is exposed for neonatal/pediatric populations.

## Regression
473 / 473 automated tests passing.
