# CLINICAL SOURCE HIERARCHY & CROSSWALK
Date: 2026-07-22
Status: ACTIVE VALIDATION GOVERNANCE

## Governing hierarchy

1. **Institutional protocol/policy** governs when an applicable current protocol is available.
2. **Applicable ELSO standards/guidelines** become the governing default whenever the institution has no applicable protocol/policy.
3. **Unvalidated** is the required status when neither source adequately supports a simulation rule.

Software tests, browser acceptance, expert intuition, and plausible physiology do **not** by themselves confer clinical validation.

## Conflict rule

When institutional practice differs from ELSO:
- do not silently average or blend the two;
- document the institutional rule as governing for this simulator;
- record the ELSO position as secondary/reference context;
- flag the divergence for reviewer visibility;
- preserve version/date provenance for both sources.

## Current institutional-source status

No institution-specific ECMO protocol documents have yet been ingested into this validation package.

Therefore:
- no rule is currently marked `institution-validated`;
- ELSO is the governing default for every documented institutional gap where an applicable ELSO standard/guideline exists;
- exact local thresholds, medication algorithms, anticoagulation targets, emergency procedures, staffing/escalation pathways, and institution-specific equipment practices remain pending institutional-source ingestion.

## Current ELSO fallback catalog

The current ELSO guideline page lists, among others:

| Domain | ELSO source currently indexed | Page-listed update |
|---|---|---|
| General ECMO management | ELSO Guidelines General v1.4 | August 2017 |
| Adult VV respiratory support | ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO | June 2021 |
| Neonatal respiratory support | ELSO Guidelines for Neonatal Respiratory Failure | October 2020 |
| Pediatric respiratory support | ELSO Guidelines for Pediatric Respiratory Failure | October 2020 |
| Adult VA/cardiac support | ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients | August 2021 |
| Pediatric cardiac support | Guidelines for Pediatric Cardiac Failure | May 2021 |
| Adult/pediatric ECMO circuits | ELSO Guidelines for Adult and Pediatric ECMO Circuits | February 2022 |
| Anticoagulation | ELSO Adult and Pediatric Anticoagulation Guidelines | January 2022 |
| Fluid overload / AKI / electrolytes | ELSO Guidelines for Fluid Overload, AKI, and Electrolyte Management | March 2022 |
| Adult neurologic monitoring/management | Neurological Monitoring and Management for Adult ECMO Patients | December 2024 |
| Adult ECPR | ELSO Adult ECPR Interim Guideline Consensus Statement | March 2021 |
| Pediatric ECPR | Pediatric ECPR ELSO Guidelines | March 2021 |
| Training / continuing education | ELSO 2025 Narrative Guideline on ECMO Training and Continuing Education | page updated June 2026 |

This catalog is a **source index**, not a claim that every simulator rule is already validated against those documents.

## Required provenance fields for every tuned clinical rule

Each validated rule should record:
- `ruleId`
- simulation case/module
- rule description
- current simulation value/behavior
- institutional source title
- institutional policy/version/date
- institutional page/section
- ELSO fallback source, if used
- ELSO publication/version/date
- exact governing authority: `institution`, `elso`, or `unvalidated`
- divergence note, if institution and ELSO differ
- reviewer name/role
- review date
- disposition: accepted / revise / rejected
- post-change regression result

## Validation order

1. Ingest institutional protocols.
2. Map each protocol section to simulator modules/rules.
3. Mark covered rules as institution-governed.
4. Identify genuine gaps.
5. Apply the most relevant current ELSO source to those gaps.
6. Leave unsupported rules explicitly unvalidated.
7. Tune code/data.
8. Run full regression.
9. Re-review changed cases.
10. Promote only fully reviewed rules to `clinicallyValidated: true`.
