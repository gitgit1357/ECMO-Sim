# RULE-LEVEL CLINICAL VALIDATION WORK QUEUE
Date: 2026-07-22

## Guardrail
ELSO is the governing default when institutional guidance is absent. However, no exact numeric value or sequence is called an “ELSO standard” until supported by the applicable source text.

## Queue
### `complication:drainage-cannula-kink`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:mechanical-circuit-obstruction`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 2
- Status: **queued for rule-level source extraction/review**

### `complication:pump-support-failure`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 90 sec
- Action classifications detected: 3
- Status: **queued for rule-level source extraction/review**

### `complication:air-emergency`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 60, 90 sec
- Action classifications detected: 6
- Status: **queued for rule-level source extraction/review**

### `complication:circuit-breach-hemorrhage`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 60, 300 sec
- Action classifications detected: 6
- Status: **queued for rule-level source extraction/review**

### `complication:oxygenator-thrombosis-failure`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 90, 150, 300 sec
- Action classifications detected: 6
- Status: **queued for rule-level source extraction/review**

### `complication:sweep-gas-failure`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 90, 150, 180, 300 sec
- Action classifications detected: 6
- Status: **queued for rule-level source extraction/review**

### `complication:hemolysis`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 180, 300 sec
- Action classifications detected: 6
- Status: **queued for rule-level source extraction/review**

### `complication:major-bleeding`
- Governing default: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Domain: `anticoagulation`
- Explicit simulator timing values detected: 90, 240 sec
- Action classifications detected: 7
- Status: **queued for rule-level source extraction/review**

### `complication:intracranial-hemorrhage`
- Governing default: **Neurological Monitoring and Management for Adult ECMO Patients**
- Domain: `adult-neurologic`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:thromboembolism-stroke`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:circuit-systemic-thrombosis`
- Governing default: **ELSO Guidelines for Adult and Pediatric ECMO Circuits**
- Domain: `circuits`
- Explicit simulator timing values detected: 90, 150, 210, 300 sec
- Action classifications detected: 5
- Status: **queued for rule-level source extraction/review**

### `complication:anticoagulation-management`
- Governing default: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Domain: `anticoagulation`
- Explicit simulator timing values detected: 120, 150, 240, 300 sec
- Action classifications detected: 5
- Status: **queued for rule-level source extraction/review**

### `complication:vv-recirculation`
- Governing default: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Explicit simulator timing values detected: 90, 120, 240 sec
- Action classifications detected: 5
- Status: **queued for rule-level source extraction/review**

### `complication:va-differential-hypoxemia`
- Governing default: **ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients**
- Domain: `adult-va-cardiac`
- Explicit simulator timing values detected: 90, 180, 240 sec
- Action classifications detected: 5
- Status: **queued for rule-level source extraction/review**

### `complication:va-lv-distension`
- Governing default: **ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients**
- Domain: `adult-va-cardiac`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:limb-ischemia`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:pneumothorax-intrathoracic-pressure`
- Governing default: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:airway-ventilator-failure`
- Governing default: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:pulmonary-hemorrhage`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:gas-exchange-failure`
- Governing default: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Explicit simulator timing values detected: 60, 90, 120, 210 sec
- Action classifications detected: 4
- Status: **queued for rule-level source extraction/review**

### `complication:arrhythmia-arrest`
- Governing default: **ELSO Adult ECPR Interim Guideline Consensus Statement**
- Domain: `adult-ecpr`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:vasoplegia-shock`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:infection-sepsis`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:aki-fluid-overload`
- Governing default: **ELSO Guidelines for Fluid Overload, AKI, and Electrolyte Management**
- Domain: `aki-fluid-electrolytes`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:ckrt-ecmo-interaction`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:metabolic-electrolyte-emergency`
- Governing default: **ELSO Guidelines for Fluid Overload, AKI, and Electrolyte Management**
- Domain: `aki-fluid-electrolytes`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:neurologic-deterioration`
- Governing default: **Neurological Monitoring and Management for Adult ECMO Patients**
- Domain: `adult-neurologic`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:abdominal-ischemic-compartment`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:pulmonary-hypertensive-crisis`
- Governing default: **ELSO Interim Guidelines for Venoarterial ECMO in Adult Cardiac Patients**
- Domain: `adult-va-cardiac`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:congenital-circulation-specific`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:treatment-transfusion-adverse`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**

### `complication:transport-procedural-operational`
- Governing default: **ELSO Guidelines General v1.4**
- Domain: `general`
- Explicit simulator timing values detected: none detected
- Action classifications detected: 0
- Status: **queued for rule-level source extraction/review**
