# Module Validation Roadmap

## What "knowledge-ready" means

A knowledge-ready module has:
- a reusable hidden complication definition,
- clinically meaningful state/trajectory burden,
- one or more recognition/assessment actions,
- one or more meaningful corrective/management actions,
- learner-safe observable feedback,
- ECMO-mode applicability metadata where relevant,
- no copied scenario-specific medical behavior.

It still may need:
- dedicated monitor/circuit visual cues,
- formal lab/imaging result payloads,
- turnaround-time calibration,
- severity thresholds,
- progression timing,
- population-specific variants,
- educator/expert review,
- bench testing.

## Bench-ready now

The current dedicated bench pack remains:
- hypovolemia / preload limitation
- postoperative tamponade
- position-sensitive cannula compromise
- drainage cannula/tubing kink
- mechanical circuit obstruction
- pump-support failure

## Next recommended bench packs

### Circuit emergency pack
- air emergency
- circuit breach/disconnection
- oxygenator thrombosis/failure
- sweep/gas-source failure
- hemolysis
- major bleeding

### VA pack
- differential hypoxemia
- LV distension/inadequate unloading
- limb ischemia
- thrombosis

### VV pack
- recirculation
- oxygenator dysfunction
- gas-exchange failure
- pneumothorax / airway emergencies

### Patient emergency pack
- intracranial hemorrhage / stroke
- arrhythmia/arrest
- vasoplegia/sepsis
- AKI/fluid overload
- metabolic/electrolyte emergency
- pulmonary hypertensive crisis

## Validation doctrine

Do not promote a module to bench-ready merely because it compiles.

Promotion should require:
1. meaningful visual/observable clues,
2. plausible divergence between correct, reasonable-but-ineffective, and harmful actions,
3. no diagnostic leakage,
4. appropriate endpoint/rescue behavior,
5. timing/threshold review,
6. scenario replay/debrief behavior,
7. clinician bench review.
