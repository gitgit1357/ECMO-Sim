# M4 — VA ECMO — LOCKED DEVELOPMENT PLAN
Date: 2026-07-22
Status: ACTIVE

## Locked V1 case families
1. VA-01 Differential hypoxemia / North-South syndrome — PROVING CASE
2. VA-02 LV distension / inadequate unloading
3. VA-03 Peripheral cannulation limb ischemia
4. VA-04 Circuit / cannula / intracardiac thrombosis

## Definition of Done
M4 is complete when:
- all four cases use the generic clinical knowledge/runtime architecture;
- each has learner-neutral handoff/recent events/objectives;
- each exposes discriminating patient/circuit/site-specific evidence;
- correct cause-directed management produces coherent recovery;
- delay/incorrect management has meaningful consequences where applicable;
- cases complete through the universal lifecycle and debrief;
- all four pass automated regression and browser acceptance;
- no open M4 DEFECT/BLOCKER remains.

## Guardrail
Do not add additional VA cases, polish, advanced graphics, or institutional protocol variants before V1 feature completion. Record those in POST_V1_BACKLOG.

## Proving case
VA-01 Differential hypoxemia is the M4 architecture proof because it requires integration of native cardiac recovery, native lung oxygenation, peripheral VA return, mixing, and site-specific upper-body oxygenation rather than treating a single global SpO2 value.
