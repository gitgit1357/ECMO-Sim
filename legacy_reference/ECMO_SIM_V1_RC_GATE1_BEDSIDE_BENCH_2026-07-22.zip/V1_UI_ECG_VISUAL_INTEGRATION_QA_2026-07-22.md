# V1 UI / ECG / VISUAL INTEGRATION QA
Date: 2026-07-22

## Finding
The latest standalone UI contains an ECG canvas and draw routine, but the UI relied on legacy browser behavior that exposes element IDs as implicit global JavaScript variables (for example `ecg`, `hr`, `map`, `rpm`). This behavior is fragile across browsers/webviews and provides a plausible explanation for the observed blank ECG despite valid engine rhythm data.

## Fix
- Added explicit `document.getElementById()` bindings for the ECG canvas and primary monitor/ECMO vital elements.
- ECG drawing now safely exits if canvas/context is unavailable instead of failing the render loop.
- Added explicit waveform branches for asystole and junctional rhythm in addition to VF/VT/sinus.
- Preserved engine-driven `presentation().rhythm` and monitored HR as the waveform source.
- Added standalone UI integration contract tests.

## Boundary
Static/runtime-contract QA is complete. A true pixel-level browser/device acceptance test still requires opening the standalone build in the target browser/device and visually confirming animation/rendering. This package no longer relies on the identified fragile implicit-global behavior.

## Regression
408 / 408 passing.

## Next
Scenario-by-scenario final acceptance sweep, then release hardening/packaging.
