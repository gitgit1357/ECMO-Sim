# GATE 1 — CORE BEDSIDE BEHAVIOR HUMAN ACCEPTANCE
Reference case: neonatal VA low-preload scenario
Date: 2026-07-22

## Purpose
Judge whether the simulator behaves like an ECMO bedside environment before further scenario-specific refinement.

## A. Baseline cockpit
Confirm at scenario start:
- HR visible and ECG populated
- arterial BP with MAP visible
- pre/post-ductal SpO2 visible when appropriate
- CVP and temperature visible
- RPM and measured circuit/indexed flow visible
- arterial and shunt flow visible where applicable
- venous, pre-oxy, post-oxy pressures and delta-P visible
- CDI Hgb/Hct/SvO2 visible
- bubble detector CLEAR and location correct

## B. Routine controls
Manipulate each without performing any diagnostic step first:
- RPM up/down
- flow target
- sweep up/down/to zero
- FdO2 down/up
- clamp/unclamp circuit
PASS only if every control is immediately available.

## C. Wrong-action physiology
In low preload:
1. Raise RPM aggressively.
2. Observe flow, venous pressure, chatter/drainage behavior, MAP/HR/CVP.
3. Do not give volume initially.
PASS only if the simulator allows the wrong action and the response is physiologically coherent rather than magically correcting/blocking it.

## D. Gas-side independence
- Set sweep to zero while leaving FdO2 unchanged.
- Restore sweep; reduce FdO2 substantially.
PASS only if CO2-side and oxygen-side consequences are distinct and evolve over time.

## E. Clamp test
- Clamp a flowing circuit.
- Observe immediate flow loss and subsequent patient response.
- Unclamp.
PASS only if support loss is immediate and physiology evolves plausibly.

## F. Bubble safety lifecycle
1. Air reaches return-limb detector -> alarm/interlock/pump-flow stop.
2. Reset alarm without de-airing.
3. Restore RPM/flow.
4. Confirm retrip.
5. Explicitly de-air.
6. Reset/re-arm.
7. Restore flow.
PASS only if reset never acts as de-airing.

## G. Bedside realism questions
- Did any displayed value remain implausibly normal during major support loss?
- Did any intervention produce no visible feedback?
- Did any correct or incorrect action feel artificially blocked?
- Did pressures/flows move in the direction an ECMO specialist would expect?
- Was deterioration fast enough to be clinically meaningful without being game-like?
- Was the reason for an alarm/interlock understandable from the cockpit?

Record every mismatch as a CORE PHYSIOLOGY defect before scenario polish.
