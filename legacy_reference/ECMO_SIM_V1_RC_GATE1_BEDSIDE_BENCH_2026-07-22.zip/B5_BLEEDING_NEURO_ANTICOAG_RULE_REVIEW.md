# BATCH 5 — BLEEDING / NEUROLOGIC / ANTICOAGULATION REVIEW
Date: 2026-07-22

## Governance
Institutional anticoagulation, bleeding, and neurologic ECMO protocols govern where available. In their absence, applicable ELSO anticoagulation and neurologic guidance govern by default.

## Cross-guideline rule
A hemorrhagic or neurologic emergency cannot be validated from a single-domain lens when anticoagulation changes affect circuit thrombosis risk. Review must preserve both patient-safety and circuit-safety consequences.

### `circuit-breach-hemorrhage`
- Primary: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Secondary: general
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; cross-guideline exact source comparison pending**

### `major-bleeding`
- Primary: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Secondary: general
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; cross-guideline exact source comparison pending**

### `intracranial-hemorrhage`
- Primary: **Neurological Monitoring and Management for Adult ECMO Patients**
- Secondary: anticoagulation
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; cross-guideline exact source comparison pending**

### `anticoagulation-management`
- Primary: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Secondary: general
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; cross-guideline exact source comparison pending**

### `pulmonary-hemorrhage`
- Primary: **ELSO Adult and Pediatric Anticoagulation Guidelines**
- Secondary: general
- Explicit timing values: none detected
- Action classifications: 0
- Status: **preclinical; cross-guideline exact source comparison pending**
