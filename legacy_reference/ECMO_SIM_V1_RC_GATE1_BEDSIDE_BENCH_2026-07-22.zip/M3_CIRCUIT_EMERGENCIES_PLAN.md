# M3 — CIRCUIT EMERGENCIES
Status: ACTIVE

## Locked V1 case families
1. Air entrainment / circuit air emergency
2. Circuit breach / disconnection with major blood loss
3. Oxygenator thrombosis / membrane-lung failure
4. Sweep gas / gas-source failure
5. Clinically significant hemolysis
6. Major bleeding / coagulopathic hemorrhage

## Development rule
Prove the reusable M3 architecture with oxygenator thrombosis/failure first. Do not polish M2 and do not expand M3 beyond the six locked families.

## M3 Definition of Done
Each of the six cases must have:
- diagnosis-neutral handoff and recent-event context where relevant;
- appropriate patient/circuit observations and discriminating assessment pathway;
- immediate stabilizing actions where clinically required;
- cause-directed definitive intervention;
- coherent deterioration if untreated;
- coherent recovery after effective treatment;
- explicit success/failure endpoint;
- debrief-compatible action history;
- automated acceptance coverage;
- final browser bench acceptance.

## Current implementation
- Dedicated `circuit-emergency-scenario-library.mjs` created.
- Six locked M3 presets created.
- Oxygenator thrombosis/failure selected as architecture proving case.
- Initial M3 automated foundation tests added.

## Pass 2 — Oxygenator Vertical Slice Engine Physiology (2026-07-22)
Completed:
- oxygenator dysfunction now raises trans-oxygenator pressure gradient through reusable circuit mechanics state (`oxygenatorDeltaPAddMmHg`)
- worsening event states progressively increase resistance and degrade post-oxygenator oxygen transfer targets
- learner assessment returns discriminating numeric pressure-gradient and pre/post-oxygenator gas evidence without naming the hidden diagnosis
- sweep increase remains temporizing only
- definitive exchange resets oxygenator resistance/gas-transfer impairment and resolves the event
- 157/157 automated tests pass, including frozen M2 regression

Still required before the oxygenator proving case is complete:
- learner cockpit integration for the M3 scenario selector and case lifecycle
- browser-driven acceptance of the full oxygenator case
- explicit debrief review in the M3 cockpit path
