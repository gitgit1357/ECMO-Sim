# B1 OXYGENATOR — EXACT ELSO EVIDENCE APPLIED
Date: 2026-07-22

## Source
ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits (2022), DOI 10.1097/MAT.0000000000001630.

## Evidence-supported changes
- Oxygenator ΔP is now explicitly described as a device/flow/trend-dependent finding, not a universal absolute cutoff.
- Existing post-oxygenator recovery target (450 mmHg) is retained as a scenario target consistent with the ELSO >300 mmHg adequacy reference at 100% oxygenator gas FiO2.
- Sweep escalation rationale now reflects its potential brief role for condensation/gas-path obstruction while remaining non-definitive for structural failure.
- Oxygenator exchange rationale now reflects inadequate passage/gas transfer/device burden and avoids unnecessary change-out language.

## Not changed
- Scenario deterioration times remain placeholders; the source does not establish our current 300/150-second timing sequence as an ELSO standard.

## Regression
335 / 335 passing.

## Validation state
Exact source comparison completed for selected oxygenator principles. Expert clinical sign-off remains pending.
