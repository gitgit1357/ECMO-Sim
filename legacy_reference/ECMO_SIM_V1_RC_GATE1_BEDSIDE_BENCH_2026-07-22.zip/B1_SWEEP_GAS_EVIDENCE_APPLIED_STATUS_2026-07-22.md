# B1 SWEEP/GAS-PATH — EXACT ELSO EVIDENCE APPLIED
Date: 2026-07-22

Source: ELSO Guidelines for Adult and Pediatric ECMO Circuits (2022).

Applied:
- Gas-path verification rationale explicitly includes source, blender/flowmeter, tubing/connections, and oxygenator gas inlet.
- Restoring effective gas delivery remains definitive management for gas-source interruption.
- Increasing the sweep setpoint while gas delivery is interrupted remains ineffective.
- Manufacturer sweep-gas limits are now explicitly respected in action rationale.
- No universal manufacturer-independent sweep limit was invented.
- Existing 150/90-second deterioration timings remain placeholders.

Regression: full suite passing after evidence application.
Expert clinical sign-off remains pending.
