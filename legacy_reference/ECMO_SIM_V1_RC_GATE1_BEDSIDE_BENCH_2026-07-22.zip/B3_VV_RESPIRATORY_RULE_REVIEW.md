# BATCH 3 — VV RESPIRATORY SUPPORT RULE REVIEW
Date: 2026-07-22

## Governing default
Institutional protocol remains primary when available. With no institutional VV protocol ingested, applicable ELSO adult VV respiratory guidance governs by default. Shared oxygenator/circuit rules retain the ELSO circuit guideline as primary with VV respiratory guidance as contextual/secondary.

## Modeling rule
Shared complications are validated once at the primitive level and referenced across scenario packs. They are not duplicated merely because they appear in both Circuit and VV scenarios.

### `oxygenator-thrombosis-failure`
- Primary source: **ELSO Guidelines for Adult and Pediatric Extracorporeal Membrane Oxygenation Circuits**
- Domain: `circuits`
- Secondary domains: adult-vv-respiratory
- Explicit timing values detected: none
- Action classifications detected: 0
- Status: **preclinical; exact source comparison pending**

### `vv-recirculation`
- Primary source: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Secondary domains: circuits
- Explicit timing values detected: none
- Action classifications detected: 0
- Status: **preclinical; exact source comparison pending**

### `pneumothorax-intrathoracic-pressure`
- Primary source: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Secondary domains: none
- Explicit timing values detected: none
- Action classifications detected: 0
- Status: **preclinical; exact source comparison pending**

### `airway-ventilator-failure`
- Primary source: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Secondary domains: none
- Explicit timing values detected: none
- Action classifications detected: 0
- Status: **preclinical; exact source comparison pending**

### `gas-exchange-failure`
- Primary source: **ELSO Guideline for Adult Respiratory Failure Managed with Venovenous ECMO**
- Domain: `adult-vv-respiratory`
- Secondary domains: circuits
- Explicit timing values detected: none
- Action classifications detected: 0
- Status: **preclinical; exact source comparison pending**
