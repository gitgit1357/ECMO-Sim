# ECMO SIMULATOR V1 — EXPERT CLINICAL REVIEW PACKET

Date: 2026-07-22

## Review boundary
Review clinical correctness, source alignment, unsafe omissions, and misleading learner feedback. Do not expand V1 scope with new features during this gate.

## Current evidence status
- B1–B7 exact-comparison sweep: complete
- Exact-comparison dossier entries: 35
- Automated regression: 394 / 394 passing
- Expert clinical sign-off: pending

## Rules requiring explicit specialty attention
- `complication:pneumothorax-intrathoracic-pressure` — pending-specialty-source-corroboration
- `complication:pulmonary-hemorrhage` — pending-pulmonary-specialty-source
- `complication:pulmonary-hypertensive-crisis` — pending-pulmonary-hypertension-specialty-source
- `complication:abdominal-ischemic-compartment` — pending-specialty-source-corroboration
- `complication:treatment-transfusion-adverse` — pending-specialty-source-corroboration

## Reviewer decision per rule
- APPROVE AS WRITTEN
- APPROVE WITH SPECIFIED CHANGE
- REJECT / REQUIRES REVISION
- OUT OF REVIEWER SCOPE

## Mandatory checks
1. Cue pattern is plausible and learner-safe.
2. Correct actions are clinically appropriate.
3. Harmful/non-corrective actions behave plausibly.
4. Numeric values are either source-supported or clearly simulation placeholders.
5. ECMO mode/age/device limitations are explicit.
6. Institution-specific practice is not presented as universal ELSO guidance.
7. Partial rules remain partial until specialty approval.

## Scope lock
No feature expansion during expert review. Findings are classified only as: clinical defect, evidence-labeling defect, safety/learner-feedback defect, documentation defect, or post-V1 enhancement.