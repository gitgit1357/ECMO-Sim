import React, { useEffect, useRef, useState } from 'react';
import { Play, RotateCcw, Activity, Bell, Clock3 } from 'lucide-react';
import { circuitSandboxEngine } from './ecmo-sim/src/engines/circuit-sandbox.mjs';
import {
  listLowFlowTroubleshootingScenarios,
  buildLowFlowTroubleshootingScenario,
  buildBlindLowFlowTroubleshootingScenario
} from './ecmo-sim/src/core/troubleshooting-scenario-library.mjs';

// --- Real ECG rendering, ported from ecmo-sandbox.jsx --------------------
// The previous version of this file rendered the literal text
// "~~~~ ECG LIVE ~~~~" instead of an actual waveform. This restores the
// canvas-based, per-rhythm-morphology trace (sinus P-QRS-T, junctional
// with no P wave, V-tach, V-fib, asystole) driven by the real engine's
// `rhythm` state — not a player control, just a readout.
function gauss(x, center, width, height) { return height * Math.exp(-((x - center) ** 2) / (2 * width * width)); }

function sinusSample(t, hr, includeP) {
  const period = 60 / Math.max(hr, 20);
  const phase = (t % period) / period;
  let v = 0;
  if (includeP) v += gauss(phase, 0.12, 0.025, 0.15);
  v += gauss(phase, 0.28, 0.010, -0.18);  // Q
  v += gauss(phase, 0.30, 0.012, 1.0);    // R
  v += gauss(phase, 0.325, 0.012, -0.35); // S
  v += gauss(phase, 0.55, 0.07, 0.28);    // T
  return v;
}

function vtachSample(t, ratePerMin) {
  const period = 60 / ratePerMin;
  const phase = (t % period) / period;
  return 0.85 * (0.5 - 0.5 * Math.cos(2 * Math.PI * phase)) * (phase < 0.9 ? 1 : (1 - phase) * 10);
}

function vfibSample(t) {
  // Sum of incommensurate sine waves — irregular, no repeating period, but
  // a pure function of t so the canvas redraws identically without any
  // stored random state.
  return 0.55 * Math.sin(2 * Math.PI * 2.3 * t + 1) +
    0.35 * Math.sin(2 * Math.PI * 3.7 * t + 2.1) +
    0.25 * Math.sin(2 * Math.PI * 5.9 * t + 0.4) +
    0.15 * Math.sin(2 * Math.PI * 9.1 * t + 3.3);
}

function asystoleSample(t) { return 0.015 * Math.sin(2 * Math.PI * 0.6 * t); }

const RHYTHMS = {
  sinus: { label: 'Sinus', sample: (t, hr) => sinusSample(t, hr, true) },
  junctional: { label: 'Junctional (JET)', sample: (t, hr) => sinusSample(t, hr, false) },
  vtach: { label: 'V-Tach', sample: (t) => vtachSample(t, 190) },
  vfib: { label: 'V-Fib', sample: (t) => vfibSample(t) },
  asystole: { label: 'Asystole', sample: (t) => asystoleSample(t) }
};

const ECG_GREEN = '#35d07f';

function Trace({ hr, rhythm }) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const startRef = useRef(performance.now());

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width, height = canvas.height, mid = height / 2;
    const sampleFn = RHYTHMS[rhythm]?.sample ?? RHYTHMS.sinus.sample;
    const windowSec = 5; // seconds of trace visible at once

    function draw() {
      const now = (performance.now() - startRef.current) / 1000;
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, width, height);
      ctx.strokeStyle = ECG_GREEN;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let px = 0; px < width; px++) {
        const t = now - windowSec * (1 - px / width);
        const amp = sampleFn(Math.max(t, 0), hr || 100);
        const y = mid - amp * (height * 0.42);
        if (px === 0) ctx.moveTo(px, y); else ctx.lineTo(px, y);
      }
      ctx.stroke();
      rafRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [hr, rhythm]);

  return (
    <canvas ref={canvasRef} width={640} height={72} style={{ width: '100%', height: 56, background: '#000', borderRadius: 4, border: '1px solid #16221f', display: 'block' }} />
  );
}

const panel={background:'#0d1417',border:'1px solid #1b2b27',borderRadius:10,padding:14};
const btn={background:'#16221f',color:'#dce7e4',border:'1px solid #2b3b37',borderRadius:7,padding:'8px 10px',cursor:'pointer'};
const input={background:'#071012',color:'#e6efec',border:'1px solid #293a36',borderRadius:6,padding:'8px 9px'};
const fmt=(s)=>`${String(Math.floor(s/60)).padStart(2,'0')}:${String(Math.floor(s%60)).padStart(2,'0')}`;

// No hardcoded action list here anymore. The engine's presentation()
// already resolves the right button set per scenario from the clinical
// knowledge registry (view.availableActions) — see circuit-sandbox.mjs.
// This is what fixes the audit finding that ~85% of registered actions
// (everything outside the six low-flow cases) had no cockpit affordance
// anywhere: any future scenario's actions show up automatically, with no
// UI file to remember to update.

export default function ECMOLowFlowTroubleshootingPack(){
  const educatorCases=listLowFlowTroubleshootingScenarios({audience:'educator'});
  const [screen,setScreen]=useState('educator');
  const [selected,setSelected]=useState(educatorCases[0].id);
  const [blind,setBlind]=useState(false);
  const [seed,setSeed]=useState('case-1');
  const [sessionVersion,setSessionVersion]=useState(0);
  const sessionRef=useRef(null);
  const [feed,setFeed]=useState([]);
  const [rpm,setRpm]=useState(1800);
  const [rpmDraft,setRpmDraft]=useState('1800');
  const latestFeedRef=useRef(null);

  const refresh=()=>setSessionVersion(v=>v+1);
  const session=sessionRef.current;
  const view=session?.presentation?.() ?? null;
  const instructor=session?.instructorPresentation?.() ?? null;
  const endpoint=view?.endpoint ?? instructor?.trajectory?.endpoint ?? null;

  useEffect(()=>{
    if(screen!=='learner' || !sessionRef.current || !sessionRef.current.presentation().started || endpoint) return;
    const id=setInterval(()=>{
      const result=sessionRef.current.advance(1);
      refresh();
      if(result.complete) setFeed(f=>[{t:result.timeSec,title:`Scenario ended: ${result.status}`,detail:''},...f]);
    },1000);
    return ()=>clearInterval(id);
  },[screen,sessionVersion,Boolean(endpoint)]);

  useEffect(()=>{
    if(feed.length===0) return;
    const id=requestAnimationFrame(()=>latestFeedRef.current?.scrollIntoView({behavior:'smooth',block:'center'}));
    return ()=>cancelAnimationFrame(id);
  },[feed]);

  const launch=()=>{
    const scenario=blind
      ? buildBlindLowFlowTroubleshootingScenario({seed})
      : buildLowFlowTroubleshootingScenario(selected);
    sessionRef.current=circuitSandboxEngine.createSession({scenario});
    setRpm(scenario.initialSettings.pumpRpm);
    setRpmDraft(String(scenario.initialSettings.pumpRpm));
    setFeed([]);
    setScreen('learner');
    refresh();
  };

  const start=()=>{
    const r=sessionRef.current.submit({type:'start-scenario'});
    setFeed([{t:0,title:'Scenario started',detail:'The scenario clock and clinical course are now live.'}]);
    refresh();
  };

  const clinicalAction=(id)=>{
    let r;
    if(id==='volume-bolus') r=sessionRef.current.submit({type:'bolus-volume',mlPerKg:10});
    else r=sessionRef.current.submit({type:'clinical-action',actionId:id});
    if(r.feedback) setFeed(f=>[{t:sessionRef.current.presentation().timeSec,title:'Clinical update',detail:r.feedback},...f]);
    refresh();
  };

  const setPump=(value)=>{
    const n=Number(value); setRpm(n);
    const r=sessionRef.current.submit({type:'set-param',param:'pumpRpm',value:n});
    if(r.feedback) setFeed(f=>[{t:sessionRef.current.presentation().timeSec,title:'Clinical update',detail:r.feedback},...f]);
    refresh();
  };

  const commitRpmDraft=()=>{
    const n=Number(rpmDraft);
    if(!Number.isFinite(n) || n<0){ setRpmDraft(String(rpm)); return; } // reject garbage, revert to last committed value
    setPump(n);
    setRpmDraft(String(n));
  };

  if(screen==='educator') return <div style={{minHeight:'100vh',background:'#05080a',color:'#e6efec',fontFamily:'system-ui',padding:24}}>
    <div style={{maxWidth:900,margin:'0 auto'}}>
      <div style={{fontSize:11,letterSpacing:2,color:'#70817c'}}>ECMO SIMULATOR • TROUBLESHOOTING PACK</div>
      <h1 style={{margin:'5px 0 6px'}}>Low-Flow Scenario Launcher</h1>
      <p style={{color:'#91a09c'}}>Educator view only. Choose a known teaching case or launch blind differential mode. After launch, the learner cockpit does not display the hidden cause.</p>
      <div style={panel}>
        <label style={{display:'grid',gap:6}}>
          <span>Scenario</span>
          <select disabled={blind} value={selected} onChange={e=>setSelected(e.target.value)} style={input}>
            {educatorCases.map(c=><option key={c.id} value={c.id}>{c.label}</option>)}
          </select>
        </label>
        <label style={{display:'flex',gap:8,alignItems:'center',marginTop:14}}>
          <input type="checkbox" checked={blind} onChange={e=>setBlind(e.target.checked)}/>
          Blind differential mode — select one implemented low-flow cause without disclosing it to learner
        </label>
        {blind&&<label style={{display:'grid',gap:5,marginTop:12}}><span>Selection seed</span><input style={input} value={seed} onChange={e=>setSeed(e.target.value)}/></label>}
        <button onClick={launch} style={{...btn,width:'100%',marginTop:16,background:'#173d2c',color:'#91f0b8',fontWeight:700}}>LOAD LEARNER COCKPIT</button>
      </div>
    </div>
  </div>;

  const monitored=view?.monitored ?? {};
  const circuit=view?.circuit ?? {};
  const started=Boolean(view?.started);
  return <div style={{minHeight:'100vh',background:'#05080a',color:'#e6efec',fontFamily:'system-ui',padding:18}}>
    <div style={{maxWidth:1180,margin:'0 auto'}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:12}}>
        <div><div style={{fontSize:11,letterSpacing:2,color:'#70817c'}}>LEARNER COCKPIT</div><b>{view?.learnerBriefing?.caseLabel ?? 'Low-Flow Troubleshooting'}</b></div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}><Clock3 size={15}/><span style={{fontFamily:'monospace'}}>{fmt(view?.timeSec ?? 0)}</span></div>
      </div>
      {!started&&<div style={{...panel,textAlign:'center',padding:24,marginBottom:14}}>
        <h2>Scenario Ready</h2>
        <p style={{color:'#91a09c'}}>{view?.learnerBriefing?.text ?? 'Review the bedside information, then start the scenario.'}</p>
        <button onClick={start} style={{...btn,background:'#173d2c',color:'#91f0b8',fontWeight:700}}><Play size={15}/> START SCENARIO</button>
      </div>}
      {endpoint&&<div style={{...panel,marginBottom:14,border:'1px solid #4d3e27'}}><b>Scenario complete</b><div style={{color:'#cbb88b',marginTop:4}}>{endpoint.type}</div></div>}
      <div style={{display:'grid',gridTemplateColumns:'1.45fr .75fr',gap:14}}>
        <div style={{display:'grid',gap:14}}>
          <div style={panel}>
            {started ? <Trace hr={monitored.hr} rhythm={view?.rhythm ?? 'sinus'} /> : (
              <div style={{height:56,background:'#000',borderRadius:6,border:'1px solid #173027',display:'flex',alignItems:'center',padding:'0 15px',color:'#3a5751',fontFamily:'monospace'}}>ECG IDLE</div>
            )}
            <div style={{display:'flex',alignItems:'center',gap:8,marginTop:8}}>
              <small style={{color:'#778983',letterSpacing:1}}>RHYTHM</small>
              <b style={{fontSize:12,color:ECG_GREEN}}>{(RHYTHMS[view?.rhythm]?.label ?? 'Sinus').toUpperCase()}</b>
            </div>
            {view?.rhythmAnnouncement && (
              <div style={{marginTop:8,background:'#1a1408',border:'1px solid #4a3416',borderRadius:6,padding:'6px 10px',fontSize:12,color:'#f0a742'}}>
                RHYTHM CHANGE: {view.rhythmAnnouncement}
              </div>
            )}
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginTop:12}}>
              {[['HR',started?monitored.hr:'--','bpm'],['MAP',started?monitored.map:'--','mmHg'],['SpO₂',started?monitored.spo2:'--','%'],['CVP',started?monitored.cvp:'--','mmHg']].map(([l,v,u])=><div key={l}><small style={{color:'#778983'}}>{l}</small><div style={{fontSize:28,fontFamily:'monospace'}}>{v}</div><small>{u}</small></div>)}
            </div>
          </div>
          <div style={panel}>
            <div style={{display:'flex',alignItems:'center',gap:7,color:'#b89af5'}}><Activity size={15}/> ECMO CONSOLE</div>
            <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:10,marginTop:12}}>
              {[['RPM',started?circuit.pumpRpm:'--'],['FLOW',started?circuit.flowIndexMlKgMin:'--'],['SWEEP',started?view?.settings?.sweepGasLpm ?? '--':'--'],['FdO₂',started?`${view?.settings?.fdo2Percent ?? '--'}%`:'--']].map(([l,v])=><div key={l}><small style={{color:'#778983'}}>{l}</small><div style={{fontSize:24,fontFamily:'monospace'}}>{v}</div>{l==='FLOW'&&<small>mL/kg/min</small>}</div>)}
            </div>
            <div style={{marginTop:14}}>
              <small>RPM control</small>
              <input
                disabled={!started||endpoint} type="number" inputMode="numeric" min="0" max="4000" step="50"
                value={rpmDraft}
                onChange={e=>setRpmDraft(e.target.value)}
                onBlur={commitRpmDraft}
                onKeyDown={e=>{ if(e.key==='Enter'){ e.preventDefault(); commitRpmDraft(); e.target.blur(); } }}
                style={{...input,width:'100%',marginTop:4}}
              />
            </div>
          </div>
          <div style={panel}>
            <b>Assessment, interventions & emergency actions</b>
            <div style={{display:'grid',gridTemplateColumns:'repeat(3,1fr)',gap:7,marginTop:10}}>
              {(view?.availableActions ?? []).map(({ label, id })=><button key={id} disabled={!started||endpoint} onClick={()=>clinicalAction(id)} style={btn}>{label}</button>)}
            </div>
          </div>
        </div>
        <div style={panel}>
          <div style={{display:'flex',gap:7,alignItems:'center'}}><Bell size={15}/><b>INFORMATION / RESULTS</b></div>
          <p style={{fontSize:12,color:'#778983'}}>Only observable consequences and returned information appear here. Hidden diagnosis, grading, and expected actions remain concealed.</p>
          <div style={{display:'grid',gap:8}}>
            {feed.length===0?<div style={{fontSize:12,color:'#52615d'}}>No new information.</div>:feed.map((x,i)=><div key={i} ref={i===0?latestFeedRef:undefined} style={{borderTop:'1px solid #1a2925',paddingTop:8}}><div style={{fontSize:11,color:'#667772',fontFamily:'monospace'}}>{fmt(x.t)}</div><b style={{fontSize:13}}>{x.title}</b><div style={{fontSize:12,color:'#a1afab',marginTop:3}}>{x.detail}</div></div>)}
          </div>
        </div>
      </div>
      <button onClick={()=>{sessionRef.current=null;setScreen('educator');setFeed([])}} style={{...btn,marginTop:14}}><RotateCcw size={14}/> Return to educator launcher</button>
    </div>
  </div>;
}
