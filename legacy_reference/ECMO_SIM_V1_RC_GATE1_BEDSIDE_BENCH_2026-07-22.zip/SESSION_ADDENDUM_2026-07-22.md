# Session Addendum — 2026-07-22

This is written on top of `START_HERE.md` / `COMPLETE_PROJECT_HANDOFF_v2.1.md`
— read those first for the overall architecture. This file covers what
changed in one extended debugging/fixing session after that handoff, so
nothing here duplicates it.

**Verified state as of this addendum: 147/147 tests passing.** Run
`cd ecmo-sim && node --test test/*.test.mjs` to confirm.

## What prompted this session

Bench-testing the six "bench-ready" low-flow cases (exactly the exercise
`START_HERE.md` recommends doing before broadening) immediately found two
real bugs in cases already marked ready. That led to auditing all 36
complications for the same defect class, which found it in 22 of them —
far more systemic than expected. Fixing those 22 then surfaced three
deeper, previously-undiscovered architecture bugs. All of it is fixed and
tested now, but it's worth reading in order because later fixes depend on
earlier ones.

## 1. Rhythm rescue (new capability)

Added 5 rescue actions (`assess-rhythm`, `defibrillate`,
`synchronized-cardioversion`, `administer-arrest-epinephrine`,
`begin-chest-compressions`) in `rhythm.mjs`, always available as cockpit
buttons. Key clinical logic: chest compressions are only *preferred* when
ECMO flow is inadequate — the pump already provides circulation, so
compressions are correctly *ineffective* when flow is fine, regardless of
rhythm. Defibrillation/cardioversion are harmful on non-shockable rhythms.
A rescue conversion does NOT reset the underlying driver (hypoxia, lost
flow) — if it's still present, the rhythm can re-escalate on the next
tick. That's intentional, tested, and explained in the code comments so it
doesn't read as a bug.

## 2. Debrief event log (new capability)

`debrief-log.mjs` — every engine action/outcome gets a canonical shape
(id, sequence, category, outcomeClass) without touching the existing
learner-disclosure filtering (which keys off the untouched `kind` field).
Exposed as `instructorPresentation().debrief` — a summary (total score,
outcome-class histogram, per-complication first-seen/resolved times,
endpoint). **Not built**: comparing the actual pathway to an ideal one
(needs a per-scenario notion of "ideal pathway" that doesn't exist yet).

## 3. UI action-coverage audit (found and fixed a real gap)

Only 11 of 72 actionIds needed by all 36 complications had a cockpit
button anywhere — both UI builds hardcoded the same static 13-button list,
tuned only for the six low-flow cases. Fixed with a registry-driven
resolver (`resolveLearnerActionButtons`) exposed as `view.availableActions`.
**Important subtlety**: it resolves the whole learning *objective's*
action union (the full differential), not the active complication's own
narrow list — using the narrow list directly would leak which
complication is real. Verified zero diagnostic leakage across all 36.

## 4. The monitor must reflect the patient (rhythm ↔ trajectory linkage)

Originally, rhythm only escalated from two narrow circuit signals
(hypoxia, lost flow). A patient could reach a "death" trajectory endpoint
with the ECG still calmly reading sinus. Fixed: added `asystole` as a 5th
terminal rhythm stage; rhythm escalation is now also driven by
`clinical-trajectory.mjs`'s own severity/arrest/death signals, not just
the two circuit-level ones. Epinephrine is now the *primary* treatment for
asystole (a non-shockable rhythm), unlike its adjunct-only role in
V-tach/V-fib.

## 5. The big one: 22 of 36 complications were silently inert

Verified **empirically**, not just from reading definitions: comparing
monitored vitals at t=15s (after a one-time init artifact settles) to
t=900s, fully untreated. 22 of 36 complications showed zero ongoing
change, however long you waited — the same defect class as the
hypovolemia/tamponade bugs bench-testing had already found, just at
systemic scale.

Fixed 21 of 22 (added `activationEffects` and/or `timeRules` giving each a
real physiological signature and time-based progression). Left
`position-sensitive-cannula` alone — it's legitimately fine as currently
used (relies on scenario-level `patientPositionProfile` wiring, which is
correct for its one real use in `lf-03-position`) but would be silently
inert if reused in a new scenario without that wiring. Documented, not
fixed, since fixing it generically risks duplicating the scenario's own
careful position logic.

**A standing test locks this in**: `test/complication-vitals-impact.test.mjs`
has an explicit, visible allowlist (currently just the one id) — any
complication not on it must show real ongoing change, and the allowlist
can only shrink, never silently grow. This is the automated version of
"bench-test before broadening" that `START_HERE.md` asks for — it now
runs itself.

### Three deeper bugs this fix surfaced (all fixed, all tested)

While fixing the 21, three previously-undiscovered architecture bugs
turned up — worth knowing if you touch `physiology.mjs`,
`clinical-consequence.mjs`, or `clinical-events.mjs` again:

1. **`trueLatent.pao2`/`trueLatent.paco2` writes from clinical-events were
   silently discarded every tick.** `physiology.mjs`'s `deriveTrueLatent()`
   always recomputed both fresh from settings (FdO2/sweep), completely
   ignoring anything a complication wrote there beyond the very first
   tick. This was already broken in several *original* complications
   (oxygenator-thrombosis-failure, sweep-gas-failure, etc.) — just masked
   because they only ever set it at activation, which looked like it
   worked due to a one-time initialization-order artifact (state is seeded
   raw before the first physiology tick recomputes it). Fixed: added a
   proper `clinicalPaco2Target` override field symmetric to the
   `clinicalPao2Target` one that already existed for the consequence
   engine, and moved every complication that touches gas exchange onto
   these fields with **absolute `set` values**, not relative `add` deltas
   (an `add` onto a field that starts unset computes from zero, not from
   the current physiological baseline — a subtle second trap, also fixed).

2. **The consequence engine was unconditionally overwriting
   `clinicalPao2Target`, including writing `null` when it found nothing
   wrong** — silently erasing a complication's own independent
   oxygenation problem the moment the support-consequence engine ran (on
   every tick and action). Fixed: the consequence engine now writes its
   own private field (`consequencePao2Target`); `physiology.mjs` combines
   both sources by taking whichever is worse, so neither engine can erase
   the other's signal.

3. **A single large time-jump only ever applied ONE stage of a
   multi-stage decline**, regardless of how much time had actually passed.
   `clinical-events.mjs`'s `advance()` checked for one eligible time-rule
   transition per call and stopped — fine for many small ticks (like a
   real per-second autoplay loop), broken for one big jump (like a "+15
   min" button, or any test using `advance(900)` in one call). This is
   also why an earlier claim in this project's own history was subtly
   wrong: hypovolemia/tamponade were said to reach death via
   "decompensating → worsened → critical → arrest," but the state machine
   was actually stuck at "worsened" — death was coming entirely through a
   separate, independent consequence-engine countdown. Fixed to cascade
   through every eligible transition within one call (with a hard
   iteration cap against pathological rule cycles). Verified: hypovolemia
   now genuinely reaches "arrest" via clinical-events at exactly t=390s,
   matching the sum of its three timeRule thresholds — the outcome didn't
   change, but the mechanism now actually matches what was claimed.

### Verification standard used throughout

Every fix in this session was checked at least two ways: (a) the relevant
unit/integration test, and (b) a direct empirical run printing real
before/after values — not just "tests are green." Specific numbers worth
knowing: hypovolemia/tamponade reach death at t=555s (~9.3 min) fully
untreated; all four cases that reach death show `asystole` on the monitor,
not sinus; all 5 complications with `arrest:true` correctly force rhythm
to `vfib` the instant the arrest flag goes true (verified individually,
not assumed from one example).

## 6. UI fixes (`ecmo-low-flow-troubleshooting-pack.jsx`)

- Real per-rhythm ECG waveform (was a static `"~~~~ ECG LIVE~~~~"` string).
- Action buttons now render from `view.availableActions` (registry-driven)
  instead of a hardcoded array — this is what made the coverage audit's
  fix actually reach the UI.
- Auto-scroll to the newest feedback entry after any action.
- RPM control is a typed number box (commits on blur/Enter, not on every
  keystroke — a naive live-onChange would submit RPM=1, then 18, then 180
  while typing "1800", each a real engine call).

## Everything still open (unchanged from the original handoff, repeated for convenience)

- Case navigation / objectives / a defined "complete" state — this is
  still an open-ended sandbox with scored checkpoints, not a full CSE
  section structure.
- A debrief UI — the data exists (`debrief-log.mjs`), nothing displays it.
- The educator form (`ecmo-educator-workflow.jsx`) is still an unwired
  mockup, not connected to the real scenario-builder.
- Every timing constant added in this session (and the original ones) is
  still a placeholder pending your clinical review — the *qualitative*
  defect (silently inert, monitor doesn't reflect condition) is fixed
  everywhere; the *pace* of each complication is still yours to tune.

## 7. Completion-First Governance adopted after this session
A formal anti-drift governance contract was added as `PROJECT_GOVERNANCE_COMPLETION_FIRST.md`, with a companion `POST_V1_BACKLOG.md`.

The project now has a frozen V1 milestone sequence M1–M12. M1 Core Engine is considered complete enough/frozen except for blockers and defects. M2 Low-Flow Vertical Slice is the active milestone. Development must satisfy each milestone's explicit Definition of Done, freeze it, and advance rather than repeatedly polishing earlier work. New ideas that are not blockers, defects, clinical-correctness fixes, or planned V1 scope are deferred to the post-V1 backlog.

## M2 Completion-First Work — Lifecycle Pass 1
- Added diagnosis-neutral learner objectives to all six low-flow scenarios.
- Added learner-facing lifecycle status (`prebrief` -> `active` -> explicit endpoint).
- Added post-endpoint learner debrief API in canonical engine with a deliberately narrowed action review.
- Corrected low-flow pack baseline hemodynamics from an inherently "unstable" baseline to a stable baseline so successfully resolved cases can actually satisfy the existing sustained-stability endpoint contract. This was a completion blocker: the previous baseline could make success structurally unreachable.
- Updated bench acceptance expectations: successful treatment may now end as `stabilized` rather than remaining indefinitely open.
- Added `test/m2-lifecycle.test.mjs`.
- Current canonical automated verification: 150/150 tests passing.
- Added `standalone-v2.2/index.html` with prebrief objectives, explicit completion presentation, locked controls after endpoint, and a basic learner action-review/debrief panel.

M2 remains ACTIVE pending six-case human bench acceptance of the integrated lifecycle/UI. Do not begin M3 until that gate is passed.

## M2 acceptance hardening pass
- Expanded M2 lifecycle acceptance from 150 to 152 automated tests.
- Added all-six-case reachable-success verification.
- Found and fixed a clinically contradictory endpoint condition where restored pump support could lead to a `stabilized` endpoint while VF remained displayed.
- VF/asystole now block stabilization by contributing an arrest-level trajectory signal.
- Low-Flow 06 now correctly requires rhythm rescue if malignant rhythm developed before pump support was restored.
- Automated M2 acceptance: **152/152 passing**.
- Remaining gate before M2 freeze: human UI bench of all six cases for visual/pacing/usability acceptance only.
