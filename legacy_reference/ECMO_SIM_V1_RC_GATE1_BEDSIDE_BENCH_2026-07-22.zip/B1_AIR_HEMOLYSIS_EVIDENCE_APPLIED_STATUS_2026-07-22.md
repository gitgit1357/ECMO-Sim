# B1 AIR + HEMOLYSIS — EXACT ELSO EVIDENCE APPLIED
Date: 2026-07-22

## Air emergency
Applied ELSO circuit-guideline principles:
- identify/address source;
- remove/de-air circuit hazard;
- massive/gross air may require immediate circuit isolation/clamping;
- contaminated pump should not be hand-cranked in a massive-air event;
- component/pump exchange may be necessary before safe support restoration;
- bubble detection and excessive-negative-pressure/connector risks remain relevant.

No exact 90-second deterioration standard was inferred.

## Hemolysis
Applied ELSO circuit-guideline principles:
- interpret hemolysis as a consequence requiring mechanical/circuit source localization;
- include plasma-free hemoglobin trend, resistance/pressure-flow behavior, cannula/drainage conditions, visible clot burden, and pump mechanics;
- consider component correction/change when clot/device problems coincide with hemolysis, impaired flow, coagulation burden, or inadequate support;
- do not treat blind RPM escalation as a cure.

No universal numeric hemolysis threshold or 300/180-second progression timing was invented.

## Circuit breach
No new clinical sequence changes were made in this pass; exact sequence remains pending stronger source-level support.

Regression: full suite passing.
Expert clinical sign-off remains pending.
