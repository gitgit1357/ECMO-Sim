import React, { useState, useRef, useEffect, useCallback } from 'react';
import { Activity, FlaskConical, Clock, Play, Pause, AlertTriangle, Check, X } from 'lucide-react';

// ---------------------------------------------------------------------
// ENGINE LOGIC — reimplemented inline from the tested source in
// src/core/physiology.mjs, lab-queue.mjs, and titration-lookup.mjs.
// Artifacts can't import local project files, so this duplicates that
// logic for the purpose of this click-through demo. The coefficients,
// protocol tables, and behavior are meant to match the tested engine
// exactly — if you spot a mismatch, the .mjs files are authoritative.
// ---------------------------------------------------------------------

const COEFFS = {
  mapPerMlKgMinFlowIndex: 0.32, // neonatal preset
  mapPerMcgKgMinEpi: 6,
  hrPerMcgKgMinEpi: 18,
  mapPerMcgKgMinNorepi: 5,
  paco2BaselineMmHg: 40,
  paco2DropPerLpmSweepAboveBaseline: 6,
  baselineSweepLpm: 2,
  pao2BaselineMmHg: 90,
  pao2GainPerFdo2Percent: 3.2,
  spo2SaturationKneeMmHg: 90,
  epiEffectRiseHalfLifeSec: 60,
  dttBaselineMcgMl: 0,
  dttPerMgKgHrBivalirudin: 1.74 // calibrated from Frank's real data point: 0.31 mg/kg/hr -> dTT 0.54
};

const TURNAROUND_SEC = { abg: 4 * 60, dtt: 25 * 60, hepptt: 20 * 60, teg: 35 * 60, atiii: 45 * 60 };
const LAB_LABELS = { abg: 'ABG', dtt: 'dTT', hepptt: 'HepPTT', teg: 'TEG r-time', atiii: 'ATIII' };

const INITIAL_SCENARIO = {
  weightKg: 4,
  hrBaseline: 150,
  mapBaseline: 38,
  cvpBaseline: 8,
  cannulaFr: 10, // fixed once cannulated — not a trainee-adjustable control
  settings: {
    pumpRpm: 1200,
    sweepGasLpm: 2,
    fdo2Percent: 50,
    epiMcgKgMin: 0.05,
    norepiMcgKgMin: 0,
    bivalirudinMgKgHr: 0.31
  },
  trueLatent: { pao2: 90, paco2: 40, lactateMmolL: 4.2, hgbGdl: 13.1 }
};

function clamp(v, min, max) { return Math.max(min, Math.min(max, v)); }

function approachSteadyState(current, target, elapsedSec, halfLifeSec) {
  const factor = 1 - Math.pow(0.5, elapsedSec / halfLifeSec);
  return current + (target - current) * factor;
}

// The player dials in RPM, not flow. Flow is what actually results — a
// centrifugal pump's real behavior is a pump curve (pressure ~ RPM^2)
// intersected with a resistance line dominated by cannula size. This is
// a simplified stand-in for that: flow rises with RPM but saturates
// toward a cannula-limited ceiling — diminishing returns, same shape as
// the real relationship, without solving the full two-curve system.
function deriveFlow(rpm, cannulaFr, cvp) {
  const maxFlowForCannula = cannulaFr * 0.09; // illustrative — bigger cannula, higher achievable flow ceiling
  const rpmScale = 1300;                       // how quickly flow approaches that ceiling as RPM rises
  const base = maxFlowForCannula * (1 - Math.exp(-rpm / rpmScale));
  const preloadPenalty = cvp < 6 ? (6 - cvp) * 0.05 : 0; // poor venous drainage clips achievable flow further
  const chatter = cvp < 3;
  const flowLpm = Math.max(0, base * (1 - preloadPenalty));
  return { flowLpm, maxFlowForCannula, chatter };
}

function deriveMonitored(settings, internal) {
  const { flowLpm, maxFlowForCannula, chatter } = deriveFlow(settings.pumpRpm, internal.cannulaFr, internal.cvpBaseline);
  const flowIndex = (flowLpm * 1000) / internal.weightKg;
  const hrTarget = internal.hrBaseline + settings.epiMcgKgMin * COEFFS.hrPerMcgKgMinEpi;
  const mapTarget = internal.mapBaseline
    + flowIndex * COEFFS.mapPerMlKgMinFlowIndex
    + settings.epiMcgKgMin * COEFFS.mapPerMcgKgMinEpi
    + settings.norepiMcgKgMin * COEFFS.mapPerMcgKgMinNorepi;
  const spo2 = internal.trueLatent.pao2 >= COEFFS.spo2SaturationKneeMmHg
    ? 100 - Math.max(0, 3 * Math.exp(-(internal.trueLatent.pao2 - COEFFS.spo2SaturationKneeMmHg) / 40))
    : 40 + (internal.trueLatent.pao2 / COEFFS.spo2SaturationKneeMmHg) * 55;
  return {
    hr: Math.round(clamp(internal.hrCurrent ?? hrTarget, 30, 220)),
    map: Math.round(clamp(internal.mapCurrent ?? mapTarget, 20, 160)),
    cvp: Math.round(internal.cvpBaseline),
    spo2: Math.round(clamp(spo2, 40, 100)),
    flowIndex: Math.round(flowIndex),
    flowLpm, maxFlowForCannula, chatter,
    _hrTarget: hrTarget,
    _mapTarget: mapTarget
  };
}

function deriveTrueLatent(settings, internal) {
  const paco2 = clamp(COEFFS.paco2BaselineMmHg - (settings.sweepGasLpm - COEFFS.baselineSweepLpm) * COEFFS.paco2DropPerLpmSweepAboveBaseline, 15, 100);
  const pao2 = clamp(COEFFS.pao2BaselineMmHg + (settings.fdo2Percent - 21) * COEFFS.pao2GainPerFdo2Percent, 30, 550);
  const dtt = clamp(COEFFS.dttBaselineMcgMl + settings.bivalirudinMgKgHr * COEFFS.dttPerMgKgHrBivalirudin, 0, 3);
  return {
    pao2, paco2, dtt,
    ph: clamp(7.4 - (paco2 - 40) * 0.008, 6.9, 7.7),
    lactateMmolL: internal.trueLatent.lactateMmolL,
    hgbGdl: internal.trueLatent.hgbGdl
  };
}

function advanceInternal(internal, settings, elapsedSec) {
  const monitored = deriveMonitored(settings, { ...internal, hrCurrent: undefined, mapCurrent: undefined });
  return {
    ...internal,
    hrCurrent: approachSteadyState(internal.hrCurrent ?? monitored._hrTarget, monitored._hrTarget, elapsedSec, COEFFS.epiEffectRiseHalfLifeSec),
    mapCurrent: approachSteadyState(internal.mapCurrent ?? monitored._mapTarget, monitored._mapTarget, elapsedSec, COEFFS.epiEffectRiseHalfLifeSec),
    trueLatent: deriveTrueLatent(settings, internal)
  };
}

// Circuit mechanics: flow probe reading, pressures at the three points
// clinicians actually watch (venous/pre-pump, pre-oxygenator,
// post-oxygenator/arterial). All ILLUSTRATIVE — magnitudes are in the
// right clinical ballpark but not calibrated against real console data
// the way dTT was. The bubble detector alarm stops the pump: flow and
// all three pressures collapse toward zero, same as a real console's
// safety interlock.
function deriveCircuitMechanics(rpm, flowLpm, bubbleAlarm, timeSec) {
  if (bubbleAlarm) {
    return { rpm: 0, measuredFlowLpm: 0, venousPressure: 0, preOxyPressure: 0, postOxyPressure: 0, deltaP: 0 };
  }
  const wiggle = 0.015 * Math.sin(timeSec * 0.7); // small deterministic jitter, stands in for flow-probe noise
  const measuredFlowLpm = Math.max(0, flowLpm + wiggle);
  const venousPressure = Math.round(-(20 + measuredFlowLpm * 25));
  const preOxyPressure = Math.round(-venousPressure + measuredFlowLpm * 60);
  const deltaP = Math.round(15 + measuredFlowLpm * 10); // normal range; real ΔP climbs over days as the oxygenator fouls — not modeled here yet
  const postOxyPressure = preOxyPressure - deltaP;
  return { rpm, measuredFlowLpm: Math.round(measuredFlowLpm * 100) / 100, venousPressure, preOxyPressure, postOxyPressure, deltaP };
}

// --- Titration protocol (neonate standard risk only, for this demo) ---
const NEONATE_STANDARD_BANDS = [
  { max: 0.3, action: 'increase20-recheck', label: 'Increase dose 20%, recheck dTT in 2h' },
  { min: 0.3, max: 0.4, action: 'increase15', label: 'Increase dose 15%' },
  { min: 0.4, max: 0.5, action: 'increase10', label: 'Increase dose 10%' },
  { min: 0.5, max: 1.0, action: 'no-change', label: 'No change' },
  { min: 1.0, max: 1.2, action: 'decrease10', label: 'Decrease dose 10%' },
  { min: 1.2, max: 1.5, action: 'decrease15', label: 'Decrease dose 15%' },
  { min: 1.5, action: 'decrease-renal-adjusted', label: 'Decrease 20-30% depending on renal function' }
];
const ACTION_LABELS = {
  'increase20-recheck': 'Increase dose 20%, recheck in 2h', 'increase20-second': 'Increase dose another 20%',
  'consult-attending': 'Consult Pedi Surgery attending/fellow', increase15: 'Increase dose 15%', increase10: 'Increase dose 10%',
  'no-change': 'No change', decrease10: 'Decrease dose 10%', decrease15: 'Decrease dose 15%',
  'decrease-renal-adjusted': 'Decrease 20-30% (renal-adjusted)'
};
function findBand(dtt) { return NEONATE_STANDARD_BANDS.find((b) => (b.min === undefined || dtt >= b.min) && (b.max === undefined || dtt < b.max)); }
function isBelowFloor(dtt) { return findBand(dtt).action === 'increase20-recheck'; }
function resolveAction(dtt, attemptNumber) {
  const band = findBand(dtt);
  if (band.action === 'increase20-recheck') {
    if (attemptNumber >= 3) return { action: 'consult-attending', label: ACTION_LABELS['consult-attending'] };
    if (attemptNumber === 2) return { action: 'increase20-second', label: ACTION_LABELS['increase20-second'] };
  }
  return band;
}
function buildCheckpoint(dtt, attemptNumber) {
  const correct = resolveAction(dtt, attemptNumber);
  const pool = Object.keys(ACTION_LABELS).filter((c) => c !== correct.action && c !== 'decrease-renal-adjusted');
  const distractors = [];
  const copy = [...pool];
  while (distractors.length < 3 && copy.length) distractors.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0]);
  const options = [{ id: correct.action, label: correct.label }, ...distractors.map((c) => ({ id: c, label: ACTION_LABELS[c] }))]
    .sort(() => Math.random() - 0.5);
  return { dtt, correctOption: correct.action, options };
}

function fmtMin(sec) { return `${Math.floor(sec / 60)}:${String(Math.floor(sec % 60)).padStart(2, '0')}`; }

// --- Rhythm waveform generators ---------------------------------------
// Each returns an amplitude in roughly [-1, 1] for a given time t (sec).
// Deterministic functions of t (not stored random state) so the canvas
// can redraw from scratch every frame without tracking history.
function gauss(x, center, width, height) { return height * Math.exp(-((x - center) ** 2) / (2 * width * width)); }

function sinusSample(t, hr, includeP) {
  const period = 60 / Math.max(hr, 20);
  const phase = (t % period) / period;
  let v = 0;
  if (includeP) v += gauss(phase, 0.12, 0.025, 0.15);
  v += gauss(phase, 0.28, 0.010, -0.18);  // Q
  v += gauss(phase, 0.30, 0.012, 1.0);    // R
  v += gauss(phase, 0.325, 0.012, -0.35); // S
  v += gauss(phase, 0.55, 0.07, 0.28);    // T
  return v;
}

function vtachSample(t, ratePerMin) {
  const period = 60 / ratePerMin;
  const phase = (t % period) / period;
  return 0.85 * (0.5 - 0.5 * Math.cos(2 * Math.PI * phase)) * (phase < 0.9 ? 1 : (1 - phase) * 10);
}

function vfibSample(t) {
  // Sum of incommensurate sine waves — irregular, no repeating period, but
  // a pure function of t so it redraws identically without stored state.
  return 0.55 * Math.sin(2 * Math.PI * 2.3 * t + 1) +
    0.35 * Math.sin(2 * Math.PI * 3.7 * t + 2.1) +
    0.25 * Math.sin(2 * Math.PI * 5.9 * t + 0.4) +
    0.15 * Math.sin(2 * Math.PI * 9.1 * t + 3.3);
}

function asystoleSample(t) { return 0.015 * Math.sin(2 * Math.PI * 0.6 * t); }

const RHYTHMS = {
  sinus: { label: 'Sinus', sample: (t, hr) => sinusSample(t, hr, true), rate: (hr) => hr },
  junctional: { label: 'Junctional (JET)', sample: (t, hr) => sinusSample(t, hr, false), rate: (hr) => hr },
  vtach: { label: 'V-Tach', sample: (t) => vtachSample(t, 190), rate: () => 190 },
  vfib: { label: 'V-Fib', sample: (t) => vfibSample(t), rate: () => null },
  asystole: { label: 'Asystole', sample: (t) => asystoleSample(t), rate: () => 0 }
};

// ---------------------------------------------------------------------
// UI
// ---------------------------------------------------------------------

const VITAL_COLOR = { hr: '#35d07f', spo2: '#34c3eb', map: '#ff6b6b', cvp: '#f4c95d' };
const CIRCUIT_COLOR = '#b794f6';

function Trace({ hr, rhythm }) {
  const canvasRef = useRef(null);
  const rafRef = useRef(null);
  const startRef = useRef(performance.now());

  useEffect(() => {
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    const width = canvas.width, height = canvas.height, mid = height / 2;
    const sampleFn = RHYTHMS[rhythm]?.sample ?? RHYTHMS.sinus.sample;
    const windowSec = 5; // seconds of trace visible at once

    function draw() {
      const now = (performance.now() - startRef.current) / 1000;
      ctx.fillStyle = '#000';
      ctx.fillRect(0, 0, width, height);
      ctx.strokeStyle = VITAL_COLOR.hr;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let px = 0; px < width; px++) {
        const t = now - windowSec * (1 - px / width);
        const amp = sampleFn(Math.max(t, 0), hr || 100);
        const y = mid - amp * (height * 0.42);
        if (px === 0) ctx.moveTo(px, y); else ctx.lineTo(px, y);
      }
      ctx.stroke();
      rafRef.current = requestAnimationFrame(draw);
    }
    draw();
    return () => cancelAnimationFrame(rafRef.current);
  }, [hr, rhythm]);

  return (
    <canvas ref={canvasRef} width={640} height={70} style={{ width: '100%', height: 56, background: '#000', borderRadius: 4, border: '1px solid #16221f', display: 'block' }} />
  );
}

function VitalReadout({ label, value, unit, color }) {
  return (
    <div style={{ flex: 1, minWidth: 90 }}>
      <div style={{ fontSize: 11, letterSpacing: '0.08em', color: '#6b7c78', fontFamily: 'ui-sans-serif, system-ui' }}>{label}</div>
      <div className="font-mono" style={{ fontSize: 34, fontWeight: 600, color, lineHeight: 1.1 }}>
        {value}<span style={{ fontSize: 14, marginLeft: 4, color: '#5a6b67' }}>{unit}</span>
      </div>
    </div>
  );
}

function Slider({ label, value, min, max, step, unit, onChange, color }) {
  return (
    <div style={{ marginBottom: 14 }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, color: '#c7d2cf', marginBottom: 4 }}>
        <span>{label}</span>
        <span className="font-mono" style={{ color }}>{value}{unit}</span>
      </div>
      <input
        type="range" min={min} max={max} step={step} value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        style={{ width: '100%', accentColor: color }}
      />
    </div>
  );
}

export default function EcmoSandbox() {
  const [state, setState] = useState(() => ({
    timeSec: 0,
    settings: { ...INITIAL_SCENARIO.settings },
    internal: {
      weightKg: INITIAL_SCENARIO.weightKg, hrBaseline: INITIAL_SCENARIO.hrBaseline,
      mapBaseline: INITIAL_SCENARIO.mapBaseline, cvpBaseline: INITIAL_SCENARIO.cvpBaseline,
      cannulaFr: INITIAL_SCENARIO.cannulaFr,
      trueLatent: { ...INITIAL_SCENARIO.trueLatent }
    },
    labs: [],
    log: [],
    dttAttemptStreak: 0,
    checkpoint: null,
    rhythm: 'sinus',
    rhythmAnnouncement: null,
    hypoxiaSeconds: 0,
    noFlowSeconds: 0,
    bubbleDetector: 'clear'
  }));
  const [autoplay, setAutoplay] = useState(false);
  const stateRef = useRef(state);
  stateRef.current = state;

  const RHYTHM_ORDER = ['sinus', 'junctional', 'vtach', 'vfib'];

  const advance = useCallback((elapsedSec) => {
    setState((prev) => {
      const timeSec = prev.timeSec + elapsedSec;
      const internal = advanceInternal(prev.internal, prev.settings, elapsedSec);
      const labs = prev.labs.map((l) => (!l.revealed && timeSec >= l.resultAtSec ? { ...l, revealed: true } : l));
      let checkpoint = prev.checkpoint;
      let dttAttemptStreak = prev.dttAttemptStreak;
      let log = prev.log;
      if (!checkpoint) {
        const freshDtt = labs.find((l) => l.type === 'dtt' && l.revealed && !l.checkpointed);
        if (freshDtt) {
          freshDtt.checkpointed = true;
          const below = isBelowFloor(freshDtt.value);
          const attemptNumber = below ? dttAttemptStreak + 1 : 1;
          checkpoint = buildCheckpoint(freshDtt.value, attemptNumber);
          dttAttemptStreak = below ? attemptNumber : 0;
          log = [...log, { t: timeSec, msg: `dTT resulted at ${freshDtt.value.toFixed(2)} — titration checkpoint opened` }];
        }
      }

      // Rhythm is scenario/physiology-driven, never player-driven. This is
      // a deliberately simple placeholder rule set — two conditions,
      // escalate-only (nothing here auto-reverts a rhythm; that would need
      // a treatment/defib action that doesn't exist yet). Swap in whatever
      // real trigger logic a scenario should use.
      const monitoredNow = deriveMonitored(prev.settings, internal);
      const circuitNow = deriveCircuitMechanics(prev.settings.pumpRpm, monitoredNow.flowLpm, prev.bubbleDetector === 'alarm', timeSec);
      const hypoxiaSeconds = monitoredNow.spo2 < 60 ? prev.hypoxiaSeconds + elapsedSec : 0;
      const noFlowSeconds = circuitNow.measuredFlowLpm < 0.05 ? prev.noFlowSeconds + elapsedSec : 0;

      const currentIndex = RHYTHM_ORDER.indexOf(prev.rhythm);
      let targetIndex = currentIndex;
      let reason = null;
      if (hypoxiaSeconds >= 60 && RHYTHM_ORDER.indexOf('junctional') > targetIndex) { targetIndex = RHYTHM_ORDER.indexOf('junctional'); reason = 'sustained hypoxia'; }
      if (hypoxiaSeconds >= 150 && RHYTHM_ORDER.indexOf('vtach') > targetIndex) { targetIndex = RHYTHM_ORDER.indexOf('vtach'); reason = 'sustained hypoxia'; }
      if (hypoxiaSeconds >= 300 && RHYTHM_ORDER.indexOf('vfib') > targetIndex) { targetIndex = RHYTHM_ORDER.indexOf('vfib'); reason = 'prolonged critical hypoxia'; }
      if (noFlowSeconds >= 20 && RHYTHM_ORDER.indexOf('vtach') > targetIndex) { targetIndex = RHYTHM_ORDER.indexOf('vtach'); reason = 'loss of circuit flow'; }
      if (noFlowSeconds >= 45 && RHYTHM_ORDER.indexOf('vfib') > targetIndex) { targetIndex = RHYTHM_ORDER.indexOf('vfib'); reason = 'loss of circuit flow'; }

      let rhythm = prev.rhythm;
      let rhythmAnnouncement = prev.rhythmAnnouncement;
      if (targetIndex > currentIndex) {
        rhythm = RHYTHM_ORDER[targetIndex];
        rhythmAnnouncement = `${RHYTHMS[rhythm].label} — ${reason}`;
        log = [...log, { t: timeSec, msg: `RHYTHM CHANGE: ${RHYTHMS[rhythm].label} (${reason})` }];
      }

      return { ...prev, timeSec, internal, labs, checkpoint, dttAttemptStreak, log, rhythm, rhythmAnnouncement, hypoxiaSeconds, noFlowSeconds };
    });
  }, []);

  useEffect(() => {
    if (!autoplay) return undefined;
    const id = setInterval(() => advance(15), 400); // 15 sim-seconds per 400ms real time
    return () => clearInterval(id);
  }, [autoplay, advance]);

  function setParam(param, value) {
    setState((prev) => ({ ...prev, settings: { ...prev.settings, [param]: value } }));
  }

  function orderLab(type) {
    setState((prev) => {
      const trueLatent = deriveTrueLatent(prev.settings, prev.internal);
      const valueByType = { abg: trueLatent.pao2, dtt: trueLatent.dtt, hepptt: null, teg: null, atiii: null };
      const record = {
        id: `${type}-${prev.timeSec}-${Math.random().toString(36).slice(2, 6)}`,
        type, orderedAtSec: prev.timeSec, resultAtSec: prev.timeSec + TURNAROUND_SEC[type],
        value: valueByType[type], revealed: false, checkpointed: false
      };
      return { ...prev, labs: [...prev.labs, record], log: [...prev.log, { t: prev.timeSec, msg: `Ordered ${LAB_LABELS[type]} — result in ~${Math.round(TURNAROUND_SEC[type] / 60)} min` }] };
    });
  }

  function answerCheckpoint(optionId) {
    const cp = state.checkpoint;
    if (!cp || cp.answeredWith) return;
    const correct = optionId === cp.correctOption;
    setState((prev) => ({ ...prev, checkpoint: { ...prev.checkpoint, answeredWith: optionId, correct } }));
  }

  function dismissCheckpoint() {
    setState((prev) => ({ ...prev, checkpoint: null, log: [...prev.log, { t: prev.timeSec, msg: prev.checkpoint.correct ? 'Titration checkpoint: correct' : 'Titration checkpoint: incorrect' }] }));
  }

  const monitored = deriveMonitored(state.settings, state.internal);
  const pendingLabs = state.labs.filter((l) => !l.revealed);
  const resultedLabs = state.labs.filter((l) => l.revealed).slice(-5).reverse();
  const displayedRate = RHYTHMS[state.rhythm].rate(monitored.hr);
  const hrDisplay = displayedRate === null ? '—' : displayedRate;


  function triggerBubbleAlarm() {
    setState((prev) => ({ ...prev, bubbleDetector: 'alarm', log: [...prev.log, { t: prev.timeSec, msg: 'BUBBLE DETECTOR: air detected — pump stopped' }] }));
  }

  function clearBubbleAlarm() {
    setState((prev) => ({ ...prev, bubbleDetector: 'clear', log: [...prev.log, { t: prev.timeSec, msg: 'Bubble detector cleared — pump resumed' }] }));
  }

  const circuit = deriveCircuitMechanics(state.settings.pumpRpm, monitored.flowLpm, state.bubbleDetector === 'alarm', state.timeSec);

  return (
    <div style={{ background: '#05080a', minHeight: '100vh', color: '#e6efec', fontFamily: 'ui-sans-serif, system-ui', padding: 20 }}>
      <style>{`@keyframes pulseAlarm { 0%, 100% { opacity: 1; } 50% { opacity: 0.55; } }`}</style>
      <div style={{ maxWidth: 880, margin: '0 auto' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', marginBottom: 14 }}>
          <div>
            <div style={{ fontSize: 11, letterSpacing: '0.12em', color: '#6b7c78' }}>ECMO CIRCUIT SANDBOX — DEMO</div>
            <div style={{ fontSize: 18, fontWeight: 600 }}>VA ECMO, post-Sano, day 1 — 4kg neonate</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Clock size={16} color="#6b7c78" />
            <span className="font-mono" style={{ fontSize: 16 }}>{fmtMin(state.timeSec)}</span>
          </div>
        </div>

        {/* Monitor panel */}
        <div style={{ background: '#0d1417', border: '1px solid #16221f', borderRadius: 10, padding: 16, marginBottom: 16 }}>
          <Trace hr={monitored.hr} rhythm={state.rhythm} />
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginTop: 10 }}>
            <span style={{ fontSize: 11, letterSpacing: '0.08em', color: '#6b7c78' }}>RHYTHM</span>
            <span style={{ fontSize: 12, color: VITAL_COLOR.hr, fontWeight: 600 }}>{RHYTHMS[state.rhythm].label.toUpperCase()}</span>
          </div>
          {state.rhythmAnnouncement && (
            <div style={{ marginTop: 8, background: '#1a1408', border: '1px solid #4a3416', borderRadius: 6, padding: '6px 10px', fontSize: 12, color: '#f0a742', display: 'flex', justifyContent: 'space-between', alignItems: 'center', animation: 'pulseAlarm 1.4s ease-in-out infinite' }}>
              <span><AlertTriangle size={12} style={{ marginRight: 6, verticalAlign: -2 }} />RHYTHM CHANGE: {state.rhythmAnnouncement}</span>
              <button onClick={() => setState((prev) => ({ ...prev, rhythmAnnouncement: null }))} style={{ background: 'none', border: 'none', color: '#f0a742', cursor: 'pointer' }}><X size={13} /></button>
            </div>
          )}
          <div style={{ display: 'flex', gap: 20, marginTop: 14, flexWrap: 'wrap' }}>
            <VitalReadout label="HR" value={hrDisplay} unit="bpm" color={VITAL_COLOR.hr} />
            <VitalReadout label="MAP" value={monitored.map} unit="mmHg" color={VITAL_COLOR.map} />
            <VitalReadout label="SpO2" value={monitored.spo2} unit="%" color={VITAL_COLOR.spo2} />
            <VitalReadout label="CVP" value={monitored.cvp} unit="mmHg" color={VITAL_COLOR.cvp} />
          </div>
        </div>

        {/* Circuit mechanics panel */}
        <div style={{ background: '#0d1417', border: `1px solid ${monitored.chatter ? '#5a3a1c' : '#16221f'}`, borderRadius: 10, padding: 16, marginBottom: 16 }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={{ fontSize: 12, letterSpacing: '0.08em', color: CIRCUIT_COLOR, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Activity size={14} /> CIRCUIT MECHANICS
            </div>
            {state.bubbleDetector === 'alarm' ? (
              <button onClick={clearBubbleAlarm} style={{ background: '#3a1010', color: '#ff8080', border: '1px solid #6b2020', borderRadius: 6, padding: '5px 10px', fontSize: 11, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6, animation: 'pulseAlarm 1s ease-in-out infinite' }}>
                <AlertTriangle size={13} /> AIR DETECTED — pump stopped · tap to clear
              </button>
            ) : (
              <button onClick={triggerBubbleAlarm} style={{ background: '#12181a', color: '#4c5a56', border: '1px solid #1c2b28', borderRadius: 6, padding: '5px 10px', fontSize: 11, cursor: 'pointer' }}>
                Bubble detector: clear · simulate air-in-line
              </button>
            )}
          </div>
          {monitored.chatter && state.bubbleDetector !== 'alarm' && (
            <div style={{ fontSize: 11, color: '#e0a458', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
              <AlertTriangle size={12} /> Low CVP — venous line chattering, flow trailing what this RPM should deliver
            </div>
          )}
          <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap' }}>
            <VitalReadout label="PUMP SPEED (SET)" value={state.settings.pumpRpm} unit=" rpm" color={CIRCUIT_COLOR} />
            <VitalReadout label="MEASURED FLOW" value={circuit.measuredFlowLpm.toFixed(2)} unit=" L/min" color={CIRCUIT_COLOR} />
            <VitalReadout label="FLOW INDEX" value={monitored.flowIndex} unit=" mL/kg/min" color={CIRCUIT_COLOR} />
            <VitalReadout label={`CEILING (${state.internal.cannulaFr} Fr)`} value={monitored.maxFlowForCannula.toFixed(2)} unit=" L/min" color="#6b7c78" />
          </div>
          <div style={{ display: 'flex', gap: 20, flexWrap: 'wrap', marginTop: 14, paddingTop: 14, borderTop: '1px solid #16221f' }}>
            <VitalReadout label="VENOUS (PRE-PUMP)" value={circuit.venousPressure} unit=" mmHg" color="#8a9fd6" />
            <VitalReadout label="PRE-OXYGENATOR" value={circuit.preOxyPressure} unit=" mmHg" color="#8a9fd6" />
            <VitalReadout label="POST-OXYGENATOR" value={circuit.postOxyPressure} unit=" mmHg" color="#8a9fd6" />
            <VitalReadout label="ΔP (OXYGENATOR)" value={circuit.deltaP} unit=" mmHg" color="#8a9fd6" />
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
          {/* Controls */}
          <div style={{ background: '#0d1417', border: '1px solid #16221f', borderRadius: 10, padding: 16 }}>
            <div style={{ fontSize: 12, letterSpacing: '0.08em', color: '#b794f6', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
              <Activity size={14} /> CIRCUIT & DRIPS
            </div>
            <Slider label="Pump speed" value={state.settings.pumpRpm} min={0} max={4000} step={50} unit=" rpm" color={CIRCUIT_COLOR} onChange={(v) => setParam('pumpRpm', v)} />
            <Slider label="Sweep gas" value={state.settings.sweepGasLpm} min={0} max={8} step={0.5} unit=" L/min" color={CIRCUIT_COLOR} onChange={(v) => setParam('sweepGasLpm', v)} />
            <Slider label="FdO2" value={state.settings.fdo2Percent} min={21} max={100} step={1} unit="%" color={CIRCUIT_COLOR} onChange={(v) => setParam('fdo2Percent', v)} />
            <Slider label="Epinephrine" value={state.settings.epiMcgKgMin} min={0} max={0.3} step={0.01} unit=" mcg/kg/min" color={VITAL_COLOR.hr} onChange={(v) => setParam('epiMcgKgMin', v)} />
            <Slider label="Norepinephrine" value={state.settings.norepiMcgKgMin} min={0} max={0.3} step={0.01} unit=" mcg/kg/min" color={VITAL_COLOR.map} onChange={(v) => setParam('norepiMcgKgMin', v)} />
            <Slider label="Bivalirudin" value={state.settings.bivalirudinMgKgHr} min={0} max={1} step={0.01} unit=" mg/kg/hr" color="#f4c95d" onChange={(v) => setParam('bivalirudinMgKgHr', v)} />
          </div>

          {/* Labs */}
          <div style={{ background: '#0d1417', border: '1px solid #16221f', borderRadius: 10, padding: 16 }}>
            <div style={{ fontSize: 12, letterSpacing: '0.08em', color: '#8fa39d', marginBottom: 10, display: 'flex', alignItems: 'center', gap: 6 }}>
              <FlaskConical size={14} /> LABS (order, then wait)
            </div>
            <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 12 }}>
              {Object.keys(LAB_LABELS).map((type) => (
                <button key={type} onClick={() => orderLab(type)}
                  style={{ background: '#16221f', color: '#c7d2cf', border: '1px solid #223330', borderRadius: 6, padding: '6px 10px', fontSize: 12, cursor: 'pointer' }}>
                  {LAB_LABELS[type]}
                </button>
              ))}
            </div>
            {pendingLabs.length > 0 && (
              <div style={{ marginBottom: 10 }}>
                {pendingLabs.map((l) => (
                  <div key={l.id} style={{ fontSize: 12, color: '#8fa39d', display: 'flex', justifyContent: 'space-between', padding: '3px 0' }}>
                    <span>{LAB_LABELS[l.type]} — pending</span>
                    <span className="font-mono">{fmtMin(Math.max(0, l.resultAtSec - state.timeSec))}</span>
                  </div>
                ))}
              </div>
            )}
            {resultedLabs.length > 0 && (
              <div>
                {resultedLabs.map((l) => (
                  <div key={l.id} style={{ fontSize: 12, color: '#e6efec', display: 'flex', justifyContent: 'space-between', padding: '3px 0', borderTop: '1px solid #16221f' }}>
                    <span>{LAB_LABELS[l.type]}</span>
                    <span className="font-mono">{l.value != null ? l.value.toFixed(2) : '—'}</span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Time controls */}
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginTop: 16 }}>
          <button onClick={() => advance(60)} style={{ background: '#16221f', color: '#c7d2cf', border: '1px solid #223330', borderRadius: 6, padding: '8px 14px', fontSize: 13, cursor: 'pointer' }}>+1 min</button>
          <button onClick={() => advance(5 * 60)} style={{ background: '#16221f', color: '#c7d2cf', border: '1px solid #223330', borderRadius: 6, padding: '8px 14px', fontSize: 13, cursor: 'pointer' }}>+5 min</button>
          <button onClick={() => advance(15 * 60)} style={{ background: '#16221f', color: '#c7d2cf', border: '1px solid #223330', borderRadius: 6, padding: '8px 14px', fontSize: 13, cursor: 'pointer' }}>+15 min</button>
          <button onClick={() => setAutoplay((a) => !a)} style={{ marginLeft: 'auto', background: autoplay ? '#1c3d2e' : '#16221f', color: autoplay ? '#7be8a6' : '#c7d2cf', border: '1px solid #223330', borderRadius: 6, padding: '8px 14px', fontSize: 13, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 6 }}>
            {autoplay ? <Pause size={14} /> : <Play size={14} />} {autoplay ? 'Pause' : 'Auto-advance'}
          </button>
        </div>

        {/* Log */}
        <div style={{ marginTop: 16, background: '#0a0f0e', border: '1px solid #16221f', borderRadius: 10, padding: '10px 16px', maxHeight: 130, overflowY: 'auto' }}>
          {state.log.length === 0 && <div style={{ color: '#4c5a56', fontSize: 12 }}>No events yet.</div>}
          {[...state.log].reverse().map((entry, i) => (
            <div key={i} style={{ fontSize: 12, color: '#8fa39d', padding: '2px 0' }}>
              <span className="font-mono" style={{ color: '#4c5a56' }}>{fmtMin(entry.t)}</span> · {entry.msg}
            </div>
          ))}
        </div>

        {/* Checkpoint */}
        {state.checkpoint && (
          <div style={{ position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.6)', display: 'flex', alignItems: 'center', justifyContent: 'center', padding: 20 }}>
            <div style={{ background: '#171008', border: '1px solid #4a3416', borderRadius: 12, padding: 22, maxWidth: 420, width: '100%' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 8, color: '#f0a742', fontSize: 12, letterSpacing: '0.08em', marginBottom: 10 }}>
                <AlertTriangle size={16} /> ANTICOAGULATION TITRATION
              </div>
              <div style={{ fontSize: 16, marginBottom: 4 }}>dTT resulted at {state.checkpoint.dtt.toFixed(2)} mcg/mL</div>
              <div style={{ fontSize: 13, color: '#a89076', marginBottom: 16 }}>Per protocol, what's the correct next step?</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
                {state.checkpoint.options.map((opt) => {
                  const answered = state.checkpoint.answeredWith;
                  const isThis = answered === opt.id;
                  const isCorrectAnswer = opt.id === state.checkpoint.correctOption;
                  let bg = '#221806', border = '#4a3416', color = '#e6efec';
                  if (answered) {
                    if (isCorrectAnswer) { bg = '#0f2318'; border = '#2f6b45'; color = '#7be8a6'; }
                    else if (isThis) { bg = '#2b0f0f'; border = '#6b2f2f'; color = '#e88f8f'; }
                  }
                  return (
                    <button key={opt.id} disabled={!!answered} onClick={() => answerCheckpoint(opt.id)}
                      style={{ textAlign: 'left', background: bg, border: `1px solid ${border}`, color, borderRadius: 8, padding: '10px 12px', fontSize: 13, cursor: answered ? 'default' : 'pointer', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                      {opt.label}
                      {answered && isCorrectAnswer && <Check size={15} />}
                      {answered && isThis && !isCorrectAnswer && <X size={15} />}
                    </button>
                  );
                })}
              </div>
              {state.checkpoint.answeredWith && (
                <button onClick={dismissCheckpoint} style={{ marginTop: 16, width: '100%', background: '#2a2015', color: '#e6efec', border: '1px solid #4a3416', borderRadius: 8, padding: '10px', fontSize: 13, cursor: 'pointer' }}>
                  Continue
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
