# B2 EXACT COMPARISON CLOSURE
Date: 2026-07-22

Actual registry primitives reviewed: 3/3
- drainage cannula/tubing kink
- mechanical circuit obstruction
- pump failure/loss of support

Key modeling result:
Scenario-level causes such as preload loss/hypovolemia and cannula malposition reuse these primitives and are not duplicated as separate complication objects.

No universal numeric drainage-pressure, RPM, resistance, or deterioration-time threshold was invented.
The pump-failure 60-second progression remains a preclinical placeholder pending expert review/source-specific justification.

All B2 rules remain pending expert clinical sign-off.

Next: B3 — VV Respiratory Support.
