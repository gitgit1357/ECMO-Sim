# B5 EXACT COMPARISON CLOSURE
Date: 2026-07-22

B5 primitives reviewed: 5/5.
- major bleeding — exact anticoagulation-guideline comparison complete
- intracranial hemorrhage — exact 2024 neurologic + anticoagulation cross-guideline comparison complete
- anticoagulation management — exact source comparison complete
- pulmonary hemorrhage — partial source comparison; pulmonary-specific specialty corroboration still required
- circuit breach/hemorrhage — shared B1 primitive reused with B5 anticoagulation context

Evidence-supported refinements:
- active bleeding management explicitly balances source control, perfusion, anticoagulation interruption/reduction, and circuit thrombosis surveillance;
- anticoagulation interpretation is multi-test/contextual rather than based on one isolated number;
- acute ICH explicitly requires urgent neurologic escalation/non-contrast CT, anticoagulation cessation/reassessment, repeated neuroimaging, and mode-specific thrombosis-risk balancing;
- prolonged >2-day anticoagulation cessation is stored only as a VV-ICH source recommendation, not generalized to VA;
- no universal anticoagulation-reversal rule was invented because the 2024 neurologic guideline provides no general recommendation.

All deterioration timers remain preclinical placeholders unless separately source-supported.

Next: B6 — Patient Emergencies.
