# B4 VALIDATION STATUS — VA / CARDIAC SUPPORT
Date: 2026-07-22

- 3 VA/cardiac registry primitives crosswalked. Pulmonary edema is represented as a consequence/presentation of VA/LV loading physiology rather than a duplicate standalone complication primitive.
- Institution-first / ELSO adult VA default governance applied.
- Current timings and action classifications inventoried.
- Secondary general/circuit applicability retained where relevant.
- No unsupported numeric or sequence claims promoted.
- Regression: 294 / 294 passing.

Next: B5 — bleeding, neurologic, and anticoagulation.
