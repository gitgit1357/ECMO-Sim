# M6 — PATIENT EMERGENCIES — LOCKED PLAN
Date: 2026-07-22
Status: ACTIVE

## Locked V1 families
1. PE-01 Arrhythmia / cardiac arrest on ECMO — PROVING CASE
2. PE-02 Intracranial hemorrhage / acute neurologic emergency
3. PE-03 Vasoplegia / sepsis / distributive shock
4. PE-04 AKI / fluid overload
5. PE-05 Metabolic / electrolyte emergency
6. PE-06 Pulmonary hypertensive / RV crisis

## Definition of Done
- Each family uses the generic clinical-event/runtime architecture.
- Learner receives diagnosis-neutral handoff, recent events, and objectives.
- Discriminating patient-side evidence is available.
- Cause-directed interventions produce coherent consequences.
- Arrhythmia/arrest integrates rhythm recognition and rescue behavior without false stabilization in malignant rhythms.
- Universal completion/debrief lifecycle works.
- All six pass automated and standalone acceptance.
- No open DEFECT/BLOCKER.

## Guardrail
No advanced ACLS/PALS protocol authoring, medication library expansion, institution-specific algorithms, or UI polish beyond what is required to make the six locked families function. Those remain post-V1 unless they block a planned case.
