# CLINICAL VALIDATION REVIEW PACKET — TIMING & THRESHOLD INVENTORY
Date: 2026-07-22

## Purpose
This packet inventories simulation timing policies that remain placeholders or require expert review. It does not assert clinical validity.

## Review rule
For each case, reviewers should confirm: onset plausibility, deterioration timing, threshold direction/magnitude, action classification, rescue window, endpoint criteria, and population/mode applicability.

## Timing inventory
### Air entrainment / circuit air emergency
- ID: `air-emergency`
- Timing status: **placeholder-until-validated**
- `active` → `critical` after **90 sec**

### Circuit breach / disconnection with major blood loss
- ID: `circuit-breach-hemorrhage`
- Timing status: **placeholder-until-validated**
- `active` → `critical` after **60 sec**

### Oxygenator thrombosis / membrane-lung failure
- ID: `oxygenator-thrombosis-failure`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **150 sec**

### Sweep gas / gas-source failure
- ID: `sweep-gas-failure`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **150 sec**
- `worsened` → `critical` after **90 sec**

### Clinically significant hemolysis
- ID: `hemolysis`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### Major bleeding / coagulopathic hemorrhage
- ID: `major-bleeding`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.

### Intracranial hemorrhage
- ID: `intracranial-hemorrhage`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **240 sec**
- `worsened` → `critical` after **90 sec**

### Thromboembolism / ischemic stroke
- ID: `thromboembolism-stroke`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### Circuit / cannula / intracardiac thrombosis
- ID: `circuit-systemic-thrombosis`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **210 sec**
- `worsened` → `critical` after **90 sec**

### Clinically significant anticoagulation imbalance
- ID: `anticoagulation-management`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **150 sec**

### VV ECMO recirculation / ineffective support
- ID: `vv-recirculation`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **240 sec**
- `worsened` → `critical` after **120 sec**

### VA differential hypoxemia / North-South syndrome
- ID: `va-differential-hypoxemia`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **240 sec**
- `worsened` → `critical` after **90 sec**

### VA ECMO LV distension / inadequate unloading
- ID: `va-lv-distension`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **180 sec**
- `worsened` → `critical` after **90 sec**

### Peripheral cannulation limb ischemia
- ID: `limb-ischemia`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### Pneumothorax / tension physiology impairing support
- ID: `pneumothorax-intrathoracic-pressure`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.

### Airway / ETT / ventilator failure
- ID: `airway-ventilator-failure`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **150 sec**
- `worsened` → `critical` after **90 sec**

### Pulmonary hemorrhage
- ID: `pulmonary-hemorrhage`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **150 sec**
- `worsened` → `critical` after **90 sec**

### Clinically significant gas-exchange failure
- ID: `gas-exchange-failure`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **210 sec**
- `worsened` → `critical` after **120 sec**

### Clinically significant arrhythmia / arrest
- ID: `arrhythmia-arrest`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **90 sec**
- `worsened` → `critical` after **60 sec**

### Vasoplegia / distributive shock
- ID: `vasoplegia-shock`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.

### Infection / sepsis with clinically significant deterioration
- ID: `infection-sepsis`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.

### Acute kidney injury / fluid overload
- ID: `aki-fluid-overload`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### CKRT / CRRT failure or ECMO interaction
- ID: `ckrt-ecmo-interaction`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### Major metabolic / electrolyte emergency
- ID: `metabolic-electrolyte-emergency`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **120 sec**
- `worsened` → `critical` after **60 sec**

### Acute neurologic deterioration / seizure
- ID: `neurologic-deterioration`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **300 sec**
- `worsened` → `critical` after **180 sec**

### Abdominal compartment / bowel ischemia / abdominal perfusion emergency
- ID: `abdominal-ischemic-compartment`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.

### Pulmonary hypertensive / RV crisis
- ID: `pulmonary-hypertensive-crisis`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **150 sec**
- `worsened` → `critical` after **90 sec**

### Congenital circulation / shunt / residual lesion failure
- ID: `congenital-circulation-specific`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **150 sec**
- `worsened` → `critical` after **90 sec**

### Clinically significant medication / transfusion adverse event
- ID: `treatment-transfusion-adverse`
- Timing status: **placeholder-until-validated**
- `active` → `worsened` after **120 sec**
- `worsened` → `critical` after **90 sec**

### Transport / positioning / operational support hazard
- ID: `transport-procedural-operational`
- Timing status: **placeholder-until-validated**
- No explicit time-rule transition in registry.
